var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/.pnpm/bare-events@2.5.0/node_modules/bare-events/lib/errors.js
var require_errors = __commonJS({
  "node_modules/.pnpm/bare-events@2.5.0/node_modules/bare-events/lib/errors.js"(exports, module) {
    module.exports = class EventEmitterError extends Error {
      constructor(msg, code, fn = EventEmitterError, opts) {
        super(`${code}: ${msg}`, opts);
        this.code = code;
        if (Error.captureStackTrace) {
          Error.captureStackTrace(this, fn);
        }
      }
      get name() {
        return "EventEmitterError";
      }
      static OPERATION_ABORTED(cause, msg = "Operation aborted") {
        return new EventEmitterError(msg, "OPERATION_ABORTED", EventEmitterError.OPERATION_ABORTED, { cause });
      }
      static UNHANDLED_ERROR(cause, msg = "Unhandled error") {
        return new EventEmitterError(msg, "UNHANDLED_ERROR", EventEmitterError.UNHANDLED_ERROR, { cause });
      }
    };
  }
});

// node_modules/.pnpm/bare-events@2.5.0/node_modules/bare-events/index.js
var require_bare_events = __commonJS({
  "node_modules/.pnpm/bare-events@2.5.0/node_modules/bare-events/index.js"(exports, module) {
    var errors = require_errors();
    var EventListener = class {
      constructor() {
        this.list = [];
        this.count = 0;
      }
      append(ctx, name, fn, once) {
        this.count++;
        ctx.emit("newListener", name, fn);
        this.list.push([fn, once]);
      }
      prepend(ctx, name, fn, once) {
        this.count++;
        ctx.emit("newListener", name, fn);
        this.list.unshift([fn, once]);
      }
      remove(ctx, name, fn) {
        for (let i = 0, n = this.list.length; i < n; i++) {
          const l = this.list[i];
          if (l[0] === fn) {
            this.list.splice(i, 1);
            if (this.count === 1) delete ctx._events[name];
            ctx.emit("removeListener", name, fn);
            this.count--;
            return;
          }
        }
      }
      removeAll(ctx, name) {
        const list = [...this.list];
        this.list = [];
        if (this.count === list.length) delete ctx._events[name];
        for (let i = list.length - 1; i >= 0; i--) {
          ctx.emit("removeListener", name, list[i][0]);
        }
        this.count -= list.length;
      }
      emit(ctx, name, ...args) {
        const list = [...this.list];
        for (let i = 0, n = list.length; i < n; i++) {
          const l = list[i];
          if (l[1] === true) this.remove(ctx, name, l[0]);
          l[0].call(ctx, ...args);
        }
        return list.length > 0;
      }
    };
    function appendListener(ctx, name, fn, once) {
      const e = ctx._events[name] || (ctx._events[name] = new EventListener());
      e.append(ctx, name, fn, once);
      return ctx;
    }
    function prependListener(ctx, name, fn, once) {
      const e = ctx._events[name] || (ctx._events[name] = new EventListener());
      e.prepend(ctx, name, fn, once);
      return ctx;
    }
    function removeListener(ctx, name, fn) {
      const e = ctx._events[name];
      if (e !== void 0) e.remove(ctx, name, fn);
      return ctx;
    }
    function throwUnhandledError(...args) {
      let err;
      if (args.length > 0) err = args[0];
      if (err instanceof Error === false) err = errors.UNHANDLED_ERROR(err);
      if (Error.captureStackTrace) {
        Error.captureStackTrace(err, exports.prototype.emit);
      }
      queueMicrotask(() => {
        throw err;
      });
    }
    module.exports = exports = class EventEmitter {
      constructor() {
        this._events = /* @__PURE__ */ Object.create(null);
      }
      addListener(name, fn) {
        return appendListener(this, name, fn, false);
      }
      addOnceListener(name, fn) {
        return appendListener(this, name, fn, true);
      }
      prependListener(name, fn) {
        return prependListener(this, name, fn, false);
      }
      prependOnceListener(name, fn) {
        return prependListener(this, name, fn, true);
      }
      removeListener(name, fn) {
        return removeListener(this, name, fn);
      }
      on(name, fn) {
        return appendListener(this, name, fn, false);
      }
      once(name, fn) {
        return appendListener(this, name, fn, true);
      }
      off(name, fn) {
        return removeListener(this, name, fn);
      }
      emit(name, ...args) {
        if (name === "error" && this._events.error === void 0) throwUnhandledError(...args);
        const e = this._events[name];
        return e === void 0 ? false : e.emit(this, name, ...args);
      }
      listeners(name) {
        const e = this._events[name];
        return e === void 0 ? [] : [...e.list];
      }
      listenerCount(name) {
        const e = this._events[name];
        return e === void 0 ? 0 : e.list.length;
      }
      getMaxListeners() {
        return EventEmitter.defaultMaxListeners;
      }
      setMaxListeners(n) {
      }
      removeAllListeners(name) {
        if (arguments.length === 0) {
          for (const key of Reflect.ownKeys(this._events)) {
            if (key === "removeListener") continue;
            this.removeAllListeners(key);
          }
          this.removeAllListeners("removeListener");
        } else {
          const e = this._events[name];
          if (e !== void 0) e.removeAll(this, name);
        }
        return this;
      }
    };
    exports.EventEmitter = exports;
    exports.errors = errors;
    exports.defaultMaxListeners = 10;
    exports.on = function on(emitter, name, opts = {}) {
      const {
        signal
      } = opts;
      if (signal && signal.aborted) {
        throw errors.OPERATION_ABORTED(signal.reason);
      }
      let error = null;
      let done = false;
      const events = [];
      const promises = [];
      emitter.on(name, onevent);
      if (name !== "error") emitter.on("error", onerror);
      if (signal) signal.addEventListener("abort", onabort);
      return {
        next() {
          if (events.length) {
            return Promise.resolve({ value: events.shift(), done: false });
          }
          if (error) {
            const err = error;
            error = null;
            return Promise.reject(err);
          }
          if (done) return onclose();
          return new Promise(
            (resolve, reject) => promises.push({ resolve, reject })
          );
        },
        return() {
          return onclose();
        },
        throw(err) {
          return onerror(err);
        },
        [Symbol.asyncIterator]() {
          return this;
        }
      };
      function onevent(...args) {
        if (promises.length) {
          promises.shift().resolve({ value: args, done: false });
        } else {
          events.push(args);
        }
      }
      function onerror(err) {
        if (promises.length) {
          promises.shift().reject(err);
        } else {
          error = err;
        }
        return Promise.resolve({ done: true });
      }
      function onabort() {
        onerror(errors.OPERATION_ABORTED(signal.reason));
      }
      function onclose() {
        emitter.off(name, onevent);
        if (name !== "error") emitter.off("error", onerror);
        if (signal) signal.removeEventListener("abort", onabort);
        done = true;
        if (promises.length) promises.shift().resolve({ done: true });
        return Promise.resolve({ done: true });
      }
    };
    exports.once = function once(emitter, name, opts = {}) {
      const {
        signal
      } = opts;
      if (signal && signal.aborted) {
        throw errors.OPERATION_ABORTED(signal.reason);
      }
      return new Promise((resolve, reject) => {
        if (name !== "error") emitter.on("error", onerror);
        if (signal) signal.addEventListener("abort", onabort);
        emitter.once(name, (...args) => {
          if (name !== "error") emitter.off("error", onerror);
          if (signal) signal.removeEventListener("abort", onabort);
          resolve(args);
        });
        function onerror(err) {
          emitter.off("error", onerror);
          reject(err);
        }
        function onabort() {
          signal.removeEventListener("abort", onabort);
          onerror(errors.OPERATION_ABORTED(signal.reason));
        }
      });
    };
    exports.forward = function forward(from, to, names, opts = {}) {
      if (typeof names === "string") names = [names];
      const {
        emit = to.emit.bind(to)
      } = opts;
      const listeners = names.map((name) => function onevent(...args) {
        emit(name, ...args);
      });
      to.on("newListener", (name) => {
        const i = names.indexOf(name);
        if (i !== -1 && to.listenerCount(name) === 0) {
          from.on(name, listeners[i]);
        }
      }).on("removeListener", (name) => {
        const i = names.indexOf(name);
        if (i !== -1 && to.listenerCount(name) === 0) {
          from.off(name, listeners[i]);
        }
      });
    };
    exports.listenerCount = function listenerCount(emitter, name) {
      return emitter.listenerCount(name);
    };
  }
});

// node_modules/.pnpm/queue-tick@1.0.1/node_modules/queue-tick/queue-microtask.js
var require_queue_microtask = __commonJS({
  "node_modules/.pnpm/queue-tick@1.0.1/node_modules/queue-tick/queue-microtask.js"(exports, module) {
    module.exports = typeof queueMicrotask === "function" ? queueMicrotask : (fn) => Promise.resolve().then(fn);
  }
});

// node_modules/.pnpm/fast-fifo@1.3.2/node_modules/fast-fifo/fixed-size.js
var require_fixed_size = __commonJS({
  "node_modules/.pnpm/fast-fifo@1.3.2/node_modules/fast-fifo/fixed-size.js"(exports, module) {
    module.exports = class FixedFIFO {
      constructor(hwm) {
        if (!(hwm > 0) || (hwm - 1 & hwm) !== 0) throw new Error("Max size for a FixedFIFO should be a power of two");
        this.buffer = new Array(hwm);
        this.mask = hwm - 1;
        this.top = 0;
        this.btm = 0;
        this.next = null;
      }
      clear() {
        this.top = this.btm = 0;
        this.next = null;
        this.buffer.fill(void 0);
      }
      push(data) {
        if (this.buffer[this.top] !== void 0) return false;
        this.buffer[this.top] = data;
        this.top = this.top + 1 & this.mask;
        return true;
      }
      shift() {
        const last = this.buffer[this.btm];
        if (last === void 0) return void 0;
        this.buffer[this.btm] = void 0;
        this.btm = this.btm + 1 & this.mask;
        return last;
      }
      peek() {
        return this.buffer[this.btm];
      }
      isEmpty() {
        return this.buffer[this.btm] === void 0;
      }
    };
  }
});

// node_modules/.pnpm/fast-fifo@1.3.2/node_modules/fast-fifo/index.js
var require_fast_fifo = __commonJS({
  "node_modules/.pnpm/fast-fifo@1.3.2/node_modules/fast-fifo/index.js"(exports, module) {
    var FixedFIFO = require_fixed_size();
    module.exports = class FastFIFO {
      constructor(hwm) {
        this.hwm = hwm || 16;
        this.head = new FixedFIFO(this.hwm);
        this.tail = this.head;
        this.length = 0;
      }
      clear() {
        this.head = this.tail;
        this.head.clear();
        this.length = 0;
      }
      push(val) {
        this.length++;
        if (!this.head.push(val)) {
          const prev = this.head;
          this.head = prev.next = new FixedFIFO(2 * this.head.buffer.length);
          this.head.push(val);
        }
      }
      shift() {
        if (this.length !== 0) this.length--;
        const val = this.tail.shift();
        if (val === void 0 && this.tail.next) {
          const next = this.tail.next;
          this.tail.next = null;
          this.tail = next;
          return this.tail.shift();
        }
        return val;
      }
      peek() {
        const val = this.tail.peek();
        if (val === void 0 && this.tail.next) return this.tail.next.peek();
        return val;
      }
      isEmpty() {
        return this.length === 0;
      }
    };
  }
});

// node_modules/.pnpm/text-decoder@1.2.3/node_modules/text-decoder/lib/browser-decoder.js
var require_browser_decoder = __commonJS({
  "node_modules/.pnpm/text-decoder@1.2.3/node_modules/text-decoder/lib/browser-decoder.js"(exports, module) {
    module.exports = class BrowserDecoder {
      constructor(encoding) {
        this.decoder = new TextDecoder(encoding === "utf16le" ? "utf16-le" : encoding);
      }
      get remaining() {
        return -1;
      }
      decode(data) {
        return this.decoder.decode(data, { stream: true });
      }
      flush() {
        return this.decoder.decode(new Uint8Array(0));
      }
    };
  }
});

// node_modules/.pnpm/text-decoder@1.2.3/node_modules/text-decoder/index.js
var require_text_decoder = __commonJS({
  "node_modules/.pnpm/text-decoder@1.2.3/node_modules/text-decoder/index.js"(exports, module) {
    var PassThroughDecoder = require_browser_decoder();
    var UTF8Decoder = require_browser_decoder();
    module.exports = class TextDecoder {
      constructor(encoding = "utf8") {
        this.encoding = normalizeEncoding(encoding);
        switch (this.encoding) {
          case "utf8":
            this.decoder = new UTF8Decoder();
            break;
          case "utf16le":
          case "base64":
            throw new Error("Unsupported encoding: " + this.encoding);
          default:
            this.decoder = new PassThroughDecoder(this.encoding);
        }
      }
      get remaining() {
        return this.decoder.remaining;
      }
      push(data) {
        if (typeof data === "string") return data;
        return this.decoder.decode(data);
      }
      // For Node.js compatibility
      write(data) {
        return this.push(data);
      }
      end(data) {
        let result = "";
        if (data) result = this.push(data);
        result += this.decoder.flush();
        return result;
      }
    };
    function normalizeEncoding(encoding) {
      encoding = encoding.toLowerCase();
      switch (encoding) {
        case "utf8":
        case "utf-8":
          return "utf8";
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return "utf16le";
        case "latin1":
        case "binary":
          return "latin1";
        case "base64":
        case "ascii":
        case "hex":
          return encoding;
        default:
          throw new Error("Unknown encoding: " + encoding);
      }
    }
  }
});

// node_modules/.pnpm/streamx@2.21.1/node_modules/streamx/index.js
var require_streamx = __commonJS({
  "node_modules/.pnpm/streamx@2.21.1/node_modules/streamx/index.js"(exports, module) {
    var { EventEmitter } = require_bare_events();
    var STREAM_DESTROYED = new Error("Stream was destroyed");
    var PREMATURE_CLOSE = new Error("Premature close");
    var queueTick = require_queue_microtask();
    var FIFO = require_fast_fifo();
    var TextDecoder2 = require_text_decoder();
    var MAX = (1 << 29) - 1;
    var OPENING = 1;
    var PREDESTROYING = 2;
    var DESTROYING = 4;
    var DESTROYED = 8;
    var NOT_OPENING = MAX ^ OPENING;
    var NOT_PREDESTROYING = MAX ^ PREDESTROYING;
    var READ_ACTIVE = 1 << 4;
    var READ_UPDATING = 2 << 4;
    var READ_PRIMARY = 4 << 4;
    var READ_QUEUED = 8 << 4;
    var READ_RESUMED = 16 << 4;
    var READ_PIPE_DRAINED = 32 << 4;
    var READ_ENDING = 64 << 4;
    var READ_EMIT_DATA = 128 << 4;
    var READ_EMIT_READABLE = 256 << 4;
    var READ_EMITTED_READABLE = 512 << 4;
    var READ_DONE = 1024 << 4;
    var READ_NEXT_TICK = 2048 << 4;
    var READ_NEEDS_PUSH = 4096 << 4;
    var READ_READ_AHEAD = 8192 << 4;
    var READ_FLOWING = READ_RESUMED | READ_PIPE_DRAINED;
    var READ_ACTIVE_AND_NEEDS_PUSH = READ_ACTIVE | READ_NEEDS_PUSH;
    var READ_PRIMARY_AND_ACTIVE = READ_PRIMARY | READ_ACTIVE;
    var READ_EMIT_READABLE_AND_QUEUED = READ_EMIT_READABLE | READ_QUEUED;
    var READ_RESUMED_READ_AHEAD = READ_RESUMED | READ_READ_AHEAD;
    var READ_NOT_ACTIVE = MAX ^ READ_ACTIVE;
    var READ_NON_PRIMARY = MAX ^ READ_PRIMARY;
    var READ_NON_PRIMARY_AND_PUSHED = MAX ^ (READ_PRIMARY | READ_NEEDS_PUSH);
    var READ_PUSHED = MAX ^ READ_NEEDS_PUSH;
    var READ_PAUSED = MAX ^ READ_RESUMED;
    var READ_NOT_QUEUED = MAX ^ (READ_QUEUED | READ_EMITTED_READABLE);
    var READ_NOT_ENDING = MAX ^ READ_ENDING;
    var READ_PIPE_NOT_DRAINED = MAX ^ READ_FLOWING;
    var READ_NOT_NEXT_TICK = MAX ^ READ_NEXT_TICK;
    var READ_NOT_UPDATING = MAX ^ READ_UPDATING;
    var READ_NO_READ_AHEAD = MAX ^ READ_READ_AHEAD;
    var READ_PAUSED_NO_READ_AHEAD = MAX ^ READ_RESUMED_READ_AHEAD;
    var WRITE_ACTIVE = 1 << 18;
    var WRITE_UPDATING = 2 << 18;
    var WRITE_PRIMARY = 4 << 18;
    var WRITE_QUEUED = 8 << 18;
    var WRITE_UNDRAINED = 16 << 18;
    var WRITE_DONE = 32 << 18;
    var WRITE_EMIT_DRAIN = 64 << 18;
    var WRITE_NEXT_TICK = 128 << 18;
    var WRITE_WRITING2 = 256 << 18;
    var WRITE_FINISHING = 512 << 18;
    var WRITE_CORKED = 1024 << 18;
    var WRITE_NOT_ACTIVE = MAX ^ (WRITE_ACTIVE | WRITE_WRITING2);
    var WRITE_NON_PRIMARY = MAX ^ WRITE_PRIMARY;
    var WRITE_NOT_FINISHING = MAX ^ (WRITE_ACTIVE | WRITE_FINISHING);
    var WRITE_DRAINED = MAX ^ WRITE_UNDRAINED;
    var WRITE_NOT_QUEUED = MAX ^ WRITE_QUEUED;
    var WRITE_NOT_NEXT_TICK = MAX ^ WRITE_NEXT_TICK;
    var WRITE_NOT_UPDATING = MAX ^ WRITE_UPDATING;
    var WRITE_NOT_CORKED = MAX ^ WRITE_CORKED;
    var ACTIVE = READ_ACTIVE | WRITE_ACTIVE;
    var NOT_ACTIVE = MAX ^ ACTIVE;
    var DONE = READ_DONE | WRITE_DONE;
    var DESTROY_STATUS = DESTROYING | DESTROYED | PREDESTROYING;
    var OPEN_STATUS = DESTROY_STATUS | OPENING;
    var AUTO_DESTROY = DESTROY_STATUS | DONE;
    var NON_PRIMARY = WRITE_NON_PRIMARY & READ_NON_PRIMARY;
    var ACTIVE_OR_TICKING = WRITE_NEXT_TICK | READ_NEXT_TICK;
    var TICKING = ACTIVE_OR_TICKING & NOT_ACTIVE;
    var IS_OPENING = OPEN_STATUS | TICKING;
    var READ_PRIMARY_STATUS = OPEN_STATUS | READ_ENDING | READ_DONE;
    var READ_STATUS = OPEN_STATUS | READ_DONE | READ_QUEUED;
    var READ_ENDING_STATUS = OPEN_STATUS | READ_ENDING | READ_QUEUED;
    var READ_READABLE_STATUS = OPEN_STATUS | READ_EMIT_READABLE | READ_QUEUED | READ_EMITTED_READABLE;
    var SHOULD_NOT_READ = OPEN_STATUS | READ_ACTIVE | READ_ENDING | READ_DONE | READ_NEEDS_PUSH | READ_READ_AHEAD;
    var READ_BACKPRESSURE_STATUS = DESTROY_STATUS | READ_ENDING | READ_DONE;
    var READ_UPDATE_SYNC_STATUS = READ_UPDATING | OPEN_STATUS | READ_NEXT_TICK | READ_PRIMARY;
    var READ_NEXT_TICK_OR_OPENING = READ_NEXT_TICK | OPENING;
    var WRITE_PRIMARY_STATUS = OPEN_STATUS | WRITE_FINISHING | WRITE_DONE;
    var WRITE_QUEUED_AND_UNDRAINED = WRITE_QUEUED | WRITE_UNDRAINED;
    var WRITE_QUEUED_AND_ACTIVE = WRITE_QUEUED | WRITE_ACTIVE;
    var WRITE_DRAIN_STATUS = WRITE_QUEUED | WRITE_UNDRAINED | OPEN_STATUS | WRITE_ACTIVE;
    var WRITE_STATUS = OPEN_STATUS | WRITE_ACTIVE | WRITE_QUEUED | WRITE_CORKED;
    var WRITE_PRIMARY_AND_ACTIVE = WRITE_PRIMARY | WRITE_ACTIVE;
    var WRITE_ACTIVE_AND_WRITING = WRITE_ACTIVE | WRITE_WRITING2;
    var WRITE_FINISHING_STATUS = OPEN_STATUS | WRITE_FINISHING | WRITE_QUEUED_AND_ACTIVE | WRITE_DONE;
    var WRITE_BACKPRESSURE_STATUS = WRITE_UNDRAINED | DESTROY_STATUS | WRITE_FINISHING | WRITE_DONE;
    var WRITE_UPDATE_SYNC_STATUS = WRITE_UPDATING | OPEN_STATUS | WRITE_NEXT_TICK | WRITE_PRIMARY;
    var WRITE_DROP_DATA = WRITE_FINISHING | WRITE_DONE | DESTROY_STATUS;
    var asyncIterator = Symbol.asyncIterator || Symbol("asyncIterator");
    var WritableState = class {
      constructor(stream, { highWaterMark = 16384, map = null, mapWritable, byteLength, byteLengthWritable } = {}) {
        this.stream = stream;
        this.queue = new FIFO();
        this.highWaterMark = highWaterMark;
        this.buffered = 0;
        this.error = null;
        this.pipeline = null;
        this.drains = null;
        this.byteLength = byteLengthWritable || byteLength || defaultByteLength;
        this.map = mapWritable || map;
        this.afterWrite = afterWrite.bind(this);
        this.afterUpdateNextTick = updateWriteNT.bind(this);
      }
      get ended() {
        return (this.stream._duplexState & WRITE_DONE) !== 0;
      }
      push(data) {
        if ((this.stream._duplexState & WRITE_DROP_DATA) !== 0) return false;
        if (this.map !== null) data = this.map(data);
        this.buffered += this.byteLength(data);
        this.queue.push(data);
        if (this.buffered < this.highWaterMark) {
          this.stream._duplexState |= WRITE_QUEUED;
          return true;
        }
        this.stream._duplexState |= WRITE_QUEUED_AND_UNDRAINED;
        return false;
      }
      shift() {
        const data = this.queue.shift();
        this.buffered -= this.byteLength(data);
        if (this.buffered === 0) this.stream._duplexState &= WRITE_NOT_QUEUED;
        return data;
      }
      end(data) {
        if (typeof data === "function") this.stream.once("finish", data);
        else if (data !== void 0 && data !== null) this.push(data);
        this.stream._duplexState = (this.stream._duplexState | WRITE_FINISHING) & WRITE_NON_PRIMARY;
      }
      autoBatch(data, cb) {
        const buffer = [];
        const stream = this.stream;
        buffer.push(data);
        while ((stream._duplexState & WRITE_STATUS) === WRITE_QUEUED_AND_ACTIVE) {
          buffer.push(stream._writableState.shift());
        }
        if ((stream._duplexState & OPEN_STATUS) !== 0) return cb(null);
        stream._writev(buffer, cb);
      }
      update() {
        const stream = this.stream;
        stream._duplexState |= WRITE_UPDATING;
        do {
          while ((stream._duplexState & WRITE_STATUS) === WRITE_QUEUED) {
            const data = this.shift();
            stream._duplexState |= WRITE_ACTIVE_AND_WRITING;
            stream._write(data, this.afterWrite);
          }
          if ((stream._duplexState & WRITE_PRIMARY_AND_ACTIVE) === 0) this.updateNonPrimary();
        } while (this.continueUpdate() === true);
        stream._duplexState &= WRITE_NOT_UPDATING;
      }
      updateNonPrimary() {
        const stream = this.stream;
        if ((stream._duplexState & WRITE_FINISHING_STATUS) === WRITE_FINISHING) {
          stream._duplexState = stream._duplexState | WRITE_ACTIVE;
          stream._final(afterFinal.bind(this));
          return;
        }
        if ((stream._duplexState & DESTROY_STATUS) === DESTROYING) {
          if ((stream._duplexState & ACTIVE_OR_TICKING) === 0) {
            stream._duplexState |= ACTIVE;
            stream._destroy(afterDestroy.bind(this));
          }
          return;
        }
        if ((stream._duplexState & IS_OPENING) === OPENING) {
          stream._duplexState = (stream._duplexState | ACTIVE) & NOT_OPENING;
          stream._open(afterOpen.bind(this));
        }
      }
      continueUpdate() {
        if ((this.stream._duplexState & WRITE_NEXT_TICK) === 0) return false;
        this.stream._duplexState &= WRITE_NOT_NEXT_TICK;
        return true;
      }
      updateCallback() {
        if ((this.stream._duplexState & WRITE_UPDATE_SYNC_STATUS) === WRITE_PRIMARY) this.update();
        else this.updateNextTick();
      }
      updateNextTick() {
        if ((this.stream._duplexState & WRITE_NEXT_TICK) !== 0) return;
        this.stream._duplexState |= WRITE_NEXT_TICK;
        if ((this.stream._duplexState & WRITE_UPDATING) === 0) queueTick(this.afterUpdateNextTick);
      }
    };
    var ReadableState = class {
      constructor(stream, { highWaterMark = 16384, map = null, mapReadable, byteLength, byteLengthReadable } = {}) {
        this.stream = stream;
        this.queue = new FIFO();
        this.highWaterMark = highWaterMark === 0 ? 1 : highWaterMark;
        this.buffered = 0;
        this.readAhead = highWaterMark > 0;
        this.error = null;
        this.pipeline = null;
        this.byteLength = byteLengthReadable || byteLength || defaultByteLength;
        this.map = mapReadable || map;
        this.pipeTo = null;
        this.afterRead = afterRead.bind(this);
        this.afterUpdateNextTick = updateReadNT.bind(this);
      }
      get ended() {
        return (this.stream._duplexState & READ_DONE) !== 0;
      }
      pipe(pipeTo, cb) {
        if (this.pipeTo !== null) throw new Error("Can only pipe to one destination");
        if (typeof cb !== "function") cb = null;
        this.stream._duplexState |= READ_PIPE_DRAINED;
        this.pipeTo = pipeTo;
        this.pipeline = new Pipeline(this.stream, pipeTo, cb);
        if (cb) this.stream.on("error", noop);
        if (isStreamx2(pipeTo)) {
          pipeTo._writableState.pipeline = this.pipeline;
          if (cb) pipeTo.on("error", noop);
          pipeTo.on("finish", this.pipeline.finished.bind(this.pipeline));
        } else {
          const onerror = this.pipeline.done.bind(this.pipeline, pipeTo);
          const onclose = this.pipeline.done.bind(this.pipeline, pipeTo, null);
          pipeTo.on("error", onerror);
          pipeTo.on("close", onclose);
          pipeTo.on("finish", this.pipeline.finished.bind(this.pipeline));
        }
        pipeTo.on("drain", afterDrain.bind(this));
        this.stream.emit("piping", pipeTo);
        pipeTo.emit("pipe", this.stream);
      }
      push(data) {
        const stream = this.stream;
        if (data === null) {
          this.highWaterMark = 0;
          stream._duplexState = (stream._duplexState | READ_ENDING) & READ_NON_PRIMARY_AND_PUSHED;
          return false;
        }
        if (this.map !== null) {
          data = this.map(data);
          if (data === null) {
            stream._duplexState &= READ_PUSHED;
            return this.buffered < this.highWaterMark;
          }
        }
        this.buffered += this.byteLength(data);
        this.queue.push(data);
        stream._duplexState = (stream._duplexState | READ_QUEUED) & READ_PUSHED;
        return this.buffered < this.highWaterMark;
      }
      shift() {
        const data = this.queue.shift();
        this.buffered -= this.byteLength(data);
        if (this.buffered === 0) this.stream._duplexState &= READ_NOT_QUEUED;
        return data;
      }
      unshift(data) {
        const pending = [this.map !== null ? this.map(data) : data];
        while (this.buffered > 0) pending.push(this.shift());
        for (let i = 0; i < pending.length - 1; i++) {
          const data2 = pending[i];
          this.buffered += this.byteLength(data2);
          this.queue.push(data2);
        }
        this.push(pending[pending.length - 1]);
      }
      read() {
        const stream = this.stream;
        if ((stream._duplexState & READ_STATUS) === READ_QUEUED) {
          const data = this.shift();
          if (this.pipeTo !== null && this.pipeTo.write(data) === false) stream._duplexState &= READ_PIPE_NOT_DRAINED;
          if ((stream._duplexState & READ_EMIT_DATA) !== 0) stream.emit("data", data);
          return data;
        }
        if (this.readAhead === false) {
          stream._duplexState |= READ_READ_AHEAD;
          this.updateNextTick();
        }
        return null;
      }
      drain() {
        const stream = this.stream;
        while ((stream._duplexState & READ_STATUS) === READ_QUEUED && (stream._duplexState & READ_FLOWING) !== 0) {
          const data = this.shift();
          if (this.pipeTo !== null && this.pipeTo.write(data) === false) stream._duplexState &= READ_PIPE_NOT_DRAINED;
          if ((stream._duplexState & READ_EMIT_DATA) !== 0) stream.emit("data", data);
        }
      }
      update() {
        const stream = this.stream;
        stream._duplexState |= READ_UPDATING;
        do {
          this.drain();
          while (this.buffered < this.highWaterMark && (stream._duplexState & SHOULD_NOT_READ) === READ_READ_AHEAD) {
            stream._duplexState |= READ_ACTIVE_AND_NEEDS_PUSH;
            stream._read(this.afterRead);
            this.drain();
          }
          if ((stream._duplexState & READ_READABLE_STATUS) === READ_EMIT_READABLE_AND_QUEUED) {
            stream._duplexState |= READ_EMITTED_READABLE;
            stream.emit("readable");
          }
          if ((stream._duplexState & READ_PRIMARY_AND_ACTIVE) === 0) this.updateNonPrimary();
        } while (this.continueUpdate() === true);
        stream._duplexState &= READ_NOT_UPDATING;
      }
      updateNonPrimary() {
        const stream = this.stream;
        if ((stream._duplexState & READ_ENDING_STATUS) === READ_ENDING) {
          stream._duplexState = (stream._duplexState | READ_DONE) & READ_NOT_ENDING;
          stream.emit("end");
          if ((stream._duplexState & AUTO_DESTROY) === DONE) stream._duplexState |= DESTROYING;
          if (this.pipeTo !== null) this.pipeTo.end();
        }
        if ((stream._duplexState & DESTROY_STATUS) === DESTROYING) {
          if ((stream._duplexState & ACTIVE_OR_TICKING) === 0) {
            stream._duplexState |= ACTIVE;
            stream._destroy(afterDestroy.bind(this));
          }
          return;
        }
        if ((stream._duplexState & IS_OPENING) === OPENING) {
          stream._duplexState = (stream._duplexState | ACTIVE) & NOT_OPENING;
          stream._open(afterOpen.bind(this));
        }
      }
      continueUpdate() {
        if ((this.stream._duplexState & READ_NEXT_TICK) === 0) return false;
        this.stream._duplexState &= READ_NOT_NEXT_TICK;
        return true;
      }
      updateCallback() {
        if ((this.stream._duplexState & READ_UPDATE_SYNC_STATUS) === READ_PRIMARY) this.update();
        else this.updateNextTick();
      }
      updateNextTickIfOpen() {
        if ((this.stream._duplexState & READ_NEXT_TICK_OR_OPENING) !== 0) return;
        this.stream._duplexState |= READ_NEXT_TICK;
        if ((this.stream._duplexState & READ_UPDATING) === 0) queueTick(this.afterUpdateNextTick);
      }
      updateNextTick() {
        if ((this.stream._duplexState & READ_NEXT_TICK) !== 0) return;
        this.stream._duplexState |= READ_NEXT_TICK;
        if ((this.stream._duplexState & READ_UPDATING) === 0) queueTick(this.afterUpdateNextTick);
      }
    };
    var TransformState = class {
      constructor(stream) {
        this.data = null;
        this.afterTransform = afterTransform.bind(stream);
        this.afterFinal = null;
      }
    };
    var Pipeline = class {
      constructor(src, dst, cb) {
        this.from = src;
        this.to = dst;
        this.afterPipe = cb;
        this.error = null;
        this.pipeToFinished = false;
      }
      finished() {
        this.pipeToFinished = true;
      }
      done(stream, err) {
        if (err) this.error = err;
        if (stream === this.to) {
          this.to = null;
          if (this.from !== null) {
            if ((this.from._duplexState & READ_DONE) === 0 || !this.pipeToFinished) {
              this.from.destroy(this.error || new Error("Writable stream closed prematurely"));
            }
            return;
          }
        }
        if (stream === this.from) {
          this.from = null;
          if (this.to !== null) {
            if ((stream._duplexState & READ_DONE) === 0) {
              this.to.destroy(this.error || new Error("Readable stream closed before ending"));
            }
            return;
          }
        }
        if (this.afterPipe !== null) this.afterPipe(this.error);
        this.to = this.from = this.afterPipe = null;
      }
    };
    function afterDrain() {
      this.stream._duplexState |= READ_PIPE_DRAINED;
      this.updateCallback();
    }
    function afterFinal(err) {
      const stream = this.stream;
      if (err) stream.destroy(err);
      if ((stream._duplexState & DESTROY_STATUS) === 0) {
        stream._duplexState |= WRITE_DONE;
        stream.emit("finish");
      }
      if ((stream._duplexState & AUTO_DESTROY) === DONE) {
        stream._duplexState |= DESTROYING;
      }
      stream._duplexState &= WRITE_NOT_FINISHING;
      if ((stream._duplexState & WRITE_UPDATING) === 0) this.update();
      else this.updateNextTick();
    }
    function afterDestroy(err) {
      const stream = this.stream;
      if (!err && this.error !== STREAM_DESTROYED) err = this.error;
      if (err) stream.emit("error", err);
      stream._duplexState |= DESTROYED;
      stream.emit("close");
      const rs = stream._readableState;
      const ws = stream._writableState;
      if (rs !== null && rs.pipeline !== null) rs.pipeline.done(stream, err);
      if (ws !== null) {
        while (ws.drains !== null && ws.drains.length > 0) ws.drains.shift().resolve(false);
        if (ws.pipeline !== null) ws.pipeline.done(stream, err);
      }
    }
    function afterWrite(err) {
      const stream = this.stream;
      if (err) stream.destroy(err);
      stream._duplexState &= WRITE_NOT_ACTIVE;
      if (this.drains !== null) tickDrains(this.drains);
      if ((stream._duplexState & WRITE_DRAIN_STATUS) === WRITE_UNDRAINED) {
        stream._duplexState &= WRITE_DRAINED;
        if ((stream._duplexState & WRITE_EMIT_DRAIN) === WRITE_EMIT_DRAIN) {
          stream.emit("drain");
        }
      }
      this.updateCallback();
    }
    function afterRead(err) {
      if (err) this.stream.destroy(err);
      this.stream._duplexState &= READ_NOT_ACTIVE;
      if (this.readAhead === false && (this.stream._duplexState & READ_RESUMED) === 0) this.stream._duplexState &= READ_NO_READ_AHEAD;
      this.updateCallback();
    }
    function updateReadNT() {
      if ((this.stream._duplexState & READ_UPDATING) === 0) {
        this.stream._duplexState &= READ_NOT_NEXT_TICK;
        this.update();
      }
    }
    function updateWriteNT() {
      if ((this.stream._duplexState & WRITE_UPDATING) === 0) {
        this.stream._duplexState &= WRITE_NOT_NEXT_TICK;
        this.update();
      }
    }
    function tickDrains(drains) {
      for (let i = 0; i < drains.length; i++) {
        if (--drains[i].writes === 0) {
          drains.shift().resolve(true);
          i--;
        }
      }
    }
    function afterOpen(err) {
      const stream = this.stream;
      if (err) stream.destroy(err);
      if ((stream._duplexState & DESTROYING) === 0) {
        if ((stream._duplexState & READ_PRIMARY_STATUS) === 0) stream._duplexState |= READ_PRIMARY;
        if ((stream._duplexState & WRITE_PRIMARY_STATUS) === 0) stream._duplexState |= WRITE_PRIMARY;
        stream.emit("open");
      }
      stream._duplexState &= NOT_ACTIVE;
      if (stream._writableState !== null) {
        stream._writableState.updateCallback();
      }
      if (stream._readableState !== null) {
        stream._readableState.updateCallback();
      }
    }
    function afterTransform(err, data) {
      if (data !== void 0 && data !== null) this.push(data);
      this._writableState.afterWrite(err);
    }
    function newListener(name) {
      if (this._readableState !== null) {
        if (name === "data") {
          this._duplexState |= READ_EMIT_DATA | READ_RESUMED_READ_AHEAD;
          this._readableState.updateNextTick();
        }
        if (name === "readable") {
          this._duplexState |= READ_EMIT_READABLE;
          this._readableState.updateNextTick();
        }
      }
      if (this._writableState !== null) {
        if (name === "drain") {
          this._duplexState |= WRITE_EMIT_DRAIN;
          this._writableState.updateNextTick();
        }
      }
    }
    var Stream = class extends EventEmitter {
      constructor(opts) {
        super();
        this._duplexState = 0;
        this._readableState = null;
        this._writableState = null;
        if (opts) {
          if (opts.open) this._open = opts.open;
          if (opts.destroy) this._destroy = opts.destroy;
          if (opts.predestroy) this._predestroy = opts.predestroy;
          if (opts.signal) {
            opts.signal.addEventListener("abort", abort.bind(this));
          }
        }
        this.on("newListener", newListener);
      }
      _open(cb) {
        cb(null);
      }
      _destroy(cb) {
        cb(null);
      }
      _predestroy() {
      }
      get readable() {
        return this._readableState !== null ? true : void 0;
      }
      get writable() {
        return this._writableState !== null ? true : void 0;
      }
      get destroyed() {
        return (this._duplexState & DESTROYED) !== 0;
      }
      get destroying() {
        return (this._duplexState & DESTROY_STATUS) !== 0;
      }
      destroy(err) {
        if ((this._duplexState & DESTROY_STATUS) === 0) {
          if (!err) err = STREAM_DESTROYED;
          this._duplexState = (this._duplexState | DESTROYING) & NON_PRIMARY;
          if (this._readableState !== null) {
            this._readableState.highWaterMark = 0;
            this._readableState.error = err;
          }
          if (this._writableState !== null) {
            this._writableState.highWaterMark = 0;
            this._writableState.error = err;
          }
          this._duplexState |= PREDESTROYING;
          this._predestroy();
          this._duplexState &= NOT_PREDESTROYING;
          if (this._readableState !== null) this._readableState.updateNextTick();
          if (this._writableState !== null) this._writableState.updateNextTick();
        }
      }
    };
    var Readable2 = class _Readable extends Stream {
      constructor(opts) {
        super(opts);
        this._duplexState |= OPENING | WRITE_DONE | READ_READ_AHEAD;
        this._readableState = new ReadableState(this, opts);
        if (opts) {
          if (this._readableState.readAhead === false) this._duplexState &= READ_NO_READ_AHEAD;
          if (opts.read) this._read = opts.read;
          if (opts.eagerOpen) this._readableState.updateNextTick();
          if (opts.encoding) this.setEncoding(opts.encoding);
        }
      }
      setEncoding(encoding) {
        const dec = new TextDecoder2(encoding);
        const map = this._readableState.map || echo;
        this._readableState.map = mapOrSkip;
        return this;
        function mapOrSkip(data) {
          const next = dec.push(data);
          return next === "" && (data.byteLength !== 0 || dec.remaining > 0) ? null : map(next);
        }
      }
      _read(cb) {
        cb(null);
      }
      pipe(dest, cb) {
        this._readableState.updateNextTick();
        this._readableState.pipe(dest, cb);
        return dest;
      }
      read() {
        this._readableState.updateNextTick();
        return this._readableState.read();
      }
      push(data) {
        this._readableState.updateNextTickIfOpen();
        return this._readableState.push(data);
      }
      unshift(data) {
        this._readableState.updateNextTickIfOpen();
        return this._readableState.unshift(data);
      }
      resume() {
        this._duplexState |= READ_RESUMED_READ_AHEAD;
        this._readableState.updateNextTick();
        return this;
      }
      pause() {
        this._duplexState &= this._readableState.readAhead === false ? READ_PAUSED_NO_READ_AHEAD : READ_PAUSED;
        return this;
      }
      static _fromAsyncIterator(ite, opts) {
        let destroy;
        const rs = new _Readable({
          ...opts,
          read(cb) {
            ite.next().then(push).then(cb.bind(null, null)).catch(cb);
          },
          predestroy() {
            destroy = ite.return();
          },
          destroy(cb) {
            if (!destroy) return cb(null);
            destroy.then(cb.bind(null, null)).catch(cb);
          }
        });
        return rs;
        function push(data) {
          if (data.done) rs.push(null);
          else rs.push(data.value);
        }
      }
      static from(data, opts) {
        if (isReadStreamx(data)) return data;
        if (data[asyncIterator]) return this._fromAsyncIterator(data[asyncIterator](), opts);
        if (!Array.isArray(data)) data = data === void 0 ? [] : [data];
        let i = 0;
        return new _Readable({
          ...opts,
          read(cb) {
            this.push(i === data.length ? null : data[i++]);
            cb(null);
          }
        });
      }
      static isBackpressured(rs) {
        return (rs._duplexState & READ_BACKPRESSURE_STATUS) !== 0 || rs._readableState.buffered >= rs._readableState.highWaterMark;
      }
      static isPaused(rs) {
        return (rs._duplexState & READ_RESUMED) === 0;
      }
      [asyncIterator]() {
        const stream = this;
        let error = null;
        let promiseResolve = null;
        let promiseReject = null;
        this.on("error", (err) => {
          error = err;
        });
        this.on("readable", onreadable);
        this.on("close", onclose);
        return {
          [asyncIterator]() {
            return this;
          },
          next() {
            return new Promise(function(resolve, reject) {
              promiseResolve = resolve;
              promiseReject = reject;
              const data = stream.read();
              if (data !== null) ondata(data);
              else if ((stream._duplexState & DESTROYED) !== 0) ondata(null);
            });
          },
          return() {
            return destroy(null);
          },
          throw(err) {
            return destroy(err);
          }
        };
        function onreadable() {
          if (promiseResolve !== null) ondata(stream.read());
        }
        function onclose() {
          if (promiseResolve !== null) ondata(null);
        }
        function ondata(data) {
          if (promiseReject === null) return;
          if (error) promiseReject(error);
          else if (data === null && (stream._duplexState & READ_DONE) === 0) promiseReject(STREAM_DESTROYED);
          else promiseResolve({ value: data, done: data === null });
          promiseReject = promiseResolve = null;
        }
        function destroy(err) {
          stream.destroy(err);
          return new Promise((resolve, reject) => {
            if (stream._duplexState & DESTROYED) return resolve({ value: void 0, done: true });
            stream.once("close", function() {
              if (err) reject(err);
              else resolve({ value: void 0, done: true });
            });
          });
        }
      }
    };
    var Writable2 = class extends Stream {
      constructor(opts) {
        super(opts);
        this._duplexState |= OPENING | READ_DONE;
        this._writableState = new WritableState(this, opts);
        if (opts) {
          if (opts.writev) this._writev = opts.writev;
          if (opts.write) this._write = opts.write;
          if (opts.final) this._final = opts.final;
          if (opts.eagerOpen) this._writableState.updateNextTick();
        }
      }
      cork() {
        this._duplexState |= WRITE_CORKED;
      }
      uncork() {
        this._duplexState &= WRITE_NOT_CORKED;
        this._writableState.updateNextTick();
      }
      _writev(batch, cb) {
        cb(null);
      }
      _write(data, cb) {
        this._writableState.autoBatch(data, cb);
      }
      _final(cb) {
        cb(null);
      }
      static isBackpressured(ws) {
        return (ws._duplexState & WRITE_BACKPRESSURE_STATUS) !== 0;
      }
      static drained(ws) {
        if (ws.destroyed) return Promise.resolve(false);
        const state = ws._writableState;
        const pending = isWritev(ws) ? Math.min(1, state.queue.length) : state.queue.length;
        const writes = pending + (ws._duplexState & WRITE_WRITING2 ? 1 : 0);
        if (writes === 0) return Promise.resolve(true);
        if (state.drains === null) state.drains = [];
        return new Promise((resolve) => {
          state.drains.push({ writes, resolve });
        });
      }
      write(data) {
        this._writableState.updateNextTick();
        return this._writableState.push(data);
      }
      end(data) {
        this._writableState.updateNextTick();
        this._writableState.end(data);
        return this;
      }
    };
    var Duplex2 = class extends Readable2 {
      // and Writable
      constructor(opts) {
        super(opts);
        this._duplexState = OPENING | this._duplexState & READ_READ_AHEAD;
        this._writableState = new WritableState(this, opts);
        if (opts) {
          if (opts.writev) this._writev = opts.writev;
          if (opts.write) this._write = opts.write;
          if (opts.final) this._final = opts.final;
        }
      }
      cork() {
        this._duplexState |= WRITE_CORKED;
      }
      uncork() {
        this._duplexState &= WRITE_NOT_CORKED;
        this._writableState.updateNextTick();
      }
      _writev(batch, cb) {
        cb(null);
      }
      _write(data, cb) {
        this._writableState.autoBatch(data, cb);
      }
      _final(cb) {
        cb(null);
      }
      write(data) {
        this._writableState.updateNextTick();
        return this._writableState.push(data);
      }
      end(data) {
        this._writableState.updateNextTick();
        this._writableState.end(data);
        return this;
      }
    };
    var Transform = class extends Duplex2 {
      constructor(opts) {
        super(opts);
        this._transformState = new TransformState(this);
        if (opts) {
          if (opts.transform) this._transform = opts.transform;
          if (opts.flush) this._flush = opts.flush;
        }
      }
      _write(data, cb) {
        if (this._readableState.buffered >= this._readableState.highWaterMark) {
          this._transformState.data = data;
        } else {
          this._transform(data, this._transformState.afterTransform);
        }
      }
      _read(cb) {
        if (this._transformState.data !== null) {
          const data = this._transformState.data;
          this._transformState.data = null;
          cb(null);
          this._transform(data, this._transformState.afterTransform);
        } else {
          cb(null);
        }
      }
      destroy(err) {
        super.destroy(err);
        if (this._transformState.data !== null) {
          this._transformState.data = null;
          this._transformState.afterTransform();
        }
      }
      _transform(data, cb) {
        cb(null, data);
      }
      _flush(cb) {
        cb(null);
      }
      _final(cb) {
        this._transformState.afterFinal = cb;
        this._flush(transformAfterFlush.bind(this));
      }
    };
    var PassThrough = class extends Transform {
    };
    function transformAfterFlush(err, data) {
      const cb = this._transformState.afterFinal;
      if (err) return cb(err);
      if (data !== null && data !== void 0) this.push(data);
      this.push(null);
      cb(null);
    }
    function pipelinePromise(...streams) {
      return new Promise((resolve, reject) => {
        return pipeline(...streams, (err) => {
          if (err) return reject(err);
          resolve();
        });
      });
    }
    function pipeline(stream, ...streams) {
      const all = Array.isArray(stream) ? [...stream, ...streams] : [stream, ...streams];
      const done = all.length && typeof all[all.length - 1] === "function" ? all.pop() : null;
      if (all.length < 2) throw new Error("Pipeline requires at least 2 streams");
      let src = all[0];
      let dest = null;
      let error = null;
      for (let i = 1; i < all.length; i++) {
        dest = all[i];
        if (isStreamx2(src)) {
          src.pipe(dest, onerror);
        } else {
          errorHandle(src, true, i > 1, onerror);
          src.pipe(dest);
        }
        src = dest;
      }
      if (done) {
        let fin = false;
        const autoDestroy = isStreamx2(dest) || !!(dest._writableState && dest._writableState.autoDestroy);
        dest.on("error", (err) => {
          if (error === null) error = err;
        });
        dest.on("finish", () => {
          fin = true;
          if (!autoDestroy) done(error);
        });
        if (autoDestroy) {
          dest.on("close", () => done(error || (fin ? null : PREMATURE_CLOSE)));
        }
      }
      return dest;
      function errorHandle(s, rd, wr, onerror2) {
        s.on("error", onerror2);
        s.on("close", onclose);
        function onclose() {
          if (rd && s._readableState && !s._readableState.ended) return onerror2(PREMATURE_CLOSE);
          if (wr && s._writableState && !s._writableState.ended) return onerror2(PREMATURE_CLOSE);
        }
      }
      function onerror(err) {
        if (!err || error) return;
        error = err;
        for (const s of all) {
          s.destroy(err);
        }
      }
    }
    function echo(s) {
      return s;
    }
    function isStream2(stream) {
      return !!stream._readableState || !!stream._writableState;
    }
    function isStreamx2(stream) {
      return typeof stream._duplexState === "number" && isStream2(stream);
    }
    function isEnded(stream) {
      return !!stream._readableState && stream._readableState.ended;
    }
    function isFinished(stream) {
      return !!stream._writableState && stream._writableState.ended;
    }
    function getStreamError(stream, opts = {}) {
      const err = stream._readableState && stream._readableState.error || stream._writableState && stream._writableState.error;
      return !opts.all && err === STREAM_DESTROYED ? null : err;
    }
    function isReadStreamx(stream) {
      return isStreamx2(stream) && stream.readable;
    }
    function isDisturbed(stream) {
      return (stream._duplexState & OPENING) !== OPENING || (stream._duplexState & ACTIVE_OR_TICKING) !== 0;
    }
    function isTypedArray(data) {
      return typeof data === "object" && data !== null && typeof data.byteLength === "number";
    }
    function defaultByteLength(data) {
      return isTypedArray(data) ? data.byteLength : 1024;
    }
    function noop() {
    }
    function abort() {
      this.destroy(new Error("Stream aborted."));
    }
    function isWritev(s) {
      return s._writev !== Writable2.prototype._writev && s._writev !== Duplex2.prototype._writev;
    }
    module.exports = {
      pipeline,
      pipelinePromise,
      isStream: isStream2,
      isStreamx: isStreamx2,
      isEnded,
      isFinished,
      isDisturbed,
      getStreamError,
      Stream,
      Writable: Writable2,
      Readable: Readable2,
      Duplex: Duplex2,
      Transform,
      // Export PassThrough for compatibility with Node.js core's stream module
      PassThrough
    };
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/ascii.js
var require_ascii = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/ascii.js"(exports, module) {
    function byteLength(string) {
      return string.length;
    }
    function toString(buffer) {
      const len = buffer.byteLength;
      let result = "";
      for (let i = 0; i < len; i++) {
        result += String.fromCharCode(buffer[i]);
      }
      return result;
    }
    function write(buffer, string, offset = 0, length = byteLength(string)) {
      const len = Math.min(length, buffer.byteLength - offset);
      for (let i = 0; i < len; i++) {
        buffer[offset + i] = string.charCodeAt(i);
      }
      return len;
    }
    module.exports = {
      byteLength,
      toString,
      write
    };
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/base64.js
var require_base64 = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/base64.js"(exports, module) {
    var alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var codes = new Uint8Array(256);
    for (let i = 0; i < alphabet.length; i++) {
      codes[alphabet.charCodeAt(i)] = i;
    }
    codes[
      /* - */
      45
    ] = 62;
    codes[
      /* _ */
      95
    ] = 63;
    function byteLength(string) {
      let len = string.length;
      if (string.charCodeAt(len - 1) === 61) len--;
      if (len > 1 && string.charCodeAt(len - 1) === 61) len--;
      return len * 3 >>> 2;
    }
    function toString(buffer) {
      const len = buffer.byteLength;
      let result = "";
      for (let i = 0; i < len; i += 3) {
        result += alphabet[buffer[i] >> 2] + alphabet[(buffer[i] & 3) << 4 | buffer[i + 1] >> 4] + alphabet[(buffer[i + 1] & 15) << 2 | buffer[i + 2] >> 6] + alphabet[buffer[i + 2] & 63];
      }
      if (len % 3 === 2) {
        result = result.substring(0, result.length - 1) + "=";
      } else if (len % 3 === 1) {
        result = result.substring(0, result.length - 2) + "==";
      }
      return result;
    }
    function write(buffer, string, offset = 0, length = byteLength(string)) {
      const len = Math.min(length, buffer.byteLength - offset);
      for (let i = 0, j = 0; j < len; i += 4) {
        const a = codes[string.charCodeAt(i)];
        const b = codes[string.charCodeAt(i + 1)];
        const c = codes[string.charCodeAt(i + 2)];
        const d = codes[string.charCodeAt(i + 3)];
        buffer[j++] = a << 2 | b >> 4;
        buffer[j++] = (b & 15) << 4 | c >> 2;
        buffer[j++] = (c & 3) << 6 | d & 63;
      }
      return len;
    }
    module.exports = {
      byteLength,
      toString,
      write
    };
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/hex.js
var require_hex = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/hex.js"(exports, module) {
    function byteLength(string) {
      return string.length >>> 1;
    }
    function toString(buffer) {
      const len = buffer.byteLength;
      buffer = new DataView(buffer.buffer, buffer.byteOffset, len);
      let result = "";
      let i = 0;
      for (let n = len - len % 4; i < n; i += 4) {
        result += buffer.getUint32(i).toString(16).padStart(8, "0");
      }
      for (; i < len; i++) {
        result += buffer.getUint8(i).toString(16).padStart(2, "0");
      }
      return result;
    }
    function write(buffer, string, offset = 0, length = byteLength(string)) {
      const len = Math.min(length, buffer.byteLength - offset);
      for (let i = 0; i < len; i++) {
        const a = hexValue(string.charCodeAt(i * 2));
        const b = hexValue(string.charCodeAt(i * 2 + 1));
        if (a === void 0 || b === void 0) {
          return buffer.subarray(0, i);
        }
        buffer[offset + i] = a << 4 | b;
      }
      return len;
    }
    module.exports = {
      byteLength,
      toString,
      write
    };
    function hexValue(char) {
      if (char >= 48 && char <= 57) return char - 48;
      if (char >= 65 && char <= 70) return char - 65 + 10;
      if (char >= 97 && char <= 102) return char - 97 + 10;
    }
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/utf8.js
var require_utf8 = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/utf8.js"(exports, module) {
    function byteLength(string) {
      let length = 0;
      for (let i = 0, n = string.length; i < n; i++) {
        const code = string.charCodeAt(i);
        if (code >= 55296 && code <= 56319 && i + 1 < n) {
          const code2 = string.charCodeAt(i + 1);
          if (code2 >= 56320 && code2 <= 57343) {
            length += 4;
            i++;
            continue;
          }
        }
        if (code <= 127) length += 1;
        else if (code <= 2047) length += 2;
        else length += 3;
      }
      return length;
    }
    var toString;
    if (typeof TextDecoder !== "undefined") {
      const decoder = new TextDecoder();
      toString = function toString2(buffer) {
        return decoder.decode(buffer);
      };
    } else {
      toString = function toString2(buffer) {
        const len = buffer.byteLength;
        let output = "";
        let i = 0;
        while (i < len) {
          let byte = buffer[i];
          if (byte <= 127) {
            output += String.fromCharCode(byte);
            i++;
            continue;
          }
          let bytesNeeded = 0;
          let codePoint = 0;
          if (byte <= 223) {
            bytesNeeded = 1;
            codePoint = byte & 31;
          } else if (byte <= 239) {
            bytesNeeded = 2;
            codePoint = byte & 15;
          } else if (byte <= 244) {
            bytesNeeded = 3;
            codePoint = byte & 7;
          }
          if (len - i - bytesNeeded > 0) {
            let k = 0;
            while (k < bytesNeeded) {
              byte = buffer[i + k + 1];
              codePoint = codePoint << 6 | byte & 63;
              k += 1;
            }
          } else {
            codePoint = 65533;
            bytesNeeded = len - i;
          }
          output += String.fromCodePoint(codePoint);
          i += bytesNeeded + 1;
        }
        return output;
      };
    }
    var write;
    if (typeof TextEncoder !== "undefined") {
      const encoder = new TextEncoder();
      write = function write2(buffer, string, offset = 0, length = byteLength(string)) {
        const len = Math.min(length, buffer.byteLength - offset);
        encoder.encodeInto(string, buffer.subarray(offset, offset + len));
        return len;
      };
    } else {
      write = function write2(buffer, string, offset = 0, length = byteLength(string)) {
        const len = Math.min(length, buffer.byteLength - offset);
        buffer = buffer.subarray(offset, offset + len);
        let i = 0;
        let j = 0;
        while (i < string.length) {
          const code = string.codePointAt(i);
          if (code <= 127) {
            buffer[j++] = code;
            i++;
            continue;
          }
          let count = 0;
          let bits = 0;
          if (code <= 2047) {
            count = 6;
            bits = 192;
          } else if (code <= 65535) {
            count = 12;
            bits = 224;
          } else if (code <= 2097151) {
            count = 18;
            bits = 240;
          }
          buffer[j++] = bits | code >> count;
          count -= 6;
          while (count >= 0) {
            buffer[j++] = 128 | code >> count & 63;
            count -= 6;
          }
          i += code >= 65536 ? 2 : 1;
        }
        return len;
      };
    }
    module.exports = {
      byteLength,
      toString,
      write
    };
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/utf16le.js
var require_utf16le = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/lib/utf16le.js"(exports, module) {
    function byteLength(string) {
      return string.length * 2;
    }
    function toString(buffer) {
      const len = buffer.byteLength;
      let result = "";
      for (let i = 0; i < len - 1; i += 2) {
        result += String.fromCharCode(buffer[i] + buffer[i + 1] * 256);
      }
      return result;
    }
    function write(buffer, string, offset = 0, length = byteLength(string)) {
      const len = Math.min(length, buffer.byteLength - offset);
      let units = len;
      for (let i = 0; i < string.length; ++i) {
        if ((units -= 2) < 0) break;
        const c = string.charCodeAt(i);
        const hi = c >> 8;
        const lo = c % 256;
        buffer[offset + i * 2] = lo;
        buffer[offset + i * 2 + 1] = hi;
      }
      return len;
    }
    module.exports = {
      byteLength,
      toString,
      write
    };
  }
});

// node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/browser.js
var require_browser = __commonJS({
  "node_modules/.pnpm/b4a@1.6.7/node_modules/b4a/browser.js"(exports, module) {
    var ascii = require_ascii();
    var base64 = require_base64();
    var hex = require_hex();
    var utf8 = require_utf8();
    var utf16le = require_utf16le();
    var LE = new Uint8Array(Uint16Array.of(255).buffer)[0] === 255;
    function codecFor(encoding) {
      switch (encoding) {
        case "ascii":
          return ascii;
        case "base64":
          return base64;
        case "hex":
          return hex;
        case "utf8":
        case "utf-8":
        case void 0:
        case null:
          return utf8;
        case "ucs2":
        case "ucs-2":
        case "utf16le":
        case "utf-16le":
          return utf16le;
        default:
          throw new Error(`Unknown encoding: ${encoding}`);
      }
    }
    function isBuffer(value) {
      return value instanceof Uint8Array;
    }
    function isEncoding(encoding) {
      try {
        codecFor(encoding);
        return true;
      } catch {
        return false;
      }
    }
    function alloc(size, fill2, encoding) {
      const buffer = new Uint8Array(size);
      if (fill2 !== void 0) exports.fill(buffer, fill2, 0, buffer.byteLength, encoding);
      return buffer;
    }
    function allocUnsafe(size) {
      return new Uint8Array(size);
    }
    function allocUnsafeSlow(size) {
      return new Uint8Array(size);
    }
    function byteLength(string, encoding) {
      return codecFor(encoding).byteLength(string);
    }
    function compare(a, b) {
      if (a === b) return 0;
      const len = Math.min(a.byteLength, b.byteLength);
      a = new DataView(a.buffer, a.byteOffset, a.byteLength);
      b = new DataView(b.buffer, b.byteOffset, b.byteLength);
      let i = 0;
      for (let n = len - len % 4; i < n; i += 4) {
        const x = a.getUint32(i, LE);
        const y = b.getUint32(i, LE);
        if (x !== y) break;
      }
      for (; i < len; i++) {
        const x = a.getUint8(i);
        const y = b.getUint8(i);
        if (x < y) return -1;
        if (x > y) return 1;
      }
      return a.byteLength > b.byteLength ? 1 : a.byteLength < b.byteLength ? -1 : 0;
    }
    function concat(buffers, totalLength) {
      if (totalLength === void 0) {
        totalLength = buffers.reduce((len, buffer) => len + buffer.byteLength, 0);
      }
      const result = new Uint8Array(totalLength);
      let offset = 0;
      for (const buffer of buffers) {
        if (offset + buffer.byteLength > result.byteLength) {
          const sub = buffer.subarray(0, result.byteLength - offset);
          result.set(sub, offset);
          return result;
        }
        result.set(buffer, offset);
        offset += buffer.byteLength;
      }
      return result;
    }
    function copy(source, target, targetStart = 0, start = 0, end = source.byteLength) {
      if (end > 0 && end < start) return 0;
      if (end === start) return 0;
      if (source.byteLength === 0 || target.byteLength === 0) return 0;
      if (targetStart < 0) throw new RangeError("targetStart is out of range");
      if (start < 0 || start >= source.byteLength) throw new RangeError("sourceStart is out of range");
      if (end < 0) throw new RangeError("sourceEnd is out of range");
      if (targetStart >= target.byteLength) targetStart = target.byteLength;
      if (end > source.byteLength) end = source.byteLength;
      if (target.byteLength - targetStart < end - start) {
        end = target.length - targetStart + start;
      }
      const len = end - start;
      if (source === target) {
        target.copyWithin(targetStart, start, end);
      } else {
        target.set(source.subarray(start, end), targetStart);
      }
      return len;
    }
    function equals(a, b) {
      if (a === b) return true;
      if (a.byteLength !== b.byteLength) return false;
      const len = a.byteLength;
      a = new DataView(a.buffer, a.byteOffset, a.byteLength);
      b = new DataView(b.buffer, b.byteOffset, b.byteLength);
      let i = 0;
      for (let n = len - len % 4; i < n; i += 4) {
        if (a.getUint32(i, LE) !== b.getUint32(i, LE)) return false;
      }
      for (; i < len; i++) {
        if (a.getUint8(i) !== b.getUint8(i)) return false;
      }
      return true;
    }
    function fill(buffer, value, offset, end, encoding) {
      if (typeof value === "string") {
        if (typeof offset === "string") {
          encoding = offset;
          offset = 0;
          end = buffer.byteLength;
        } else if (typeof end === "string") {
          encoding = end;
          end = buffer.byteLength;
        }
      } else if (typeof value === "number") {
        value = value & 255;
      } else if (typeof value === "boolean") {
        value = +value;
      }
      if (offset < 0 || buffer.byteLength < offset || buffer.byteLength < end) {
        throw new RangeError("Out of range index");
      }
      if (offset === void 0) offset = 0;
      if (end === void 0) end = buffer.byteLength;
      if (end <= offset) return buffer;
      if (!value) value = 0;
      if (typeof value === "number") {
        for (let i = offset; i < end; ++i) {
          buffer[i] = value;
        }
      } else {
        value = isBuffer(value) ? value : from(value, encoding);
        const len = value.byteLength;
        for (let i = 0; i < end - offset; ++i) {
          buffer[i + offset] = value[i % len];
        }
      }
      return buffer;
    }
    function from(value, encodingOrOffset, length) {
      if (typeof value === "string") return fromString(value, encodingOrOffset);
      if (Array.isArray(value)) return fromArray(value);
      if (ArrayBuffer.isView(value)) return fromBuffer(value);
      return fromArrayBuffer(value, encodingOrOffset, length);
    }
    function fromString(string, encoding) {
      const codec = codecFor(encoding);
      const buffer = new Uint8Array(codec.byteLength(string));
      codec.write(buffer, string, 0, buffer.byteLength);
      return buffer;
    }
    function fromArray(array) {
      const buffer = new Uint8Array(array.length);
      buffer.set(array);
      return buffer;
    }
    function fromBuffer(buffer) {
      const copy2 = new Uint8Array(buffer.byteLength);
      copy2.set(buffer);
      return copy2;
    }
    function fromArrayBuffer(arrayBuffer, byteOffset, length) {
      return new Uint8Array(arrayBuffer, byteOffset, length);
    }
    function includes(buffer, value, byteOffset, encoding) {
      return indexOf(buffer, value, byteOffset, encoding) !== -1;
    }
    function bidirectionalIndexOf(buffer, value, byteOffset, encoding, first) {
      if (buffer.byteLength === 0) return -1;
      if (typeof byteOffset === "string") {
        encoding = byteOffset;
        byteOffset = 0;
      } else if (byteOffset === void 0) {
        byteOffset = first ? 0 : buffer.length - 1;
      } else if (byteOffset < 0) {
        byteOffset += buffer.byteLength;
      }
      if (byteOffset >= buffer.byteLength) {
        if (first) return -1;
        else byteOffset = buffer.byteLength - 1;
      } else if (byteOffset < 0) {
        if (first) byteOffset = 0;
        else return -1;
      }
      if (typeof value === "string") {
        value = from(value, encoding);
      } else if (typeof value === "number") {
        value = value & 255;
        if (first) {
          return buffer.indexOf(value, byteOffset);
        } else {
          return buffer.lastIndexOf(value, byteOffset);
        }
      }
      if (value.byteLength === 0) return -1;
      if (first) {
        let foundIndex = -1;
        for (let i = byteOffset; i < buffer.byteLength; i++) {
          if (buffer[i] === value[foundIndex === -1 ? 0 : i - foundIndex]) {
            if (foundIndex === -1) foundIndex = i;
            if (i - foundIndex + 1 === value.byteLength) return foundIndex;
          } else {
            if (foundIndex !== -1) i -= i - foundIndex;
            foundIndex = -1;
          }
        }
      } else {
        if (byteOffset + value.byteLength > buffer.byteLength) {
          byteOffset = buffer.byteLength - value.byteLength;
        }
        for (let i = byteOffset; i >= 0; i--) {
          let found = true;
          for (let j = 0; j < value.byteLength; j++) {
            if (buffer[i + j] !== value[j]) {
              found = false;
              break;
            }
          }
          if (found) return i;
        }
      }
      return -1;
    }
    function indexOf(buffer, value, byteOffset, encoding) {
      return bidirectionalIndexOf(
        buffer,
        value,
        byteOffset,
        encoding,
        true
        /* first */
      );
    }
    function lastIndexOf(buffer, value, byteOffset, encoding) {
      return bidirectionalIndexOf(
        buffer,
        value,
        byteOffset,
        encoding,
        false
        /* last */
      );
    }
    function swap(buffer, n, m) {
      const i = buffer[n];
      buffer[n] = buffer[m];
      buffer[m] = i;
    }
    function swap16(buffer) {
      const len = buffer.byteLength;
      if (len % 2 !== 0) throw new RangeError("Buffer size must be a multiple of 16-bits");
      for (let i = 0; i < len; i += 2) swap(buffer, i, i + 1);
      return buffer;
    }
    function swap32(buffer) {
      const len = buffer.byteLength;
      if (len % 4 !== 0) throw new RangeError("Buffer size must be a multiple of 32-bits");
      for (let i = 0; i < len; i += 4) {
        swap(buffer, i, i + 3);
        swap(buffer, i + 1, i + 2);
      }
      return buffer;
    }
    function swap64(buffer) {
      const len = buffer.byteLength;
      if (len % 8 !== 0) throw new RangeError("Buffer size must be a multiple of 64-bits");
      for (let i = 0; i < len; i += 8) {
        swap(buffer, i, i + 7);
        swap(buffer, i + 1, i + 6);
        swap(buffer, i + 2, i + 5);
        swap(buffer, i + 3, i + 4);
      }
      return buffer;
    }
    function toBuffer(buffer) {
      return buffer;
    }
    function toString(buffer, encoding, start = 0, end = buffer.byteLength) {
      const len = buffer.byteLength;
      if (start >= len) return "";
      if (end <= start) return "";
      if (start < 0) start = 0;
      if (end > len) end = len;
      if (start !== 0 || end < len) buffer = buffer.subarray(start, end);
      return codecFor(encoding).toString(buffer);
    }
    function write(buffer, string, offset, length, encoding) {
      if (offset === void 0) {
        encoding = "utf8";
      } else if (length === void 0 && typeof offset === "string") {
        encoding = offset;
        offset = void 0;
      } else if (encoding === void 0 && typeof length === "string") {
        encoding = length;
        length = void 0;
      }
      return codecFor(encoding).write(buffer, string, offset, length);
    }
    function writeDoubleLE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setFloat64(offset, value, true);
      return offset + 8;
    }
    function writeFloatLE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setFloat32(offset, value, true);
      return offset + 4;
    }
    function writeUInt32LE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setUint32(offset, value, true);
      return offset + 4;
    }
    function writeInt32LE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setInt32(offset, value, true);
      return offset + 4;
    }
    function readDoubleLE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getFloat64(offset, true);
    }
    function readFloatLE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getFloat32(offset, true);
    }
    function readUInt32LE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getUint32(offset, true);
    }
    function readInt32LE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getInt32(offset, true);
    }
    function writeDoubleBE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setFloat64(offset, value, false);
      return offset + 8;
    }
    function writeFloatBE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setFloat32(offset, value, false);
      return offset + 4;
    }
    function writeUInt32BE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setUint32(offset, value, false);
      return offset + 4;
    }
    function writeInt32BE(buffer, value, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      view.setInt32(offset, value, false);
      return offset + 4;
    }
    function readDoubleBE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getFloat64(offset, false);
    }
    function readFloatBE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getFloat32(offset, false);
    }
    function readUInt32BE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getUint32(offset, false);
    }
    function readInt32BE(buffer, offset) {
      if (offset === void 0) offset = 0;
      const view = new DataView(buffer.buffer, buffer.byteOffset, buffer.byteLength);
      return view.getInt32(offset, false);
    }
    module.exports = exports = {
      isBuffer,
      isEncoding,
      alloc,
      allocUnsafe,
      allocUnsafeSlow,
      byteLength,
      compare,
      concat,
      copy,
      equals,
      fill,
      from,
      includes,
      indexOf,
      lastIndexOf,
      swap16,
      swap32,
      swap64,
      toBuffer,
      toString,
      write,
      writeDoubleLE,
      writeFloatLE,
      writeUInt32LE,
      writeInt32LE,
      readDoubleLE,
      readFloatLE,
      readUInt32LE,
      readInt32LE,
      writeDoubleBE,
      writeFloatBE,
      writeUInt32BE,
      writeInt32BE,
      readDoubleBE,
      readFloatBE,
      readUInt32BE,
      readInt32BE
    };
  }
});

// node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/headers.js
var require_headers = __commonJS({
  "node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/headers.js"(exports) {
    var b4a2 = require_browser();
    var ZEROS = "0000000000000000000";
    var SEVENS = "7777777777777777777";
    var ZERO_OFFSET = "0".charCodeAt(0);
    var USTAR_MAGIC = b4a2.from([117, 115, 116, 97, 114, 0]);
    var USTAR_VER = b4a2.from([ZERO_OFFSET, ZERO_OFFSET]);
    var GNU_MAGIC = b4a2.from([117, 115, 116, 97, 114, 32]);
    var GNU_VER = b4a2.from([32, 0]);
    var MASK = 4095;
    var MAGIC_OFFSET = 257;
    var VERSION_OFFSET = 263;
    exports.decodeLongPath = function decodeLongPath(buf, encoding) {
      return decodeStr(buf, 0, buf.length, encoding);
    };
    exports.encodePax = function encodePax(opts) {
      let result = "";
      if (opts.name) result += addLength(" path=" + opts.name + "\n");
      if (opts.linkname) result += addLength(" linkpath=" + opts.linkname + "\n");
      const pax = opts.pax;
      if (pax) {
        for (const key in pax) {
          result += addLength(" " + key + "=" + pax[key] + "\n");
        }
      }
      return b4a2.from(result);
    };
    exports.decodePax = function decodePax(buf) {
      const result = {};
      while (buf.length) {
        let i = 0;
        while (i < buf.length && buf[i] !== 32) i++;
        const len = parseInt(b4a2.toString(buf.subarray(0, i)), 10);
        if (!len) return result;
        const b = b4a2.toString(buf.subarray(i + 1, len - 1));
        const keyIndex = b.indexOf("=");
        if (keyIndex === -1) return result;
        result[b.slice(0, keyIndex)] = b.slice(keyIndex + 1);
        buf = buf.subarray(len);
      }
      return result;
    };
    exports.encode = function encode(opts) {
      const buf = b4a2.alloc(512);
      let name = opts.name;
      let prefix = "";
      if (opts.typeflag === 5 && name[name.length - 1] !== "/") name += "/";
      if (b4a2.byteLength(name) !== name.length) return null;
      while (b4a2.byteLength(name) > 100) {
        const i = name.indexOf("/");
        if (i === -1) return null;
        prefix += prefix ? "/" + name.slice(0, i) : name.slice(0, i);
        name = name.slice(i + 1);
      }
      if (b4a2.byteLength(name) > 100 || b4a2.byteLength(prefix) > 155) return null;
      if (opts.linkname && b4a2.byteLength(opts.linkname) > 100) return null;
      b4a2.write(buf, name);
      b4a2.write(buf, encodeOct(opts.mode & MASK, 6), 100);
      b4a2.write(buf, encodeOct(opts.uid, 6), 108);
      b4a2.write(buf, encodeOct(opts.gid, 6), 116);
      encodeSize(opts.size, buf, 124);
      b4a2.write(buf, encodeOct(opts.mtime.getTime() / 1e3 | 0, 11), 136);
      buf[156] = ZERO_OFFSET + toTypeflag(opts.type);
      if (opts.linkname) b4a2.write(buf, opts.linkname, 157);
      b4a2.copy(USTAR_MAGIC, buf, MAGIC_OFFSET);
      b4a2.copy(USTAR_VER, buf, VERSION_OFFSET);
      if (opts.uname) b4a2.write(buf, opts.uname, 265);
      if (opts.gname) b4a2.write(buf, opts.gname, 297);
      b4a2.write(buf, encodeOct(opts.devmajor || 0, 6), 329);
      b4a2.write(buf, encodeOct(opts.devminor || 0, 6), 337);
      if (prefix) b4a2.write(buf, prefix, 345);
      b4a2.write(buf, encodeOct(cksum(buf), 6), 148);
      return buf;
    };
    exports.decode = function decode(buf, filenameEncoding, allowUnknownFormat) {
      let typeflag = buf[156] === 0 ? 0 : buf[156] - ZERO_OFFSET;
      let name = decodeStr(buf, 0, 100, filenameEncoding);
      const mode = decodeOct(buf, 100, 8);
      const uid = decodeOct(buf, 108, 8);
      const gid = decodeOct(buf, 116, 8);
      const size = decodeOct(buf, 124, 12);
      const mtime = decodeOct(buf, 136, 12);
      const type = toType(typeflag);
      const linkname = buf[157] === 0 ? null : decodeStr(buf, 157, 100, filenameEncoding);
      const uname = decodeStr(buf, 265, 32);
      const gname = decodeStr(buf, 297, 32);
      const devmajor = decodeOct(buf, 329, 8);
      const devminor = decodeOct(buf, 337, 8);
      const c = cksum(buf);
      if (c === 8 * 32) return null;
      if (c !== decodeOct(buf, 148, 8)) throw new Error("Invalid tar header. Maybe the tar is corrupted or it needs to be gunzipped?");
      if (isUSTAR(buf)) {
        if (buf[345]) name = decodeStr(buf, 345, 155, filenameEncoding) + "/" + name;
      } else if (isGNU(buf)) {
      } else {
        if (!allowUnknownFormat) {
          throw new Error("Invalid tar header: unknown format.");
        }
      }
      if (typeflag === 0 && name && name[name.length - 1] === "/") typeflag = 5;
      return {
        name,
        mode,
        uid,
        gid,
        size,
        mtime: new Date(1e3 * mtime),
        type,
        linkname,
        uname,
        gname,
        devmajor,
        devminor,
        pax: null
      };
    };
    function isUSTAR(buf) {
      return b4a2.equals(USTAR_MAGIC, buf.subarray(MAGIC_OFFSET, MAGIC_OFFSET + 6));
    }
    function isGNU(buf) {
      return b4a2.equals(GNU_MAGIC, buf.subarray(MAGIC_OFFSET, MAGIC_OFFSET + 6)) && b4a2.equals(GNU_VER, buf.subarray(VERSION_OFFSET, VERSION_OFFSET + 2));
    }
    function clamp(index, len, defaultValue) {
      if (typeof index !== "number") return defaultValue;
      index = ~~index;
      if (index >= len) return len;
      if (index >= 0) return index;
      index += len;
      if (index >= 0) return index;
      return 0;
    }
    function toType(flag) {
      switch (flag) {
        case 0:
          return "file";
        case 1:
          return "link";
        case 2:
          return "symlink";
        case 3:
          return "character-device";
        case 4:
          return "block-device";
        case 5:
          return "directory";
        case 6:
          return "fifo";
        case 7:
          return "contiguous-file";
        case 72:
          return "pax-header";
        case 55:
          return "pax-global-header";
        case 27:
          return "gnu-long-link-path";
        case 28:
        case 30:
          return "gnu-long-path";
      }
      return null;
    }
    function toTypeflag(flag) {
      switch (flag) {
        case "file":
          return 0;
        case "link":
          return 1;
        case "symlink":
          return 2;
        case "character-device":
          return 3;
        case "block-device":
          return 4;
        case "directory":
          return 5;
        case "fifo":
          return 6;
        case "contiguous-file":
          return 7;
        case "pax-header":
          return 72;
      }
      return 0;
    }
    function indexOf(block, num, offset, end) {
      for (; offset < end; offset++) {
        if (block[offset] === num) return offset;
      }
      return end;
    }
    function cksum(block) {
      let sum = 8 * 32;
      for (let i = 0; i < 148; i++) sum += block[i];
      for (let j = 156; j < 512; j++) sum += block[j];
      return sum;
    }
    function encodeOct(val, n) {
      val = val.toString(8);
      if (val.length > n) return SEVENS.slice(0, n) + " ";
      return ZEROS.slice(0, n - val.length) + val + " ";
    }
    function encodeSizeBin(num, buf, off) {
      buf[off] = 128;
      for (let i = 11; i > 0; i--) {
        buf[off + i] = num & 255;
        num = Math.floor(num / 256);
      }
    }
    function encodeSize(num, buf, off) {
      if (num.toString(8).length > 11) {
        encodeSizeBin(num, buf, off);
      } else {
        b4a2.write(buf, encodeOct(num, 11), off);
      }
    }
    function parse256(buf) {
      let positive;
      if (buf[0] === 128) positive = true;
      else if (buf[0] === 255) positive = false;
      else return null;
      const tuple = [];
      let i;
      for (i = buf.length - 1; i > 0; i--) {
        const byte = buf[i];
        if (positive) tuple.push(byte);
        else tuple.push(255 - byte);
      }
      let sum = 0;
      const l = tuple.length;
      for (i = 0; i < l; i++) {
        sum += tuple[i] * Math.pow(256, i);
      }
      return positive ? sum : -1 * sum;
    }
    function decodeOct(val, offset, length) {
      val = val.subarray(offset, offset + length);
      offset = 0;
      if (val[offset] & 128) {
        return parse256(val);
      } else {
        while (offset < val.length && val[offset] === 32) offset++;
        const end = clamp(indexOf(val, 32, offset, val.length), val.length, val.length);
        while (offset < end && val[offset] === 0) offset++;
        if (end === offset) return 0;
        return parseInt(b4a2.toString(val.subarray(offset, end)), 8);
      }
    }
    function decodeStr(val, offset, length, encoding) {
      return b4a2.toString(val.subarray(offset, indexOf(val, 0, offset, offset + length)), encoding);
    }
    function addLength(str) {
      const len = b4a2.byteLength(str);
      let digits = Math.floor(Math.log(len) / Math.log(10)) + 1;
      if (len + digits >= Math.pow(10, digits)) digits++;
      return len + digits + str;
    }
  }
});

// node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/extract.js
var require_extract = __commonJS({
  "node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/extract.js"(exports, module) {
    var { Writable: Writable2, Readable: Readable2, getStreamError } = require_streamx();
    var FIFO = require_fast_fifo();
    var b4a2 = require_browser();
    var headers = require_headers();
    var EMPTY = b4a2.alloc(0);
    var BufferList = class {
      constructor() {
        this.buffered = 0;
        this.shifted = 0;
        this.queue = new FIFO();
        this._offset = 0;
      }
      push(buffer) {
        this.buffered += buffer.byteLength;
        this.queue.push(buffer);
      }
      shiftFirst(size) {
        return this._buffered === 0 ? null : this._next(size);
      }
      shift(size) {
        if (size > this.buffered) return null;
        if (size === 0) return EMPTY;
        let chunk = this._next(size);
        if (size === chunk.byteLength) return chunk;
        const chunks = [chunk];
        while ((size -= chunk.byteLength) > 0) {
          chunk = this._next(size);
          chunks.push(chunk);
        }
        return b4a2.concat(chunks);
      }
      _next(size) {
        const buf = this.queue.peek();
        const rem = buf.byteLength - this._offset;
        if (size >= rem) {
          const sub = this._offset ? buf.subarray(this._offset, buf.byteLength) : buf;
          this.queue.shift();
          this._offset = 0;
          this.buffered -= rem;
          this.shifted += rem;
          return sub;
        }
        this.buffered -= size;
        this.shifted += size;
        return buf.subarray(this._offset, this._offset += size);
      }
    };
    var Source = class extends Readable2 {
      constructor(self2, header, offset) {
        super();
        this.header = header;
        this.offset = offset;
        this._parent = self2;
      }
      _read(cb) {
        if (this.header.size === 0) {
          this.push(null);
        }
        if (this._parent._stream === this) {
          this._parent._update();
        }
        cb(null);
      }
      _predestroy() {
        this._parent.destroy(getStreamError(this));
      }
      _detach() {
        if (this._parent._stream === this) {
          this._parent._stream = null;
          this._parent._missing = overflow(this.header.size);
          this._parent._update();
        }
      }
      _destroy(cb) {
        this._detach();
        cb(null);
      }
    };
    var Extract = class extends Writable2 {
      constructor(opts) {
        super(opts);
        if (!opts) opts = {};
        this._buffer = new BufferList();
        this._offset = 0;
        this._header = null;
        this._stream = null;
        this._missing = 0;
        this._longHeader = false;
        this._callback = noop;
        this._locked = false;
        this._finished = false;
        this._pax = null;
        this._paxGlobal = null;
        this._gnuLongPath = null;
        this._gnuLongLinkPath = null;
        this._filenameEncoding = opts.filenameEncoding || "utf-8";
        this._allowUnknownFormat = !!opts.allowUnknownFormat;
        this._unlockBound = this._unlock.bind(this);
      }
      _unlock(err) {
        this._locked = false;
        if (err) {
          this.destroy(err);
          this._continueWrite(err);
          return;
        }
        this._update();
      }
      _consumeHeader() {
        if (this._locked) return false;
        this._offset = this._buffer.shifted;
        try {
          this._header = headers.decode(this._buffer.shift(512), this._filenameEncoding, this._allowUnknownFormat);
        } catch (err) {
          this._continueWrite(err);
          return false;
        }
        if (!this._header) return true;
        switch (this._header.type) {
          case "gnu-long-path":
          case "gnu-long-link-path":
          case "pax-global-header":
          case "pax-header":
            this._longHeader = true;
            this._missing = this._header.size;
            return true;
        }
        this._locked = true;
        this._applyLongHeaders();
        if (this._header.size === 0 || this._header.type === "directory") {
          this.emit("entry", this._header, this._createStream(), this._unlockBound);
          return true;
        }
        this._stream = this._createStream();
        this._missing = this._header.size;
        this.emit("entry", this._header, this._stream, this._unlockBound);
        return true;
      }
      _applyLongHeaders() {
        if (this._gnuLongPath) {
          this._header.name = this._gnuLongPath;
          this._gnuLongPath = null;
        }
        if (this._gnuLongLinkPath) {
          this._header.linkname = this._gnuLongLinkPath;
          this._gnuLongLinkPath = null;
        }
        if (this._pax) {
          if (this._pax.path) this._header.name = this._pax.path;
          if (this._pax.linkpath) this._header.linkname = this._pax.linkpath;
          if (this._pax.size) this._header.size = parseInt(this._pax.size, 10);
          this._header.pax = this._pax;
          this._pax = null;
        }
      }
      _decodeLongHeader(buf) {
        switch (this._header.type) {
          case "gnu-long-path":
            this._gnuLongPath = headers.decodeLongPath(buf, this._filenameEncoding);
            break;
          case "gnu-long-link-path":
            this._gnuLongLinkPath = headers.decodeLongPath(buf, this._filenameEncoding);
            break;
          case "pax-global-header":
            this._paxGlobal = headers.decodePax(buf);
            break;
          case "pax-header":
            this._pax = this._paxGlobal === null ? headers.decodePax(buf) : Object.assign({}, this._paxGlobal, headers.decodePax(buf));
            break;
        }
      }
      _consumeLongHeader() {
        this._longHeader = false;
        this._missing = overflow(this._header.size);
        const buf = this._buffer.shift(this._header.size);
        try {
          this._decodeLongHeader(buf);
        } catch (err) {
          this._continueWrite(err);
          return false;
        }
        return true;
      }
      _consumeStream() {
        const buf = this._buffer.shiftFirst(this._missing);
        if (buf === null) return false;
        this._missing -= buf.byteLength;
        const drained2 = this._stream.push(buf);
        if (this._missing === 0) {
          this._stream.push(null);
          if (drained2) this._stream._detach();
          return drained2 && this._locked === false;
        }
        return drained2;
      }
      _createStream() {
        return new Source(this, this._header, this._offset);
      }
      _update() {
        while (this._buffer.buffered > 0 && !this.destroying) {
          if (this._missing > 0) {
            if (this._stream !== null) {
              if (this._consumeStream() === false) return;
              continue;
            }
            if (this._longHeader === true) {
              if (this._missing > this._buffer.buffered) break;
              if (this._consumeLongHeader() === false) return false;
              continue;
            }
            const ignore = this._buffer.shiftFirst(this._missing);
            if (ignore !== null) this._missing -= ignore.byteLength;
            continue;
          }
          if (this._buffer.buffered < 512) break;
          if (this._stream !== null || this._consumeHeader() === false) return;
        }
        this._continueWrite(null);
      }
      _continueWrite(err) {
        const cb = this._callback;
        this._callback = noop;
        cb(err);
      }
      _write(data, cb) {
        this._callback = cb;
        this._buffer.push(data);
        this._update();
      }
      _final(cb) {
        this._finished = this._missing === 0 && this._buffer.buffered === 0;
        cb(this._finished ? null : new Error("Unexpected end of data"));
      }
      _predestroy() {
        this._continueWrite(null);
      }
      _destroy(cb) {
        if (this._stream) this._stream.destroy(getStreamError(this));
        cb(null);
      }
      [Symbol.asyncIterator]() {
        let error = null;
        let promiseResolve = null;
        let promiseReject = null;
        let entryStream = null;
        let entryCallback = null;
        const extract = this;
        this.on("entry", onentry);
        this.on("error", (err) => {
          error = err;
        });
        this.on("close", onclose);
        return {
          [Symbol.asyncIterator]() {
            return this;
          },
          next() {
            return new Promise(onnext);
          },
          return() {
            return destroy(null);
          },
          throw(err) {
            return destroy(err);
          }
        };
        function consumeCallback(err) {
          if (!entryCallback) return;
          const cb = entryCallback;
          entryCallback = null;
          cb(err);
        }
        function onnext(resolve, reject) {
          if (error) {
            return reject(error);
          }
          if (entryStream) {
            resolve({ value: entryStream, done: false });
            entryStream = null;
            return;
          }
          promiseResolve = resolve;
          promiseReject = reject;
          consumeCallback(null);
          if (extract._finished && promiseResolve) {
            promiseResolve({ value: void 0, done: true });
            promiseResolve = promiseReject = null;
          }
        }
        function onentry(header, stream, callback) {
          entryCallback = callback;
          stream.on("error", noop);
          if (promiseResolve) {
            promiseResolve({ value: stream, done: false });
            promiseResolve = promiseReject = null;
          } else {
            entryStream = stream;
          }
        }
        function onclose() {
          consumeCallback(error);
          if (!promiseResolve) return;
          if (error) promiseReject(error);
          else promiseResolve({ value: void 0, done: true });
          promiseResolve = promiseReject = null;
        }
        function destroy(err) {
          extract.destroy(err);
          consumeCallback(err);
          return new Promise((resolve, reject) => {
            if (extract.destroyed) return resolve({ value: void 0, done: true });
            extract.once("close", function() {
              if (err) reject(err);
              else resolve({ value: void 0, done: true });
            });
          });
        }
      }
    };
    module.exports = function extract(opts) {
      return new Extract(opts);
    };
    function noop() {
    }
    function overflow(size) {
      size &= 511;
      return size && 512 - size;
    }
  }
});

// (disabled):fs
var require_fs = __commonJS({
  "(disabled):fs"() {
  }
});

// node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/constants.js
var require_constants = __commonJS({
  "node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/constants.js"(exports, module) {
    var constants = {
      // just for envs without fs
      S_IFMT: 61440,
      S_IFDIR: 16384,
      S_IFCHR: 8192,
      S_IFBLK: 24576,
      S_IFIFO: 4096,
      S_IFLNK: 40960
    };
    try {
      module.exports = require_fs().constants || constants;
    } catch {
      module.exports = constants;
    }
  }
});

// node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/pack.js
var require_pack = __commonJS({
  "node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/pack.js"(exports, module) {
    var { Readable: Readable2, Writable: Writable2, getStreamError } = require_streamx();
    var b4a2 = require_browser();
    var constants = require_constants();
    var headers = require_headers();
    var DMODE = 493;
    var FMODE = 420;
    var END_OF_TAR = b4a2.alloc(1024);
    var Sink = class extends Writable2 {
      constructor(pack, header, callback) {
        super({ mapWritable, eagerOpen: true });
        this.written = 0;
        this.header = header;
        this._callback = callback;
        this._linkname = null;
        this._isLinkname = header.type === "symlink" && !header.linkname;
        this._isVoid = header.type !== "file" && header.type !== "contiguous-file";
        this._finished = false;
        this._pack = pack;
        this._openCallback = null;
        if (this._pack._stream === null) this._pack._stream = this;
        else this._pack._pending.push(this);
      }
      _open(cb) {
        this._openCallback = cb;
        if (this._pack._stream === this) this._continueOpen();
      }
      _continuePack(err) {
        if (this._callback === null) return;
        const callback = this._callback;
        this._callback = null;
        callback(err);
      }
      _continueOpen() {
        if (this._pack._stream === null) this._pack._stream = this;
        const cb = this._openCallback;
        this._openCallback = null;
        if (cb === null) return;
        if (this._pack.destroying) return cb(new Error("pack stream destroyed"));
        if (this._pack._finalized) return cb(new Error("pack stream is already finalized"));
        this._pack._stream = this;
        if (!this._isLinkname) {
          this._pack._encode(this.header);
        }
        if (this._isVoid) {
          this._finish();
          this._continuePack(null);
        }
        cb(null);
      }
      _write(data, cb) {
        if (this._isLinkname) {
          this._linkname = this._linkname ? b4a2.concat([this._linkname, data]) : data;
          return cb(null);
        }
        if (this._isVoid) {
          if (data.byteLength > 0) {
            return cb(new Error("No body allowed for this entry"));
          }
          return cb();
        }
        this.written += data.byteLength;
        if (this._pack.push(data)) return cb();
        this._pack._drain = cb;
      }
      _finish() {
        if (this._finished) return;
        this._finished = true;
        if (this._isLinkname) {
          this.header.linkname = this._linkname ? b4a2.toString(this._linkname, "utf-8") : "";
          this._pack._encode(this.header);
        }
        overflow(this._pack, this.header.size);
        this._pack._done(this);
      }
      _final(cb) {
        if (this.written !== this.header.size) {
          return cb(new Error("Size mismatch"));
        }
        this._finish();
        cb(null);
      }
      _getError() {
        return getStreamError(this) || new Error("tar entry destroyed");
      }
      _predestroy() {
        this._pack.destroy(this._getError());
      }
      _destroy(cb) {
        this._pack._done(this);
        this._continuePack(this._finished ? null : this._getError());
        cb();
      }
    };
    var Pack = class extends Readable2 {
      constructor(opts) {
        super(opts);
        this._drain = noop;
        this._finalized = false;
        this._finalizing = false;
        this._pending = [];
        this._stream = null;
      }
      entry(header, buffer, callback) {
        if (this._finalized || this.destroying) throw new Error("already finalized or destroyed");
        if (typeof buffer === "function") {
          callback = buffer;
          buffer = null;
        }
        if (!callback) callback = noop;
        if (!header.size || header.type === "symlink") header.size = 0;
        if (!header.type) header.type = modeToType(header.mode);
        if (!header.mode) header.mode = header.type === "directory" ? DMODE : FMODE;
        if (!header.uid) header.uid = 0;
        if (!header.gid) header.gid = 0;
        if (!header.mtime) header.mtime = /* @__PURE__ */ new Date();
        if (typeof buffer === "string") buffer = b4a2.from(buffer);
        const sink = new Sink(this, header, callback);
        if (b4a2.isBuffer(buffer)) {
          header.size = buffer.byteLength;
          sink.write(buffer);
          sink.end();
          return sink;
        }
        if (sink._isVoid) {
          return sink;
        }
        return sink;
      }
      finalize() {
        if (this._stream || this._pending.length > 0) {
          this._finalizing = true;
          return;
        }
        if (this._finalized) return;
        this._finalized = true;
        this.push(END_OF_TAR);
        this.push(null);
      }
      _done(stream) {
        if (stream !== this._stream) return;
        this._stream = null;
        if (this._finalizing) this.finalize();
        if (this._pending.length) this._pending.shift()._continueOpen();
      }
      _encode(header) {
        if (!header.pax) {
          const buf = headers.encode(header);
          if (buf) {
            this.push(buf);
            return;
          }
        }
        this._encodePax(header);
      }
      _encodePax(header) {
        const paxHeader = headers.encodePax({
          name: header.name,
          linkname: header.linkname,
          pax: header.pax
        });
        const newHeader = {
          name: "PaxHeader",
          mode: header.mode,
          uid: header.uid,
          gid: header.gid,
          size: paxHeader.byteLength,
          mtime: header.mtime,
          type: "pax-header",
          linkname: header.linkname && "PaxHeader",
          uname: header.uname,
          gname: header.gname,
          devmajor: header.devmajor,
          devminor: header.devminor
        };
        this.push(headers.encode(newHeader));
        this.push(paxHeader);
        overflow(this, paxHeader.byteLength);
        newHeader.size = header.size;
        newHeader.type = header.type;
        this.push(headers.encode(newHeader));
      }
      _doDrain() {
        const drain = this._drain;
        this._drain = noop;
        drain();
      }
      _predestroy() {
        const err = getStreamError(this);
        if (this._stream) this._stream.destroy(err);
        while (this._pending.length) {
          const stream = this._pending.shift();
          stream.destroy(err);
          stream._continueOpen();
        }
        this._doDrain();
      }
      _read(cb) {
        this._doDrain();
        cb();
      }
    };
    module.exports = function pack(opts) {
      return new Pack(opts);
    };
    function modeToType(mode) {
      switch (mode & constants.S_IFMT) {
        case constants.S_IFBLK:
          return "block-device";
        case constants.S_IFCHR:
          return "character-device";
        case constants.S_IFDIR:
          return "directory";
        case constants.S_IFIFO:
          return "fifo";
        case constants.S_IFLNK:
          return "symlink";
      }
      return "file";
    }
    function noop() {
    }
    function overflow(self2, size) {
      size &= 511;
      if (size) self2.push(END_OF_TAR.subarray(0, 512 - size));
    }
    function mapWritable(buf) {
      return b4a2.isBuffer(buf) ? buf : b4a2.from(buf);
    }
  }
});

// node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/index.js
var require_tar_stream = __commonJS({
  "node_modules/.pnpm/tar-stream@3.1.7/node_modules/tar-stream/index.js"(exports) {
    exports.extract = require_extract();
    exports.pack = require_pack();
  }
});

// src/background/index.ts
var import_tar_stream = __toESM(require_tar_stream(), 1);

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/errors/HTTPError.js
var HTTPError = class extends Error {
  response;
  request;
  options;
  constructor(response, request, options) {
    const code = response.status || response.status === 0 ? response.status : "";
    const title = response.statusText || "";
    const status = `${code} ${title}`.trim();
    const reason = status ? `status code ${status}` : "an unknown error";
    super(`Request failed with ${reason}: ${request.method} ${request.url}`);
    this.name = "HTTPError";
    this.response = response;
    this.request = request;
    this.options = options;
  }
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/errors/TimeoutError.js
var TimeoutError = class extends Error {
  request;
  constructor(request) {
    super(`Request timed out: ${request.method} ${request.url}`);
    this.name = "TimeoutError";
    this.request = request;
  }
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/is.js
var isObject = (value) => value !== null && typeof value === "object";

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/merge.js
var validateAndMerge = (...sources) => {
  for (const source of sources) {
    if ((!isObject(source) || Array.isArray(source)) && source !== void 0) {
      throw new TypeError("The `options` argument must be an object");
    }
  }
  return deepMerge({}, ...sources);
};
var mergeHeaders = (source1 = {}, source2 = {}) => {
  const result = new globalThis.Headers(source1);
  const isHeadersInstance = source2 instanceof globalThis.Headers;
  const source = new globalThis.Headers(source2);
  for (const [key, value] of source.entries()) {
    if (isHeadersInstance && value === "undefined" || value === void 0) {
      result.delete(key);
    } else {
      result.set(key, value);
    }
  }
  return result;
};
function newHookValue(original, incoming, property) {
  return Object.hasOwn(incoming, property) && incoming[property] === void 0 ? [] : deepMerge(original[property] ?? [], incoming[property] ?? []);
}
var mergeHooks = (original = {}, incoming = {}) => ({
  beforeRequest: newHookValue(original, incoming, "beforeRequest"),
  beforeRetry: newHookValue(original, incoming, "beforeRetry"),
  afterResponse: newHookValue(original, incoming, "afterResponse"),
  beforeError: newHookValue(original, incoming, "beforeError")
});
var deepMerge = (...sources) => {
  let returnValue = {};
  let headers = {};
  let hooks = {};
  for (const source of sources) {
    if (Array.isArray(source)) {
      if (!Array.isArray(returnValue)) {
        returnValue = [];
      }
      returnValue = [...returnValue, ...source];
    } else if (isObject(source)) {
      for (let [key, value] of Object.entries(source)) {
        if (isObject(value) && key in returnValue) {
          value = deepMerge(returnValue[key], value);
        }
        returnValue = { ...returnValue, [key]: value };
      }
      if (isObject(source.hooks)) {
        hooks = mergeHooks(hooks, source.hooks);
        returnValue.hooks = hooks;
      }
      if (isObject(source.headers)) {
        headers = mergeHeaders(headers, source.headers);
        returnValue.headers = headers;
      }
    }
  }
  return returnValue;
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/core/constants.js
var supportsRequestStreams = (() => {
  let duplexAccessed = false;
  let hasContentType = false;
  const supportsReadableStream = typeof globalThis.ReadableStream === "function";
  const supportsRequest = typeof globalThis.Request === "function";
  if (supportsReadableStream && supportsRequest) {
    try {
      hasContentType = new globalThis.Request("https://empty.invalid", {
        body: new globalThis.ReadableStream(),
        method: "POST",
        // @ts-expect-error - Types are outdated.
        get duplex() {
          duplexAccessed = true;
          return "half";
        }
      }).headers.has("Content-Type");
    } catch (error) {
      if (error instanceof Error && error.message === "unsupported BodyInit type") {
        return false;
      }
      throw error;
    }
  }
  return duplexAccessed && !hasContentType;
})();
var supportsAbortController = typeof globalThis.AbortController === "function";
var supportsResponseStreams = typeof globalThis.ReadableStream === "function";
var supportsFormData = typeof globalThis.FormData === "function";
var requestMethods = ["get", "post", "put", "patch", "head", "delete"];
var validate = () => void 0;
validate();
var responseTypes = {
  json: "application/json",
  text: "text/*",
  formData: "multipart/form-data",
  arrayBuffer: "*/*",
  blob: "*/*"
};
var maxSafeTimeout = 2147483647;
var stop = Symbol("stop");
var kyOptionKeys = {
  json: true,
  parseJson: true,
  stringifyJson: true,
  searchParams: true,
  prefixUrl: true,
  retry: true,
  timeout: true,
  hooks: true,
  throwHttpErrors: true,
  onDownloadProgress: true,
  fetch: true
};
var requestOptionsRegistry = {
  method: true,
  headers: true,
  body: true,
  mode: true,
  credentials: true,
  cache: true,
  redirect: true,
  referrer: true,
  referrerPolicy: true,
  integrity: true,
  keepalive: true,
  signal: true,
  window: true,
  dispatcher: true,
  duplex: true,
  priority: true
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/normalize.js
var normalizeRequestMethod = (input) => requestMethods.includes(input) ? input.toUpperCase() : input;
var retryMethods = ["get", "put", "head", "delete", "options", "trace"];
var retryStatusCodes = [408, 413, 429, 500, 502, 503, 504];
var retryAfterStatusCodes = [413, 429, 503];
var defaultRetryOptions = {
  limit: 2,
  methods: retryMethods,
  statusCodes: retryStatusCodes,
  afterStatusCodes: retryAfterStatusCodes,
  maxRetryAfter: Number.POSITIVE_INFINITY,
  backoffLimit: Number.POSITIVE_INFINITY,
  delay: (attemptCount) => 0.3 * 2 ** (attemptCount - 1) * 1e3
};
var normalizeRetryOptions = (retry = {}) => {
  if (typeof retry === "number") {
    return {
      ...defaultRetryOptions,
      limit: retry
    };
  }
  if (retry.methods && !Array.isArray(retry.methods)) {
    throw new Error("retry.methods must be an array");
  }
  if (retry.statusCodes && !Array.isArray(retry.statusCodes)) {
    throw new Error("retry.statusCodes must be an array");
  }
  return {
    ...defaultRetryOptions,
    ...retry
  };
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/timeout.js
async function timeout(request, init, abortController, options) {
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      if (abortController) {
        abortController.abort();
      }
      reject(new TimeoutError(request));
    }, options.timeout);
    void options.fetch(request, init).then(resolve).catch(reject).then(() => {
      clearTimeout(timeoutId);
    });
  });
}

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/delay.js
async function delay(ms, { signal }) {
  return new Promise((resolve, reject) => {
    if (signal) {
      signal.throwIfAborted();
      signal.addEventListener("abort", abortHandler, { once: true });
    }
    function abortHandler() {
      clearTimeout(timeoutId);
      reject(signal.reason);
    }
    const timeoutId = setTimeout(() => {
      signal?.removeEventListener("abort", abortHandler);
      resolve();
    }, ms);
  });
}

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/utils/options.js
var findUnknownOptions = (request, options) => {
  const unknownOptions = {};
  for (const key in options) {
    if (!(key in requestOptionsRegistry) && !(key in kyOptionKeys) && !(key in request)) {
      unknownOptions[key] = options[key];
    }
  }
  return unknownOptions;
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/core/Ky.js
var Ky = class _Ky {
  static create(input, options) {
    const ky2 = new _Ky(input, options);
    const function_ = async () => {
      if (typeof ky2._options.timeout === "number" && ky2._options.timeout > maxSafeTimeout) {
        throw new RangeError(`The \`timeout\` option cannot be greater than ${maxSafeTimeout}`);
      }
      await Promise.resolve();
      let response = await ky2._fetch();
      for (const hook of ky2._options.hooks.afterResponse) {
        const modifiedResponse = await hook(ky2.request, ky2._options, ky2._decorateResponse(response.clone()));
        if (modifiedResponse instanceof globalThis.Response) {
          response = modifiedResponse;
        }
      }
      ky2._decorateResponse(response);
      if (!response.ok && ky2._options.throwHttpErrors) {
        let error = new HTTPError(response, ky2.request, ky2._options);
        for (const hook of ky2._options.hooks.beforeError) {
          error = await hook(error);
        }
        throw error;
      }
      if (ky2._options.onDownloadProgress) {
        if (typeof ky2._options.onDownloadProgress !== "function") {
          throw new TypeError("The `onDownloadProgress` option must be a function");
        }
        if (!supportsResponseStreams) {
          throw new Error("Streams are not supported in your environment. `ReadableStream` is missing.");
        }
        return ky2._stream(response.clone(), ky2._options.onDownloadProgress);
      }
      return response;
    };
    const isRetriableMethod = ky2._options.retry.methods.includes(ky2.request.method.toLowerCase());
    const result = isRetriableMethod ? ky2._retry(function_) : function_();
    for (const [type, mimeType] of Object.entries(responseTypes)) {
      result[type] = async () => {
        ky2.request.headers.set("accept", ky2.request.headers.get("accept") || mimeType);
        const response = await result;
        if (type === "json") {
          if (response.status === 204) {
            return "";
          }
          const arrayBuffer = await response.clone().arrayBuffer();
          const responseSize = arrayBuffer.byteLength;
          if (responseSize === 0) {
            return "";
          }
          if (options.parseJson) {
            return options.parseJson(await response.text());
          }
        }
        return response[type]();
      };
    }
    return result;
  }
  request;
  abortController;
  _retryCount = 0;
  _input;
  _options;
  // eslint-disable-next-line complexity
  constructor(input, options = {}) {
    this._input = input;
    this._options = {
      ...options,
      headers: mergeHeaders(this._input.headers, options.headers),
      hooks: mergeHooks({
        beforeRequest: [],
        beforeRetry: [],
        beforeError: [],
        afterResponse: []
      }, options.hooks),
      method: normalizeRequestMethod(options.method ?? this._input.method),
      // eslint-disable-next-line @typescript-eslint/prefer-nullish-coalescing
      prefixUrl: String(options.prefixUrl || ""),
      retry: normalizeRetryOptions(options.retry),
      throwHttpErrors: options.throwHttpErrors !== false,
      timeout: options.timeout ?? 1e4,
      fetch: options.fetch ?? globalThis.fetch.bind(globalThis)
    };
    if (typeof this._input !== "string" && !(this._input instanceof URL || this._input instanceof globalThis.Request)) {
      throw new TypeError("`input` must be a string, URL, or Request");
    }
    if (this._options.prefixUrl && typeof this._input === "string") {
      if (this._input.startsWith("/")) {
        throw new Error("`input` must not begin with a slash when using `prefixUrl`");
      }
      if (!this._options.prefixUrl.endsWith("/")) {
        this._options.prefixUrl += "/";
      }
      this._input = this._options.prefixUrl + this._input;
    }
    if (supportsAbortController) {
      this.abortController = new globalThis.AbortController();
      const originalSignal = this._options.signal ?? this._input.signal;
      if (originalSignal?.aborted) {
        this.abortController.abort(originalSignal?.reason);
      }
      originalSignal?.addEventListener("abort", () => {
        this.abortController.abort(originalSignal.reason);
      });
      this._options.signal = this.abortController.signal;
    }
    if (supportsRequestStreams) {
      this._options.duplex = "half";
    }
    if (this._options.json !== void 0) {
      this._options.body = this._options.stringifyJson?.(this._options.json) ?? JSON.stringify(this._options.json);
      this._options.headers.set("content-type", this._options.headers.get("content-type") ?? "application/json");
    }
    this.request = new globalThis.Request(this._input, this._options);
    if (this._options.searchParams) {
      const textSearchParams = typeof this._options.searchParams === "string" ? this._options.searchParams.replace(/^\?/, "") : new URLSearchParams(this._options.searchParams).toString();
      const searchParams = "?" + textSearchParams;
      const url = this.request.url.replace(/(?:\?.*?)?(?=#|$)/, searchParams);
      if ((supportsFormData && this._options.body instanceof globalThis.FormData || this._options.body instanceof URLSearchParams) && !(this._options.headers && this._options.headers["content-type"])) {
        this.request.headers.delete("content-type");
      }
      this.request = new globalThis.Request(new globalThis.Request(url, { ...this.request }), this._options);
    }
  }
  _calculateRetryDelay(error) {
    this._retryCount++;
    if (this._retryCount > this._options.retry.limit || error instanceof TimeoutError) {
      throw error;
    }
    if (error instanceof HTTPError) {
      if (!this._options.retry.statusCodes.includes(error.response.status)) {
        throw error;
      }
      const retryAfter = error.response.headers.get("Retry-After") ?? error.response.headers.get("RateLimit-Reset") ?? error.response.headers.get("X-RateLimit-Reset") ?? error.response.headers.get("X-Rate-Limit-Reset");
      if (retryAfter && this._options.retry.afterStatusCodes.includes(error.response.status)) {
        let after = Number(retryAfter) * 1e3;
        if (Number.isNaN(after)) {
          after = Date.parse(retryAfter) - Date.now();
        } else if (after >= Date.parse("2024-01-01")) {
          after -= Date.now();
        }
        const max = this._options.retry.maxRetryAfter ?? after;
        return after < max ? after : max;
      }
      if (error.response.status === 413) {
        throw error;
      }
    }
    const retryDelay = this._options.retry.delay(this._retryCount);
    return Math.min(this._options.retry.backoffLimit, retryDelay);
  }
  _decorateResponse(response) {
    if (this._options.parseJson) {
      response.json = async () => this._options.parseJson(await response.text());
    }
    return response;
  }
  async _retry(function_) {
    try {
      return await function_();
    } catch (error) {
      const ms = Math.min(this._calculateRetryDelay(error), maxSafeTimeout);
      if (this._retryCount < 1) {
        throw error;
      }
      await delay(ms, { signal: this._options.signal });
      for (const hook of this._options.hooks.beforeRetry) {
        const hookResult = await hook({
          request: this.request,
          options: this._options,
          error,
          retryCount: this._retryCount
        });
        if (hookResult === stop) {
          return;
        }
      }
      return this._retry(function_);
    }
  }
  async _fetch() {
    for (const hook of this._options.hooks.beforeRequest) {
      const result = await hook(this.request, this._options);
      if (result instanceof Request) {
        this.request = result;
        break;
      }
      if (result instanceof Response) {
        return result;
      }
    }
    const nonRequestOptions = findUnknownOptions(this.request, this._options);
    const mainRequest = this.request;
    this.request = mainRequest.clone();
    if (this._options.timeout === false) {
      return this._options.fetch(mainRequest, nonRequestOptions);
    }
    return timeout(mainRequest, nonRequestOptions, this.abortController, this._options);
  }
  /* istanbul ignore next */
  _stream(response, onDownloadProgress) {
    const totalBytes = Number(response.headers.get("content-length")) || 0;
    let transferredBytes = 0;
    if (response.status === 204) {
      if (onDownloadProgress) {
        onDownloadProgress({ percent: 1, totalBytes, transferredBytes }, new Uint8Array());
      }
      return new globalThis.Response(null, {
        status: response.status,
        statusText: response.statusText,
        headers: response.headers
      });
    }
    return new globalThis.Response(new globalThis.ReadableStream({
      async start(controller) {
        const reader = response.body.getReader();
        if (onDownloadProgress) {
          onDownloadProgress({ percent: 0, transferredBytes: 0, totalBytes }, new Uint8Array());
        }
        async function read() {
          const { done, value } = await reader.read();
          if (done) {
            controller.close();
            return;
          }
          if (onDownloadProgress) {
            transferredBytes += value.byteLength;
            const percent = totalBytes === 0 ? 0 : transferredBytes / totalBytes;
            onDownloadProgress({ percent, transferredBytes, totalBytes }, value);
          }
          controller.enqueue(value);
          await read();
        }
        await read();
      }
    }), {
      status: response.status,
      statusText: response.statusText,
      headers: response.headers
    });
  }
};

// node_modules/.pnpm/ky@1.7.4/node_modules/ky/distribution/index.js
var createInstance = (defaults) => {
  const ky2 = (input, options) => Ky.create(input, validateAndMerge(defaults, options));
  for (const method of requestMethods) {
    ky2[method] = (input, options) => Ky.create(input, validateAndMerge(defaults, options, { method }));
  }
  ky2.create = (newDefaults) => createInstance(validateAndMerge(newDefaults));
  ky2.extend = (newDefaults) => {
    if (typeof newDefaults === "function") {
      newDefaults = newDefaults(defaults ?? {});
    }
    return createInstance(validateAndMerge(defaults, newDefaults));
  };
  ky2.stop = stop;
  return ky2;
};
var ky = createInstance();
var distribution_default = ky;

// src/lib/imgpull.ts
var Monitor = class {
  constructor(name, arch) {
    this.name = name;
    this.arch = arch;
  }
  layers = {};
  error = null;
  id = crypto.randomUUID();
  setLayers(layers) {
    for (const layer of layers) {
      this.layers[layer] = [-1, -1];
    }
  }
  setLayerProgress(layer, downloaded, total) {
    this.layers[layer] = [downloaded, total];
  }
  setError(error) {
    this.error = error;
  }
};
var ImageRef = class _ImageRef {
  constructor(namespace, name, tag = "latest", registry, digest) {
    this.namespace = namespace;
    this.name = name;
    this.tag = tag;
    this.registry = registry;
    this.digest = digest;
  }
  static parse(image) {
    const regex = /^(?:([^\/]+)\/)?(?:([^\/]+)\/)?([^@:]+)(?:[:@](.+))?$/;
    const matches = image.match(regex);
    if (!matches) {
      throw new Error(`Invalid image name: ${image}`);
    }
    let [, registry, namespace, name, reference] = matches;
    if (!namespace && registry) {
      namespace = registry;
      registry = "";
    }
    if (reference?.startsWith("sha256:")) {
      return new _ImageRef(
        namespace || "library",
        name,
        "latest",
        registry,
        reference
      );
    }
    return new _ImageRef(
      namespace || "library",
      name,
      reference || "latest",
      registry
    );
  }
  imageName() {
    let out = "";
    if (this.registry) {
      out += `${this.registry}/`;
    }
    if (this.namespace !== "library") {
      out += `${this.namespace}/`;
    }
    out += this.name;
    return out;
  }
  toString() {
    return `${this.imageName()}:${this.tag}`;
  }
  registryUrl() {
    return this.registry ? `https://${this.registry}` : "https://registry-1.docker.io";
  }
  async detectAuthServer() {
    try {
      const resp = await fetch(`${this.registryUrl()}/v2/`);
      if (resp.ok) {
        return void 0;
      }
      if (Math.floor(resp.status / 100) === 4) {
        const wwwauth = resp.headers.get("www-authenticate")?.trim();
        if (!wwwauth) {
          return void 0;
        }
        const BEARER_PREFIX = "Bearer ";
        const SERVICE_PREFIX = 'service="';
        const REALM_PREFIX = 'realm="';
        if (!wwwauth.startsWith(BEARER_PREFIX)) {
          throw new Error(`Unknown www-authenticate ${wwwauth}`);
        }
        let realm = "";
        let service = "";
        const parts = wwwauth.slice(BEARER_PREFIX.length).split(/[;,]/);
        for (const kv of parts) {
          if (kv.startsWith(SERVICE_PREFIX)) {
            service = kv.slice(SERVICE_PREFIX.length, -1);
          }
          if (kv.startsWith(REALM_PREFIX)) {
            realm = kv.slice(REALM_PREFIX.length, -1);
          }
        }
        return { realm, service };
      }
      return void 0;
    } catch (err) {
      throw new Error(`Failed to detect auth server: ${err}`);
    }
  }
};
async function getToken(image, opt) {
  const url = `${opt.realm}?service=${opt.service}&scope=repository:${image.namespace}/${image.name}:pull`;
  const response = await distribution_default.get(url);
  const result = await response.json();
  if (result.token && typeof result.token === "string") {
    return result.token;
  }
  throw new Error("Failed to parse token response");
}
async function fetchManifest(image, opt) {
  const reference = opt.reference ?? image.tag;
  const registry = image.registryUrl();
  const url = `${registry}/v2/${image.namespace}/${image.name}/manifests/${reference}`;
  const headers = {
    Accept: [
      "application/vnd.oci.image.manifest.v1+json",
      "application/vnd.oci.image.index.v1+json",
      "application/vnd.docker.distribution.manifest.v2+json",
      "application/vnd.docker.distribution.manifest.list.v2+json",
      "application/vnd.docker.distribution.manifest.v1+json"
    ].join(",")
  };
  if (opt.token) {
    headers["Authorization"] = `Bearer ${opt.token}`;
  }
  const response = await distribution_default.get(url, { headers });
  return await response.json();
}
async function fetchBlob(image, filepath, opt) {
  console.log(`fetching blob: ${opt.digest.slice(7, 23)}`);
  const url = `${image.registryUrl()}/v2/${image.namespace}/${image.name}/blobs/${opt.digest}`;
  const headers = {};
  if (opt.token) {
    headers["Authorization"] = `Bearer ${opt.token}`;
  }
  const response = await distribution_default.get(url, {
    headers,
    onDownloadProgress: (progress) => {
      opt.monitor?.setLayerProgress(
        opt.digest,
        progress.transferredBytes,
        progress.totalBytes
      );
    }
  });
  const contentSize = parseInt(
    response.headers.get("Content-Length") ?? "0",
    10
  );
  if (!opt.pack) {
    return await response.text();
  } else {
    const writable = opt.pack.entry({
      name: filepath,
      type: "file",
      size: contentSize
    });
    const rdr = response.body.getReader();
    while (true) {
      const { done, value } = await rdr.read();
      if (done) {
        writable.end();
        break;
      }
      writable.write(value);
    }
    opt.monitor?.setLayerProgress(
      opt.digest,
      contentSize,
      contentSize
    );
  }
}
async function handleSingleManifestV2(image, pack, opt) {
  const configDigest = opt.manifestJson.config.digest;
  const imageId = configDigest.replace("sha256:", "");
  let layerId = "";
  let layerJson = {};
  const layerFiles = [];
  const configFile = `${imageId}.json`;
  const configFileContent = await fetchBlob(image, configFile, {
    token: opt.token,
    digest: configDigest
  });
  pack.entry({ name: configFile, type: "file" }, configFileContent);
  const layers = opt.manifestJson.layers;
  opt.monitor?.setLayers(layers.map((l) => l.digest));
  for (const layer of layers) {
    const layerMediaType = layer.mediaType;
    const layerDigest = layer.digest;
    const parentId = layerId;
    const hash = await crypto.subtle.digest(
      "SHA-256",
      new TextEncoder().encode(`${layerId}
${layerDigest}`)
    );
    layerId = Array.from(new Uint8Array(hash)).map((b) => b.toString(16).padStart(2, "0")).join("");
    pack.entry({ name: layerId, type: "directory" });
    const layerDir = layerId;
    pack.entry({ name: `${layerDir}/VERSION`, type: "file" }, "1.0");
    const layerTar = `${layerId}/layer.tar`;
    layerFiles.push(layerTar);
    layerJson = {
      id: layerId,
      created: "0001-01-01T00:00:00Z",
      container_config: {
        Hostname: "",
        Domainname: "",
        User: "",
        AttachStdin: false,
        AttachStdout: false,
        AttachStderr: false,
        Tty: false,
        OpenStdin: false,
        StdinOnce: false,
        Env: null,
        Cmd: null,
        Image: "",
        Volumes: null,
        WorkingDir: "",
        Entrypoint: null,
        OnBuild: null,
        Labels: null
      }
    };
    if (parentId) {
      layerJson.parentId = parentId;
    }
    pack.entry(
      { name: `${layerDir}/json`, type: "file" },
      JSON.stringify(layerJson)
    );
    if (layerMediaType === "application/vnd.oci.image.layer.v1.tar+gzip" || layerMediaType === "application/vnd.docker.image.rootfs.diff.tar.gzip") {
      console.log(layerTar);
      await fetchBlob(image, layerTar, {
        token: opt.token,
        digest: layerDigest,
        pack,
        monitor: opt.monitor
      });
      console.log("fetched");
    } else {
      throw new Error(
        `Unknown media type (${image.name}, ${layerMediaType}): '${layerId}'`
      );
    }
  }
  const configJson = JSON.parse(configFileContent);
  configJson.id = layerJson.id;
  if (layerJson.parentId) {
    configJson.parentId = layerJson.parentId;
  }
  delete configJson.history;
  delete configJson.rootfs;
  pack.entry(
    { name: `${layerId}/json`, type: "file" },
    JSON.stringify(configJson)
  );
  const manifest = {
    Config: configFile,
    RepoTags: [image.toString()],
    Layers: layerFiles
  };
  return [manifest, layerId];
}
async function handleSingleManifestV1(image, pack, opt) {
  console.log(`Start pulling ${image.toString()}... (v1)`);
  const history = opt.manifestJson.history;
  if (!Array.isArray(history)) {
    throw new Error("history is not a valid array");
  }
  const fsLayers = opt.manifestJson.fsLayers;
  if (!Array.isArray(fsLayers)) {
    throw new Error("fsLayers is not a valid array");
  }
  opt.monitor?.setLayers(fsLayers.map((l) => l.blobSum));
  let layerId = "";
  for (let i = 0; i < fsLayers.length; i++) {
    const layer = fsLayers[i];
    const digest = layer.blobSum;
    if (typeof digest !== "string") {
      throw new Error("blobSum is not a valid string");
    }
    const v1Compatibility = history[i].v1Compatibility;
    if (typeof v1Compatibility !== "string") {
      throw new Error("v1Compatibility is not a valid string");
    }
    const imageJson = JSON.parse(v1Compatibility);
    layerId = imageJson.id;
    const layerDir = layerId;
    pack.entry({ name: layerId, type: "directory" });
    pack.entry({ name: `${layerDir}/VERSION`, type: "file" }, "1.0");
    pack.entry({ name: `${layerDir}/json`, type: "file" }, v1Compatibility);
    console.log(`${layerDir}/layer.tar`);
    await fetchBlob(image, `${layerDir}/layer.tar`, {
      token: opt.token,
      digest,
      pack,
      monitor: opt.monitor
    });
  }
  return [
    {
      Config: `${layerId}/json`,
      RepoTags: [image.toString()],
      Layers: fsLayers.map((layer) => `${layer.id}/layer.tar`)
    },
    layerId
  ];
}
async function handleImage(image, pack, opt) {
  const manifestOut = [];
  const repositories = {};
  const authServer = await image.detectAuthServer();
  const token = authServer ? await getToken(image, authServer) : void 0;
  const manifest = await fetchManifest(image, { token });
  const schemaVersion = manifest.schemaVersion;
  if (typeof schemaVersion !== "number") {
    throw new Error("schemaVersion is not a valid number");
  }
  if (schemaVersion === 2) {
    const mediaType = manifest.mediaType;
    if (typeof mediaType !== "string") {
      throw new Error("mediaType is not a valid string");
    }
    let out;
    if (mediaType === "application/vnd.oci.image.manifest.v1+json" || mediaType === "application/vnd.docker.distribution.manifest.v2+json") {
      console.log(`Start pulling ${image.toString()}... (v2)`);
      if (opt.dryrun) return;
      out = await handleSingleManifestV2(image, pack, {
        manifestJson: manifest,
        token
      });
    } else if (mediaType === "application/vnd.oci.image.index.v1+json" || mediaType === "application/vnd.docker.distribution.manifest.list.v2+json") {
      let found = false;
      for (const m of manifest.manifests) {
        if (m.platform?.architecture?.split("/").includes(opt.arch)) {
          found = true;
          const manifestJson = await fetchManifest(image, {
            token,
            reference: m.digest
          });
          if (opt.dryrun) return;
          console.log(`Start pulling ${image.toString()}... (v2:${opt.arch}:${m.platform?.architecture})`);
          out = await handleSingleManifestV2(image, pack, {
            manifestJson,
            token,
            monitor: opt.monitor
          });
          break;
        }
      }
      if (!found) {
        throw new Error(`manifest for (${opt.arch}) is not found`);
      }
    } else {
      throw new Error(
        `unknown manifest mediaType (${image.name}): '${mediaType}'`
      );
    }
    if (!out) throw new Error("No manifest processed");
    const [manifestItem, layerId] = out;
    const tagMap = {};
    tagMap[image.tag] = layerId;
    repositories[image.name] = tagMap;
    manifestOut.push(manifestItem);
  } else if (schemaVersion === 1) {
    if (opt.dryrun) return;
    console.log(`Start pulling ${image.toString()}... (v1)`);
    const [manifestItem, layerId] = await handleSingleManifestV1(image, pack, {
      manifestJson: manifest,
      token,
      monitor: opt.monitor
    });
    const tagMap = {};
    tagMap[image.tag] = layerId;
    repositories[image.name] = tagMap;
    manifestOut.push(manifestItem);
  } else {
    throw new Error(`unsupported schema version: ${schemaVersion}`);
  }
  pack.entry(
    { name: "repositories", type: "file" },
    JSON.stringify(repositories)
  );
  pack.entry(
    { name: "manifest.json", type: "file" },
    JSON.stringify(manifestOut)
  );
}

// node_modules/.pnpm/streamx-webstream@1.2.12/node_modules/streamx-webstream/lib/fromWeb.js
var import_streamx = __toESM(require_streamx(), 1);
function fromWeb(webStream, options = {}) {
  if (webStream instanceof ReadableStream && webStream instanceof WritableStream) {
    return new DuplexWebStream(webStream, webStream, options);
  } else if (webStream instanceof ReadableStream) {
    return new ReadableWebStream(webStream, options);
  } else if (webStream instanceof WritableStream) {
    return new WritableWebStream(webStream, options);
  } else if (webStream.readable && webStream.writable) {
    return new DuplexWebStream(webStream.readable, webStream.writable, options);
  } else if (webStream.readable) {
    return new ReadableWebStream(webStream.readable, options);
  } else if (webStream.writable) {
    return new WritableWebStream(webStream.writable, options);
  } else {
    throw new Error("fromWeb: Requires at least a readable or writable stream.");
  }
}
var ReadableWebStream = class extends import_streamx.Readable {
  constructor(readableStream, options) {
    super(options);
    this._reader = readableStream.getReader();
    this._attachErrorHandler();
  }
  _attachErrorHandler() {
    this._reader.closed.catch((error) => {
      this.destroy(error);
    });
  }
  async _read(cb) {
    try {
      const { done, value } = await this._reader.read();
      if (done) {
        this.push(null);
      } else {
        this.push(value);
      }
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  _destroy(cb) {
    this._reader.releaseLock();
    cb();
  }
};
var WritableWebStream = class extends import_streamx.Writable {
  constructor(writableStream, options) {
    super(options);
    this._writer = writableStream.getWriter();
  }
  async _write(chunk, cb) {
    try {
      await this._writer.write(chunk);
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  async _final(cb) {
    try {
      await this._writer.close();
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  _destroy(cb) {
    this._writer.releaseLock();
    cb();
  }
};
var DuplexWebStream = class extends import_streamx.Duplex {
  constructor(readableStream, writableStream, options) {
    super(options);
    this._reader = readableStream.getReader();
    this._writer = writableStream.getWriter();
    this._attachErrorHandler();
    this._handleCompletion();
  }
  _attachErrorHandler() {
    this._reader.closed.catch((error) => {
      this.destroy(error);
    });
    this._writer.closed.catch((error) => {
      this.destroy(error);
    });
  }
  async _read(cb) {
    try {
      const { done, value } = await this._reader.read();
      if (done) {
        this.push(null);
      } else {
        this.push(value);
      }
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  async _write(chunk, cb) {
    try {
      await this._writer.write(chunk);
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  async _final(cb) {
    try {
      await this._writer.close();
      cb();
    } catch (error) {
      this.destroy(error);
      cb(error);
    }
  }
  _destroy(cb) {
    this._reader.releaseLock();
    this._writer.releaseLock();
    cb();
  }
  _handleCompletion() {
    this.on("finish", () => {
      this.emit("end");
    });
  }
};

// node_modules/.pnpm/streamx-webstream@1.2.12/node_modules/streamx-webstream/lib/drained.js
var WRITE_WRITING = 256 << 17;

// node_modules/.pnpm/streamx-webstream@1.2.12/node_modules/streamx-webstream/lib/toWeb.js
var import_b4a = __toESM(require_browser(), 1);

// src/background/index.ts
var items = [];
chrome.runtime.onMessage.addListener((request, _sender, sendResponse) => {
  if (request.type === "query_status") {
    sendResponse({
      type: "status",
      items: items.map((m) => ({
        name: m.name,
        id: m.id,
        arch: m.arch,
        layers: m.layers,
        error: m.error
      }))
    });
  } else if (request.type === "dryrun") {
    (async () => {
      try {
        const pack = import_tar_stream.default.pack();
        await handleImage(ImageRef.parse(request.image), pack, { arch: request.arch ?? "amd64", dryrun: true });
        sendResponse({ type: "dryrun", ok: true });
      } catch (e) {
        sendResponse({ type: "dryrun", ok: false, error: e.message });
      }
    })();
    return true;
  } else if (request.type === "clear") {
    items.splice(0);
  } else {
    sendResponse({});
  }
});
self.addEventListener("fetch", (event) => {
  const url = new URL(event.request.url);
  if (!url.pathname.startsWith("/pull/")) {
    return;
    url.protocol = "http";
    url.host = "localhost";
    url.port = "5173";
    const respPromise = fetch(url, { body: event.request.body, headers: event.request.headers });
    return event.respondWith(respPromise);
  }
  const name = url.pathname.slice(6);
  const pack = import_tar_stream.default.pack();
  const arch = url.searchParams.get("arch") ?? "amd64";
  const monitor = new Monitor(name, arch);
  items.push(monitor);
  let _controller;
  const tr = new TransformStream({
    start(controller) {
      _controller = controller;
    }
  });
  handleImage(ImageRef.parse(name), pack, { arch, monitor }).then(() => {
    pack.finalize();
  }).catch((e) => {
    console.error(e);
    pack.destroy(e);
    _controller.error(e);
    monitor.setError(e?.message);
  });
  pack.pipe(fromWeb(tr.writable, true));
  let filename = name.replaceAll(/[:@/]/g, "_");
  if (arch !== "amd64") {
    filename += "_" + arch;
  }
  event.respondWith(
    new Response(tr.readable, {
      headers: {
        "Transfer-Encoding": "chunked",
        "Content-Type": "application/x-tar",
        "Content-Disposition": `attachment; filename="${filename}.tar`
      }
    })
  );
});
/*! Bundled license information:

ky/distribution/index.js:
  (*! MIT License © Sindre Sorhus *)
*/
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2JhcmUtZXZlbnRzQDIuNS4wL25vZGVfbW9kdWxlcy9iYXJlLWV2ZW50cy9saWIvZXJyb3JzLmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9iYXJlLWV2ZW50c0AyLjUuMC9ub2RlX21vZHVsZXMvYmFyZS1ldmVudHMvaW5kZXguanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3F1ZXVlLXRpY2tAMS4wLjEvbm9kZV9tb2R1bGVzL3F1ZXVlLXRpY2svcXVldWUtbWljcm90YXNrLmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9mYXN0LWZpZm9AMS4zLjIvbm9kZV9tb2R1bGVzL2Zhc3QtZmlmby9maXhlZC1zaXplLmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9mYXN0LWZpZm9AMS4zLjIvbm9kZV9tb2R1bGVzL2Zhc3QtZmlmby9pbmRleC5qcyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0vdGV4dC1kZWNvZGVyQDEuMi4zL25vZGVfbW9kdWxlcy90ZXh0LWRlY29kZXIvbGliL2Jyb3dzZXItZGVjb2Rlci5qcyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0vdGV4dC1kZWNvZGVyQDEuMi4zL25vZGVfbW9kdWxlcy90ZXh0LWRlY29kZXIvaW5kZXguanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N0cmVhbXhAMi4yMS4xL25vZGVfbW9kdWxlcy9zdHJlYW14L2luZGV4LmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9iNGFAMS42Ljcvbm9kZV9tb2R1bGVzL2I0YS9saWIvYXNjaWkuanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2I0YUAxLjYuNy9ub2RlX21vZHVsZXMvYjRhL2xpYi9iYXNlNjQuanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2I0YUAxLjYuNy9ub2RlX21vZHVsZXMvYjRhL2xpYi9oZXguanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2I0YUAxLjYuNy9ub2RlX21vZHVsZXMvYjRhL2xpYi91dGY4LmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9iNGFAMS42Ljcvbm9kZV9tb2R1bGVzL2I0YS9saWIvdXRmMTZsZS5qcyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0vYjRhQDEuNi43L25vZGVfbW9kdWxlcy9iNGEvYnJvd3Nlci5qcyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0vdGFyLXN0cmVhbUAzLjEuNy9ub2RlX21vZHVsZXMvdGFyLXN0cmVhbS9oZWFkZXJzLmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS90YXItc3RyZWFtQDMuMS43L25vZGVfbW9kdWxlcy90YXItc3RyZWFtL2V4dHJhY3QuanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3Rhci1zdHJlYW1AMy4xLjcvbm9kZV9tb2R1bGVzL3Rhci1zdHJlYW0vY29uc3RhbnRzLmpzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS90YXItc3RyZWFtQDMuMS43L25vZGVfbW9kdWxlcy90YXItc3RyZWFtL3BhY2suanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3Rhci1zdHJlYW1AMy4xLjcvbm9kZV9tb2R1bGVzL3Rhci1zdHJlYW0vaW5kZXguanMiLCAiLi4vc3JjL2JhY2tncm91bmQvaW5kZXgudHMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2t5QDEuNy40L25vZGVfbW9kdWxlcy9reS9zb3VyY2UvZXJyb3JzL0hUVFBFcnJvci50cyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0va3lAMS43LjQvbm9kZV9tb2R1bGVzL2t5L3NvdXJjZS9lcnJvcnMvVGltZW91dEVycm9yLnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL3V0aWxzL2lzLnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL3V0aWxzL21lcmdlLnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL2NvcmUvY29uc3RhbnRzLnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL3V0aWxzL25vcm1hbGl6ZS50cyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0va3lAMS43LjQvbm9kZV9tb2R1bGVzL2t5L3NvdXJjZS91dGlscy90aW1lb3V0LnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL3V0aWxzL2RlbGF5LnRzIiwgIi4uL25vZGVfbW9kdWxlcy8ucG5wbS9reUAxLjcuNC9ub2RlX21vZHVsZXMva3kvc291cmNlL3V0aWxzL29wdGlvbnMudHMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2t5QDEuNy40L25vZGVfbW9kdWxlcy9reS9zb3VyY2UvY29yZS9LeS50cyIsICIuLi9ub2RlX21vZHVsZXMvLnBucG0va3lAMS43LjQvbm9kZV9tb2R1bGVzL2t5L3NvdXJjZS9pbmRleC50cyIsICIuLi9zcmMvbGliL2ltZ3B1bGwudHMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N0cmVhbXgtd2Vic3RyZWFtQDEuMi4xMi9ub2RlX21vZHVsZXMvc3RyZWFteC13ZWJzdHJlYW0vbGliL2Zyb21XZWIuanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N0cmVhbXgtd2Vic3RyZWFtQDEuMi4xMi9ub2RlX21vZHVsZXMvc3RyZWFteC13ZWJzdHJlYW0vbGliL2RyYWluZWQuanMiLCAiLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3N0cmVhbXgtd2Vic3RyZWFtQDEuMi4xMi9ub2RlX21vZHVsZXMvc3RyZWFteC13ZWJzdHJlYW0vbGliL3RvV2ViLmpzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJtb2R1bGUuZXhwb3J0cyA9IGNsYXNzIEV2ZW50RW1pdHRlckVycm9yIGV4dGVuZHMgRXJyb3Ige1xuICBjb25zdHJ1Y3RvciAobXNnLCBjb2RlLCBmbiA9IEV2ZW50RW1pdHRlckVycm9yLCBvcHRzKSB7XG4gICAgc3VwZXIoYCR7Y29kZX06ICR7bXNnfWAsIG9wdHMpXG4gICAgdGhpcy5jb2RlID0gY29kZVxuXG4gICAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSh0aGlzLCBmbilcbiAgICB9XG4gIH1cblxuICBnZXQgbmFtZSAoKSB7XG4gICAgcmV0dXJuICdFdmVudEVtaXR0ZXJFcnJvcidcbiAgfVxuXG4gIHN0YXRpYyBPUEVSQVRJT05fQUJPUlRFRCAoY2F1c2UsIG1zZyA9ICdPcGVyYXRpb24gYWJvcnRlZCcpIHtcbiAgICByZXR1cm4gbmV3IEV2ZW50RW1pdHRlckVycm9yKG1zZywgJ09QRVJBVElPTl9BQk9SVEVEJywgRXZlbnRFbWl0dGVyRXJyb3IuT1BFUkFUSU9OX0FCT1JURUQsIHsgY2F1c2UgfSlcbiAgfVxuXG4gIHN0YXRpYyBVTkhBTkRMRURfRVJST1IgKGNhdXNlLCBtc2cgPSAnVW5oYW5kbGVkIGVycm9yJykge1xuICAgIHJldHVybiBuZXcgRXZlbnRFbWl0dGVyRXJyb3IobXNnLCAnVU5IQU5ETEVEX0VSUk9SJywgRXZlbnRFbWl0dGVyRXJyb3IuVU5IQU5ETEVEX0VSUk9SLCB7IGNhdXNlIH0pXG4gIH1cbn1cbiIsICJjb25zdCBlcnJvcnMgPSByZXF1aXJlKCcuL2xpYi9lcnJvcnMnKVxuXG5jbGFzcyBFdmVudExpc3RlbmVyIHtcbiAgY29uc3RydWN0b3IgKCkge1xuICAgIHRoaXMubGlzdCA9IFtdXG4gICAgdGhpcy5jb3VudCA9IDBcbiAgfVxuXG4gIGFwcGVuZCAoY3R4LCBuYW1lLCBmbiwgb25jZSkge1xuICAgIHRoaXMuY291bnQrK1xuICAgIGN0eC5lbWl0KCduZXdMaXN0ZW5lcicsIG5hbWUsIGZuKSAvLyBFbWl0IEJFRk9SRSBhZGRpbmdcbiAgICB0aGlzLmxpc3QucHVzaChbZm4sIG9uY2VdKVxuICB9XG5cbiAgcHJlcGVuZCAoY3R4LCBuYW1lLCBmbiwgb25jZSkge1xuICAgIHRoaXMuY291bnQrK1xuICAgIGN0eC5lbWl0KCduZXdMaXN0ZW5lcicsIG5hbWUsIGZuKSAvLyBFbWl0IEJFRk9SRSBhZGRpbmdcbiAgICB0aGlzLmxpc3QudW5zaGlmdChbZm4sIG9uY2VdKVxuICB9XG5cbiAgcmVtb3ZlIChjdHgsIG5hbWUsIGZuKSB7XG4gICAgZm9yIChsZXQgaSA9IDAsIG4gPSB0aGlzLmxpc3QubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICBjb25zdCBsID0gdGhpcy5saXN0W2ldXG5cbiAgICAgIGlmIChsWzBdID09PSBmbikge1xuICAgICAgICB0aGlzLmxpc3Quc3BsaWNlKGksIDEpXG5cbiAgICAgICAgaWYgKHRoaXMuY291bnQgPT09IDEpIGRlbGV0ZSBjdHguX2V2ZW50c1tuYW1lXVxuXG4gICAgICAgIGN0eC5lbWl0KCdyZW1vdmVMaXN0ZW5lcicsIG5hbWUsIGZuKSAvLyBFbWl0IEFGVEVSIHJlbW92aW5nXG5cbiAgICAgICAgdGhpcy5jb3VudC0tXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHJlbW92ZUFsbCAoY3R4LCBuYW1lKSB7XG4gICAgY29uc3QgbGlzdCA9IFsuLi50aGlzLmxpc3RdXG4gICAgdGhpcy5saXN0ID0gW11cblxuICAgIGlmICh0aGlzLmNvdW50ID09PSBsaXN0Lmxlbmd0aCkgZGVsZXRlIGN0eC5fZXZlbnRzW25hbWVdXG5cbiAgICBmb3IgKGxldCBpID0gbGlzdC5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY3R4LmVtaXQoJ3JlbW92ZUxpc3RlbmVyJywgbmFtZSwgbGlzdFtpXVswXSkgLy8gRW1pdCBBRlRFUiByZW1vdmluZ1xuICAgIH1cblxuICAgIHRoaXMuY291bnQgLT0gbGlzdC5sZW5ndGhcbiAgfVxuXG4gIGVtaXQgKGN0eCwgbmFtZSwgLi4uYXJncykge1xuICAgIGNvbnN0IGxpc3QgPSBbLi4udGhpcy5saXN0XVxuXG4gICAgZm9yIChsZXQgaSA9IDAsIG4gPSBsaXN0Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgY29uc3QgbCA9IGxpc3RbaV1cblxuICAgICAgaWYgKGxbMV0gPT09IHRydWUpIHRoaXMucmVtb3ZlKGN0eCwgbmFtZSwgbFswXSlcblxuICAgICAgbFswXS5jYWxsKGN0eCwgLi4uYXJncylcbiAgICB9XG5cbiAgICByZXR1cm4gbGlzdC5sZW5ndGggPiAwXG4gIH1cbn1cblxuZnVuY3Rpb24gYXBwZW5kTGlzdGVuZXIgKGN0eCwgbmFtZSwgZm4sIG9uY2UpIHtcbiAgY29uc3QgZSA9IGN0eC5fZXZlbnRzW25hbWVdIHx8IChjdHguX2V2ZW50c1tuYW1lXSA9IG5ldyBFdmVudExpc3RlbmVyKCkpXG4gIGUuYXBwZW5kKGN0eCwgbmFtZSwgZm4sIG9uY2UpXG4gIHJldHVybiBjdHhcbn1cblxuZnVuY3Rpb24gcHJlcGVuZExpc3RlbmVyIChjdHgsIG5hbWUsIGZuLCBvbmNlKSB7XG4gIGNvbnN0IGUgPSBjdHguX2V2ZW50c1tuYW1lXSB8fCAoY3R4Ll9ldmVudHNbbmFtZV0gPSBuZXcgRXZlbnRMaXN0ZW5lcigpKVxuICBlLnByZXBlbmQoY3R4LCBuYW1lLCBmbiwgb25jZSlcbiAgcmV0dXJuIGN0eFxufVxuXG5mdW5jdGlvbiByZW1vdmVMaXN0ZW5lciAoY3R4LCBuYW1lLCBmbikge1xuICBjb25zdCBlID0gY3R4Ll9ldmVudHNbbmFtZV1cbiAgaWYgKGUgIT09IHVuZGVmaW5lZCkgZS5yZW1vdmUoY3R4LCBuYW1lLCBmbilcbiAgcmV0dXJuIGN0eFxufVxuXG5mdW5jdGlvbiB0aHJvd1VuaGFuZGxlZEVycm9yICguLi5hcmdzKSB7XG4gIGxldCBlcnJcblxuICBpZiAoYXJncy5sZW5ndGggPiAwKSBlcnIgPSBhcmdzWzBdXG5cbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yID09PSBmYWxzZSkgZXJyID0gZXJyb3JzLlVOSEFORExFRF9FUlJPUihlcnIpXG5cbiAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgRXJyb3IuY2FwdHVyZVN0YWNrVHJhY2UoZXJyLCBleHBvcnRzLnByb3RvdHlwZS5lbWl0KVxuICB9XG5cbiAgcXVldWVNaWNyb3Rhc2soKCkgPT4geyB0aHJvdyBlcnIgfSlcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0gY2xhc3MgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IgKCkge1xuICAgIHRoaXMuX2V2ZW50cyA9IE9iamVjdC5jcmVhdGUobnVsbClcbiAgfVxuXG4gIGFkZExpc3RlbmVyIChuYW1lLCBmbikge1xuICAgIHJldHVybiBhcHBlbmRMaXN0ZW5lcih0aGlzLCBuYW1lLCBmbiwgZmFsc2UpXG4gIH1cblxuICBhZGRPbmNlTGlzdGVuZXIgKG5hbWUsIGZuKSB7XG4gICAgcmV0dXJuIGFwcGVuZExpc3RlbmVyKHRoaXMsIG5hbWUsIGZuLCB0cnVlKVxuICB9XG5cbiAgcHJlcGVuZExpc3RlbmVyIChuYW1lLCBmbikge1xuICAgIHJldHVybiBwcmVwZW5kTGlzdGVuZXIodGhpcywgbmFtZSwgZm4sIGZhbHNlKVxuICB9XG5cbiAgcHJlcGVuZE9uY2VMaXN0ZW5lciAobmFtZSwgZm4pIHtcbiAgICByZXR1cm4gcHJlcGVuZExpc3RlbmVyKHRoaXMsIG5hbWUsIGZuLCB0cnVlKVxuICB9XG5cbiAgcmVtb3ZlTGlzdGVuZXIgKG5hbWUsIGZuKSB7XG4gICAgcmV0dXJuIHJlbW92ZUxpc3RlbmVyKHRoaXMsIG5hbWUsIGZuKVxuICB9XG5cbiAgb24gKG5hbWUsIGZuKSB7XG4gICAgcmV0dXJuIGFwcGVuZExpc3RlbmVyKHRoaXMsIG5hbWUsIGZuLCBmYWxzZSlcbiAgfVxuXG4gIG9uY2UgKG5hbWUsIGZuKSB7XG4gICAgcmV0dXJuIGFwcGVuZExpc3RlbmVyKHRoaXMsIG5hbWUsIGZuLCB0cnVlKVxuICB9XG5cbiAgb2ZmIChuYW1lLCBmbikge1xuICAgIHJldHVybiByZW1vdmVMaXN0ZW5lcih0aGlzLCBuYW1lLCBmbilcbiAgfVxuXG4gIGVtaXQgKG5hbWUsIC4uLmFyZ3MpIHtcbiAgICBpZiAobmFtZSA9PT0gJ2Vycm9yJyAmJiB0aGlzLl9ldmVudHMuZXJyb3IgPT09IHVuZGVmaW5lZCkgdGhyb3dVbmhhbmRsZWRFcnJvciguLi5hcmdzKVxuICAgIGNvbnN0IGUgPSB0aGlzLl9ldmVudHNbbmFtZV1cbiAgICByZXR1cm4gZSA9PT0gdW5kZWZpbmVkID8gZmFsc2UgOiBlLmVtaXQodGhpcywgbmFtZSwgLi4uYXJncylcbiAgfVxuXG4gIGxpc3RlbmVycyAobmFtZSkge1xuICAgIGNvbnN0IGUgPSB0aGlzLl9ldmVudHNbbmFtZV1cbiAgICByZXR1cm4gZSA9PT0gdW5kZWZpbmVkID8gW10gOiBbLi4uZS5saXN0XVxuICB9XG5cbiAgbGlzdGVuZXJDb3VudCAobmFtZSkge1xuICAgIGNvbnN0IGUgPSB0aGlzLl9ldmVudHNbbmFtZV1cbiAgICByZXR1cm4gZSA9PT0gdW5kZWZpbmVkID8gMCA6IGUubGlzdC5sZW5ndGhcbiAgfVxuXG4gIGdldE1heExpc3RlbmVycyAoKSB7XG4gICAgcmV0dXJuIEV2ZW50RW1pdHRlci5kZWZhdWx0TWF4TGlzdGVuZXJzXG4gIH1cblxuICBzZXRNYXhMaXN0ZW5lcnMgKG4pIHt9XG5cbiAgcmVtb3ZlQWxsTGlzdGVuZXJzIChuYW1lKSB7XG4gICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApIHtcbiAgICAgIGZvciAoY29uc3Qga2V5IG9mIFJlZmxlY3Qub3duS2V5cyh0aGlzLl9ldmVudHMpKSB7XG4gICAgICAgIGlmIChrZXkgPT09ICdyZW1vdmVMaXN0ZW5lcicpIGNvbnRpbnVlXG4gICAgICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKGtleSlcbiAgICAgIH1cbiAgICAgIHRoaXMucmVtb3ZlQWxsTGlzdGVuZXJzKCdyZW1vdmVMaXN0ZW5lcicpXG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnN0IGUgPSB0aGlzLl9ldmVudHNbbmFtZV1cbiAgICAgIGlmIChlICE9PSB1bmRlZmluZWQpIGUucmVtb3ZlQWxsKHRoaXMsIG5hbWUpXG4gICAgfVxuICAgIHJldHVybiB0aGlzXG4gIH1cbn1cblxuZXhwb3J0cy5FdmVudEVtaXR0ZXIgPSBleHBvcnRzXG5cbmV4cG9ydHMuZXJyb3JzID0gZXJyb3JzXG5cbmV4cG9ydHMuZGVmYXVsdE1heExpc3RlbmVycyA9IDEwXG5cbmV4cG9ydHMub24gPSBmdW5jdGlvbiBvbiAoZW1pdHRlciwgbmFtZSwgb3B0cyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBzaWduYWxcbiAgfSA9IG9wdHNcblxuICBpZiAoc2lnbmFsICYmIHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgdGhyb3cgZXJyb3JzLk9QRVJBVElPTl9BQk9SVEVEKHNpZ25hbC5yZWFzb24pXG4gIH1cblxuICBsZXQgZXJyb3IgPSBudWxsXG4gIGxldCBkb25lID0gZmFsc2VcblxuICBjb25zdCBldmVudHMgPSBbXVxuICBjb25zdCBwcm9taXNlcyA9IFtdXG5cbiAgZW1pdHRlci5vbihuYW1lLCBvbmV2ZW50KVxuXG4gIGlmIChuYW1lICE9PSAnZXJyb3InKSBlbWl0dGVyLm9uKCdlcnJvcicsIG9uZXJyb3IpXG5cbiAgaWYgKHNpZ25hbCkgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0Jywgb25hYm9ydClcblxuICByZXR1cm4ge1xuICAgIG5leHQgKCkge1xuICAgICAgaWYgKGV2ZW50cy5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7IHZhbHVlOiBldmVudHMuc2hpZnQoKSwgZG9uZTogZmFsc2UgfSlcbiAgICAgIH1cblxuICAgICAgaWYgKGVycm9yKSB7XG4gICAgICAgIGNvbnN0IGVyciA9IGVycm9yXG5cbiAgICAgICAgZXJyb3IgPSBudWxsXG5cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVqZWN0KGVycilcbiAgICAgIH1cblxuICAgICAgaWYgKGRvbmUpIHJldHVybiBvbmNsb3NlKClcblxuICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+XG4gICAgICAgIHByb21pc2VzLnB1c2goeyByZXNvbHZlLCByZWplY3QgfSlcbiAgICAgIClcbiAgICB9LFxuXG4gICAgcmV0dXJuICgpIHtcbiAgICAgIHJldHVybiBvbmNsb3NlKClcbiAgICB9LFxuXG4gICAgdGhyb3cgKGVycikge1xuICAgICAgcmV0dXJuIG9uZXJyb3IoZXJyKVxuICAgIH0sXG5cbiAgICBbU3ltYm9sLmFzeW5jSXRlcmF0b3JdICgpIHtcbiAgICAgIHJldHVybiB0aGlzXG4gICAgfVxuICB9XG5cbiAgZnVuY3Rpb24gb25ldmVudCAoLi4uYXJncykge1xuICAgIGlmIChwcm9taXNlcy5sZW5ndGgpIHtcbiAgICAgIHByb21pc2VzLnNoaWZ0KCkucmVzb2x2ZSh7IHZhbHVlOiBhcmdzLCBkb25lOiBmYWxzZSB9KVxuICAgIH0gZWxzZSB7XG4gICAgICBldmVudHMucHVzaChhcmdzKVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIG9uZXJyb3IgKGVycikge1xuICAgIGlmIChwcm9taXNlcy5sZW5ndGgpIHtcbiAgICAgIHByb21pc2VzLnNoaWZ0KCkucmVqZWN0KGVycilcbiAgICB9IGVsc2Uge1xuICAgICAgZXJyb3IgPSBlcnJcbiAgICB9XG5cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHsgZG9uZTogdHJ1ZSB9KVxuICB9XG5cbiAgZnVuY3Rpb24gb25hYm9ydCAoKSB7XG4gICAgb25lcnJvcihlcnJvcnMuT1BFUkFUSU9OX0FCT1JURUQoc2lnbmFsLnJlYXNvbikpXG4gIH1cblxuICBmdW5jdGlvbiBvbmNsb3NlICgpIHtcbiAgICBlbWl0dGVyLm9mZihuYW1lLCBvbmV2ZW50KVxuXG4gICAgaWYgKG5hbWUgIT09ICdlcnJvcicpIGVtaXR0ZXIub2ZmKCdlcnJvcicsIG9uZXJyb3IpXG5cbiAgICBpZiAoc2lnbmFsKSBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0KVxuXG4gICAgZG9uZSA9IHRydWVcblxuICAgIGlmIChwcm9taXNlcy5sZW5ndGgpIHByb21pc2VzLnNoaWZ0KCkucmVzb2x2ZSh7IGRvbmU6IHRydWUgfSlcblxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoeyBkb25lOiB0cnVlIH0pXG4gIH1cbn1cblxuZXhwb3J0cy5vbmNlID0gZnVuY3Rpb24gb25jZSAoZW1pdHRlciwgbmFtZSwgb3B0cyA9IHt9KSB7XG4gIGNvbnN0IHtcbiAgICBzaWduYWxcbiAgfSA9IG9wdHNcblxuICBpZiAoc2lnbmFsICYmIHNpZ25hbC5hYm9ydGVkKSB7XG4gICAgdGhyb3cgZXJyb3JzLk9QRVJBVElPTl9BQk9SVEVEKHNpZ25hbC5yZWFzb24pXG4gIH1cblxuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIGlmIChuYW1lICE9PSAnZXJyb3InKSBlbWl0dGVyLm9uKCdlcnJvcicsIG9uZXJyb3IpXG5cbiAgICBpZiAoc2lnbmFsKSBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0KVxuXG4gICAgZW1pdHRlci5vbmNlKG5hbWUsICguLi5hcmdzKSA9PiB7XG4gICAgICBpZiAobmFtZSAhPT0gJ2Vycm9yJykgZW1pdHRlci5vZmYoJ2Vycm9yJywgb25lcnJvcilcblxuICAgICAgaWYgKHNpZ25hbCkgc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0Jywgb25hYm9ydClcblxuICAgICAgcmVzb2x2ZShhcmdzKVxuICAgIH0pXG5cbiAgICBmdW5jdGlvbiBvbmVycm9yIChlcnIpIHtcbiAgICAgIGVtaXR0ZXIub2ZmKCdlcnJvcicsIG9uZXJyb3IpXG5cbiAgICAgIHJlamVjdChlcnIpXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gb25hYm9ydCAoKSB7XG4gICAgICBzaWduYWwucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBvbmFib3J0KVxuXG4gICAgICBvbmVycm9yKGVycm9ycy5PUEVSQVRJT05fQUJPUlRFRChzaWduYWwucmVhc29uKSlcbiAgICB9XG4gIH0pXG59XG5cbmV4cG9ydHMuZm9yd2FyZCA9IGZ1bmN0aW9uIGZvcndhcmQgKGZyb20sIHRvLCBuYW1lcywgb3B0cyA9IHt9KSB7XG4gIGlmICh0eXBlb2YgbmFtZXMgPT09ICdzdHJpbmcnKSBuYW1lcyA9IFtuYW1lc11cblxuICBjb25zdCB7XG4gICAgZW1pdCA9IHRvLmVtaXQuYmluZCh0bylcbiAgfSA9IG9wdHNcblxuICBjb25zdCBsaXN0ZW5lcnMgPSBuYW1lcy5tYXAoKG5hbWUpID0+IGZ1bmN0aW9uIG9uZXZlbnQgKC4uLmFyZ3MpIHtcbiAgICBlbWl0KG5hbWUsIC4uLmFyZ3MpXG4gIH0pXG5cbiAgdG9cbiAgICAub24oJ25ld0xpc3RlbmVyJywgKG5hbWUpID0+IHtcbiAgICAgIGNvbnN0IGkgPSBuYW1lcy5pbmRleE9mKG5hbWUpXG5cbiAgICAgIGlmIChpICE9PSAtMSAmJiB0by5saXN0ZW5lckNvdW50KG5hbWUpID09PSAwKSB7XG4gICAgICAgIGZyb20ub24obmFtZSwgbGlzdGVuZXJzW2ldKVxuICAgICAgfVxuICAgIH0pXG4gICAgLm9uKCdyZW1vdmVMaXN0ZW5lcicsIChuYW1lKSA9PiB7XG4gICAgICBjb25zdCBpID0gbmFtZXMuaW5kZXhPZihuYW1lKVxuXG4gICAgICBpZiAoaSAhPT0gLTEgJiYgdG8ubGlzdGVuZXJDb3VudChuYW1lKSA9PT0gMCkge1xuICAgICAgICBmcm9tLm9mZihuYW1lLCBsaXN0ZW5lcnNbaV0pXG4gICAgICB9XG4gICAgfSlcbn1cblxuZXhwb3J0cy5saXN0ZW5lckNvdW50ID0gZnVuY3Rpb24gbGlzdGVuZXJDb3VudCAoZW1pdHRlciwgbmFtZSkge1xuICByZXR1cm4gZW1pdHRlci5saXN0ZW5lckNvdW50KG5hbWUpXG59XG4iLCAibW9kdWxlLmV4cG9ydHMgPSB0eXBlb2YgcXVldWVNaWNyb3Rhc2sgPT09ICdmdW5jdGlvbicgPyBxdWV1ZU1pY3JvdGFzayA6IChmbikgPT4gUHJvbWlzZS5yZXNvbHZlKCkudGhlbihmbilcbiIsICJtb2R1bGUuZXhwb3J0cyA9IGNsYXNzIEZpeGVkRklGTyB7XG4gIGNvbnN0cnVjdG9yIChod20pIHtcbiAgICBpZiAoIShod20gPiAwKSB8fCAoKGh3bSAtIDEpICYgaHdtKSAhPT0gMCkgdGhyb3cgbmV3IEVycm9yKCdNYXggc2l6ZSBmb3IgYSBGaXhlZEZJRk8gc2hvdWxkIGJlIGEgcG93ZXIgb2YgdHdvJylcbiAgICB0aGlzLmJ1ZmZlciA9IG5ldyBBcnJheShod20pXG4gICAgdGhpcy5tYXNrID0gaHdtIC0gMVxuICAgIHRoaXMudG9wID0gMFxuICAgIHRoaXMuYnRtID0gMFxuICAgIHRoaXMubmV4dCA9IG51bGxcbiAgfVxuXG4gIGNsZWFyICgpIHtcbiAgICB0aGlzLnRvcCA9IHRoaXMuYnRtID0gMFxuICAgIHRoaXMubmV4dCA9IG51bGxcbiAgICB0aGlzLmJ1ZmZlci5maWxsKHVuZGVmaW5lZClcbiAgfVxuXG4gIHB1c2ggKGRhdGEpIHtcbiAgICBpZiAodGhpcy5idWZmZXJbdGhpcy50b3BdICE9PSB1bmRlZmluZWQpIHJldHVybiBmYWxzZVxuICAgIHRoaXMuYnVmZmVyW3RoaXMudG9wXSA9IGRhdGFcbiAgICB0aGlzLnRvcCA9ICh0aGlzLnRvcCArIDEpICYgdGhpcy5tYXNrXG4gICAgcmV0dXJuIHRydWVcbiAgfVxuXG4gIHNoaWZ0ICgpIHtcbiAgICBjb25zdCBsYXN0ID0gdGhpcy5idWZmZXJbdGhpcy5idG1dXG4gICAgaWYgKGxhc3QgPT09IHVuZGVmaW5lZCkgcmV0dXJuIHVuZGVmaW5lZFxuICAgIHRoaXMuYnVmZmVyW3RoaXMuYnRtXSA9IHVuZGVmaW5lZFxuICAgIHRoaXMuYnRtID0gKHRoaXMuYnRtICsgMSkgJiB0aGlzLm1hc2tcbiAgICByZXR1cm4gbGFzdFxuICB9XG5cbiAgcGVlayAoKSB7XG4gICAgcmV0dXJuIHRoaXMuYnVmZmVyW3RoaXMuYnRtXVxuICB9XG5cbiAgaXNFbXB0eSAoKSB7XG4gICAgcmV0dXJuIHRoaXMuYnVmZmVyW3RoaXMuYnRtXSA9PT0gdW5kZWZpbmVkXG4gIH1cbn1cbiIsICJjb25zdCBGaXhlZEZJRk8gPSByZXF1aXJlKCcuL2ZpeGVkLXNpemUnKVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNsYXNzIEZhc3RGSUZPIHtcbiAgY29uc3RydWN0b3IgKGh3bSkge1xuICAgIHRoaXMuaHdtID0gaHdtIHx8IDE2XG4gICAgdGhpcy5oZWFkID0gbmV3IEZpeGVkRklGTyh0aGlzLmh3bSlcbiAgICB0aGlzLnRhaWwgPSB0aGlzLmhlYWRcbiAgICB0aGlzLmxlbmd0aCA9IDBcbiAgfVxuXG4gIGNsZWFyICgpIHtcbiAgICB0aGlzLmhlYWQgPSB0aGlzLnRhaWxcbiAgICB0aGlzLmhlYWQuY2xlYXIoKVxuICAgIHRoaXMubGVuZ3RoID0gMFxuICB9XG5cbiAgcHVzaCAodmFsKSB7XG4gICAgdGhpcy5sZW5ndGgrK1xuICAgIGlmICghdGhpcy5oZWFkLnB1c2godmFsKSkge1xuICAgICAgY29uc3QgcHJldiA9IHRoaXMuaGVhZFxuICAgICAgdGhpcy5oZWFkID0gcHJldi5uZXh0ID0gbmV3IEZpeGVkRklGTygyICogdGhpcy5oZWFkLmJ1ZmZlci5sZW5ndGgpXG4gICAgICB0aGlzLmhlYWQucHVzaCh2YWwpXG4gICAgfVxuICB9XG5cbiAgc2hpZnQgKCkge1xuICAgIGlmICh0aGlzLmxlbmd0aCAhPT0gMCkgdGhpcy5sZW5ndGgtLVxuICAgIGNvbnN0IHZhbCA9IHRoaXMudGFpbC5zaGlmdCgpXG4gICAgaWYgKHZhbCA9PT0gdW5kZWZpbmVkICYmIHRoaXMudGFpbC5uZXh0KSB7XG4gICAgICBjb25zdCBuZXh0ID0gdGhpcy50YWlsLm5leHRcbiAgICAgIHRoaXMudGFpbC5uZXh0ID0gbnVsbFxuICAgICAgdGhpcy50YWlsID0gbmV4dFxuICAgICAgcmV0dXJuIHRoaXMudGFpbC5zaGlmdCgpXG4gICAgfVxuXG4gICAgcmV0dXJuIHZhbFxuICB9XG5cbiAgcGVlayAoKSB7XG4gICAgY29uc3QgdmFsID0gdGhpcy50YWlsLnBlZWsoKVxuICAgIGlmICh2YWwgPT09IHVuZGVmaW5lZCAmJiB0aGlzLnRhaWwubmV4dCkgcmV0dXJuIHRoaXMudGFpbC5uZXh0LnBlZWsoKVxuICAgIHJldHVybiB2YWxcbiAgfVxuXG4gIGlzRW1wdHkgKCkge1xuICAgIHJldHVybiB0aGlzLmxlbmd0aCA9PT0gMFxuICB9XG59XG4iLCAibW9kdWxlLmV4cG9ydHMgPSBjbGFzcyBCcm93c2VyRGVjb2RlciB7XG4gIGNvbnN0cnVjdG9yIChlbmNvZGluZykge1xuICAgIHRoaXMuZGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcihlbmNvZGluZyA9PT0gJ3V0ZjE2bGUnID8gJ3V0ZjE2LWxlJyA6IGVuY29kaW5nKVxuICB9XG5cbiAgZ2V0IHJlbWFpbmluZyAoKSB7XG4gICAgcmV0dXJuIC0xXG4gIH1cblxuICBkZWNvZGUgKGRhdGEpIHtcbiAgICByZXR1cm4gdGhpcy5kZWNvZGVyLmRlY29kZShkYXRhLCB7IHN0cmVhbTogdHJ1ZSB9KVxuICB9XG5cbiAgZmx1c2ggKCkge1xuICAgIHJldHVybiB0aGlzLmRlY29kZXIuZGVjb2RlKG5ldyBVaW50OEFycmF5KDApKVxuICB9XG59XG4iLCAiY29uc3QgUGFzc1Rocm91Z2hEZWNvZGVyID0gcmVxdWlyZSgnLi9saWIvcGFzcy10aHJvdWdoLWRlY29kZXInKVxuY29uc3QgVVRGOERlY29kZXIgPSByZXF1aXJlKCcuL2xpYi91dGY4LWRlY29kZXInKVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNsYXNzIFRleHREZWNvZGVyIHtcbiAgY29uc3RydWN0b3IgKGVuY29kaW5nID0gJ3V0ZjgnKSB7XG4gICAgdGhpcy5lbmNvZGluZyA9IG5vcm1hbGl6ZUVuY29kaW5nKGVuY29kaW5nKVxuXG4gICAgc3dpdGNoICh0aGlzLmVuY29kaW5nKSB7XG4gICAgICBjYXNlICd1dGY4JzpcbiAgICAgICAgdGhpcy5kZWNvZGVyID0gbmV3IFVURjhEZWNvZGVyKClcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ3V0ZjE2bGUnOlxuICAgICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbnN1cHBvcnRlZCBlbmNvZGluZzogJyArIHRoaXMuZW5jb2RpbmcpXG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aGlzLmRlY29kZXIgPSBuZXcgUGFzc1Rocm91Z2hEZWNvZGVyKHRoaXMuZW5jb2RpbmcpXG4gICAgfVxuICB9XG5cbiAgZ2V0IHJlbWFpbmluZyAoKSB7XG4gICAgcmV0dXJuIHRoaXMuZGVjb2Rlci5yZW1haW5pbmdcbiAgfVxuXG4gIHB1c2ggKGRhdGEpIHtcbiAgICBpZiAodHlwZW9mIGRhdGEgPT09ICdzdHJpbmcnKSByZXR1cm4gZGF0YVxuICAgIHJldHVybiB0aGlzLmRlY29kZXIuZGVjb2RlKGRhdGEpXG4gIH1cblxuICAvLyBGb3IgTm9kZS5qcyBjb21wYXRpYmlsaXR5XG4gIHdyaXRlIChkYXRhKSB7XG4gICAgcmV0dXJuIHRoaXMucHVzaChkYXRhKVxuICB9XG5cbiAgZW5kIChkYXRhKSB7XG4gICAgbGV0IHJlc3VsdCA9ICcnXG4gICAgaWYgKGRhdGEpIHJlc3VsdCA9IHRoaXMucHVzaChkYXRhKVxuICAgIHJlc3VsdCArPSB0aGlzLmRlY29kZXIuZmx1c2goKVxuICAgIHJldHVybiByZXN1bHRcbiAgfVxufVxuXG5mdW5jdGlvbiBub3JtYWxpemVFbmNvZGluZyAoZW5jb2RpbmcpIHtcbiAgZW5jb2RpbmcgPSBlbmNvZGluZy50b0xvd2VyQ2FzZSgpXG5cbiAgc3dpdGNoIChlbmNvZGluZykge1xuICAgIGNhc2UgJ3V0ZjgnOlxuICAgIGNhc2UgJ3V0Zi04JzpcbiAgICAgIHJldHVybiAndXRmOCdcbiAgICBjYXNlICd1Y3MyJzpcbiAgICBjYXNlICd1Y3MtMic6XG4gICAgY2FzZSAndXRmMTZsZSc6XG4gICAgY2FzZSAndXRmLTE2bGUnOlxuICAgICAgcmV0dXJuICd1dGYxNmxlJ1xuICAgIGNhc2UgJ2xhdGluMSc6XG4gICAgY2FzZSAnYmluYXJ5JzpcbiAgICAgIHJldHVybiAnbGF0aW4xJ1xuICAgIGNhc2UgJ2Jhc2U2NCc6XG4gICAgY2FzZSAnYXNjaWknOlxuICAgIGNhc2UgJ2hleCc6XG4gICAgICByZXR1cm4gZW5jb2RpbmdcbiAgICBkZWZhdWx0OlxuICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbmtub3duIGVuY29kaW5nOiAnICsgZW5jb2RpbmcpXG4gIH1cbn07XG4iLCAiY29uc3QgeyBFdmVudEVtaXR0ZXIgfSA9IHJlcXVpcmUoJ2V2ZW50cycpXG5jb25zdCBTVFJFQU1fREVTVFJPWUVEID0gbmV3IEVycm9yKCdTdHJlYW0gd2FzIGRlc3Ryb3llZCcpXG5jb25zdCBQUkVNQVRVUkVfQ0xPU0UgPSBuZXcgRXJyb3IoJ1ByZW1hdHVyZSBjbG9zZScpXG5cbmNvbnN0IHF1ZXVlVGljayA9IHJlcXVpcmUoJ3F1ZXVlLXRpY2snKVxuY29uc3QgRklGTyA9IHJlcXVpcmUoJ2Zhc3QtZmlmbycpXG5jb25zdCBUZXh0RGVjb2RlciA9IHJlcXVpcmUoJ3RleHQtZGVjb2RlcicpXG5cbi8qIGVzbGludC1kaXNhYmxlIG5vLW11bHRpLXNwYWNlcyAqL1xuXG4vLyAyOSBiaXRzIHVzZWQgdG90YWwgKDQgZnJvbSBzaGFyZWQsIDE0IGZyb20gcmVhZCwgYW5kIDExIGZyb20gd3JpdGUpXG5jb25zdCBNQVggPSAoKDEgPDwgMjkpIC0gMSlcblxuLy8gU2hhcmVkIHN0YXRlXG5jb25zdCBPUEVOSU5HICAgICAgID0gMGIwMDAxXG5jb25zdCBQUkVERVNUUk9ZSU5HID0gMGIwMDEwXG5jb25zdCBERVNUUk9ZSU5HICAgID0gMGIwMTAwXG5jb25zdCBERVNUUk9ZRUQgICAgID0gMGIxMDAwXG5cbmNvbnN0IE5PVF9PUEVOSU5HID0gTUFYIF4gT1BFTklOR1xuY29uc3QgTk9UX1BSRURFU1RST1lJTkcgPSBNQVggXiBQUkVERVNUUk9ZSU5HXG5cbi8vIFJlYWQgc3RhdGUgKDQgYml0IG9mZnNldCBmcm9tIHNoYXJlZCBzdGF0ZSlcbmNvbnN0IFJFQURfQUNUSVZFICAgICAgICAgICA9IDBiMDAwMDAwMDAwMDAwMDEgPDwgNFxuY29uc3QgUkVBRF9VUERBVElORyAgICAgICAgID0gMGIwMDAwMDAwMDAwMDAxMCA8PCA0XG5jb25zdCBSRUFEX1BSSU1BUlkgICAgICAgICAgPSAwYjAwMDAwMDAwMDAwMTAwIDw8IDRcbmNvbnN0IFJFQURfUVVFVUVEICAgICAgICAgICA9IDBiMDAwMDAwMDAwMDEwMDAgPDwgNFxuY29uc3QgUkVBRF9SRVNVTUVEICAgICAgICAgID0gMGIwMDAwMDAwMDAxMDAwMCA8PCA0XG5jb25zdCBSRUFEX1BJUEVfRFJBSU5FRCAgICAgPSAwYjAwMDAwMDAwMTAwMDAwIDw8IDRcbmNvbnN0IFJFQURfRU5ESU5HICAgICAgICAgICA9IDBiMDAwMDAwMDEwMDAwMDAgPDwgNFxuY29uc3QgUkVBRF9FTUlUX0RBVEEgICAgICAgID0gMGIwMDAwMDAxMDAwMDAwMCA8PCA0XG5jb25zdCBSRUFEX0VNSVRfUkVBREFCTEUgICAgPSAwYjAwMDAwMTAwMDAwMDAwIDw8IDRcbmNvbnN0IFJFQURfRU1JVFRFRF9SRUFEQUJMRSA9IDBiMDAwMDEwMDAwMDAwMDAgPDwgNFxuY29uc3QgUkVBRF9ET05FICAgICAgICAgICAgID0gMGIwMDAxMDAwMDAwMDAwMCA8PCA0XG5jb25zdCBSRUFEX05FWFRfVElDSyAgICAgICAgPSAwYjAwMTAwMDAwMDAwMDAwIDw8IDRcbmNvbnN0IFJFQURfTkVFRFNfUFVTSCAgICAgICA9IDBiMDEwMDAwMDAwMDAwMDAgPDwgNFxuY29uc3QgUkVBRF9SRUFEX0FIRUFEICAgICAgID0gMGIxMDAwMDAwMDAwMDAwMCA8PCA0XG5cbi8vIENvbWJpbmVkIHJlYWQgc3RhdGVcbmNvbnN0IFJFQURfRkxPV0lORyA9IFJFQURfUkVTVU1FRCB8IFJFQURfUElQRV9EUkFJTkVEXG5jb25zdCBSRUFEX0FDVElWRV9BTkRfTkVFRFNfUFVTSCA9IFJFQURfQUNUSVZFIHwgUkVBRF9ORUVEU19QVVNIXG5jb25zdCBSRUFEX1BSSU1BUllfQU5EX0FDVElWRSA9IFJFQURfUFJJTUFSWSB8IFJFQURfQUNUSVZFXG5jb25zdCBSRUFEX0VNSVRfUkVBREFCTEVfQU5EX1FVRVVFRCA9IFJFQURfRU1JVF9SRUFEQUJMRSB8IFJFQURfUVVFVUVEXG5jb25zdCBSRUFEX1JFU1VNRURfUkVBRF9BSEVBRCA9IFJFQURfUkVTVU1FRCB8IFJFQURfUkVBRF9BSEVBRFxuXG5jb25zdCBSRUFEX05PVF9BQ1RJVkUgICAgICAgICAgICAgPSBNQVggXiBSRUFEX0FDVElWRVxuY29uc3QgUkVBRF9OT05fUFJJTUFSWSAgICAgICAgICAgID0gTUFYIF4gUkVBRF9QUklNQVJZXG5jb25zdCBSRUFEX05PTl9QUklNQVJZX0FORF9QVVNIRUQgPSBNQVggXiAoUkVBRF9QUklNQVJZIHwgUkVBRF9ORUVEU19QVVNIKVxuY29uc3QgUkVBRF9QVVNIRUQgICAgICAgICAgICAgICAgID0gTUFYIF4gUkVBRF9ORUVEU19QVVNIXG5jb25zdCBSRUFEX1BBVVNFRCAgICAgICAgICAgICAgICAgPSBNQVggXiBSRUFEX1JFU1VNRURcbmNvbnN0IFJFQURfTk9UX1FVRVVFRCAgICAgICAgICAgICA9IE1BWCBeIChSRUFEX1FVRVVFRCB8IFJFQURfRU1JVFRFRF9SRUFEQUJMRSlcbmNvbnN0IFJFQURfTk9UX0VORElORyAgICAgICAgICAgICA9IE1BWCBeIFJFQURfRU5ESU5HXG5jb25zdCBSRUFEX1BJUEVfTk9UX0RSQUlORUQgICAgICAgPSBNQVggXiBSRUFEX0ZMT1dJTkdcbmNvbnN0IFJFQURfTk9UX05FWFRfVElDSyAgICAgICAgICA9IE1BWCBeIFJFQURfTkVYVF9USUNLXG5jb25zdCBSRUFEX05PVF9VUERBVElORyAgICAgICAgICAgPSBNQVggXiBSRUFEX1VQREFUSU5HXG5jb25zdCBSRUFEX05PX1JFQURfQUhFQUQgICAgICAgICAgPSBNQVggXiBSRUFEX1JFQURfQUhFQURcbmNvbnN0IFJFQURfUEFVU0VEX05PX1JFQURfQUhFQUQgICA9IE1BWCBeIFJFQURfUkVTVU1FRF9SRUFEX0FIRUFEXG5cbi8vIFdyaXRlIHN0YXRlICgxOCBiaXQgb2Zmc2V0LCA0IGJpdCBvZmZzZXQgZnJvbSBzaGFyZWQgc3RhdGUgYW5kIDE0IGZyb20gcmVhZCBzdGF0ZSlcbmNvbnN0IFdSSVRFX0FDVElWRSAgICAgPSAwYjAwMDAwMDAwMDAxIDw8IDE4XG5jb25zdCBXUklURV9VUERBVElORyAgID0gMGIwMDAwMDAwMDAxMCA8PCAxOFxuY29uc3QgV1JJVEVfUFJJTUFSWSAgICA9IDBiMDAwMDAwMDAxMDAgPDwgMThcbmNvbnN0IFdSSVRFX1FVRVVFRCAgICAgPSAwYjAwMDAwMDAxMDAwIDw8IDE4XG5jb25zdCBXUklURV9VTkRSQUlORUQgID0gMGIwMDAwMDAxMDAwMCA8PCAxOFxuY29uc3QgV1JJVEVfRE9ORSAgICAgICA9IDBiMDAwMDAxMDAwMDAgPDwgMThcbmNvbnN0IFdSSVRFX0VNSVRfRFJBSU4gPSAwYjAwMDAxMDAwMDAwIDw8IDE4XG5jb25zdCBXUklURV9ORVhUX1RJQ0sgID0gMGIwMDAxMDAwMDAwMCA8PCAxOFxuY29uc3QgV1JJVEVfV1JJVElORyAgICA9IDBiMDAxMDAwMDAwMDAgPDwgMThcbmNvbnN0IFdSSVRFX0ZJTklTSElORyAgPSAwYjAxMDAwMDAwMDAwIDw8IDE4XG5jb25zdCBXUklURV9DT1JLRUQgICAgID0gMGIxMDAwMDAwMDAwMCA8PCAxOFxuXG5jb25zdCBXUklURV9OT1RfQUNUSVZFICAgID0gTUFYIF4gKFdSSVRFX0FDVElWRSB8IFdSSVRFX1dSSVRJTkcpXG5jb25zdCBXUklURV9OT05fUFJJTUFSWSAgID0gTUFYIF4gV1JJVEVfUFJJTUFSWVxuY29uc3QgV1JJVEVfTk9UX0ZJTklTSElORyA9IE1BWCBeIChXUklURV9BQ1RJVkUgfCBXUklURV9GSU5JU0hJTkcpXG5jb25zdCBXUklURV9EUkFJTkVEICAgICAgID0gTUFYIF4gV1JJVEVfVU5EUkFJTkVEXG5jb25zdCBXUklURV9OT1RfUVVFVUVEICAgID0gTUFYIF4gV1JJVEVfUVVFVUVEXG5jb25zdCBXUklURV9OT1RfTkVYVF9USUNLID0gTUFYIF4gV1JJVEVfTkVYVF9USUNLXG5jb25zdCBXUklURV9OT1RfVVBEQVRJTkcgID0gTUFYIF4gV1JJVEVfVVBEQVRJTkdcbmNvbnN0IFdSSVRFX05PVF9DT1JLRUQgICAgPSBNQVggXiBXUklURV9DT1JLRURcblxuLy8gQ29tYmluZWQgc2hhcmVkIHN0YXRlXG5jb25zdCBBQ1RJVkUgPSBSRUFEX0FDVElWRSB8IFdSSVRFX0FDVElWRVxuY29uc3QgTk9UX0FDVElWRSA9IE1BWCBeIEFDVElWRVxuY29uc3QgRE9ORSA9IFJFQURfRE9ORSB8IFdSSVRFX0RPTkVcbmNvbnN0IERFU1RST1lfU1RBVFVTID0gREVTVFJPWUlORyB8IERFU1RST1lFRCB8IFBSRURFU1RST1lJTkdcbmNvbnN0IE9QRU5fU1RBVFVTID0gREVTVFJPWV9TVEFUVVMgfCBPUEVOSU5HXG5jb25zdCBBVVRPX0RFU1RST1kgPSBERVNUUk9ZX1NUQVRVUyB8IERPTkVcbmNvbnN0IE5PTl9QUklNQVJZID0gV1JJVEVfTk9OX1BSSU1BUlkgJiBSRUFEX05PTl9QUklNQVJZXG5jb25zdCBBQ1RJVkVfT1JfVElDS0lORyA9IFdSSVRFX05FWFRfVElDSyB8IFJFQURfTkVYVF9USUNLXG5jb25zdCBUSUNLSU5HID0gQUNUSVZFX09SX1RJQ0tJTkcgJiBOT1RfQUNUSVZFXG5jb25zdCBJU19PUEVOSU5HID0gT1BFTl9TVEFUVVMgfCBUSUNLSU5HXG5cbi8vIENvbWJpbmVkIHNoYXJlZCBzdGF0ZSBhbmQgcmVhZCBzdGF0ZVxuY29uc3QgUkVBRF9QUklNQVJZX1NUQVRVUyA9IE9QRU5fU1RBVFVTIHwgUkVBRF9FTkRJTkcgfCBSRUFEX0RPTkVcbmNvbnN0IFJFQURfU1RBVFVTID0gT1BFTl9TVEFUVVMgfCBSRUFEX0RPTkUgfCBSRUFEX1FVRVVFRFxuY29uc3QgUkVBRF9FTkRJTkdfU1RBVFVTID0gT1BFTl9TVEFUVVMgfCBSRUFEX0VORElORyB8IFJFQURfUVVFVUVEXG5jb25zdCBSRUFEX1JFQURBQkxFX1NUQVRVUyA9IE9QRU5fU1RBVFVTIHwgUkVBRF9FTUlUX1JFQURBQkxFIHwgUkVBRF9RVUVVRUQgfCBSRUFEX0VNSVRURURfUkVBREFCTEVcbmNvbnN0IFNIT1VMRF9OT1RfUkVBRCA9IE9QRU5fU1RBVFVTIHwgUkVBRF9BQ1RJVkUgfCBSRUFEX0VORElORyB8IFJFQURfRE9ORSB8IFJFQURfTkVFRFNfUFVTSCB8IFJFQURfUkVBRF9BSEVBRFxuY29uc3QgUkVBRF9CQUNLUFJFU1NVUkVfU1RBVFVTID0gREVTVFJPWV9TVEFUVVMgfCBSRUFEX0VORElORyB8IFJFQURfRE9ORVxuY29uc3QgUkVBRF9VUERBVEVfU1lOQ19TVEFUVVMgPSBSRUFEX1VQREFUSU5HIHwgT1BFTl9TVEFUVVMgfCBSRUFEX05FWFRfVElDSyB8IFJFQURfUFJJTUFSWVxuY29uc3QgUkVBRF9ORVhUX1RJQ0tfT1JfT1BFTklORyA9IFJFQURfTkVYVF9USUNLIHwgT1BFTklOR1xuXG4vLyBDb21iaW5lZCB3cml0ZSBzdGF0ZVxuY29uc3QgV1JJVEVfUFJJTUFSWV9TVEFUVVMgPSBPUEVOX1NUQVRVUyB8IFdSSVRFX0ZJTklTSElORyB8IFdSSVRFX0RPTkVcbmNvbnN0IFdSSVRFX1FVRVVFRF9BTkRfVU5EUkFJTkVEID0gV1JJVEVfUVVFVUVEIHwgV1JJVEVfVU5EUkFJTkVEXG5jb25zdCBXUklURV9RVUVVRURfQU5EX0FDVElWRSA9IFdSSVRFX1FVRVVFRCB8IFdSSVRFX0FDVElWRVxuY29uc3QgV1JJVEVfRFJBSU5fU1RBVFVTID0gV1JJVEVfUVVFVUVEIHwgV1JJVEVfVU5EUkFJTkVEIHwgT1BFTl9TVEFUVVMgfCBXUklURV9BQ1RJVkVcbmNvbnN0IFdSSVRFX1NUQVRVUyA9IE9QRU5fU1RBVFVTIHwgV1JJVEVfQUNUSVZFIHwgV1JJVEVfUVVFVUVEIHwgV1JJVEVfQ09SS0VEXG5jb25zdCBXUklURV9QUklNQVJZX0FORF9BQ1RJVkUgPSBXUklURV9QUklNQVJZIHwgV1JJVEVfQUNUSVZFXG5jb25zdCBXUklURV9BQ1RJVkVfQU5EX1dSSVRJTkcgPSBXUklURV9BQ1RJVkUgfCBXUklURV9XUklUSU5HXG5jb25zdCBXUklURV9GSU5JU0hJTkdfU1RBVFVTID0gT1BFTl9TVEFUVVMgfCBXUklURV9GSU5JU0hJTkcgfCBXUklURV9RVUVVRURfQU5EX0FDVElWRSB8IFdSSVRFX0RPTkVcbmNvbnN0IFdSSVRFX0JBQ0tQUkVTU1VSRV9TVEFUVVMgPSBXUklURV9VTkRSQUlORUQgfCBERVNUUk9ZX1NUQVRVUyB8IFdSSVRFX0ZJTklTSElORyB8IFdSSVRFX0RPTkVcbmNvbnN0IFdSSVRFX1VQREFURV9TWU5DX1NUQVRVUyA9IFdSSVRFX1VQREFUSU5HIHwgT1BFTl9TVEFUVVMgfCBXUklURV9ORVhUX1RJQ0sgfCBXUklURV9QUklNQVJZXG5jb25zdCBXUklURV9EUk9QX0RBVEEgPSBXUklURV9GSU5JU0hJTkcgfCBXUklURV9ET05FIHwgREVTVFJPWV9TVEFUVVNcblxuY29uc3QgYXN5bmNJdGVyYXRvciA9IFN5bWJvbC5hc3luY0l0ZXJhdG9yIHx8IFN5bWJvbCgnYXN5bmNJdGVyYXRvcicpXG5cbmNsYXNzIFdyaXRhYmxlU3RhdGUge1xuICBjb25zdHJ1Y3RvciAoc3RyZWFtLCB7IGhpZ2hXYXRlck1hcmsgPSAxNjM4NCwgbWFwID0gbnVsbCwgbWFwV3JpdGFibGUsIGJ5dGVMZW5ndGgsIGJ5dGVMZW5ndGhXcml0YWJsZSB9ID0ge30pIHtcbiAgICB0aGlzLnN0cmVhbSA9IHN0cmVhbVxuICAgIHRoaXMucXVldWUgPSBuZXcgRklGTygpXG4gICAgdGhpcy5oaWdoV2F0ZXJNYXJrID0gaGlnaFdhdGVyTWFya1xuICAgIHRoaXMuYnVmZmVyZWQgPSAwXG4gICAgdGhpcy5lcnJvciA9IG51bGxcbiAgICB0aGlzLnBpcGVsaW5lID0gbnVsbFxuICAgIHRoaXMuZHJhaW5zID0gbnVsbCAvLyBpZiB3ZSBhZGQgbW9yZSBzZWxkb21seSB1c2VkIGhlbHBlcnMgd2UgbWlnaHQgdGhlbSBpbnRvIGEgc3Vib2JqZWN0IHNvIGl0cyBhIHNpbmdsZSBwdHJcbiAgICB0aGlzLmJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoV3JpdGFibGUgfHwgYnl0ZUxlbmd0aCB8fCBkZWZhdWx0Qnl0ZUxlbmd0aFxuICAgIHRoaXMubWFwID0gbWFwV3JpdGFibGUgfHwgbWFwXG4gICAgdGhpcy5hZnRlcldyaXRlID0gYWZ0ZXJXcml0ZS5iaW5kKHRoaXMpXG4gICAgdGhpcy5hZnRlclVwZGF0ZU5leHRUaWNrID0gdXBkYXRlV3JpdGVOVC5iaW5kKHRoaXMpXG4gIH1cblxuICBnZXQgZW5kZWQgKCkge1xuICAgIHJldHVybiAodGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICYgV1JJVEVfRE9ORSkgIT09IDBcbiAgfVxuXG4gIHB1c2ggKGRhdGEpIHtcbiAgICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX0RST1BfREFUQSkgIT09IDApIHJldHVybiBmYWxzZVxuICAgIGlmICh0aGlzLm1hcCAhPT0gbnVsbCkgZGF0YSA9IHRoaXMubWFwKGRhdGEpXG5cbiAgICB0aGlzLmJ1ZmZlcmVkICs9IHRoaXMuYnl0ZUxlbmd0aChkYXRhKVxuICAgIHRoaXMucXVldWUucHVzaChkYXRhKVxuXG4gICAgaWYgKHRoaXMuYnVmZmVyZWQgPCB0aGlzLmhpZ2hXYXRlck1hcmspIHtcbiAgICAgIHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBXUklURV9RVUVVRURcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlIHw9IFdSSVRFX1FVRVVFRF9BTkRfVU5EUkFJTkVEXG4gICAgcmV0dXJuIGZhbHNlXG4gIH1cblxuICBzaGlmdCAoKSB7XG4gICAgY29uc3QgZGF0YSA9IHRoaXMucXVldWUuc2hpZnQoKVxuXG4gICAgdGhpcy5idWZmZXJlZCAtPSB0aGlzLmJ5dGVMZW5ndGgoZGF0YSlcbiAgICBpZiAodGhpcy5idWZmZXJlZCA9PT0gMCkgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICY9IFdSSVRFX05PVF9RVUVVRURcblxuICAgIHJldHVybiBkYXRhXG4gIH1cblxuICBlbmQgKGRhdGEpIHtcbiAgICBpZiAodHlwZW9mIGRhdGEgPT09ICdmdW5jdGlvbicpIHRoaXMuc3RyZWFtLm9uY2UoJ2ZpbmlzaCcsIGRhdGEpXG4gICAgZWxzZSBpZiAoZGF0YSAhPT0gdW5kZWZpbmVkICYmIGRhdGEgIT09IG51bGwpIHRoaXMucHVzaChkYXRhKVxuICAgIHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSA9ICh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgfCBXUklURV9GSU5JU0hJTkcpICYgV1JJVEVfTk9OX1BSSU1BUllcbiAgfVxuXG4gIGF1dG9CYXRjaCAoZGF0YSwgY2IpIHtcbiAgICBjb25zdCBidWZmZXIgPSBbXVxuICAgIGNvbnN0IHN0cmVhbSA9IHRoaXMuc3RyZWFtXG5cbiAgICBidWZmZXIucHVzaChkYXRhKVxuICAgIHdoaWxlICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX1NUQVRVUykgPT09IFdSSVRFX1FVRVVFRF9BTkRfQUNUSVZFKSB7XG4gICAgICBidWZmZXIucHVzaChzdHJlYW0uX3dyaXRhYmxlU3RhdGUuc2hpZnQoKSlcbiAgICB9XG5cbiAgICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBPUEVOX1NUQVRVUykgIT09IDApIHJldHVybiBjYihudWxsKVxuICAgIHN0cmVhbS5fd3JpdGV2KGJ1ZmZlciwgY2IpXG4gIH1cblxuICB1cGRhdGUgKCkge1xuICAgIGNvbnN0IHN0cmVhbSA9IHRoaXMuc3RyZWFtXG5cbiAgICBzdHJlYW0uX2R1cGxleFN0YXRlIHw9IFdSSVRFX1VQREFUSU5HXG5cbiAgICBkbyB7XG4gICAgICB3aGlsZSAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBXUklURV9TVEFUVVMpID09PSBXUklURV9RVUVVRUQpIHtcbiAgICAgICAgY29uc3QgZGF0YSA9IHRoaXMuc2hpZnQoKVxuICAgICAgICBzdHJlYW0uX2R1cGxleFN0YXRlIHw9IFdSSVRFX0FDVElWRV9BTkRfV1JJVElOR1xuICAgICAgICBzdHJlYW0uX3dyaXRlKGRhdGEsIHRoaXMuYWZ0ZXJXcml0ZSlcbiAgICAgIH1cblxuICAgICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgV1JJVEVfUFJJTUFSWV9BTkRfQUNUSVZFKSA9PT0gMCkgdGhpcy51cGRhdGVOb25QcmltYXJ5KClcbiAgICB9IHdoaWxlICh0aGlzLmNvbnRpbnVlVXBkYXRlKCkgPT09IHRydWUpXG5cbiAgICBzdHJlYW0uX2R1cGxleFN0YXRlICY9IFdSSVRFX05PVF9VUERBVElOR1xuICB9XG5cbiAgdXBkYXRlTm9uUHJpbWFyeSAoKSB7XG4gICAgY29uc3Qgc3RyZWFtID0gdGhpcy5zdHJlYW1cblxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX0ZJTklTSElOR19TVEFUVVMpID09PSBXUklURV9GSU5JU0hJTkcpIHtcbiAgICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgPSBzdHJlYW0uX2R1cGxleFN0YXRlIHwgV1JJVEVfQUNUSVZFXG4gICAgICBzdHJlYW0uX2ZpbmFsKGFmdGVyRmluYWwuYmluZCh0aGlzKSlcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIERFU1RST1lfU1RBVFVTKSA9PT0gREVTVFJPWUlORykge1xuICAgICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgQUNUSVZFX09SX1RJQ0tJTkcpID09PSAwKSB7XG4gICAgICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgfD0gQUNUSVZFXG4gICAgICAgIHN0cmVhbS5fZGVzdHJveShhZnRlckRlc3Ryb3kuYmluZCh0aGlzKSlcbiAgICAgIH1cbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIElTX09QRU5JTkcpID09PSBPUEVOSU5HKSB7XG4gICAgICBzdHJlYW0uX2R1cGxleFN0YXRlID0gKHN0cmVhbS5fZHVwbGV4U3RhdGUgfCBBQ1RJVkUpICYgTk9UX09QRU5JTkdcbiAgICAgIHN0cmVhbS5fb3BlbihhZnRlck9wZW4uYmluZCh0aGlzKSlcbiAgICB9XG4gIH1cblxuICBjb250aW51ZVVwZGF0ZSAoKSB7XG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBXUklURV9ORVhUX1RJQ0spID09PSAwKSByZXR1cm4gZmFsc2VcbiAgICB0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJj0gV1JJVEVfTk9UX05FWFRfVElDS1xuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICB1cGRhdGVDYWxsYmFjayAoKSB7XG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBXUklURV9VUERBVEVfU1lOQ19TVEFUVVMpID09PSBXUklURV9QUklNQVJZKSB0aGlzLnVwZGF0ZSgpXG4gICAgZWxzZSB0aGlzLnVwZGF0ZU5leHRUaWNrKClcbiAgfVxuXG4gIHVwZGF0ZU5leHRUaWNrICgpIHtcbiAgICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX05FWFRfVElDSykgIT09IDApIHJldHVyblxuICAgIHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBXUklURV9ORVhUX1RJQ0tcbiAgICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX1VQREFUSU5HKSA9PT0gMCkgcXVldWVUaWNrKHRoaXMuYWZ0ZXJVcGRhdGVOZXh0VGljaylcbiAgfVxufVxuXG5jbGFzcyBSZWFkYWJsZVN0YXRlIHtcbiAgY29uc3RydWN0b3IgKHN0cmVhbSwgeyBoaWdoV2F0ZXJNYXJrID0gMTYzODQsIG1hcCA9IG51bGwsIG1hcFJlYWRhYmxlLCBieXRlTGVuZ3RoLCBieXRlTGVuZ3RoUmVhZGFibGUgfSA9IHt9KSB7XG4gICAgdGhpcy5zdHJlYW0gPSBzdHJlYW1cbiAgICB0aGlzLnF1ZXVlID0gbmV3IEZJRk8oKVxuICAgIHRoaXMuaGlnaFdhdGVyTWFyayA9IGhpZ2hXYXRlck1hcmsgPT09IDAgPyAxIDogaGlnaFdhdGVyTWFya1xuICAgIHRoaXMuYnVmZmVyZWQgPSAwXG4gICAgdGhpcy5yZWFkQWhlYWQgPSBoaWdoV2F0ZXJNYXJrID4gMFxuICAgIHRoaXMuZXJyb3IgPSBudWxsXG4gICAgdGhpcy5waXBlbGluZSA9IG51bGxcbiAgICB0aGlzLmJ5dGVMZW5ndGggPSBieXRlTGVuZ3RoUmVhZGFibGUgfHwgYnl0ZUxlbmd0aCB8fCBkZWZhdWx0Qnl0ZUxlbmd0aFxuICAgIHRoaXMubWFwID0gbWFwUmVhZGFibGUgfHwgbWFwXG4gICAgdGhpcy5waXBlVG8gPSBudWxsXG4gICAgdGhpcy5hZnRlclJlYWQgPSBhZnRlclJlYWQuYmluZCh0aGlzKVxuICAgIHRoaXMuYWZ0ZXJVcGRhdGVOZXh0VGljayA9IHVwZGF0ZVJlYWROVC5iaW5kKHRoaXMpXG4gIH1cblxuICBnZXQgZW5kZWQgKCkge1xuICAgIHJldHVybiAodGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICYgUkVBRF9ET05FKSAhPT0gMFxuICB9XG5cbiAgcGlwZSAocGlwZVRvLCBjYikge1xuICAgIGlmICh0aGlzLnBpcGVUbyAhPT0gbnVsbCkgdGhyb3cgbmV3IEVycm9yKCdDYW4gb25seSBwaXBlIHRvIG9uZSBkZXN0aW5hdGlvbicpXG4gICAgaWYgKHR5cGVvZiBjYiAhPT0gJ2Z1bmN0aW9uJykgY2IgPSBudWxsXG5cbiAgICB0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgfD0gUkVBRF9QSVBFX0RSQUlORURcbiAgICB0aGlzLnBpcGVUbyA9IHBpcGVUb1xuICAgIHRoaXMucGlwZWxpbmUgPSBuZXcgUGlwZWxpbmUodGhpcy5zdHJlYW0sIHBpcGVUbywgY2IpXG5cbiAgICBpZiAoY2IpIHRoaXMuc3RyZWFtLm9uKCdlcnJvcicsIG5vb3ApIC8vIFdlIGFscmVhZHkgZXJyb3IgaGFuZGxlIHRoaXMgc28gc3VwcmVzcyBjcmFzaGVzXG5cbiAgICBpZiAoaXNTdHJlYW14KHBpcGVUbykpIHtcbiAgICAgIHBpcGVUby5fd3JpdGFibGVTdGF0ZS5waXBlbGluZSA9IHRoaXMucGlwZWxpbmVcbiAgICAgIGlmIChjYikgcGlwZVRvLm9uKCdlcnJvcicsIG5vb3ApIC8vIFdlIGFscmVhZHkgZXJyb3IgaGFuZGxlIHRoaXMgc28gc3VwcmVzcyBjcmFzaGVzXG4gICAgICBwaXBlVG8ub24oJ2ZpbmlzaCcsIHRoaXMucGlwZWxpbmUuZmluaXNoZWQuYmluZCh0aGlzLnBpcGVsaW5lKSkgLy8gVE9ETzoganVzdCBjYWxsIGZpbmlzaGVkIGZyb20gcGlwZVRvIGl0c2VsZlxuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvbmVycm9yID0gdGhpcy5waXBlbGluZS5kb25lLmJpbmQodGhpcy5waXBlbGluZSwgcGlwZVRvKVxuICAgICAgY29uc3Qgb25jbG9zZSA9IHRoaXMucGlwZWxpbmUuZG9uZS5iaW5kKHRoaXMucGlwZWxpbmUsIHBpcGVUbywgbnVsbCkgLy8gb25jbG9zZSBoYXMgYSB3ZWlyZCBib29sIGFyZ1xuICAgICAgcGlwZVRvLm9uKCdlcnJvcicsIG9uZXJyb3IpXG4gICAgICBwaXBlVG8ub24oJ2Nsb3NlJywgb25jbG9zZSlcbiAgICAgIHBpcGVUby5vbignZmluaXNoJywgdGhpcy5waXBlbGluZS5maW5pc2hlZC5iaW5kKHRoaXMucGlwZWxpbmUpKVxuICAgIH1cblxuICAgIHBpcGVUby5vbignZHJhaW4nLCBhZnRlckRyYWluLmJpbmQodGhpcykpXG4gICAgdGhpcy5zdHJlYW0uZW1pdCgncGlwaW5nJywgcGlwZVRvKVxuICAgIHBpcGVUby5lbWl0KCdwaXBlJywgdGhpcy5zdHJlYW0pXG4gIH1cblxuICBwdXNoIChkYXRhKSB7XG4gICAgY29uc3Qgc3RyZWFtID0gdGhpcy5zdHJlYW1cblxuICAgIGlmIChkYXRhID09PSBudWxsKSB7XG4gICAgICB0aGlzLmhpZ2hXYXRlck1hcmsgPSAwXG4gICAgICBzdHJlYW0uX2R1cGxleFN0YXRlID0gKHN0cmVhbS5fZHVwbGV4U3RhdGUgfCBSRUFEX0VORElORykgJiBSRUFEX05PTl9QUklNQVJZX0FORF9QVVNIRURcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIGlmICh0aGlzLm1hcCAhPT0gbnVsbCkge1xuICAgICAgZGF0YSA9IHRoaXMubWFwKGRhdGEpXG4gICAgICBpZiAoZGF0YSA9PT0gbnVsbCkge1xuICAgICAgICBzdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfUFVTSEVEXG4gICAgICAgIHJldHVybiB0aGlzLmJ1ZmZlcmVkIDwgdGhpcy5oaWdoV2F0ZXJNYXJrXG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5idWZmZXJlZCArPSB0aGlzLmJ5dGVMZW5ndGgoZGF0YSlcbiAgICB0aGlzLnF1ZXVlLnB1c2goZGF0YSlcblxuICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgPSAoc3RyZWFtLl9kdXBsZXhTdGF0ZSB8IFJFQURfUVVFVUVEKSAmIFJFQURfUFVTSEVEXG5cbiAgICByZXR1cm4gdGhpcy5idWZmZXJlZCA8IHRoaXMuaGlnaFdhdGVyTWFya1xuICB9XG5cbiAgc2hpZnQgKCkge1xuICAgIGNvbnN0IGRhdGEgPSB0aGlzLnF1ZXVlLnNoaWZ0KClcblxuICAgIHRoaXMuYnVmZmVyZWQgLT0gdGhpcy5ieXRlTGVuZ3RoKGRhdGEpXG4gICAgaWYgKHRoaXMuYnVmZmVyZWQgPT09IDApIHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmPSBSRUFEX05PVF9RVUVVRURcbiAgICByZXR1cm4gZGF0YVxuICB9XG5cbiAgdW5zaGlmdCAoZGF0YSkge1xuICAgIGNvbnN0IHBlbmRpbmcgPSBbdGhpcy5tYXAgIT09IG51bGwgPyB0aGlzLm1hcChkYXRhKSA6IGRhdGFdXG4gICAgd2hpbGUgKHRoaXMuYnVmZmVyZWQgPiAwKSBwZW5kaW5nLnB1c2godGhpcy5zaGlmdCgpKVxuXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwZW5kaW5nLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgY29uc3QgZGF0YSA9IHBlbmRpbmdbaV1cbiAgICAgIHRoaXMuYnVmZmVyZWQgKz0gdGhpcy5ieXRlTGVuZ3RoKGRhdGEpXG4gICAgICB0aGlzLnF1ZXVlLnB1c2goZGF0YSlcbiAgICB9XG5cbiAgICB0aGlzLnB1c2gocGVuZGluZ1twZW5kaW5nLmxlbmd0aCAtIDFdKVxuICB9XG5cbiAgcmVhZCAoKSB7XG4gICAgY29uc3Qgc3RyZWFtID0gdGhpcy5zdHJlYW1cblxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfU1RBVFVTKSA9PT0gUkVBRF9RVUVVRUQpIHtcbiAgICAgIGNvbnN0IGRhdGEgPSB0aGlzLnNoaWZ0KClcbiAgICAgIGlmICh0aGlzLnBpcGVUbyAhPT0gbnVsbCAmJiB0aGlzLnBpcGVUby53cml0ZShkYXRhKSA9PT0gZmFsc2UpIHN0cmVhbS5fZHVwbGV4U3RhdGUgJj0gUkVBRF9QSVBFX05PVF9EUkFJTkVEXG4gICAgICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX0VNSVRfREFUQSkgIT09IDApIHN0cmVhbS5lbWl0KCdkYXRhJywgZGF0YSlcbiAgICAgIHJldHVybiBkYXRhXG4gICAgfVxuXG4gICAgaWYgKHRoaXMucmVhZEFoZWFkID09PSBmYWxzZSkge1xuICAgICAgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBSRUFEX1JFQURfQUhFQURcbiAgICAgIHRoaXMudXBkYXRlTmV4dFRpY2soKVxuICAgIH1cblxuICAgIHJldHVybiBudWxsXG4gIH1cblxuICBkcmFpbiAoKSB7XG4gICAgY29uc3Qgc3RyZWFtID0gdGhpcy5zdHJlYW1cblxuICAgIHdoaWxlICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfU1RBVFVTKSA9PT0gUkVBRF9RVUVVRUQgJiYgKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX0ZMT1dJTkcpICE9PSAwKSB7XG4gICAgICBjb25zdCBkYXRhID0gdGhpcy5zaGlmdCgpXG4gICAgICBpZiAodGhpcy5waXBlVG8gIT09IG51bGwgJiYgdGhpcy5waXBlVG8ud3JpdGUoZGF0YSkgPT09IGZhbHNlKSBzdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfUElQRV9OT1RfRFJBSU5FRFxuICAgICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgUkVBRF9FTUlUX0RBVEEpICE9PSAwKSBzdHJlYW0uZW1pdCgnZGF0YScsIGRhdGEpXG4gICAgfVxuICB9XG5cbiAgdXBkYXRlICgpIHtcbiAgICBjb25zdCBzdHJlYW0gPSB0aGlzLnN0cmVhbVxuXG4gICAgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBSRUFEX1VQREFUSU5HXG5cbiAgICBkbyB7XG4gICAgICB0aGlzLmRyYWluKClcblxuICAgICAgd2hpbGUgKHRoaXMuYnVmZmVyZWQgPCB0aGlzLmhpZ2hXYXRlck1hcmsgJiYgKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBTSE9VTERfTk9UX1JFQUQpID09PSBSRUFEX1JFQURfQUhFQUQpIHtcbiAgICAgICAgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBSRUFEX0FDVElWRV9BTkRfTkVFRFNfUFVTSFxuICAgICAgICBzdHJlYW0uX3JlYWQodGhpcy5hZnRlclJlYWQpXG4gICAgICAgIHRoaXMuZHJhaW4oKVxuICAgICAgfVxuXG4gICAgICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX1JFQURBQkxFX1NUQVRVUykgPT09IFJFQURfRU1JVF9SRUFEQUJMRV9BTkRfUVVFVUVEKSB7XG4gICAgICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgfD0gUkVBRF9FTUlUVEVEX1JFQURBQkxFXG4gICAgICAgIHN0cmVhbS5lbWl0KCdyZWFkYWJsZScpXG4gICAgICB9XG5cbiAgICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfUFJJTUFSWV9BTkRfQUNUSVZFKSA9PT0gMCkgdGhpcy51cGRhdGVOb25QcmltYXJ5KClcbiAgICB9IHdoaWxlICh0aGlzLmNvbnRpbnVlVXBkYXRlKCkgPT09IHRydWUpXG5cbiAgICBzdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfTk9UX1VQREFUSU5HXG4gIH1cblxuICB1cGRhdGVOb25QcmltYXJ5ICgpIHtcbiAgICBjb25zdCBzdHJlYW0gPSB0aGlzLnN0cmVhbVxuXG4gICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgUkVBRF9FTkRJTkdfU1RBVFVTKSA9PT0gUkVBRF9FTkRJTkcpIHtcbiAgICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgPSAoc3RyZWFtLl9kdXBsZXhTdGF0ZSB8IFJFQURfRE9ORSkgJiBSRUFEX05PVF9FTkRJTkdcbiAgICAgIHN0cmVhbS5lbWl0KCdlbmQnKVxuICAgICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgQVVUT19ERVNUUk9ZKSA9PT0gRE9ORSkgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBERVNUUk9ZSU5HXG4gICAgICBpZiAodGhpcy5waXBlVG8gIT09IG51bGwpIHRoaXMucGlwZVRvLmVuZCgpXG4gICAgfVxuXG4gICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgREVTVFJPWV9TVEFUVVMpID09PSBERVNUUk9ZSU5HKSB7XG4gICAgICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBBQ1RJVkVfT1JfVElDS0lORykgPT09IDApIHtcbiAgICAgICAgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBBQ1RJVkVcbiAgICAgICAgc3RyZWFtLl9kZXN0cm95KGFmdGVyRGVzdHJveS5iaW5kKHRoaXMpKVxuICAgICAgfVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgSVNfT1BFTklORykgPT09IE9QRU5JTkcpIHtcbiAgICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgPSAoc3RyZWFtLl9kdXBsZXhTdGF0ZSB8IEFDVElWRSkgJiBOT1RfT1BFTklOR1xuICAgICAgc3RyZWFtLl9vcGVuKGFmdGVyT3Blbi5iaW5kKHRoaXMpKVxuICAgIH1cbiAgfVxuXG4gIGNvbnRpbnVlVXBkYXRlICgpIHtcbiAgICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfTkVYVF9USUNLKSA9PT0gMCkgcmV0dXJuIGZhbHNlXG4gICAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfTk9UX05FWFRfVElDS1xuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICB1cGRhdGVDYWxsYmFjayAoKSB7XG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX1VQREFURV9TWU5DX1NUQVRVUykgPT09IFJFQURfUFJJTUFSWSkgdGhpcy51cGRhdGUoKVxuICAgIGVsc2UgdGhpcy51cGRhdGVOZXh0VGljaygpXG4gIH1cblxuICB1cGRhdGVOZXh0VGlja0lmT3BlbiAoKSB7XG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX05FWFRfVElDS19PUl9PUEVOSU5HKSAhPT0gMCkgcmV0dXJuXG4gICAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlIHw9IFJFQURfTkVYVF9USUNLXG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX1VQREFUSU5HKSA9PT0gMCkgcXVldWVUaWNrKHRoaXMuYWZ0ZXJVcGRhdGVOZXh0VGljaylcbiAgfVxuXG4gIHVwZGF0ZU5leHRUaWNrICgpIHtcbiAgICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfTkVYVF9USUNLKSAhPT0gMCkgcmV0dXJuXG4gICAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlIHw9IFJFQURfTkVYVF9USUNLXG4gICAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX1VQREFUSU5HKSA9PT0gMCkgcXVldWVUaWNrKHRoaXMuYWZ0ZXJVcGRhdGVOZXh0VGljaylcbiAgfVxufVxuXG5jbGFzcyBUcmFuc2Zvcm1TdGF0ZSB7XG4gIGNvbnN0cnVjdG9yIChzdHJlYW0pIHtcbiAgICB0aGlzLmRhdGEgPSBudWxsXG4gICAgdGhpcy5hZnRlclRyYW5zZm9ybSA9IGFmdGVyVHJhbnNmb3JtLmJpbmQoc3RyZWFtKVxuICAgIHRoaXMuYWZ0ZXJGaW5hbCA9IG51bGxcbiAgfVxufVxuXG5jbGFzcyBQaXBlbGluZSB7XG4gIGNvbnN0cnVjdG9yIChzcmMsIGRzdCwgY2IpIHtcbiAgICB0aGlzLmZyb20gPSBzcmNcbiAgICB0aGlzLnRvID0gZHN0XG4gICAgdGhpcy5hZnRlclBpcGUgPSBjYlxuICAgIHRoaXMuZXJyb3IgPSBudWxsXG4gICAgdGhpcy5waXBlVG9GaW5pc2hlZCA9IGZhbHNlXG4gIH1cblxuICBmaW5pc2hlZCAoKSB7XG4gICAgdGhpcy5waXBlVG9GaW5pc2hlZCA9IHRydWVcbiAgfVxuXG4gIGRvbmUgKHN0cmVhbSwgZXJyKSB7XG4gICAgaWYgKGVycikgdGhpcy5lcnJvciA9IGVyclxuXG4gICAgaWYgKHN0cmVhbSA9PT0gdGhpcy50bykge1xuICAgICAgdGhpcy50byA9IG51bGxcblxuICAgICAgaWYgKHRoaXMuZnJvbSAhPT0gbnVsbCkge1xuICAgICAgICBpZiAoKHRoaXMuZnJvbS5fZHVwbGV4U3RhdGUgJiBSRUFEX0RPTkUpID09PSAwIHx8ICF0aGlzLnBpcGVUb0ZpbmlzaGVkKSB7XG4gICAgICAgICAgdGhpcy5mcm9tLmRlc3Ryb3kodGhpcy5lcnJvciB8fCBuZXcgRXJyb3IoJ1dyaXRhYmxlIHN0cmVhbSBjbG9zZWQgcHJlbWF0dXJlbHknKSlcbiAgICAgICAgfVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAoc3RyZWFtID09PSB0aGlzLmZyb20pIHtcbiAgICAgIHRoaXMuZnJvbSA9IG51bGxcblxuICAgICAgaWYgKHRoaXMudG8gIT09IG51bGwpIHtcbiAgICAgICAgaWYgKChzdHJlYW0uX2R1cGxleFN0YXRlICYgUkVBRF9ET05FKSA9PT0gMCkge1xuICAgICAgICAgIHRoaXMudG8uZGVzdHJveSh0aGlzLmVycm9yIHx8IG5ldyBFcnJvcignUmVhZGFibGUgc3RyZWFtIGNsb3NlZCBiZWZvcmUgZW5kaW5nJykpXG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuXG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKHRoaXMuYWZ0ZXJQaXBlICE9PSBudWxsKSB0aGlzLmFmdGVyUGlwZSh0aGlzLmVycm9yKVxuICAgIHRoaXMudG8gPSB0aGlzLmZyb20gPSB0aGlzLmFmdGVyUGlwZSA9IG51bGxcbiAgfVxufVxuXG5mdW5jdGlvbiBhZnRlckRyYWluICgpIHtcbiAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlIHw9IFJFQURfUElQRV9EUkFJTkVEXG4gIHRoaXMudXBkYXRlQ2FsbGJhY2soKVxufVxuXG5mdW5jdGlvbiBhZnRlckZpbmFsIChlcnIpIHtcbiAgY29uc3Qgc3RyZWFtID0gdGhpcy5zdHJlYW1cbiAgaWYgKGVycikgc3RyZWFtLmRlc3Ryb3koZXJyKVxuICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBERVNUUk9ZX1NUQVRVUykgPT09IDApIHtcbiAgICBzdHJlYW0uX2R1cGxleFN0YXRlIHw9IFdSSVRFX0RPTkVcbiAgICBzdHJlYW0uZW1pdCgnZmluaXNoJylcbiAgfVxuICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBBVVRPX0RFU1RST1kpID09PSBET05FKSB7XG4gICAgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBERVNUUk9ZSU5HXG4gIH1cblxuICBzdHJlYW0uX2R1cGxleFN0YXRlICY9IFdSSVRFX05PVF9GSU5JU0hJTkdcblxuICAvLyBubyBuZWVkIHRvIHdhaXQgdGhlIGV4dHJhIHRpY2sgaGVyZSwgc28gd2Ugc2hvcnQgY2lyY3VpdCB0aGF0XG4gIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX1VQREFUSU5HKSA9PT0gMCkgdGhpcy51cGRhdGUoKVxuICBlbHNlIHRoaXMudXBkYXRlTmV4dFRpY2soKVxufVxuXG5mdW5jdGlvbiBhZnRlckRlc3Ryb3kgKGVycikge1xuICBjb25zdCBzdHJlYW0gPSB0aGlzLnN0cmVhbVxuXG4gIGlmICghZXJyICYmIHRoaXMuZXJyb3IgIT09IFNUUkVBTV9ERVNUUk9ZRUQpIGVyciA9IHRoaXMuZXJyb3JcbiAgaWYgKGVycikgc3RyZWFtLmVtaXQoJ2Vycm9yJywgZXJyKVxuICBzdHJlYW0uX2R1cGxleFN0YXRlIHw9IERFU1RST1lFRFxuICBzdHJlYW0uZW1pdCgnY2xvc2UnKVxuXG4gIGNvbnN0IHJzID0gc3RyZWFtLl9yZWFkYWJsZVN0YXRlXG4gIGNvbnN0IHdzID0gc3RyZWFtLl93cml0YWJsZVN0YXRlXG5cbiAgaWYgKHJzICE9PSBudWxsICYmIHJzLnBpcGVsaW5lICE9PSBudWxsKSBycy5waXBlbGluZS5kb25lKHN0cmVhbSwgZXJyKVxuXG4gIGlmICh3cyAhPT0gbnVsbCkge1xuICAgIHdoaWxlICh3cy5kcmFpbnMgIT09IG51bGwgJiYgd3MuZHJhaW5zLmxlbmd0aCA+IDApIHdzLmRyYWlucy5zaGlmdCgpLnJlc29sdmUoZmFsc2UpXG4gICAgaWYgKHdzLnBpcGVsaW5lICE9PSBudWxsKSB3cy5waXBlbGluZS5kb25lKHN0cmVhbSwgZXJyKVxuICB9XG59XG5cbmZ1bmN0aW9uIGFmdGVyV3JpdGUgKGVycikge1xuICBjb25zdCBzdHJlYW0gPSB0aGlzLnN0cmVhbVxuXG4gIGlmIChlcnIpIHN0cmVhbS5kZXN0cm95KGVycilcbiAgc3RyZWFtLl9kdXBsZXhTdGF0ZSAmPSBXUklURV9OT1RfQUNUSVZFXG5cbiAgaWYgKHRoaXMuZHJhaW5zICE9PSBudWxsKSB0aWNrRHJhaW5zKHRoaXMuZHJhaW5zKVxuXG4gIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX0RSQUlOX1NUQVRVUykgPT09IFdSSVRFX1VORFJBSU5FRCkge1xuICAgIHN0cmVhbS5fZHVwbGV4U3RhdGUgJj0gV1JJVEVfRFJBSU5FRFxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX0VNSVRfRFJBSU4pID09PSBXUklURV9FTUlUX0RSQUlOKSB7XG4gICAgICBzdHJlYW0uZW1pdCgnZHJhaW4nKVxuICAgIH1cbiAgfVxuXG4gIHRoaXMudXBkYXRlQ2FsbGJhY2soKVxufVxuXG5mdW5jdGlvbiBhZnRlclJlYWQgKGVycikge1xuICBpZiAoZXJyKSB0aGlzLnN0cmVhbS5kZXN0cm95KGVycilcbiAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfTk9UX0FDVElWRVxuICBpZiAodGhpcy5yZWFkQWhlYWQgPT09IGZhbHNlICYmICh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBSRUFEX1JFU1VNRUQpID09PSAwKSB0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJj0gUkVBRF9OT19SRUFEX0FIRUFEXG4gIHRoaXMudXBkYXRlQ2FsbGJhY2soKVxufVxuXG5mdW5jdGlvbiB1cGRhdGVSZWFkTlQgKCkge1xuICBpZiAoKHRoaXMuc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfVVBEQVRJTkcpID09PSAwKSB7XG4gICAgdGhpcy5zdHJlYW0uX2R1cGxleFN0YXRlICY9IFJFQURfTk9UX05FWFRfVElDS1xuICAgIHRoaXMudXBkYXRlKClcbiAgfVxufVxuXG5mdW5jdGlvbiB1cGRhdGVXcml0ZU5UICgpIHtcbiAgaWYgKCh0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJiBXUklURV9VUERBVElORykgPT09IDApIHtcbiAgICB0aGlzLnN0cmVhbS5fZHVwbGV4U3RhdGUgJj0gV1JJVEVfTk9UX05FWFRfVElDS1xuICAgIHRoaXMudXBkYXRlKClcbiAgfVxufVxuXG5mdW5jdGlvbiB0aWNrRHJhaW5zIChkcmFpbnMpIHtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBkcmFpbnMubGVuZ3RoOyBpKyspIHtcbiAgICAvLyBkcmFpbnMud3JpdGVzIGFyZSBtb25vdG9uaWMsIHNvIGlmIG9uZSBpcyAwIGl0cyBhbHdheXMgdGhlIGZpcnN0IG9uZVxuICAgIGlmICgtLWRyYWluc1tpXS53cml0ZXMgPT09IDApIHtcbiAgICAgIGRyYWlucy5zaGlmdCgpLnJlc29sdmUodHJ1ZSlcbiAgICAgIGktLVxuICAgIH1cbiAgfVxufVxuXG5mdW5jdGlvbiBhZnRlck9wZW4gKGVycikge1xuICBjb25zdCBzdHJlYW0gPSB0aGlzLnN0cmVhbVxuXG4gIGlmIChlcnIpIHN0cmVhbS5kZXN0cm95KGVycilcblxuICBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBERVNUUk9ZSU5HKSA9PT0gMCkge1xuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFJFQURfUFJJTUFSWV9TVEFUVVMpID09PSAwKSBzdHJlYW0uX2R1cGxleFN0YXRlIHw9IFJFQURfUFJJTUFSWVxuICAgIGlmICgoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX1BSSU1BUllfU1RBVFVTKSA9PT0gMCkgc3RyZWFtLl9kdXBsZXhTdGF0ZSB8PSBXUklURV9QUklNQVJZXG4gICAgc3RyZWFtLmVtaXQoJ29wZW4nKVxuICB9XG5cbiAgc3RyZWFtLl9kdXBsZXhTdGF0ZSAmPSBOT1RfQUNUSVZFXG5cbiAgaWYgKHN0cmVhbS5fd3JpdGFibGVTdGF0ZSAhPT0gbnVsbCkge1xuICAgIHN0cmVhbS5fd3JpdGFibGVTdGF0ZS51cGRhdGVDYWxsYmFjaygpXG4gIH1cblxuICBpZiAoc3RyZWFtLl9yZWFkYWJsZVN0YXRlICE9PSBudWxsKSB7XG4gICAgc3RyZWFtLl9yZWFkYWJsZVN0YXRlLnVwZGF0ZUNhbGxiYWNrKClcbiAgfVxufVxuXG5mdW5jdGlvbiBhZnRlclRyYW5zZm9ybSAoZXJyLCBkYXRhKSB7XG4gIGlmIChkYXRhICE9PSB1bmRlZmluZWQgJiYgZGF0YSAhPT0gbnVsbCkgdGhpcy5wdXNoKGRhdGEpXG4gIHRoaXMuX3dyaXRhYmxlU3RhdGUuYWZ0ZXJXcml0ZShlcnIpXG59XG5cbmZ1bmN0aW9uIG5ld0xpc3RlbmVyIChuYW1lKSB7XG4gIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlICE9PSBudWxsKSB7XG4gICAgaWYgKG5hbWUgPT09ICdkYXRhJykge1xuICAgICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gKFJFQURfRU1JVF9EQVRBIHwgUkVBRF9SRVNVTUVEX1JFQURfQUhFQUQpXG4gICAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLnVwZGF0ZU5leHRUaWNrKClcbiAgICB9XG4gICAgaWYgKG5hbWUgPT09ICdyZWFkYWJsZScpIHtcbiAgICAgIHRoaXMuX2R1cGxleFN0YXRlIHw9IFJFQURfRU1JVF9SRUFEQUJMRVxuICAgICAgdGhpcy5fcmVhZGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgfVxuICB9XG5cbiAgaWYgKHRoaXMuX3dyaXRhYmxlU3RhdGUgIT09IG51bGwpIHtcbiAgICBpZiAobmFtZSA9PT0gJ2RyYWluJykge1xuICAgICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gV1JJVEVfRU1JVF9EUkFJTlxuICAgICAgdGhpcy5fd3JpdGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFN0cmVhbSBleHRlbmRzIEV2ZW50RW1pdHRlciB7XG4gIGNvbnN0cnVjdG9yIChvcHRzKSB7XG4gICAgc3VwZXIoKVxuXG4gICAgdGhpcy5fZHVwbGV4U3RhdGUgPSAwXG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZSA9IG51bGxcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlID0gbnVsbFxuXG4gICAgaWYgKG9wdHMpIHtcbiAgICAgIGlmIChvcHRzLm9wZW4pIHRoaXMuX29wZW4gPSBvcHRzLm9wZW5cbiAgICAgIGlmIChvcHRzLmRlc3Ryb3kpIHRoaXMuX2Rlc3Ryb3kgPSBvcHRzLmRlc3Ryb3lcbiAgICAgIGlmIChvcHRzLnByZWRlc3Ryb3kpIHRoaXMuX3ByZWRlc3Ryb3kgPSBvcHRzLnByZWRlc3Ryb3lcbiAgICAgIGlmIChvcHRzLnNpZ25hbCkge1xuICAgICAgICBvcHRzLnNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsIGFib3J0LmJpbmQodGhpcykpXG4gICAgICB9XG4gICAgfVxuXG4gICAgdGhpcy5vbignbmV3TGlzdGVuZXInLCBuZXdMaXN0ZW5lcilcbiAgfVxuXG4gIF9vcGVuIChjYikge1xuICAgIGNiKG51bGwpXG4gIH1cblxuICBfZGVzdHJveSAoY2IpIHtcbiAgICBjYihudWxsKVxuICB9XG5cbiAgX3ByZWRlc3Ryb3kgKCkge1xuICAgIC8vIGRvZXMgbm90aGluZ1xuICB9XG5cbiAgZ2V0IHJlYWRhYmxlICgpIHtcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZSAhPT0gbnVsbCA/IHRydWUgOiB1bmRlZmluZWRcbiAgfVxuXG4gIGdldCB3cml0YWJsZSAoKSB7XG4gICAgcmV0dXJuIHRoaXMuX3dyaXRhYmxlU3RhdGUgIT09IG51bGwgPyB0cnVlIDogdW5kZWZpbmVkXG4gIH1cblxuICBnZXQgZGVzdHJveWVkICgpIHtcbiAgICByZXR1cm4gKHRoaXMuX2R1cGxleFN0YXRlICYgREVTVFJPWUVEKSAhPT0gMFxuICB9XG5cbiAgZ2V0IGRlc3Ryb3lpbmcgKCkge1xuICAgIHJldHVybiAodGhpcy5fZHVwbGV4U3RhdGUgJiBERVNUUk9ZX1NUQVRVUykgIT09IDBcbiAgfVxuXG4gIGRlc3Ryb3kgKGVycikge1xuICAgIGlmICgodGhpcy5fZHVwbGV4U3RhdGUgJiBERVNUUk9ZX1NUQVRVUykgPT09IDApIHtcbiAgICAgIGlmICghZXJyKSBlcnIgPSBTVFJFQU1fREVTVFJPWUVEXG4gICAgICB0aGlzLl9kdXBsZXhTdGF0ZSA9ICh0aGlzLl9kdXBsZXhTdGF0ZSB8IERFU1RST1lJTkcpICYgTk9OX1BSSU1BUllcblxuICAgICAgaWYgKHRoaXMuX3JlYWRhYmxlU3RhdGUgIT09IG51bGwpIHtcbiAgICAgICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5oaWdoV2F0ZXJNYXJrID0gMFxuICAgICAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLmVycm9yID0gZXJyXG4gICAgICB9XG4gICAgICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZSAhPT0gbnVsbCkge1xuICAgICAgICB0aGlzLl93cml0YWJsZVN0YXRlLmhpZ2hXYXRlck1hcmsgPSAwXG4gICAgICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZXJyb3IgPSBlcnJcbiAgICAgIH1cblxuICAgICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gUFJFREVTVFJPWUlOR1xuICAgICAgdGhpcy5fcHJlZGVzdHJveSgpXG4gICAgICB0aGlzLl9kdXBsZXhTdGF0ZSAmPSBOT1RfUFJFREVTVFJPWUlOR1xuXG4gICAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZSAhPT0gbnVsbCkgdGhpcy5fcmVhZGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgICBpZiAodGhpcy5fd3JpdGFibGVTdGF0ZSAhPT0gbnVsbCkgdGhpcy5fd3JpdGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFJlYWRhYmxlIGV4dGVuZHMgU3RyZWFtIHtcbiAgY29uc3RydWN0b3IgKG9wdHMpIHtcbiAgICBzdXBlcihvcHRzKVxuXG4gICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gT1BFTklORyB8IFdSSVRFX0RPTkUgfCBSRUFEX1JFQURfQUhFQURcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlID0gbmV3IFJlYWRhYmxlU3RhdGUodGhpcywgb3B0cylcblxuICAgIGlmIChvcHRzKSB7XG4gICAgICBpZiAodGhpcy5fcmVhZGFibGVTdGF0ZS5yZWFkQWhlYWQgPT09IGZhbHNlKSB0aGlzLl9kdXBsZXhTdGF0ZSAmPSBSRUFEX05PX1JFQURfQUhFQURcbiAgICAgIGlmIChvcHRzLnJlYWQpIHRoaXMuX3JlYWQgPSBvcHRzLnJlYWRcbiAgICAgIGlmIChvcHRzLmVhZ2VyT3BlbikgdGhpcy5fcmVhZGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgICBpZiAob3B0cy5lbmNvZGluZykgdGhpcy5zZXRFbmNvZGluZyhvcHRzLmVuY29kaW5nKVxuICAgIH1cbiAgfVxuXG4gIHNldEVuY29kaW5nIChlbmNvZGluZykge1xuICAgIGNvbnN0IGRlYyA9IG5ldyBUZXh0RGVjb2RlcihlbmNvZGluZylcbiAgICBjb25zdCBtYXAgPSB0aGlzLl9yZWFkYWJsZVN0YXRlLm1hcCB8fCBlY2hvXG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS5tYXAgPSBtYXBPclNraXBcbiAgICByZXR1cm4gdGhpc1xuXG4gICAgZnVuY3Rpb24gbWFwT3JTa2lwIChkYXRhKSB7XG4gICAgICBjb25zdCBuZXh0ID0gZGVjLnB1c2goZGF0YSlcbiAgICAgIHJldHVybiBuZXh0ID09PSAnJyAmJiAoZGF0YS5ieXRlTGVuZ3RoICE9PSAwIHx8IGRlYy5yZW1haW5pbmcgPiAwKSA/IG51bGwgOiBtYXAobmV4dClcbiAgICB9XG4gIH1cblxuICBfcmVhZCAoY2IpIHtcbiAgICBjYihudWxsKVxuICB9XG5cbiAgcGlwZSAoZGVzdCwgY2IpIHtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLnVwZGF0ZU5leHRUaWNrKClcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLnBpcGUoZGVzdCwgY2IpXG4gICAgcmV0dXJuIGRlc3RcbiAgfVxuXG4gIHJlYWQgKCkge1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2soKVxuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLnJlYWQoKVxuICB9XG5cbiAgcHVzaCAoZGF0YSkge1xuICAgIHRoaXMuX3JlYWRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2tJZk9wZW4oKVxuICAgIHJldHVybiB0aGlzLl9yZWFkYWJsZVN0YXRlLnB1c2goZGF0YSlcbiAgfVxuXG4gIHVuc2hpZnQgKGRhdGEpIHtcbiAgICB0aGlzLl9yZWFkYWJsZVN0YXRlLnVwZGF0ZU5leHRUaWNrSWZPcGVuKClcbiAgICByZXR1cm4gdGhpcy5fcmVhZGFibGVTdGF0ZS51bnNoaWZ0KGRhdGEpXG4gIH1cblxuICByZXN1bWUgKCkge1xuICAgIHRoaXMuX2R1cGxleFN0YXRlIHw9IFJFQURfUkVTVU1FRF9SRUFEX0FIRUFEXG4gICAgdGhpcy5fcmVhZGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxuXG4gIHBhdXNlICgpIHtcbiAgICB0aGlzLl9kdXBsZXhTdGF0ZSAmPSAodGhpcy5fcmVhZGFibGVTdGF0ZS5yZWFkQWhlYWQgPT09IGZhbHNlID8gUkVBRF9QQVVTRURfTk9fUkVBRF9BSEVBRCA6IFJFQURfUEFVU0VEKVxuICAgIHJldHVybiB0aGlzXG4gIH1cblxuICBzdGF0aWMgX2Zyb21Bc3luY0l0ZXJhdG9yIChpdGUsIG9wdHMpIHtcbiAgICBsZXQgZGVzdHJveVxuXG4gICAgY29uc3QgcnMgPSBuZXcgUmVhZGFibGUoe1xuICAgICAgLi4ub3B0cyxcbiAgICAgIHJlYWQgKGNiKSB7XG4gICAgICAgIGl0ZS5uZXh0KCkudGhlbihwdXNoKS50aGVuKGNiLmJpbmQobnVsbCwgbnVsbCkpLmNhdGNoKGNiKVxuICAgICAgfSxcbiAgICAgIHByZWRlc3Ryb3kgKCkge1xuICAgICAgICBkZXN0cm95ID0gaXRlLnJldHVybigpXG4gICAgICB9LFxuICAgICAgZGVzdHJveSAoY2IpIHtcbiAgICAgICAgaWYgKCFkZXN0cm95KSByZXR1cm4gY2IobnVsbClcbiAgICAgICAgZGVzdHJveS50aGVuKGNiLmJpbmQobnVsbCwgbnVsbCkpLmNhdGNoKGNiKVxuICAgICAgfVxuICAgIH0pXG5cbiAgICByZXR1cm4gcnNcblxuICAgIGZ1bmN0aW9uIHB1c2ggKGRhdGEpIHtcbiAgICAgIGlmIChkYXRhLmRvbmUpIHJzLnB1c2gobnVsbClcbiAgICAgIGVsc2UgcnMucHVzaChkYXRhLnZhbHVlKVxuICAgIH1cbiAgfVxuXG4gIHN0YXRpYyBmcm9tIChkYXRhLCBvcHRzKSB7XG4gICAgaWYgKGlzUmVhZFN0cmVhbXgoZGF0YSkpIHJldHVybiBkYXRhXG4gICAgaWYgKGRhdGFbYXN5bmNJdGVyYXRvcl0pIHJldHVybiB0aGlzLl9mcm9tQXN5bmNJdGVyYXRvcihkYXRhW2FzeW5jSXRlcmF0b3JdKCksIG9wdHMpXG4gICAgaWYgKCFBcnJheS5pc0FycmF5KGRhdGEpKSBkYXRhID0gZGF0YSA9PT0gdW5kZWZpbmVkID8gW10gOiBbZGF0YV1cblxuICAgIGxldCBpID0gMFxuICAgIHJldHVybiBuZXcgUmVhZGFibGUoe1xuICAgICAgLi4ub3B0cyxcbiAgICAgIHJlYWQgKGNiKSB7XG4gICAgICAgIHRoaXMucHVzaChpID09PSBkYXRhLmxlbmd0aCA/IG51bGwgOiBkYXRhW2krK10pXG4gICAgICAgIGNiKG51bGwpXG4gICAgICB9XG4gICAgfSlcbiAgfVxuXG4gIHN0YXRpYyBpc0JhY2twcmVzc3VyZWQgKHJzKSB7XG4gICAgcmV0dXJuIChycy5fZHVwbGV4U3RhdGUgJiBSRUFEX0JBQ0tQUkVTU1VSRV9TVEFUVVMpICE9PSAwIHx8IHJzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlcmVkID49IHJzLl9yZWFkYWJsZVN0YXRlLmhpZ2hXYXRlck1hcmtcbiAgfVxuXG4gIHN0YXRpYyBpc1BhdXNlZCAocnMpIHtcbiAgICByZXR1cm4gKHJzLl9kdXBsZXhTdGF0ZSAmIFJFQURfUkVTVU1FRCkgPT09IDBcbiAgfVxuXG4gIFthc3luY0l0ZXJhdG9yXSAoKSB7XG4gICAgY29uc3Qgc3RyZWFtID0gdGhpc1xuXG4gICAgbGV0IGVycm9yID0gbnVsbFxuICAgIGxldCBwcm9taXNlUmVzb2x2ZSA9IG51bGxcbiAgICBsZXQgcHJvbWlzZVJlamVjdCA9IG51bGxcblxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycikgPT4geyBlcnJvciA9IGVyciB9KVxuICAgIHRoaXMub24oJ3JlYWRhYmxlJywgb25yZWFkYWJsZSlcbiAgICB0aGlzLm9uKCdjbG9zZScsIG9uY2xvc2UpXG5cbiAgICByZXR1cm4ge1xuICAgICAgW2FzeW5jSXRlcmF0b3JdICgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXNcbiAgICAgIH0sXG4gICAgICBuZXh0ICgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgICBwcm9taXNlUmVzb2x2ZSA9IHJlc29sdmVcbiAgICAgICAgICBwcm9taXNlUmVqZWN0ID0gcmVqZWN0XG4gICAgICAgICAgY29uc3QgZGF0YSA9IHN0cmVhbS5yZWFkKClcbiAgICAgICAgICBpZiAoZGF0YSAhPT0gbnVsbCkgb25kYXRhKGRhdGEpXG4gICAgICAgICAgZWxzZSBpZiAoKHN0cmVhbS5fZHVwbGV4U3RhdGUgJiBERVNUUk9ZRUQpICE9PSAwKSBvbmRhdGEobnVsbClcbiAgICAgICAgfSlcbiAgICAgIH0sXG4gICAgICByZXR1cm4gKCkge1xuICAgICAgICByZXR1cm4gZGVzdHJveShudWxsKVxuICAgICAgfSxcbiAgICAgIHRocm93IChlcnIpIHtcbiAgICAgICAgcmV0dXJuIGRlc3Ryb3koZXJyKVxuICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIG9ucmVhZGFibGUgKCkge1xuICAgICAgaWYgKHByb21pc2VSZXNvbHZlICE9PSBudWxsKSBvbmRhdGEoc3RyZWFtLnJlYWQoKSlcbiAgICB9XG5cbiAgICBmdW5jdGlvbiBvbmNsb3NlICgpIHtcbiAgICAgIGlmIChwcm9taXNlUmVzb2x2ZSAhPT0gbnVsbCkgb25kYXRhKG51bGwpXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gb25kYXRhIChkYXRhKSB7XG4gICAgICBpZiAocHJvbWlzZVJlamVjdCA9PT0gbnVsbCkgcmV0dXJuXG4gICAgICBpZiAoZXJyb3IpIHByb21pc2VSZWplY3QoZXJyb3IpXG4gICAgICBlbHNlIGlmIChkYXRhID09PSBudWxsICYmIChzdHJlYW0uX2R1cGxleFN0YXRlICYgUkVBRF9ET05FKSA9PT0gMCkgcHJvbWlzZVJlamVjdChTVFJFQU1fREVTVFJPWUVEKVxuICAgICAgZWxzZSBwcm9taXNlUmVzb2x2ZSh7IHZhbHVlOiBkYXRhLCBkb25lOiBkYXRhID09PSBudWxsIH0pXG4gICAgICBwcm9taXNlUmVqZWN0ID0gcHJvbWlzZVJlc29sdmUgPSBudWxsXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gZGVzdHJveSAoZXJyKSB7XG4gICAgICBzdHJlYW0uZGVzdHJveShlcnIpXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBpZiAoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIERFU1RST1lFRCkgcmV0dXJuIHJlc29sdmUoeyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH0pXG4gICAgICAgIHN0cmVhbS5vbmNlKCdjbG9zZScsIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICBpZiAoZXJyKSByZWplY3QoZXJyKVxuICAgICAgICAgIGVsc2UgcmVzb2x2ZSh7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfSlcbiAgICAgICAgfSlcbiAgICAgIH0pXG4gICAgfVxuICB9XG59XG5cbmNsYXNzIFdyaXRhYmxlIGV4dGVuZHMgU3RyZWFtIHtcbiAgY29uc3RydWN0b3IgKG9wdHMpIHtcbiAgICBzdXBlcihvcHRzKVxuXG4gICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gT1BFTklORyB8IFJFQURfRE9ORVxuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUgPSBuZXcgV3JpdGFibGVTdGF0ZSh0aGlzLCBvcHRzKVxuXG4gICAgaWYgKG9wdHMpIHtcbiAgICAgIGlmIChvcHRzLndyaXRldikgdGhpcy5fd3JpdGV2ID0gb3B0cy53cml0ZXZcbiAgICAgIGlmIChvcHRzLndyaXRlKSB0aGlzLl93cml0ZSA9IG9wdHMud3JpdGVcbiAgICAgIGlmIChvcHRzLmZpbmFsKSB0aGlzLl9maW5hbCA9IG9wdHMuZmluYWxcbiAgICAgIGlmIChvcHRzLmVhZ2VyT3BlbikgdGhpcy5fd3JpdGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gICAgfVxuICB9XG5cbiAgY29yayAoKSB7XG4gICAgdGhpcy5fZHVwbGV4U3RhdGUgfD0gV1JJVEVfQ09SS0VEXG4gIH1cblxuICB1bmNvcmsgKCkge1xuICAgIHRoaXMuX2R1cGxleFN0YXRlICY9IFdSSVRFX05PVF9DT1JLRURcbiAgICB0aGlzLl93cml0YWJsZVN0YXRlLnVwZGF0ZU5leHRUaWNrKClcbiAgfVxuXG4gIF93cml0ZXYgKGJhdGNoLCBjYikge1xuICAgIGNiKG51bGwpXG4gIH1cblxuICBfd3JpdGUgKGRhdGEsIGNiKSB7XG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS5hdXRvQmF0Y2goZGF0YSwgY2IpXG4gIH1cblxuICBfZmluYWwgKGNiKSB7XG4gICAgY2IobnVsbClcbiAgfVxuXG4gIHN0YXRpYyBpc0JhY2twcmVzc3VyZWQgKHdzKSB7XG4gICAgcmV0dXJuICh3cy5fZHVwbGV4U3RhdGUgJiBXUklURV9CQUNLUFJFU1NVUkVfU1RBVFVTKSAhPT0gMFxuICB9XG5cbiAgc3RhdGljIGRyYWluZWQgKHdzKSB7XG4gICAgaWYgKHdzLmRlc3Ryb3llZCkgcmV0dXJuIFByb21pc2UucmVzb2x2ZShmYWxzZSlcbiAgICBjb25zdCBzdGF0ZSA9IHdzLl93cml0YWJsZVN0YXRlXG4gICAgY29uc3QgcGVuZGluZyA9IChpc1dyaXRldih3cykgPyBNYXRoLm1pbigxLCBzdGF0ZS5xdWV1ZS5sZW5ndGgpIDogc3RhdGUucXVldWUubGVuZ3RoKVxuICAgIGNvbnN0IHdyaXRlcyA9IHBlbmRpbmcgKyAoKHdzLl9kdXBsZXhTdGF0ZSAmIFdSSVRFX1dSSVRJTkcpID8gMSA6IDApXG4gICAgaWYgKHdyaXRlcyA9PT0gMCkgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh0cnVlKVxuICAgIGlmIChzdGF0ZS5kcmFpbnMgPT09IG51bGwpIHN0YXRlLmRyYWlucyA9IFtdXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICBzdGF0ZS5kcmFpbnMucHVzaCh7IHdyaXRlcywgcmVzb2x2ZSB9KVxuICAgIH0pXG4gIH1cblxuICB3cml0ZSAoZGF0YSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2soKVxuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLnB1c2goZGF0YSlcbiAgfVxuXG4gIGVuZCAoZGF0YSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2soKVxuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZW5kKGRhdGEpXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxufVxuXG5jbGFzcyBEdXBsZXggZXh0ZW5kcyBSZWFkYWJsZSB7IC8vIGFuZCBXcml0YWJsZVxuICBjb25zdHJ1Y3RvciAob3B0cykge1xuICAgIHN1cGVyKG9wdHMpXG5cbiAgICB0aGlzLl9kdXBsZXhTdGF0ZSA9IE9QRU5JTkcgfCAodGhpcy5fZHVwbGV4U3RhdGUgJiBSRUFEX1JFQURfQUhFQUQpXG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZSA9IG5ldyBXcml0YWJsZVN0YXRlKHRoaXMsIG9wdHMpXG5cbiAgICBpZiAob3B0cykge1xuICAgICAgaWYgKG9wdHMud3JpdGV2KSB0aGlzLl93cml0ZXYgPSBvcHRzLndyaXRldlxuICAgICAgaWYgKG9wdHMud3JpdGUpIHRoaXMuX3dyaXRlID0gb3B0cy53cml0ZVxuICAgICAgaWYgKG9wdHMuZmluYWwpIHRoaXMuX2ZpbmFsID0gb3B0cy5maW5hbFxuICAgIH1cbiAgfVxuXG4gIGNvcmsgKCkge1xuICAgIHRoaXMuX2R1cGxleFN0YXRlIHw9IFdSSVRFX0NPUktFRFxuICB9XG5cbiAgdW5jb3JrICgpIHtcbiAgICB0aGlzLl9kdXBsZXhTdGF0ZSAmPSBXUklURV9OT1RfQ09SS0VEXG4gICAgdGhpcy5fd3JpdGFibGVTdGF0ZS51cGRhdGVOZXh0VGljaygpXG4gIH1cblxuICBfd3JpdGV2IChiYXRjaCwgY2IpIHtcbiAgICBjYihudWxsKVxuICB9XG5cbiAgX3dyaXRlIChkYXRhLCBjYikge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuYXV0b0JhdGNoKGRhdGEsIGNiKVxuICB9XG5cbiAgX2ZpbmFsIChjYikge1xuICAgIGNiKG51bGwpXG4gIH1cblxuICB3cml0ZSAoZGF0YSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2soKVxuICAgIHJldHVybiB0aGlzLl93cml0YWJsZVN0YXRlLnB1c2goZGF0YSlcbiAgfVxuXG4gIGVuZCAoZGF0YSkge1xuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUudXBkYXRlTmV4dFRpY2soKVxuICAgIHRoaXMuX3dyaXRhYmxlU3RhdGUuZW5kKGRhdGEpXG4gICAgcmV0dXJuIHRoaXNcbiAgfVxufVxuXG5jbGFzcyBUcmFuc2Zvcm0gZXh0ZW5kcyBEdXBsZXgge1xuICBjb25zdHJ1Y3RvciAob3B0cykge1xuICAgIHN1cGVyKG9wdHMpXG4gICAgdGhpcy5fdHJhbnNmb3JtU3RhdGUgPSBuZXcgVHJhbnNmb3JtU3RhdGUodGhpcylcblxuICAgIGlmIChvcHRzKSB7XG4gICAgICBpZiAob3B0cy50cmFuc2Zvcm0pIHRoaXMuX3RyYW5zZm9ybSA9IG9wdHMudHJhbnNmb3JtXG4gICAgICBpZiAob3B0cy5mbHVzaCkgdGhpcy5fZmx1c2ggPSBvcHRzLmZsdXNoXG4gICAgfVxuICB9XG5cbiAgX3dyaXRlIChkYXRhLCBjYikge1xuICAgIGlmICh0aGlzLl9yZWFkYWJsZVN0YXRlLmJ1ZmZlcmVkID49IHRoaXMuX3JlYWRhYmxlU3RhdGUuaGlnaFdhdGVyTWFyaykge1xuICAgICAgdGhpcy5fdHJhbnNmb3JtU3RhdGUuZGF0YSA9IGRhdGFcbiAgICB9IGVsc2Uge1xuICAgICAgdGhpcy5fdHJhbnNmb3JtKGRhdGEsIHRoaXMuX3RyYW5zZm9ybVN0YXRlLmFmdGVyVHJhbnNmb3JtKVxuICAgIH1cbiAgfVxuXG4gIF9yZWFkIChjYikge1xuICAgIGlmICh0aGlzLl90cmFuc2Zvcm1TdGF0ZS5kYXRhICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBkYXRhID0gdGhpcy5fdHJhbnNmb3JtU3RhdGUuZGF0YVxuICAgICAgdGhpcy5fdHJhbnNmb3JtU3RhdGUuZGF0YSA9IG51bGxcbiAgICAgIGNiKG51bGwpXG4gICAgICB0aGlzLl90cmFuc2Zvcm0oZGF0YSwgdGhpcy5fdHJhbnNmb3JtU3RhdGUuYWZ0ZXJUcmFuc2Zvcm0pXG4gICAgfSBlbHNlIHtcbiAgICAgIGNiKG51bGwpXG4gICAgfVxuICB9XG5cbiAgZGVzdHJveSAoZXJyKSB7XG4gICAgc3VwZXIuZGVzdHJveShlcnIpXG4gICAgaWYgKHRoaXMuX3RyYW5zZm9ybVN0YXRlLmRhdGEgIT09IG51bGwpIHtcbiAgICAgIHRoaXMuX3RyYW5zZm9ybVN0YXRlLmRhdGEgPSBudWxsXG4gICAgICB0aGlzLl90cmFuc2Zvcm1TdGF0ZS5hZnRlclRyYW5zZm9ybSgpXG4gICAgfVxuICB9XG5cbiAgX3RyYW5zZm9ybSAoZGF0YSwgY2IpIHtcbiAgICBjYihudWxsLCBkYXRhKVxuICB9XG5cbiAgX2ZsdXNoIChjYikge1xuICAgIGNiKG51bGwpXG4gIH1cblxuICBfZmluYWwgKGNiKSB7XG4gICAgdGhpcy5fdHJhbnNmb3JtU3RhdGUuYWZ0ZXJGaW5hbCA9IGNiXG4gICAgdGhpcy5fZmx1c2godHJhbnNmb3JtQWZ0ZXJGbHVzaC5iaW5kKHRoaXMpKVxuICB9XG59XG5cbmNsYXNzIFBhc3NUaHJvdWdoIGV4dGVuZHMgVHJhbnNmb3JtIHt9XG5cbmZ1bmN0aW9uIHRyYW5zZm9ybUFmdGVyRmx1c2ggKGVyciwgZGF0YSkge1xuICBjb25zdCBjYiA9IHRoaXMuX3RyYW5zZm9ybVN0YXRlLmFmdGVyRmluYWxcbiAgaWYgKGVycikgcmV0dXJuIGNiKGVycilcbiAgaWYgKGRhdGEgIT09IG51bGwgJiYgZGF0YSAhPT0gdW5kZWZpbmVkKSB0aGlzLnB1c2goZGF0YSlcbiAgdGhpcy5wdXNoKG51bGwpXG4gIGNiKG51bGwpXG59XG5cbmZ1bmN0aW9uIHBpcGVsaW5lUHJvbWlzZSAoLi4uc3RyZWFtcykge1xuICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgIHJldHVybiBwaXBlbGluZSguLi5zdHJlYW1zLCAoZXJyKSA9PiB7XG4gICAgICBpZiAoZXJyKSByZXR1cm4gcmVqZWN0KGVycilcbiAgICAgIHJlc29sdmUoKVxuICAgIH0pXG4gIH0pXG59XG5cbmZ1bmN0aW9uIHBpcGVsaW5lIChzdHJlYW0sIC4uLnN0cmVhbXMpIHtcbiAgY29uc3QgYWxsID0gQXJyYXkuaXNBcnJheShzdHJlYW0pID8gWy4uLnN0cmVhbSwgLi4uc3RyZWFtc10gOiBbc3RyZWFtLCAuLi5zdHJlYW1zXVxuICBjb25zdCBkb25lID0gKGFsbC5sZW5ndGggJiYgdHlwZW9mIGFsbFthbGwubGVuZ3RoIC0gMV0gPT09ICdmdW5jdGlvbicpID8gYWxsLnBvcCgpIDogbnVsbFxuXG4gIGlmIChhbGwubGVuZ3RoIDwgMikgdGhyb3cgbmV3IEVycm9yKCdQaXBlbGluZSByZXF1aXJlcyBhdCBsZWFzdCAyIHN0cmVhbXMnKVxuXG4gIGxldCBzcmMgPSBhbGxbMF1cbiAgbGV0IGRlc3QgPSBudWxsXG4gIGxldCBlcnJvciA9IG51bGxcblxuICBmb3IgKGxldCBpID0gMTsgaSA8IGFsbC5sZW5ndGg7IGkrKykge1xuICAgIGRlc3QgPSBhbGxbaV1cblxuICAgIGlmIChpc1N0cmVhbXgoc3JjKSkge1xuICAgICAgc3JjLnBpcGUoZGVzdCwgb25lcnJvcilcbiAgICB9IGVsc2Uge1xuICAgICAgZXJyb3JIYW5kbGUoc3JjLCB0cnVlLCBpID4gMSwgb25lcnJvcilcbiAgICAgIHNyYy5waXBlKGRlc3QpXG4gICAgfVxuXG4gICAgc3JjID0gZGVzdFxuICB9XG5cbiAgaWYgKGRvbmUpIHtcbiAgICBsZXQgZmluID0gZmFsc2VcblxuICAgIGNvbnN0IGF1dG9EZXN0cm95ID0gaXNTdHJlYW14KGRlc3QpIHx8ICEhKGRlc3QuX3dyaXRhYmxlU3RhdGUgJiYgZGVzdC5fd3JpdGFibGVTdGF0ZS5hdXRvRGVzdHJveSlcblxuICAgIGRlc3Qub24oJ2Vycm9yJywgKGVycikgPT4ge1xuICAgICAgaWYgKGVycm9yID09PSBudWxsKSBlcnJvciA9IGVyclxuICAgIH0pXG5cbiAgICBkZXN0Lm9uKCdmaW5pc2gnLCAoKSA9PiB7XG4gICAgICBmaW4gPSB0cnVlXG4gICAgICBpZiAoIWF1dG9EZXN0cm95KSBkb25lKGVycm9yKVxuICAgIH0pXG5cbiAgICBpZiAoYXV0b0Rlc3Ryb3kpIHtcbiAgICAgIGRlc3Qub24oJ2Nsb3NlJywgKCkgPT4gZG9uZShlcnJvciB8fCAoZmluID8gbnVsbCA6IFBSRU1BVFVSRV9DTE9TRSkpKVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBkZXN0XG5cbiAgZnVuY3Rpb24gZXJyb3JIYW5kbGUgKHMsIHJkLCB3ciwgb25lcnJvcikge1xuICAgIHMub24oJ2Vycm9yJywgb25lcnJvcilcbiAgICBzLm9uKCdjbG9zZScsIG9uY2xvc2UpXG5cbiAgICBmdW5jdGlvbiBvbmNsb3NlICgpIHtcbiAgICAgIGlmIChyZCAmJiBzLl9yZWFkYWJsZVN0YXRlICYmICFzLl9yZWFkYWJsZVN0YXRlLmVuZGVkKSByZXR1cm4gb25lcnJvcihQUkVNQVRVUkVfQ0xPU0UpXG4gICAgICBpZiAod3IgJiYgcy5fd3JpdGFibGVTdGF0ZSAmJiAhcy5fd3JpdGFibGVTdGF0ZS5lbmRlZCkgcmV0dXJuIG9uZXJyb3IoUFJFTUFUVVJFX0NMT1NFKVxuICAgIH1cbiAgfVxuXG4gIGZ1bmN0aW9uIG9uZXJyb3IgKGVycikge1xuICAgIGlmICghZXJyIHx8IGVycm9yKSByZXR1cm5cbiAgICBlcnJvciA9IGVyclxuXG4gICAgZm9yIChjb25zdCBzIG9mIGFsbCkge1xuICAgICAgcy5kZXN0cm95KGVycilcbiAgICB9XG4gIH1cbn1cblxuZnVuY3Rpb24gZWNobyAocykge1xuICByZXR1cm4gc1xufVxuXG5mdW5jdGlvbiBpc1N0cmVhbSAoc3RyZWFtKSB7XG4gIHJldHVybiAhIXN0cmVhbS5fcmVhZGFibGVTdGF0ZSB8fCAhIXN0cmVhbS5fd3JpdGFibGVTdGF0ZVxufVxuXG5mdW5jdGlvbiBpc1N0cmVhbXggKHN0cmVhbSkge1xuICByZXR1cm4gdHlwZW9mIHN0cmVhbS5fZHVwbGV4U3RhdGUgPT09ICdudW1iZXInICYmIGlzU3RyZWFtKHN0cmVhbSlcbn1cblxuZnVuY3Rpb24gaXNFbmRlZCAoc3RyZWFtKSB7XG4gIHJldHVybiAhIXN0cmVhbS5fcmVhZGFibGVTdGF0ZSAmJiBzdHJlYW0uX3JlYWRhYmxlU3RhdGUuZW5kZWRcbn1cblxuZnVuY3Rpb24gaXNGaW5pc2hlZCAoc3RyZWFtKSB7XG4gIHJldHVybiAhIXN0cmVhbS5fd3JpdGFibGVTdGF0ZSAmJiBzdHJlYW0uX3dyaXRhYmxlU3RhdGUuZW5kZWRcbn1cblxuZnVuY3Rpb24gZ2V0U3RyZWFtRXJyb3IgKHN0cmVhbSwgb3B0cyA9IHt9KSB7XG4gIGNvbnN0IGVyciA9IChzdHJlYW0uX3JlYWRhYmxlU3RhdGUgJiYgc3RyZWFtLl9yZWFkYWJsZVN0YXRlLmVycm9yKSB8fCAoc3RyZWFtLl93cml0YWJsZVN0YXRlICYmIHN0cmVhbS5fd3JpdGFibGVTdGF0ZS5lcnJvcilcblxuICAvLyBhdm9pZCBpbXBsaWNpdCBlcnJvcnMgYnkgZGVmYXVsdFxuICByZXR1cm4gKCFvcHRzLmFsbCAmJiBlcnIgPT09IFNUUkVBTV9ERVNUUk9ZRUQpID8gbnVsbCA6IGVyclxufVxuXG5mdW5jdGlvbiBpc1JlYWRTdHJlYW14IChzdHJlYW0pIHtcbiAgcmV0dXJuIGlzU3RyZWFteChzdHJlYW0pICYmIHN0cmVhbS5yZWFkYWJsZVxufVxuXG5mdW5jdGlvbiBpc0Rpc3R1cmJlZCAoc3RyZWFtKSB7XG4gIHJldHVybiAoc3RyZWFtLl9kdXBsZXhTdGF0ZSAmIE9QRU5JTkcpICE9PSBPUEVOSU5HIHx8IChzdHJlYW0uX2R1cGxleFN0YXRlICYgQUNUSVZFX09SX1RJQ0tJTkcpICE9PSAwXG59XG5cbmZ1bmN0aW9uIGlzVHlwZWRBcnJheSAoZGF0YSkge1xuICByZXR1cm4gdHlwZW9mIGRhdGEgPT09ICdvYmplY3QnICYmIGRhdGEgIT09IG51bGwgJiYgdHlwZW9mIGRhdGEuYnl0ZUxlbmd0aCA9PT0gJ251bWJlcidcbn1cblxuZnVuY3Rpb24gZGVmYXVsdEJ5dGVMZW5ndGggKGRhdGEpIHtcbiAgcmV0dXJuIGlzVHlwZWRBcnJheShkYXRhKSA/IGRhdGEuYnl0ZUxlbmd0aCA6IDEwMjRcbn1cblxuZnVuY3Rpb24gbm9vcCAoKSB7fVxuXG5mdW5jdGlvbiBhYm9ydCAoKSB7XG4gIHRoaXMuZGVzdHJveShuZXcgRXJyb3IoJ1N0cmVhbSBhYm9ydGVkLicpKVxufVxuXG5mdW5jdGlvbiBpc1dyaXRldiAocykge1xuICByZXR1cm4gcy5fd3JpdGV2ICE9PSBXcml0YWJsZS5wcm90b3R5cGUuX3dyaXRldiAmJiBzLl93cml0ZXYgIT09IER1cGxleC5wcm90b3R5cGUuX3dyaXRldlxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgcGlwZWxpbmUsXG4gIHBpcGVsaW5lUHJvbWlzZSxcbiAgaXNTdHJlYW0sXG4gIGlzU3RyZWFteCxcbiAgaXNFbmRlZCxcbiAgaXNGaW5pc2hlZCxcbiAgaXNEaXN0dXJiZWQsXG4gIGdldFN0cmVhbUVycm9yLFxuICBTdHJlYW0sXG4gIFdyaXRhYmxlLFxuICBSZWFkYWJsZSxcbiAgRHVwbGV4LFxuICBUcmFuc2Zvcm0sXG4gIC8vIEV4cG9ydCBQYXNzVGhyb3VnaCBmb3IgY29tcGF0aWJpbGl0eSB3aXRoIE5vZGUuanMgY29yZSdzIHN0cmVhbSBtb2R1bGVcbiAgUGFzc1Rocm91Z2hcbn1cbiIsICJmdW5jdGlvbiBieXRlTGVuZ3RoIChzdHJpbmcpIHtcbiAgcmV0dXJuIHN0cmluZy5sZW5ndGhcbn1cblxuZnVuY3Rpb24gdG9TdHJpbmcgKGJ1ZmZlcikge1xuICBjb25zdCBsZW4gPSBidWZmZXIuYnl0ZUxlbmd0aFxuXG4gIGxldCByZXN1bHQgPSAnJ1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICByZXN1bHQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShidWZmZXJbaV0pXG4gIH1cblxuICByZXR1cm4gcmVzdWx0XG59XG5cbmZ1bmN0aW9uIHdyaXRlIChidWZmZXIsIHN0cmluZywgb2Zmc2V0ID0gMCwgbGVuZ3RoID0gYnl0ZUxlbmd0aChzdHJpbmcpKSB7XG4gIGNvbnN0IGxlbiA9IE1hdGgubWluKGxlbmd0aCwgYnVmZmVyLmJ5dGVMZW5ndGggLSBvZmZzZXQpXG5cbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgIGJ1ZmZlcltvZmZzZXQgKyBpXSA9IHN0cmluZy5jaGFyQ29kZUF0KGkpXG4gIH1cblxuICByZXR1cm4gbGVuXG59XG5cbm1vZHVsZS5leHBvcnRzID0ge1xuICBieXRlTGVuZ3RoLFxuICB0b1N0cmluZyxcbiAgd3JpdGVcbn1cbiIsICJjb25zdCBhbHBoYWJldCA9ICdBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6MDEyMzQ1Njc4OSsvJ1xuXG5jb25zdCBjb2RlcyA9IG5ldyBVaW50OEFycmF5KDI1NilcblxuZm9yIChsZXQgaSA9IDA7IGkgPCBhbHBoYWJldC5sZW5ndGg7IGkrKykge1xuICBjb2Rlc1thbHBoYWJldC5jaGFyQ29kZUF0KGkpXSA9IGlcbn1cblxuY29kZXNbLyogLSAqLyAweDJkXSA9IDYyXG5jb2Rlc1svKiBfICovIDB4NWZdID0gNjNcblxuZnVuY3Rpb24gYnl0ZUxlbmd0aCAoc3RyaW5nKSB7XG4gIGxldCBsZW4gPSBzdHJpbmcubGVuZ3RoXG5cbiAgaWYgKHN0cmluZy5jaGFyQ29kZUF0KGxlbiAtIDEpID09PSAweDNkKSBsZW4tLVxuICBpZiAobGVuID4gMSAmJiBzdHJpbmcuY2hhckNvZGVBdChsZW4gLSAxKSA9PT0gMHgzZCkgbGVuLS1cblxuICByZXR1cm4gKGxlbiAqIDMpID4+PiAyXG59XG5cbmZ1bmN0aW9uIHRvU3RyaW5nIChidWZmZXIpIHtcbiAgY29uc3QgbGVuID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBsZXQgcmVzdWx0ID0gJydcblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSAzKSB7XG4gICAgcmVzdWx0ICs9IChcbiAgICAgIGFscGhhYmV0W2J1ZmZlcltpXSA+PiAyXSArXG4gICAgICBhbHBoYWJldFsoKGJ1ZmZlcltpXSAmIDMpIDw8IDQpIHwgKGJ1ZmZlcltpICsgMV0gPj4gNCldICtcbiAgICAgIGFscGhhYmV0WygoYnVmZmVyW2kgKyAxXSAmIDE1KSA8PCAyKSB8IChidWZmZXJbaSArIDJdID4+IDYpXSArXG4gICAgICBhbHBoYWJldFtidWZmZXJbaSArIDJdICYgNjNdXG4gICAgKVxuICB9XG5cbiAgaWYgKGxlbiAlIDMgPT09IDIpIHtcbiAgICByZXN1bHQgPSByZXN1bHQuc3Vic3RyaW5nKDAsIHJlc3VsdC5sZW5ndGggLSAxKSArICc9J1xuICB9IGVsc2UgaWYgKGxlbiAlIDMgPT09IDEpIHtcbiAgICByZXN1bHQgPSByZXN1bHQuc3Vic3RyaW5nKDAsIHJlc3VsdC5sZW5ndGggLSAyKSArICc9PSdcbiAgfVxuXG4gIHJldHVybiByZXN1bHRcbn07XG5cbmZ1bmN0aW9uIHdyaXRlIChidWZmZXIsIHN0cmluZywgb2Zmc2V0ID0gMCwgbGVuZ3RoID0gYnl0ZUxlbmd0aChzdHJpbmcpKSB7XG4gIGNvbnN0IGxlbiA9IE1hdGgubWluKGxlbmd0aCwgYnVmZmVyLmJ5dGVMZW5ndGggLSBvZmZzZXQpXG5cbiAgZm9yIChsZXQgaSA9IDAsIGogPSAwOyBqIDwgbGVuOyBpICs9IDQpIHtcbiAgICBjb25zdCBhID0gY29kZXNbc3RyaW5nLmNoYXJDb2RlQXQoaSldXG4gICAgY29uc3QgYiA9IGNvZGVzW3N0cmluZy5jaGFyQ29kZUF0KGkgKyAxKV1cbiAgICBjb25zdCBjID0gY29kZXNbc3RyaW5nLmNoYXJDb2RlQXQoaSArIDIpXVxuICAgIGNvbnN0IGQgPSBjb2Rlc1tzdHJpbmcuY2hhckNvZGVBdChpICsgMyldXG5cbiAgICBidWZmZXJbaisrXSA9IChhIDw8IDIpIHwgKGIgPj4gNClcbiAgICBidWZmZXJbaisrXSA9ICgoYiAmIDE1KSA8PCA0KSB8IChjID4+IDIpXG4gICAgYnVmZmVyW2orK10gPSAoKGMgJiAzKSA8PCA2KSB8IChkICYgNjMpXG4gIH1cblxuICByZXR1cm4gbGVuXG59O1xuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgYnl0ZUxlbmd0aCxcbiAgdG9TdHJpbmcsXG4gIHdyaXRlXG59XG4iLCAiZnVuY3Rpb24gYnl0ZUxlbmd0aCAoc3RyaW5nKSB7XG4gIHJldHVybiBzdHJpbmcubGVuZ3RoID4+PiAxXG59XG5cbmZ1bmN0aW9uIHRvU3RyaW5nIChidWZmZXIpIHtcbiAgY29uc3QgbGVuID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBidWZmZXIgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGxlbilcblxuICBsZXQgcmVzdWx0ID0gJydcbiAgbGV0IGkgPSAwXG5cbiAgZm9yIChsZXQgbiA9IGxlbiAtIChsZW4gJSA0KTsgaSA8IG47IGkgKz0gNCkge1xuICAgIHJlc3VsdCArPSBidWZmZXIuZ2V0VWludDMyKGkpLnRvU3RyaW5nKDE2KS5wYWRTdGFydCg4LCAnMCcpXG4gIH1cblxuICBmb3IgKDsgaSA8IGxlbjsgaSsrKSB7XG4gICAgcmVzdWx0ICs9IGJ1ZmZlci5nZXRVaW50OChpKS50b1N0cmluZygxNikucGFkU3RhcnQoMiwgJzAnKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5mdW5jdGlvbiB3cml0ZSAoYnVmZmVyLCBzdHJpbmcsIG9mZnNldCA9IDAsIGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nKSkge1xuICBjb25zdCBsZW4gPSBNYXRoLm1pbihsZW5ndGgsIGJ1ZmZlci5ieXRlTGVuZ3RoIC0gb2Zmc2V0KVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCBhID0gaGV4VmFsdWUoc3RyaW5nLmNoYXJDb2RlQXQoaSAqIDIpKVxuICAgIGNvbnN0IGIgPSBoZXhWYWx1ZShzdHJpbmcuY2hhckNvZGVBdChpICogMiArIDEpKVxuXG4gICAgaWYgKGEgPT09IHVuZGVmaW5lZCB8fCBiID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJldHVybiBidWZmZXIuc3ViYXJyYXkoMCwgaSlcbiAgICB9XG5cbiAgICBidWZmZXJbb2Zmc2V0ICsgaV0gPSAoYSA8PCA0KSB8IGJcbiAgfVxuXG4gIHJldHVybiBsZW5cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGJ5dGVMZW5ndGgsXG4gIHRvU3RyaW5nLFxuICB3cml0ZVxufVxuXG5mdW5jdGlvbiBoZXhWYWx1ZSAoY2hhcikge1xuICBpZiAoY2hhciA+PSAweDMwICYmIGNoYXIgPD0gMHgzOSkgcmV0dXJuIGNoYXIgLSAweDMwXG4gIGlmIChjaGFyID49IDB4NDEgJiYgY2hhciA8PSAweDQ2KSByZXR1cm4gY2hhciAtIDB4NDEgKyAxMFxuICBpZiAoY2hhciA+PSAweDYxICYmIGNoYXIgPD0gMHg2NikgcmV0dXJuIGNoYXIgLSAweDYxICsgMTBcbn1cbiIsICJmdW5jdGlvbiBieXRlTGVuZ3RoIChzdHJpbmcpIHtcbiAgbGV0IGxlbmd0aCA9IDBcblxuICBmb3IgKGxldCBpID0gMCwgbiA9IHN0cmluZy5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICBjb25zdCBjb2RlID0gc3RyaW5nLmNoYXJDb2RlQXQoaSlcblxuICAgIGlmIChjb2RlID49IDB4ZDgwMCAmJiBjb2RlIDw9IDB4ZGJmZiAmJiBpICsgMSA8IG4pIHtcbiAgICAgIGNvbnN0IGNvZGUgPSBzdHJpbmcuY2hhckNvZGVBdChpICsgMSlcblxuICAgICAgaWYgKGNvZGUgPj0gMHhkYzAwICYmIGNvZGUgPD0gMHhkZmZmKSB7XG4gICAgICAgIGxlbmd0aCArPSA0XG4gICAgICAgIGkrK1xuICAgICAgICBjb250aW51ZVxuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChjb2RlIDw9IDB4N2YpIGxlbmd0aCArPSAxXG4gICAgZWxzZSBpZiAoY29kZSA8PSAweDdmZikgbGVuZ3RoICs9IDJcbiAgICBlbHNlIGxlbmd0aCArPSAzXG4gIH1cblxuICByZXR1cm4gbGVuZ3RoXG59XG5cbmxldCB0b1N0cmluZ1xuXG5pZiAodHlwZW9mIFRleHREZWNvZGVyICE9PSAndW5kZWZpbmVkJykge1xuICBjb25zdCBkZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKClcblxuICB0b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nIChidWZmZXIpIHtcbiAgICByZXR1cm4gZGVjb2Rlci5kZWNvZGUoYnVmZmVyKVxuICB9XG59IGVsc2Uge1xuICB0b1N0cmluZyA9IGZ1bmN0aW9uIHRvU3RyaW5nIChidWZmZXIpIHtcbiAgICBjb25zdCBsZW4gPSBidWZmZXIuYnl0ZUxlbmd0aFxuXG4gICAgbGV0IG91dHB1dCA9ICcnXG4gICAgbGV0IGkgPSAwXG5cbiAgICB3aGlsZSAoaSA8IGxlbikge1xuICAgICAgbGV0IGJ5dGUgPSBidWZmZXJbaV1cblxuICAgICAgaWYgKGJ5dGUgPD0gMHg3Zikge1xuICAgICAgICBvdXRwdXQgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlKVxuICAgICAgICBpKytcbiAgICAgICAgY29udGludWVcbiAgICAgIH1cblxuICAgICAgbGV0IGJ5dGVzTmVlZGVkID0gMFxuICAgICAgbGV0IGNvZGVQb2ludCA9IDBcblxuICAgICAgaWYgKGJ5dGUgPD0gMHhkZikge1xuICAgICAgICBieXRlc05lZWRlZCA9IDFcbiAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MWZcbiAgICAgIH0gZWxzZSBpZiAoYnl0ZSA8PSAweGVmKSB7XG4gICAgICAgIGJ5dGVzTmVlZGVkID0gMlxuICAgICAgICBjb2RlUG9pbnQgPSBieXRlICYgMHgwZlxuICAgICAgfSBlbHNlIGlmIChieXRlIDw9IDB4ZjQpIHtcbiAgICAgICAgYnl0ZXNOZWVkZWQgPSAzXG4gICAgICAgIGNvZGVQb2ludCA9IGJ5dGUgJiAweDA3XG4gICAgICB9XG5cbiAgICAgIGlmIChsZW4gLSBpIC0gYnl0ZXNOZWVkZWQgPiAwKSB7XG4gICAgICAgIGxldCBrID0gMFxuXG4gICAgICAgIHdoaWxlIChrIDwgYnl0ZXNOZWVkZWQpIHtcbiAgICAgICAgICBieXRlID0gYnVmZmVyW2kgKyBrICsgMV1cbiAgICAgICAgICBjb2RlUG9pbnQgPSAoY29kZVBvaW50IDw8IDYpIHwgKGJ5dGUgJiAweDNmKVxuICAgICAgICAgIGsgKz0gMVxuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb2RlUG9pbnQgPSAweGZmZmRcbiAgICAgICAgYnl0ZXNOZWVkZWQgPSBsZW4gLSBpXG4gICAgICB9XG5cbiAgICAgIG91dHB1dCArPSBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlUG9pbnQpXG4gICAgICBpICs9IGJ5dGVzTmVlZGVkICsgMVxuICAgIH1cblxuICAgIHJldHVybiBvdXRwdXRcbiAgfVxufVxuXG5sZXQgd3JpdGVcblxuaWYgKHR5cGVvZiBUZXh0RW5jb2RlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpXG5cbiAgd3JpdGUgPSBmdW5jdGlvbiB3cml0ZSAoYnVmZmVyLCBzdHJpbmcsIG9mZnNldCA9IDAsIGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nKSkge1xuICAgIGNvbnN0IGxlbiA9IE1hdGgubWluKGxlbmd0aCwgYnVmZmVyLmJ5dGVMZW5ndGggLSBvZmZzZXQpXG4gICAgZW5jb2Rlci5lbmNvZGVJbnRvKHN0cmluZywgYnVmZmVyLnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKSlcbiAgICByZXR1cm4gbGVuXG4gIH1cbn0gZWxzZSB7XG4gIHdyaXRlID0gZnVuY3Rpb24gd3JpdGUgKGJ1ZmZlciwgc3RyaW5nLCBvZmZzZXQgPSAwLCBsZW5ndGggPSBieXRlTGVuZ3RoKHN0cmluZykpIHtcbiAgICBjb25zdCBsZW4gPSBNYXRoLm1pbihsZW5ndGgsIGJ1ZmZlci5ieXRlTGVuZ3RoIC0gb2Zmc2V0KVxuXG4gICAgYnVmZmVyID0gYnVmZmVyLnN1YmFycmF5KG9mZnNldCwgb2Zmc2V0ICsgbGVuKVxuXG4gICAgbGV0IGkgPSAwXG4gICAgbGV0IGogPSAwXG5cbiAgICB3aGlsZSAoaSA8IHN0cmluZy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IGNvZGUgPSBzdHJpbmcuY29kZVBvaW50QXQoaSlcblxuICAgICAgaWYgKGNvZGUgPD0gMHg3Zikge1xuICAgICAgICBidWZmZXJbaisrXSA9IGNvZGVcbiAgICAgICAgaSsrXG4gICAgICAgIGNvbnRpbnVlXG4gICAgICB9XG5cbiAgICAgIGxldCBjb3VudCA9IDBcbiAgICAgIGxldCBiaXRzID0gMFxuXG4gICAgICBpZiAoY29kZSA8PSAweDdmZikge1xuICAgICAgICBjb3VudCA9IDZcbiAgICAgICAgYml0cyA9IDB4YzBcbiAgICAgIH0gZWxzZSBpZiAoY29kZSA8PSAweGZmZmYpIHtcbiAgICAgICAgY291bnQgPSAxMlxuICAgICAgICBiaXRzID0gMHhlMFxuICAgICAgfSBlbHNlIGlmIChjb2RlIDw9IDB4MWZmZmZmKSB7XG4gICAgICAgIGNvdW50ID0gMThcbiAgICAgICAgYml0cyA9IDB4ZjBcbiAgICAgIH1cblxuICAgICAgYnVmZmVyW2orK10gPSBiaXRzIHwgKGNvZGUgPj4gY291bnQpXG4gICAgICBjb3VudCAtPSA2XG5cbiAgICAgIHdoaWxlIChjb3VudCA+PSAwKSB7XG4gICAgICAgIGJ1ZmZlcltqKytdID0gMHg4MCB8ICgoY29kZSA+PiBjb3VudCkgJiAweDNmKVxuICAgICAgICBjb3VudCAtPSA2XG4gICAgICB9XG5cbiAgICAgIGkgKz0gY29kZSA+PSAweDEwMDAwID8gMiA6IDFcbiAgICB9XG5cbiAgICByZXR1cm4gbGVuXG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSB7XG4gIGJ5dGVMZW5ndGgsXG4gIHRvU3RyaW5nLFxuICB3cml0ZVxufVxuIiwgImZ1bmN0aW9uIGJ5dGVMZW5ndGggKHN0cmluZykge1xuICByZXR1cm4gc3RyaW5nLmxlbmd0aCAqIDJcbn1cblxuZnVuY3Rpb24gdG9TdHJpbmcgKGJ1ZmZlcikge1xuICBjb25zdCBsZW4gPSBidWZmZXIuYnl0ZUxlbmd0aFxuXG4gIGxldCByZXN1bHQgPSAnJ1xuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuIC0gMTsgaSArPSAyKSB7XG4gICAgcmVzdWx0ICs9IFN0cmluZy5mcm9tQ2hhckNvZGUoYnVmZmVyW2ldICsgKGJ1ZmZlcltpICsgMV0gKiAyNTYpKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5mdW5jdGlvbiB3cml0ZSAoYnVmZmVyLCBzdHJpbmcsIG9mZnNldCA9IDAsIGxlbmd0aCA9IGJ5dGVMZW5ndGgoc3RyaW5nKSkge1xuICBjb25zdCBsZW4gPSBNYXRoLm1pbihsZW5ndGgsIGJ1ZmZlci5ieXRlTGVuZ3RoIC0gb2Zmc2V0KVxuXG4gIGxldCB1bml0cyA9IGxlblxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgc3RyaW5nLmxlbmd0aDsgKytpKSB7XG4gICAgaWYgKCh1bml0cyAtPSAyKSA8IDApIGJyZWFrXG5cbiAgICBjb25zdCBjID0gc3RyaW5nLmNoYXJDb2RlQXQoaSlcbiAgICBjb25zdCBoaSA9IGMgPj4gOFxuICAgIGNvbnN0IGxvID0gYyAlIDI1NlxuXG4gICAgYnVmZmVyW29mZnNldCArIGkgKiAyXSA9IGxvXG4gICAgYnVmZmVyW29mZnNldCArIGkgKiAyICsgMV0gPSBoaVxuICB9XG5cbiAgcmV0dXJuIGxlblxufVxuXG5tb2R1bGUuZXhwb3J0cyA9IHtcbiAgYnl0ZUxlbmd0aCxcbiAgdG9TdHJpbmcsXG4gIHdyaXRlXG59XG4iLCAiY29uc3QgYXNjaWkgPSByZXF1aXJlKCcuL2xpYi9hc2NpaScpXG5jb25zdCBiYXNlNjQgPSByZXF1aXJlKCcuL2xpYi9iYXNlNjQnKVxuY29uc3QgaGV4ID0gcmVxdWlyZSgnLi9saWIvaGV4JylcbmNvbnN0IHV0ZjggPSByZXF1aXJlKCcuL2xpYi91dGY4JylcbmNvbnN0IHV0ZjE2bGUgPSByZXF1aXJlKCcuL2xpYi91dGYxNmxlJylcblxuY29uc3QgTEUgPSBuZXcgVWludDhBcnJheShVaW50MTZBcnJheS5vZigweGZmKS5idWZmZXIpWzBdID09PSAweGZmXG5cbmZ1bmN0aW9uIGNvZGVjRm9yIChlbmNvZGluZykge1xuICBzd2l0Y2ggKGVuY29kaW5nKSB7XG4gICAgY2FzZSAnYXNjaWknOlxuICAgICAgcmV0dXJuIGFzY2lpXG4gICAgY2FzZSAnYmFzZTY0JzpcbiAgICAgIHJldHVybiBiYXNlNjRcbiAgICBjYXNlICdoZXgnOlxuICAgICAgcmV0dXJuIGhleFxuICAgIGNhc2UgJ3V0ZjgnOlxuICAgIGNhc2UgJ3V0Zi04JzpcbiAgICBjYXNlIHVuZGVmaW5lZDpcbiAgICBjYXNlIG51bGw6XG4gICAgICByZXR1cm4gdXRmOFxuICAgIGNhc2UgJ3VjczInOlxuICAgIGNhc2UgJ3Vjcy0yJzpcbiAgICBjYXNlICd1dGYxNmxlJzpcbiAgICBjYXNlICd1dGYtMTZsZSc6XG4gICAgICByZXR1cm4gdXRmMTZsZVxuICAgIGRlZmF1bHQ6XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gZW5jb2Rpbmc6ICR7ZW5jb2Rpbmd9YClcbiAgfVxufVxuXG5mdW5jdGlvbiBpc0J1ZmZlciAodmFsdWUpIHtcbiAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgVWludDhBcnJheVxufVxuXG5mdW5jdGlvbiBpc0VuY29kaW5nIChlbmNvZGluZykge1xuICB0cnkge1xuICAgIGNvZGVjRm9yKGVuY29kaW5nKVxuICAgIHJldHVybiB0cnVlXG4gIH0gY2F0Y2gge1xuICAgIHJldHVybiBmYWxzZVxuICB9XG59XG5cbmZ1bmN0aW9uIGFsbG9jIChzaXplLCBmaWxsLCBlbmNvZGluZykge1xuICBjb25zdCBidWZmZXIgPSBuZXcgVWludDhBcnJheShzaXplKVxuICBpZiAoZmlsbCAhPT0gdW5kZWZpbmVkKSBleHBvcnRzLmZpbGwoYnVmZmVyLCBmaWxsLCAwLCBidWZmZXIuYnl0ZUxlbmd0aCwgZW5jb2RpbmcpXG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gYWxsb2NVbnNhZmUgKHNpemUpIHtcbiAgcmV0dXJuIG5ldyBVaW50OEFycmF5KHNpemUpXG59XG5cbmZ1bmN0aW9uIGFsbG9jVW5zYWZlU2xvdyAoc2l6ZSkge1xuICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkoc2l6ZSlcbn1cblxuZnVuY3Rpb24gYnl0ZUxlbmd0aCAoc3RyaW5nLCBlbmNvZGluZykge1xuICByZXR1cm4gY29kZWNGb3IoZW5jb2RpbmcpLmJ5dGVMZW5ndGgoc3RyaW5nKVxufVxuXG5mdW5jdGlvbiBjb21wYXJlIChhLCBiKSB7XG4gIGlmIChhID09PSBiKSByZXR1cm4gMFxuXG4gIGNvbnN0IGxlbiA9IE1hdGgubWluKGEuYnl0ZUxlbmd0aCwgYi5ieXRlTGVuZ3RoKVxuXG4gIGEgPSBuZXcgRGF0YVZpZXcoYS5idWZmZXIsIGEuYnl0ZU9mZnNldCwgYS5ieXRlTGVuZ3RoKVxuICBiID0gbmV3IERhdGFWaWV3KGIuYnVmZmVyLCBiLmJ5dGVPZmZzZXQsIGIuYnl0ZUxlbmd0aClcblxuICBsZXQgaSA9IDBcblxuICBmb3IgKGxldCBuID0gbGVuIC0gKGxlbiAlIDQpOyBpIDwgbjsgaSArPSA0KSB7XG4gICAgY29uc3QgeCA9IGEuZ2V0VWludDMyKGksIExFKVxuICAgIGNvbnN0IHkgPSBiLmdldFVpbnQzMihpLCBMRSlcbiAgICBpZiAoeCAhPT0geSkgYnJlYWtcbiAgfVxuXG4gIGZvciAoOyBpIDwgbGVuOyBpKyspIHtcbiAgICBjb25zdCB4ID0gYS5nZXRVaW50OChpKVxuICAgIGNvbnN0IHkgPSBiLmdldFVpbnQ4KGkpXG4gICAgaWYgKHggPCB5KSByZXR1cm4gLTFcbiAgICBpZiAoeCA+IHkpIHJldHVybiAxXG4gIH1cblxuICByZXR1cm4gYS5ieXRlTGVuZ3RoID4gYi5ieXRlTGVuZ3RoID8gMSA6IGEuYnl0ZUxlbmd0aCA8IGIuYnl0ZUxlbmd0aCA/IC0xIDogMFxufVxuXG5mdW5jdGlvbiBjb25jYXQgKGJ1ZmZlcnMsIHRvdGFsTGVuZ3RoKSB7XG4gIGlmICh0b3RhbExlbmd0aCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdG90YWxMZW5ndGggPSBidWZmZXJzLnJlZHVjZSgobGVuLCBidWZmZXIpID0+IGxlbiArIGJ1ZmZlci5ieXRlTGVuZ3RoLCAwKVxuICB9XG5cbiAgY29uc3QgcmVzdWx0ID0gbmV3IFVpbnQ4QXJyYXkodG90YWxMZW5ndGgpXG5cbiAgbGV0IG9mZnNldCA9IDBcbiAgZm9yIChjb25zdCBidWZmZXIgb2YgYnVmZmVycykge1xuICAgIGlmIChvZmZzZXQgKyBidWZmZXIuYnl0ZUxlbmd0aCA+IHJlc3VsdC5ieXRlTGVuZ3RoKSB7XG4gICAgICBjb25zdCBzdWIgPSBidWZmZXIuc3ViYXJyYXkoMCwgcmVzdWx0LmJ5dGVMZW5ndGggLSBvZmZzZXQpXG4gICAgICByZXN1bHQuc2V0KHN1Yiwgb2Zmc2V0KVxuICAgICAgcmV0dXJuIHJlc3VsdFxuICAgIH1cbiAgICByZXN1bHQuc2V0KGJ1ZmZlciwgb2Zmc2V0KVxuICAgIG9mZnNldCArPSBidWZmZXIuYnl0ZUxlbmd0aFxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5mdW5jdGlvbiBjb3B5IChzb3VyY2UsIHRhcmdldCwgdGFyZ2V0U3RhcnQgPSAwLCBzdGFydCA9IDAsIGVuZCA9IHNvdXJjZS5ieXRlTGVuZ3RoKSB7XG4gIGlmIChlbmQgPiAwICYmIGVuZCA8IHN0YXJ0KSByZXR1cm4gMFxuICBpZiAoZW5kID09PSBzdGFydCkgcmV0dXJuIDBcbiAgaWYgKHNvdXJjZS5ieXRlTGVuZ3RoID09PSAwIHx8IHRhcmdldC5ieXRlTGVuZ3RoID09PSAwKSByZXR1cm4gMFxuXG4gIGlmICh0YXJnZXRTdGFydCA8IDApIHRocm93IG5ldyBSYW5nZUVycm9yKCd0YXJnZXRTdGFydCBpcyBvdXQgb2YgcmFuZ2UnKVxuICBpZiAoc3RhcnQgPCAwIHx8IHN0YXJ0ID49IHNvdXJjZS5ieXRlTGVuZ3RoKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignc291cmNlU3RhcnQgaXMgb3V0IG9mIHJhbmdlJylcbiAgaWYgKGVuZCA8IDApIHRocm93IG5ldyBSYW5nZUVycm9yKCdzb3VyY2VFbmQgaXMgb3V0IG9mIHJhbmdlJylcblxuICBpZiAodGFyZ2V0U3RhcnQgPj0gdGFyZ2V0LmJ5dGVMZW5ndGgpIHRhcmdldFN0YXJ0ID0gdGFyZ2V0LmJ5dGVMZW5ndGhcbiAgaWYgKGVuZCA+IHNvdXJjZS5ieXRlTGVuZ3RoKSBlbmQgPSBzb3VyY2UuYnl0ZUxlbmd0aFxuICBpZiAodGFyZ2V0LmJ5dGVMZW5ndGggLSB0YXJnZXRTdGFydCA8IGVuZCAtIHN0YXJ0KSB7XG4gICAgZW5kID0gdGFyZ2V0Lmxlbmd0aCAtIHRhcmdldFN0YXJ0ICsgc3RhcnRcbiAgfVxuXG4gIGNvbnN0IGxlbiA9IGVuZCAtIHN0YXJ0XG5cbiAgaWYgKHNvdXJjZSA9PT0gdGFyZ2V0KSB7XG4gICAgdGFyZ2V0LmNvcHlXaXRoaW4odGFyZ2V0U3RhcnQsIHN0YXJ0LCBlbmQpXG4gIH0gZWxzZSB7XG4gICAgdGFyZ2V0LnNldChzb3VyY2Uuc3ViYXJyYXkoc3RhcnQsIGVuZCksIHRhcmdldFN0YXJ0KVxuICB9XG5cbiAgcmV0dXJuIGxlblxufVxuXG5mdW5jdGlvbiBlcXVhbHMgKGEsIGIpIHtcbiAgaWYgKGEgPT09IGIpIHJldHVybiB0cnVlXG4gIGlmIChhLmJ5dGVMZW5ndGggIT09IGIuYnl0ZUxlbmd0aCkgcmV0dXJuIGZhbHNlXG5cbiAgY29uc3QgbGVuID0gYS5ieXRlTGVuZ3RoXG5cbiAgYSA9IG5ldyBEYXRhVmlldyhhLmJ1ZmZlciwgYS5ieXRlT2Zmc2V0LCBhLmJ5dGVMZW5ndGgpXG4gIGIgPSBuZXcgRGF0YVZpZXcoYi5idWZmZXIsIGIuYnl0ZU9mZnNldCwgYi5ieXRlTGVuZ3RoKVxuXG4gIGxldCBpID0gMFxuXG4gIGZvciAobGV0IG4gPSBsZW4gLSAobGVuICUgNCk7IGkgPCBuOyBpICs9IDQpIHtcbiAgICBpZiAoYS5nZXRVaW50MzIoaSwgTEUpICE9PSBiLmdldFVpbnQzMihpLCBMRSkpIHJldHVybiBmYWxzZVxuICB9XG5cbiAgZm9yICg7IGkgPCBsZW47IGkrKykge1xuICAgIGlmIChhLmdldFVpbnQ4KGkpICE9PSBiLmdldFVpbnQ4KGkpKSByZXR1cm4gZmFsc2VcbiAgfVxuXG4gIHJldHVybiB0cnVlXG59XG5cbmZ1bmN0aW9uIGZpbGwgKGJ1ZmZlciwgdmFsdWUsIG9mZnNldCwgZW5kLCBlbmNvZGluZykge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgIC8vIGZpbGwoYnVmZmVyLCBzdHJpbmcsIGVuY29kaW5nKVxuICAgIGlmICh0eXBlb2Ygb2Zmc2V0ID09PSAnc3RyaW5nJykge1xuICAgICAgZW5jb2RpbmcgPSBvZmZzZXRcbiAgICAgIG9mZnNldCA9IDBcbiAgICAgIGVuZCA9IGJ1ZmZlci5ieXRlTGVuZ3RoXG5cbiAgICAvLyBmaWxsKGJ1ZmZlciwgc3RyaW5nLCBvZmZzZXQsIGVuY29kaW5nKVxuICAgIH0gZWxzZSBpZiAodHlwZW9mIGVuZCA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGVuY29kaW5nID0gZW5kXG4gICAgICBlbmQgPSBidWZmZXIuYnl0ZUxlbmd0aFxuICAgIH1cbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgdmFsdWUgPSB2YWx1ZSAmIDB4ZmZcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykge1xuICAgIHZhbHVlID0gK3ZhbHVlXG4gIH1cblxuICBpZiAob2Zmc2V0IDwgMCB8fCBidWZmZXIuYnl0ZUxlbmd0aCA8IG9mZnNldCB8fCBidWZmZXIuYnl0ZUxlbmd0aCA8IGVuZCkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdPdXQgb2YgcmFuZ2UgaW5kZXgnKVxuICB9XG5cbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG4gIGlmIChlbmQgPT09IHVuZGVmaW5lZCkgZW5kID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBpZiAoZW5kIDw9IG9mZnNldCkgcmV0dXJuIGJ1ZmZlclxuXG4gIGlmICghdmFsdWUpIHZhbHVlID0gMFxuXG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSB7XG4gICAgZm9yIChsZXQgaSA9IG9mZnNldDsgaSA8IGVuZDsgKytpKSB7XG4gICAgICBidWZmZXJbaV0gPSB2YWx1ZVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICB2YWx1ZSA9IGlzQnVmZmVyKHZhbHVlKSA/IHZhbHVlIDogZnJvbSh2YWx1ZSwgZW5jb2RpbmcpXG5cbiAgICBjb25zdCBsZW4gPSB2YWx1ZS5ieXRlTGVuZ3RoXG5cbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGVuZCAtIG9mZnNldDsgKytpKSB7XG4gICAgICBidWZmZXJbaSArIG9mZnNldF0gPSB2YWx1ZVtpICUgbGVuXVxuICAgIH1cbiAgfVxuXG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gZnJvbSAodmFsdWUsIGVuY29kaW5nT3JPZmZzZXQsIGxlbmd0aCkge1xuICAvLyBmcm9tKHN0cmluZywgZW5jb2RpbmcpXG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gZnJvbVN0cmluZyh2YWx1ZSwgZW5jb2RpbmdPck9mZnNldClcblxuICAvLyBmcm9tKGFycmF5KVxuICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHJldHVybiBmcm9tQXJyYXkodmFsdWUpXG5cbiAgLy8gZnJvbShidWZmZXIpXG4gIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUpKSByZXR1cm4gZnJvbUJ1ZmZlcih2YWx1ZSlcblxuICAvLyBmcm9tKGFycmF5QnVmZmVyWywgYnl0ZU9mZnNldFssIGxlbmd0aF1dKVxuICByZXR1cm4gZnJvbUFycmF5QnVmZmVyKHZhbHVlLCBlbmNvZGluZ09yT2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIGZyb21TdHJpbmcgKHN0cmluZywgZW5jb2RpbmcpIHtcbiAgY29uc3QgY29kZWMgPSBjb2RlY0ZvcihlbmNvZGluZylcbiAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoY29kZWMuYnl0ZUxlbmd0aChzdHJpbmcpKVxuICBjb2RlYy53cml0ZShidWZmZXIsIHN0cmluZywgMCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gZnJvbUFycmF5IChhcnJheSkge1xuICBjb25zdCBidWZmZXIgPSBuZXcgVWludDhBcnJheShhcnJheS5sZW5ndGgpXG4gIGJ1ZmZlci5zZXQoYXJyYXkpXG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gZnJvbUJ1ZmZlciAoYnVmZmVyKSB7XG4gIGNvbnN0IGNvcHkgPSBuZXcgVWludDhBcnJheShidWZmZXIuYnl0ZUxlbmd0aClcbiAgY29weS5zZXQoYnVmZmVyKVxuICByZXR1cm4gY29weVxufVxuXG5mdW5jdGlvbiBmcm9tQXJyYXlCdWZmZXIgKGFycmF5QnVmZmVyLCBieXRlT2Zmc2V0LCBsZW5ndGgpIHtcbiAgcmV0dXJuIG5ldyBVaW50OEFycmF5KGFycmF5QnVmZmVyLCBieXRlT2Zmc2V0LCBsZW5ndGgpXG59XG5cbmZ1bmN0aW9uIGluY2x1ZGVzIChidWZmZXIsIHZhbHVlLCBieXRlT2Zmc2V0LCBlbmNvZGluZykge1xuICByZXR1cm4gaW5kZXhPZihidWZmZXIsIHZhbHVlLCBieXRlT2Zmc2V0LCBlbmNvZGluZykgIT09IC0xXG59XG5cbmZ1bmN0aW9uIGJpZGlyZWN0aW9uYWxJbmRleE9mIChidWZmZXIsIHZhbHVlLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZmlyc3QpIHtcbiAgaWYgKGJ1ZmZlci5ieXRlTGVuZ3RoID09PSAwKSByZXR1cm4gLTFcblxuICBpZiAodHlwZW9mIGJ5dGVPZmZzZXQgPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBieXRlT2Zmc2V0XG4gICAgYnl0ZU9mZnNldCA9IDBcbiAgfSBlbHNlIGlmIChieXRlT2Zmc2V0ID09PSB1bmRlZmluZWQpIHtcbiAgICBieXRlT2Zmc2V0ID0gZmlyc3QgPyAwIDogKGJ1ZmZlci5sZW5ndGggLSAxKVxuICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAwKSB7XG4gICAgYnl0ZU9mZnNldCArPSBidWZmZXIuYnl0ZUxlbmd0aFxuICB9XG5cbiAgaWYgKGJ5dGVPZmZzZXQgPj0gYnVmZmVyLmJ5dGVMZW5ndGgpIHtcbiAgICBpZiAoZmlyc3QpIHJldHVybiAtMVxuICAgIGVsc2UgYnl0ZU9mZnNldCA9IGJ1ZmZlci5ieXRlTGVuZ3RoIC0gMVxuICB9IGVsc2UgaWYgKGJ5dGVPZmZzZXQgPCAwKSB7XG4gICAgaWYgKGZpcnN0KSBieXRlT2Zmc2V0ID0gMFxuICAgIGVsc2UgcmV0dXJuIC0xXG4gIH1cblxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykge1xuICAgIHZhbHVlID0gZnJvbSh2YWx1ZSwgZW5jb2RpbmcpXG4gIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykge1xuICAgIHZhbHVlID0gdmFsdWUgJiAweGZmXG5cbiAgICBpZiAoZmlyc3QpIHtcbiAgICAgIHJldHVybiBidWZmZXIuaW5kZXhPZih2YWx1ZSwgYnl0ZU9mZnNldClcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuIGJ1ZmZlci5sYXN0SW5kZXhPZih2YWx1ZSwgYnl0ZU9mZnNldClcbiAgICB9XG4gIH1cblxuICBpZiAodmFsdWUuYnl0ZUxlbmd0aCA9PT0gMCkgcmV0dXJuIC0xXG5cbiAgaWYgKGZpcnN0KSB7XG4gICAgbGV0IGZvdW5kSW5kZXggPSAtMVxuXG4gICAgZm9yIChsZXQgaSA9IGJ5dGVPZmZzZXQ7IGkgPCBidWZmZXIuYnl0ZUxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoYnVmZmVyW2ldID09PSB2YWx1ZVtmb3VuZEluZGV4ID09PSAtMSA/IDAgOiBpIC0gZm91bmRJbmRleF0pIHtcbiAgICAgICAgaWYgKGZvdW5kSW5kZXggPT09IC0xKSBmb3VuZEluZGV4ID0gaVxuICAgICAgICBpZiAoaSAtIGZvdW5kSW5kZXggKyAxID09PSB2YWx1ZS5ieXRlTGVuZ3RoKSByZXR1cm4gZm91bmRJbmRleFxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKGZvdW5kSW5kZXggIT09IC0xKSBpIC09IGkgLSBmb3VuZEluZGV4XG4gICAgICAgIGZvdW5kSW5kZXggPSAtMVxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICBpZiAoYnl0ZU9mZnNldCArIHZhbHVlLmJ5dGVMZW5ndGggPiBidWZmZXIuYnl0ZUxlbmd0aCkge1xuICAgICAgYnl0ZU9mZnNldCA9IGJ1ZmZlci5ieXRlTGVuZ3RoIC0gdmFsdWUuYnl0ZUxlbmd0aFxuICAgIH1cblxuICAgIGZvciAobGV0IGkgPSBieXRlT2Zmc2V0OyBpID49IDA7IGktLSkge1xuICAgICAgbGV0IGZvdW5kID0gdHJ1ZVxuXG4gICAgICBmb3IgKGxldCBqID0gMDsgaiA8IHZhbHVlLmJ5dGVMZW5ndGg7IGorKykge1xuICAgICAgICBpZiAoYnVmZmVyW2kgKyBqXSAhPT0gdmFsdWVbal0pIHtcbiAgICAgICAgICBmb3VuZCA9IGZhbHNlXG4gICAgICAgICAgYnJlYWtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBpZiAoZm91bmQpIHJldHVybiBpXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIC0xXG59XG5cbmZ1bmN0aW9uIGluZGV4T2YgKGJ1ZmZlciwgdmFsdWUsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSB7XG4gIHJldHVybiBiaWRpcmVjdGlvbmFsSW5kZXhPZihidWZmZXIsIHZhbHVlLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgdHJ1ZSAvKiBmaXJzdCAqLylcbn1cblxuZnVuY3Rpb24gbGFzdEluZGV4T2YgKGJ1ZmZlciwgdmFsdWUsIGJ5dGVPZmZzZXQsIGVuY29kaW5nKSB7XG4gIHJldHVybiBiaWRpcmVjdGlvbmFsSW5kZXhPZihidWZmZXIsIHZhbHVlLCBieXRlT2Zmc2V0LCBlbmNvZGluZywgZmFsc2UgLyogbGFzdCAqLylcbn1cblxuZnVuY3Rpb24gc3dhcCAoYnVmZmVyLCBuLCBtKSB7XG4gIGNvbnN0IGkgPSBidWZmZXJbbl1cbiAgYnVmZmVyW25dID0gYnVmZmVyW21dXG4gIGJ1ZmZlclttXSA9IGlcbn1cblxuZnVuY3Rpb24gc3dhcDE2IChidWZmZXIpIHtcbiAgY29uc3QgbGVuID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBpZiAobGVuICUgMiAhPT0gMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiAxNi1iaXRzJylcblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSAyKSBzd2FwKGJ1ZmZlciwgaSwgaSArIDEpXG5cbiAgcmV0dXJuIGJ1ZmZlclxufVxuXG5mdW5jdGlvbiBzd2FwMzIgKGJ1ZmZlcikge1xuICBjb25zdCBsZW4gPSBidWZmZXIuYnl0ZUxlbmd0aFxuXG4gIGlmIChsZW4gJSA0ICE9PSAwKSB0aHJvdyBuZXcgUmFuZ2VFcnJvcignQnVmZmVyIHNpemUgbXVzdCBiZSBhIG11bHRpcGxlIG9mIDMyLWJpdHMnKVxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuOyBpICs9IDQpIHtcbiAgICBzd2FwKGJ1ZmZlciwgaSwgaSArIDMpXG4gICAgc3dhcChidWZmZXIsIGkgKyAxLCBpICsgMilcbiAgfVxuXG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gc3dhcDY0IChidWZmZXIpIHtcbiAgY29uc3QgbGVuID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBpZiAobGVuICUgOCAhPT0gMCkgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ0J1ZmZlciBzaXplIG11c3QgYmUgYSBtdWx0aXBsZSBvZiA2NC1iaXRzJylcblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbjsgaSArPSA4KSB7XG4gICAgc3dhcChidWZmZXIsIGksIGkgKyA3KVxuICAgIHN3YXAoYnVmZmVyLCBpICsgMSwgaSArIDYpXG4gICAgc3dhcChidWZmZXIsIGkgKyAyLCBpICsgNSlcbiAgICBzd2FwKGJ1ZmZlciwgaSArIDMsIGkgKyA0KVxuICB9XG5cbiAgcmV0dXJuIGJ1ZmZlclxufVxuXG5mdW5jdGlvbiB0b0J1ZmZlciAoYnVmZmVyKSB7XG4gIHJldHVybiBidWZmZXJcbn1cblxuZnVuY3Rpb24gdG9TdHJpbmcgKGJ1ZmZlciwgZW5jb2RpbmcsIHN0YXJ0ID0gMCwgZW5kID0gYnVmZmVyLmJ5dGVMZW5ndGgpIHtcbiAgY29uc3QgbGVuID0gYnVmZmVyLmJ5dGVMZW5ndGhcblxuICBpZiAoc3RhcnQgPj0gbGVuKSByZXR1cm4gJydcbiAgaWYgKGVuZCA8PSBzdGFydCkgcmV0dXJuICcnXG4gIGlmIChzdGFydCA8IDApIHN0YXJ0ID0gMFxuICBpZiAoZW5kID4gbGVuKSBlbmQgPSBsZW5cblxuICBpZiAoc3RhcnQgIT09IDAgfHwgZW5kIDwgbGVuKSBidWZmZXIgPSBidWZmZXIuc3ViYXJyYXkoc3RhcnQsIGVuZClcblxuICByZXR1cm4gY29kZWNGb3IoZW5jb2RpbmcpLnRvU3RyaW5nKGJ1ZmZlcilcbn1cblxuZnVuY3Rpb24gd3JpdGUgKGJ1ZmZlciwgc3RyaW5nLCBvZmZzZXQsIGxlbmd0aCwgZW5jb2RpbmcpIHtcbiAgLy8gd3JpdGUoYnVmZmVyLCBzdHJpbmcpXG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkge1xuICAgIGVuY29kaW5nID0gJ3V0ZjgnXG5cbiAgLy8gd3JpdGUoYnVmZmVyLCBzdHJpbmcsIGVuY29kaW5nKVxuICB9IGVsc2UgaWYgKGxlbmd0aCA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBvZmZzZXQgPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBvZmZzZXRcbiAgICBvZmZzZXQgPSB1bmRlZmluZWRcblxuICAvLyB3cml0ZShidWZmZXIsIHN0cmluZywgb2Zmc2V0LCBlbmNvZGluZylcbiAgfSBlbHNlIGlmIChlbmNvZGluZyA9PT0gdW5kZWZpbmVkICYmIHR5cGVvZiBsZW5ndGggPT09ICdzdHJpbmcnKSB7XG4gICAgZW5jb2RpbmcgPSBsZW5ndGhcbiAgICBsZW5ndGggPSB1bmRlZmluZWRcbiAgfVxuXG4gIHJldHVybiBjb2RlY0ZvcihlbmNvZGluZykud3JpdGUoYnVmZmVyLCBzdHJpbmcsIG9mZnNldCwgbGVuZ3RoKVxufVxuXG5mdW5jdGlvbiB3cml0ZURvdWJsZUxFIChidWZmZXIsIHZhbHVlLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHZpZXcuc2V0RmxvYXQ2NChvZmZzZXQsIHZhbHVlLCB0cnVlKVxuXG4gIHJldHVybiBvZmZzZXQgKyA4XG59XG5cbmZ1bmN0aW9uIHdyaXRlRmxvYXRMRSAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuICB2aWV3LnNldEZsb2F0MzIob2Zmc2V0LCB2YWx1ZSwgdHJ1ZSlcblxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5mdW5jdGlvbiB3cml0ZVVJbnQzMkxFIChidWZmZXIsIHZhbHVlLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHZpZXcuc2V0VWludDMyKG9mZnNldCwgdmFsdWUsIHRydWUpXG5cbiAgcmV0dXJuIG9mZnNldCArIDRcbn1cblxuZnVuY3Rpb24gd3JpdGVJbnQzMkxFIChidWZmZXIsIHZhbHVlLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHZpZXcuc2V0SW50MzIob2Zmc2V0LCB2YWx1ZSwgdHJ1ZSlcblxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5mdW5jdGlvbiByZWFkRG91YmxlTEUgKGJ1ZmZlciwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2aWV3LmdldEZsb2F0NjQob2Zmc2V0LCB0cnVlKVxufVxuXG5mdW5jdGlvbiByZWFkRmxvYXRMRSAoYnVmZmVyLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZpZXcuZ2V0RmxvYXQzMihvZmZzZXQsIHRydWUpXG59XG5cbmZ1bmN0aW9uIHJlYWRVSW50MzJMRSAoYnVmZmVyLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZpZXcuZ2V0VWludDMyKG9mZnNldCwgdHJ1ZSlcbn1cblxuZnVuY3Rpb24gcmVhZEludDMyTEUgKGJ1ZmZlciwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2aWV3LmdldEludDMyKG9mZnNldCwgdHJ1ZSlcbn1cblxuZnVuY3Rpb24gd3JpdGVEb3VibGVCRSAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuICB2aWV3LnNldEZsb2F0NjQob2Zmc2V0LCB2YWx1ZSwgZmFsc2UpXG5cbiAgcmV0dXJuIG9mZnNldCArIDhcbn1cblxuZnVuY3Rpb24gd3JpdGVGbG9hdEJFIChidWZmZXIsIHZhbHVlLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHZpZXcuc2V0RmxvYXQzMihvZmZzZXQsIHZhbHVlLCBmYWxzZSlcblxuICByZXR1cm4gb2Zmc2V0ICsgNFxufVxuXG5mdW5jdGlvbiB3cml0ZVVJbnQzMkJFIChidWZmZXIsIHZhbHVlLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG4gIHZpZXcuc2V0VWludDMyKG9mZnNldCwgdmFsdWUsIGZhbHNlKVxuXG4gIHJldHVybiBvZmZzZXQgKyA0XG59XG5cbmZ1bmN0aW9uIHdyaXRlSW50MzJCRSAoYnVmZmVyLCB2YWx1ZSwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuICB2aWV3LnNldEludDMyKG9mZnNldCwgdmFsdWUsIGZhbHNlKVxuXG4gIHJldHVybiBvZmZzZXQgKyA0XG59XG5cbmZ1bmN0aW9uIHJlYWREb3VibGVCRSAoYnVmZmVyLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZpZXcuZ2V0RmxvYXQ2NChvZmZzZXQsIGZhbHNlKVxufVxuXG5mdW5jdGlvbiByZWFkRmxvYXRCRSAoYnVmZmVyLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZpZXcuZ2V0RmxvYXQzMihvZmZzZXQsIGZhbHNlKVxufVxuXG5mdW5jdGlvbiByZWFkVUludDMyQkUgKGJ1ZmZlciwgb2Zmc2V0KSB7XG4gIGlmIChvZmZzZXQgPT09IHVuZGVmaW5lZCkgb2Zmc2V0ID0gMFxuXG4gIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyLmJ1ZmZlciwgYnVmZmVyLmJ5dGVPZmZzZXQsIGJ1ZmZlci5ieXRlTGVuZ3RoKVxuXG4gIHJldHVybiB2aWV3LmdldFVpbnQzMihvZmZzZXQsIGZhbHNlKVxufVxuXG5mdW5jdGlvbiByZWFkSW50MzJCRSAoYnVmZmVyLCBvZmZzZXQpIHtcbiAgaWYgKG9mZnNldCA9PT0gdW5kZWZpbmVkKSBvZmZzZXQgPSAwXG5cbiAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIuYnVmZmVyLCBidWZmZXIuYnl0ZU9mZnNldCwgYnVmZmVyLmJ5dGVMZW5ndGgpXG5cbiAgcmV0dXJuIHZpZXcuZ2V0SW50MzIob2Zmc2V0LCBmYWxzZSlcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBleHBvcnRzID0ge1xuICBpc0J1ZmZlcixcbiAgaXNFbmNvZGluZyxcbiAgYWxsb2MsXG4gIGFsbG9jVW5zYWZlLFxuICBhbGxvY1Vuc2FmZVNsb3csXG4gIGJ5dGVMZW5ndGgsXG4gIGNvbXBhcmUsXG4gIGNvbmNhdCxcbiAgY29weSxcbiAgZXF1YWxzLFxuICBmaWxsLFxuICBmcm9tLFxuICBpbmNsdWRlcyxcbiAgaW5kZXhPZixcbiAgbGFzdEluZGV4T2YsXG4gIHN3YXAxNixcbiAgc3dhcDMyLFxuICBzd2FwNjQsXG4gIHRvQnVmZmVyLFxuICB0b1N0cmluZyxcbiAgd3JpdGUsXG4gIHdyaXRlRG91YmxlTEUsXG4gIHdyaXRlRmxvYXRMRSxcbiAgd3JpdGVVSW50MzJMRSxcbiAgd3JpdGVJbnQzMkxFLFxuICByZWFkRG91YmxlTEUsXG4gIHJlYWRGbG9hdExFLFxuICByZWFkVUludDMyTEUsXG4gIHJlYWRJbnQzMkxFLFxuICB3cml0ZURvdWJsZUJFLFxuICB3cml0ZUZsb2F0QkUsXG4gIHdyaXRlVUludDMyQkUsXG4gIHdyaXRlSW50MzJCRSxcbiAgcmVhZERvdWJsZUJFLFxuICByZWFkRmxvYXRCRSxcbiAgcmVhZFVJbnQzMkJFLFxuICByZWFkSW50MzJCRVxufVxuIiwgImNvbnN0IGI0YSA9IHJlcXVpcmUoJ2I0YScpXG5cbmNvbnN0IFpFUk9TID0gJzAwMDAwMDAwMDAwMDAwMDAwMDAnXG5jb25zdCBTRVZFTlMgPSAnNzc3Nzc3Nzc3Nzc3Nzc3Nzc3NydcbmNvbnN0IFpFUk9fT0ZGU0VUID0gJzAnLmNoYXJDb2RlQXQoMClcbmNvbnN0IFVTVEFSX01BR0lDID0gYjRhLmZyb20oWzB4NzUsIDB4NzMsIDB4NzQsIDB4NjEsIDB4NzIsIDB4MDBdKSAvLyB1c3RhclxceDAwXG5jb25zdCBVU1RBUl9WRVIgPSBiNGEuZnJvbShbWkVST19PRkZTRVQsIFpFUk9fT0ZGU0VUXSlcbmNvbnN0IEdOVV9NQUdJQyA9IGI0YS5mcm9tKFsweDc1LCAweDczLCAweDc0LCAweDYxLCAweDcyLCAweDIwXSkgLy8gdXN0YXJcXHgyMFxuY29uc3QgR05VX1ZFUiA9IGI0YS5mcm9tKFsweDIwLCAweDAwXSlcbmNvbnN0IE1BU0sgPSAwbzc3NzdcbmNvbnN0IE1BR0lDX09GRlNFVCA9IDI1N1xuY29uc3QgVkVSU0lPTl9PRkZTRVQgPSAyNjNcblxuZXhwb3J0cy5kZWNvZGVMb25nUGF0aCA9IGZ1bmN0aW9uIGRlY29kZUxvbmdQYXRoIChidWYsIGVuY29kaW5nKSB7XG4gIHJldHVybiBkZWNvZGVTdHIoYnVmLCAwLCBidWYubGVuZ3RoLCBlbmNvZGluZylcbn1cblxuZXhwb3J0cy5lbmNvZGVQYXggPSBmdW5jdGlvbiBlbmNvZGVQYXggKG9wdHMpIHsgLy8gVE9ETzogZW5jb2RlIG1vcmUgc3R1ZmYgaW4gcGF4XG4gIGxldCByZXN1bHQgPSAnJ1xuICBpZiAob3B0cy5uYW1lKSByZXN1bHQgKz0gYWRkTGVuZ3RoKCcgcGF0aD0nICsgb3B0cy5uYW1lICsgJ1xcbicpXG4gIGlmIChvcHRzLmxpbmtuYW1lKSByZXN1bHQgKz0gYWRkTGVuZ3RoKCcgbGlua3BhdGg9JyArIG9wdHMubGlua25hbWUgKyAnXFxuJylcbiAgY29uc3QgcGF4ID0gb3B0cy5wYXhcbiAgaWYgKHBheCkge1xuICAgIGZvciAoY29uc3Qga2V5IGluIHBheCkge1xuICAgICAgcmVzdWx0ICs9IGFkZExlbmd0aCgnICcgKyBrZXkgKyAnPScgKyBwYXhba2V5XSArICdcXG4nKVxuICAgIH1cbiAgfVxuICByZXR1cm4gYjRhLmZyb20ocmVzdWx0KVxufVxuXG5leHBvcnRzLmRlY29kZVBheCA9IGZ1bmN0aW9uIGRlY29kZVBheCAoYnVmKSB7XG4gIGNvbnN0IHJlc3VsdCA9IHt9XG5cbiAgd2hpbGUgKGJ1Zi5sZW5ndGgpIHtcbiAgICBsZXQgaSA9IDBcbiAgICB3aGlsZSAoaSA8IGJ1Zi5sZW5ndGggJiYgYnVmW2ldICE9PSAzMikgaSsrXG4gICAgY29uc3QgbGVuID0gcGFyc2VJbnQoYjRhLnRvU3RyaW5nKGJ1Zi5zdWJhcnJheSgwLCBpKSksIDEwKVxuICAgIGlmICghbGVuKSByZXR1cm4gcmVzdWx0XG5cbiAgICBjb25zdCBiID0gYjRhLnRvU3RyaW5nKGJ1Zi5zdWJhcnJheShpICsgMSwgbGVuIC0gMSkpXG4gICAgY29uc3Qga2V5SW5kZXggPSBiLmluZGV4T2YoJz0nKVxuICAgIGlmIChrZXlJbmRleCA9PT0gLTEpIHJldHVybiByZXN1bHRcbiAgICByZXN1bHRbYi5zbGljZSgwLCBrZXlJbmRleCldID0gYi5zbGljZShrZXlJbmRleCArIDEpXG5cbiAgICBidWYgPSBidWYuc3ViYXJyYXkobGVuKVxuICB9XG5cbiAgcmV0dXJuIHJlc3VsdFxufVxuXG5leHBvcnRzLmVuY29kZSA9IGZ1bmN0aW9uIGVuY29kZSAob3B0cykge1xuICBjb25zdCBidWYgPSBiNGEuYWxsb2MoNTEyKVxuICBsZXQgbmFtZSA9IG9wdHMubmFtZVxuICBsZXQgcHJlZml4ID0gJydcblxuICBpZiAob3B0cy50eXBlZmxhZyA9PT0gNSAmJiBuYW1lW25hbWUubGVuZ3RoIC0gMV0gIT09ICcvJykgbmFtZSArPSAnLydcbiAgaWYgKGI0YS5ieXRlTGVuZ3RoKG5hbWUpICE9PSBuYW1lLmxlbmd0aCkgcmV0dXJuIG51bGwgLy8gdXRmLThcblxuICB3aGlsZSAoYjRhLmJ5dGVMZW5ndGgobmFtZSkgPiAxMDApIHtcbiAgICBjb25zdCBpID0gbmFtZS5pbmRleE9mKCcvJylcbiAgICBpZiAoaSA9PT0gLTEpIHJldHVybiBudWxsXG4gICAgcHJlZml4ICs9IHByZWZpeCA/ICcvJyArIG5hbWUuc2xpY2UoMCwgaSkgOiBuYW1lLnNsaWNlKDAsIGkpXG4gICAgbmFtZSA9IG5hbWUuc2xpY2UoaSArIDEpXG4gIH1cblxuICBpZiAoYjRhLmJ5dGVMZW5ndGgobmFtZSkgPiAxMDAgfHwgYjRhLmJ5dGVMZW5ndGgocHJlZml4KSA+IDE1NSkgcmV0dXJuIG51bGxcbiAgaWYgKG9wdHMubGlua25hbWUgJiYgYjRhLmJ5dGVMZW5ndGgob3B0cy5saW5rbmFtZSkgPiAxMDApIHJldHVybiBudWxsXG5cbiAgYjRhLndyaXRlKGJ1ZiwgbmFtZSlcbiAgYjRhLndyaXRlKGJ1ZiwgZW5jb2RlT2N0KG9wdHMubW9kZSAmIE1BU0ssIDYpLCAxMDApXG4gIGI0YS53cml0ZShidWYsIGVuY29kZU9jdChvcHRzLnVpZCwgNiksIDEwOClcbiAgYjRhLndyaXRlKGJ1ZiwgZW5jb2RlT2N0KG9wdHMuZ2lkLCA2KSwgMTE2KVxuICBlbmNvZGVTaXplKG9wdHMuc2l6ZSwgYnVmLCAxMjQpXG4gIGI0YS53cml0ZShidWYsIGVuY29kZU9jdCgob3B0cy5tdGltZS5nZXRUaW1lKCkgLyAxMDAwKSB8IDAsIDExKSwgMTM2KVxuXG4gIGJ1ZlsxNTZdID0gWkVST19PRkZTRVQgKyB0b1R5cGVmbGFnKG9wdHMudHlwZSlcblxuICBpZiAob3B0cy5saW5rbmFtZSkgYjRhLndyaXRlKGJ1Ziwgb3B0cy5saW5rbmFtZSwgMTU3KVxuXG4gIGI0YS5jb3B5KFVTVEFSX01BR0lDLCBidWYsIE1BR0lDX09GRlNFVClcbiAgYjRhLmNvcHkoVVNUQVJfVkVSLCBidWYsIFZFUlNJT05fT0ZGU0VUKVxuICBpZiAob3B0cy51bmFtZSkgYjRhLndyaXRlKGJ1Ziwgb3B0cy51bmFtZSwgMjY1KVxuICBpZiAob3B0cy5nbmFtZSkgYjRhLndyaXRlKGJ1Ziwgb3B0cy5nbmFtZSwgMjk3KVxuICBiNGEud3JpdGUoYnVmLCBlbmNvZGVPY3Qob3B0cy5kZXZtYWpvciB8fCAwLCA2KSwgMzI5KVxuICBiNGEud3JpdGUoYnVmLCBlbmNvZGVPY3Qob3B0cy5kZXZtaW5vciB8fCAwLCA2KSwgMzM3KVxuXG4gIGlmIChwcmVmaXgpIGI0YS53cml0ZShidWYsIHByZWZpeCwgMzQ1KVxuXG4gIGI0YS53cml0ZShidWYsIGVuY29kZU9jdChja3N1bShidWYpLCA2KSwgMTQ4KVxuXG4gIHJldHVybiBidWZcbn1cblxuZXhwb3J0cy5kZWNvZGUgPSBmdW5jdGlvbiBkZWNvZGUgKGJ1ZiwgZmlsZW5hbWVFbmNvZGluZywgYWxsb3dVbmtub3duRm9ybWF0KSB7XG4gIGxldCB0eXBlZmxhZyA9IGJ1ZlsxNTZdID09PSAwID8gMCA6IGJ1ZlsxNTZdIC0gWkVST19PRkZTRVRcblxuICBsZXQgbmFtZSA9IGRlY29kZVN0cihidWYsIDAsIDEwMCwgZmlsZW5hbWVFbmNvZGluZylcbiAgY29uc3QgbW9kZSA9IGRlY29kZU9jdChidWYsIDEwMCwgOClcbiAgY29uc3QgdWlkID0gZGVjb2RlT2N0KGJ1ZiwgMTA4LCA4KVxuICBjb25zdCBnaWQgPSBkZWNvZGVPY3QoYnVmLCAxMTYsIDgpXG4gIGNvbnN0IHNpemUgPSBkZWNvZGVPY3QoYnVmLCAxMjQsIDEyKVxuICBjb25zdCBtdGltZSA9IGRlY29kZU9jdChidWYsIDEzNiwgMTIpXG4gIGNvbnN0IHR5cGUgPSB0b1R5cGUodHlwZWZsYWcpXG4gIGNvbnN0IGxpbmtuYW1lID0gYnVmWzE1N10gPT09IDAgPyBudWxsIDogZGVjb2RlU3RyKGJ1ZiwgMTU3LCAxMDAsIGZpbGVuYW1lRW5jb2RpbmcpXG4gIGNvbnN0IHVuYW1lID0gZGVjb2RlU3RyKGJ1ZiwgMjY1LCAzMilcbiAgY29uc3QgZ25hbWUgPSBkZWNvZGVTdHIoYnVmLCAyOTcsIDMyKVxuICBjb25zdCBkZXZtYWpvciA9IGRlY29kZU9jdChidWYsIDMyOSwgOClcbiAgY29uc3QgZGV2bWlub3IgPSBkZWNvZGVPY3QoYnVmLCAzMzcsIDgpXG5cbiAgY29uc3QgYyA9IGNrc3VtKGJ1ZilcblxuICAvLyBjaGVja3N1bSBpcyBzdGlsbCBpbml0aWFsIHZhbHVlIGlmIGhlYWRlciB3YXMgbnVsbC5cbiAgaWYgKGMgPT09IDggKiAzMikgcmV0dXJuIG51bGxcblxuICAvLyB2YWxpZCBjaGVja3N1bVxuICBpZiAoYyAhPT0gZGVjb2RlT2N0KGJ1ZiwgMTQ4LCA4KSkgdGhyb3cgbmV3IEVycm9yKCdJbnZhbGlkIHRhciBoZWFkZXIuIE1heWJlIHRoZSB0YXIgaXMgY29ycnVwdGVkIG9yIGl0IG5lZWRzIHRvIGJlIGd1bnppcHBlZD8nKVxuXG4gIGlmIChpc1VTVEFSKGJ1ZikpIHtcbiAgICAvLyB1c3RhciAocG9zaXgpIGZvcm1hdC5cbiAgICAvLyBwcmVwZW5kIHByZWZpeCwgaWYgcHJlc2VudC5cbiAgICBpZiAoYnVmWzM0NV0pIG5hbWUgPSBkZWNvZGVTdHIoYnVmLCAzNDUsIDE1NSwgZmlsZW5hbWVFbmNvZGluZykgKyAnLycgKyBuYW1lXG4gIH0gZWxzZSBpZiAoaXNHTlUoYnVmKSkge1xuICAgIC8vICdnbnUnLydvbGRnbnUnIGZvcm1hdC4gU2ltaWxhciB0byB1c3RhciwgYnV0IGhhcyBzdXBwb3J0IGZvciBpbmNyZW1lbnRhbCBhbmRcbiAgICAvLyBtdWx0aS12b2x1bWUgdGFyYmFsbHMuXG4gIH0gZWxzZSB7XG4gICAgaWYgKCFhbGxvd1Vua25vd25Gb3JtYXQpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignSW52YWxpZCB0YXIgaGVhZGVyOiB1bmtub3duIGZvcm1hdC4nKVxuICAgIH1cbiAgfVxuXG4gIC8vIHRvIHN1cHBvcnQgb2xkIHRhciB2ZXJzaW9ucyB0aGF0IHVzZSB0cmFpbGluZyAvIHRvIGluZGljYXRlIGRpcnNcbiAgaWYgKHR5cGVmbGFnID09PSAwICYmIG5hbWUgJiYgbmFtZVtuYW1lLmxlbmd0aCAtIDFdID09PSAnLycpIHR5cGVmbGFnID0gNVxuXG4gIHJldHVybiB7XG4gICAgbmFtZSxcbiAgICBtb2RlLFxuICAgIHVpZCxcbiAgICBnaWQsXG4gICAgc2l6ZSxcbiAgICBtdGltZTogbmV3IERhdGUoMTAwMCAqIG10aW1lKSxcbiAgICB0eXBlLFxuICAgIGxpbmtuYW1lLFxuICAgIHVuYW1lLFxuICAgIGduYW1lLFxuICAgIGRldm1ham9yLFxuICAgIGRldm1pbm9yLFxuICAgIHBheDogbnVsbFxuICB9XG59XG5cbmZ1bmN0aW9uIGlzVVNUQVIgKGJ1Zikge1xuICByZXR1cm4gYjRhLmVxdWFscyhVU1RBUl9NQUdJQywgYnVmLnN1YmFycmF5KE1BR0lDX09GRlNFVCwgTUFHSUNfT0ZGU0VUICsgNikpXG59XG5cbmZ1bmN0aW9uIGlzR05VIChidWYpIHtcbiAgcmV0dXJuIGI0YS5lcXVhbHMoR05VX01BR0lDLCBidWYuc3ViYXJyYXkoTUFHSUNfT0ZGU0VULCBNQUdJQ19PRkZTRVQgKyA2KSkgJiZcbiAgICBiNGEuZXF1YWxzKEdOVV9WRVIsIGJ1Zi5zdWJhcnJheShWRVJTSU9OX09GRlNFVCwgVkVSU0lPTl9PRkZTRVQgKyAyKSlcbn1cblxuZnVuY3Rpb24gY2xhbXAgKGluZGV4LCBsZW4sIGRlZmF1bHRWYWx1ZSkge1xuICBpZiAodHlwZW9mIGluZGV4ICE9PSAnbnVtYmVyJykgcmV0dXJuIGRlZmF1bHRWYWx1ZVxuICBpbmRleCA9IH5+aW5kZXggLy8gQ29lcmNlIHRvIGludGVnZXIuXG4gIGlmIChpbmRleCA+PSBsZW4pIHJldHVybiBsZW5cbiAgaWYgKGluZGV4ID49IDApIHJldHVybiBpbmRleFxuICBpbmRleCArPSBsZW5cbiAgaWYgKGluZGV4ID49IDApIHJldHVybiBpbmRleFxuICByZXR1cm4gMFxufVxuXG5mdW5jdGlvbiB0b1R5cGUgKGZsYWcpIHtcbiAgc3dpdGNoIChmbGFnKSB7XG4gICAgY2FzZSAwOlxuICAgICAgcmV0dXJuICdmaWxlJ1xuICAgIGNhc2UgMTpcbiAgICAgIHJldHVybiAnbGluaydcbiAgICBjYXNlIDI6XG4gICAgICByZXR1cm4gJ3N5bWxpbmsnXG4gICAgY2FzZSAzOlxuICAgICAgcmV0dXJuICdjaGFyYWN0ZXItZGV2aWNlJ1xuICAgIGNhc2UgNDpcbiAgICAgIHJldHVybiAnYmxvY2stZGV2aWNlJ1xuICAgIGNhc2UgNTpcbiAgICAgIHJldHVybiAnZGlyZWN0b3J5J1xuICAgIGNhc2UgNjpcbiAgICAgIHJldHVybiAnZmlmbydcbiAgICBjYXNlIDc6XG4gICAgICByZXR1cm4gJ2NvbnRpZ3VvdXMtZmlsZSdcbiAgICBjYXNlIDcyOlxuICAgICAgcmV0dXJuICdwYXgtaGVhZGVyJ1xuICAgIGNhc2UgNTU6XG4gICAgICByZXR1cm4gJ3BheC1nbG9iYWwtaGVhZGVyJ1xuICAgIGNhc2UgMjc6XG4gICAgICByZXR1cm4gJ2dudS1sb25nLWxpbmstcGF0aCdcbiAgICBjYXNlIDI4OlxuICAgIGNhc2UgMzA6XG4gICAgICByZXR1cm4gJ2dudS1sb25nLXBhdGgnXG4gIH1cblxuICByZXR1cm4gbnVsbFxufVxuXG5mdW5jdGlvbiB0b1R5cGVmbGFnIChmbGFnKSB7XG4gIHN3aXRjaCAoZmxhZykge1xuICAgIGNhc2UgJ2ZpbGUnOlxuICAgICAgcmV0dXJuIDBcbiAgICBjYXNlICdsaW5rJzpcbiAgICAgIHJldHVybiAxXG4gICAgY2FzZSAnc3ltbGluayc6XG4gICAgICByZXR1cm4gMlxuICAgIGNhc2UgJ2NoYXJhY3Rlci1kZXZpY2UnOlxuICAgICAgcmV0dXJuIDNcbiAgICBjYXNlICdibG9jay1kZXZpY2UnOlxuICAgICAgcmV0dXJuIDRcbiAgICBjYXNlICdkaXJlY3RvcnknOlxuICAgICAgcmV0dXJuIDVcbiAgICBjYXNlICdmaWZvJzpcbiAgICAgIHJldHVybiA2XG4gICAgY2FzZSAnY29udGlndW91cy1maWxlJzpcbiAgICAgIHJldHVybiA3XG4gICAgY2FzZSAncGF4LWhlYWRlcic6XG4gICAgICByZXR1cm4gNzJcbiAgfVxuXG4gIHJldHVybiAwXG59XG5cbmZ1bmN0aW9uIGluZGV4T2YgKGJsb2NrLCBudW0sIG9mZnNldCwgZW5kKSB7XG4gIGZvciAoOyBvZmZzZXQgPCBlbmQ7IG9mZnNldCsrKSB7XG4gICAgaWYgKGJsb2NrW29mZnNldF0gPT09IG51bSkgcmV0dXJuIG9mZnNldFxuICB9XG4gIHJldHVybiBlbmRcbn1cblxuZnVuY3Rpb24gY2tzdW0gKGJsb2NrKSB7XG4gIGxldCBzdW0gPSA4ICogMzJcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCAxNDg7IGkrKykgc3VtICs9IGJsb2NrW2ldXG4gIGZvciAobGV0IGogPSAxNTY7IGogPCA1MTI7IGorKykgc3VtICs9IGJsb2NrW2pdXG4gIHJldHVybiBzdW1cbn1cblxuZnVuY3Rpb24gZW5jb2RlT2N0ICh2YWwsIG4pIHtcbiAgdmFsID0gdmFsLnRvU3RyaW5nKDgpXG4gIGlmICh2YWwubGVuZ3RoID4gbikgcmV0dXJuIFNFVkVOUy5zbGljZSgwLCBuKSArICcgJ1xuICByZXR1cm4gWkVST1Muc2xpY2UoMCwgbiAtIHZhbC5sZW5ndGgpICsgdmFsICsgJyAnXG59XG5cbmZ1bmN0aW9uIGVuY29kZVNpemVCaW4gKG51bSwgYnVmLCBvZmYpIHtcbiAgYnVmW29mZl0gPSAweDgwXG4gIGZvciAobGV0IGkgPSAxMTsgaSA+IDA7IGktLSkge1xuICAgIGJ1ZltvZmYgKyBpXSA9IG51bSAmIDB4ZmZcbiAgICBudW0gPSBNYXRoLmZsb29yKG51bSAvIDB4MTAwKVxuICB9XG59XG5cbmZ1bmN0aW9uIGVuY29kZVNpemUgKG51bSwgYnVmLCBvZmYpIHtcbiAgaWYgKG51bS50b1N0cmluZyg4KS5sZW5ndGggPiAxMSkge1xuICAgIGVuY29kZVNpemVCaW4obnVtLCBidWYsIG9mZilcbiAgfSBlbHNlIHtcbiAgICBiNGEud3JpdGUoYnVmLCBlbmNvZGVPY3QobnVtLCAxMSksIG9mZilcbiAgfVxufVxuXG4vKiBDb3BpZWQgZnJvbSB0aGUgbm9kZS10YXIgcmVwbyBhbmQgbW9kaWZpZWQgdG8gbWVldFxuICogdGFyLXN0cmVhbSBjb2Rpbmcgc3RhbmRhcmQuXG4gKlxuICogU291cmNlOiBodHRwczovL2dpdGh1Yi5jb20vbnBtL25vZGUtdGFyL2Jsb2IvNTFiNjYyN2ExZjM1N2QyZWI0MzNlNzM3OGU1ZjA1ZTgzYjdhYTZjZC9saWIvaGVhZGVyLmpzI0wzNDlcbiAqL1xuZnVuY3Rpb24gcGFyc2UyNTYgKGJ1Zikge1xuICAvLyBmaXJzdCBieXRlIE1VU1QgYmUgZWl0aGVyIDgwIG9yIEZGXG4gIC8vIDgwIGZvciBwb3NpdGl2ZSwgRkYgZm9yIDIncyBjb21wXG4gIGxldCBwb3NpdGl2ZVxuICBpZiAoYnVmWzBdID09PSAweDgwKSBwb3NpdGl2ZSA9IHRydWVcbiAgZWxzZSBpZiAoYnVmWzBdID09PSAweEZGKSBwb3NpdGl2ZSA9IGZhbHNlXG4gIGVsc2UgcmV0dXJuIG51bGxcblxuICAvLyBidWlsZCB1cCBhIGJhc2UtMjU2IHR1cGxlIGZyb20gdGhlIGxlYXN0IHNpZyB0byB0aGUgaGlnaGVzdFxuICBjb25zdCB0dXBsZSA9IFtdXG4gIGxldCBpXG4gIGZvciAoaSA9IGJ1Zi5sZW5ndGggLSAxOyBpID4gMDsgaS0tKSB7XG4gICAgY29uc3QgYnl0ZSA9IGJ1ZltpXVxuICAgIGlmIChwb3NpdGl2ZSkgdHVwbGUucHVzaChieXRlKVxuICAgIGVsc2UgdHVwbGUucHVzaCgweEZGIC0gYnl0ZSlcbiAgfVxuXG4gIGxldCBzdW0gPSAwXG4gIGNvbnN0IGwgPSB0dXBsZS5sZW5ndGhcbiAgZm9yIChpID0gMDsgaSA8IGw7IGkrKykge1xuICAgIHN1bSArPSB0dXBsZVtpXSAqIE1hdGgucG93KDI1NiwgaSlcbiAgfVxuXG4gIHJldHVybiBwb3NpdGl2ZSA/IHN1bSA6IC0xICogc3VtXG59XG5cbmZ1bmN0aW9uIGRlY29kZU9jdCAodmFsLCBvZmZzZXQsIGxlbmd0aCkge1xuICB2YWwgPSB2YWwuc3ViYXJyYXkob2Zmc2V0LCBvZmZzZXQgKyBsZW5ndGgpXG4gIG9mZnNldCA9IDBcblxuICAvLyBJZiBwcmVmaXhlZCB3aXRoIDB4ODAgdGhlbiBwYXJzZSBhcyBhIGJhc2UtMjU2IGludGVnZXJcbiAgaWYgKHZhbFtvZmZzZXRdICYgMHg4MCkge1xuICAgIHJldHVybiBwYXJzZTI1Nih2YWwpXG4gIH0gZWxzZSB7XG4gICAgLy8gT2xkZXIgdmVyc2lvbnMgb2YgdGFyIGNhbiBwcmVmaXggd2l0aCBzcGFjZXNcbiAgICB3aGlsZSAob2Zmc2V0IDwgdmFsLmxlbmd0aCAmJiB2YWxbb2Zmc2V0XSA9PT0gMzIpIG9mZnNldCsrXG4gICAgY29uc3QgZW5kID0gY2xhbXAoaW5kZXhPZih2YWwsIDMyLCBvZmZzZXQsIHZhbC5sZW5ndGgpLCB2YWwubGVuZ3RoLCB2YWwubGVuZ3RoKVxuICAgIHdoaWxlIChvZmZzZXQgPCBlbmQgJiYgdmFsW29mZnNldF0gPT09IDApIG9mZnNldCsrXG4gICAgaWYgKGVuZCA9PT0gb2Zmc2V0KSByZXR1cm4gMFxuICAgIHJldHVybiBwYXJzZUludChiNGEudG9TdHJpbmcodmFsLnN1YmFycmF5KG9mZnNldCwgZW5kKSksIDgpXG4gIH1cbn1cblxuZnVuY3Rpb24gZGVjb2RlU3RyICh2YWwsIG9mZnNldCwgbGVuZ3RoLCBlbmNvZGluZykge1xuICByZXR1cm4gYjRhLnRvU3RyaW5nKHZhbC5zdWJhcnJheShvZmZzZXQsIGluZGV4T2YodmFsLCAwLCBvZmZzZXQsIG9mZnNldCArIGxlbmd0aCkpLCBlbmNvZGluZylcbn1cblxuZnVuY3Rpb24gYWRkTGVuZ3RoIChzdHIpIHtcbiAgY29uc3QgbGVuID0gYjRhLmJ5dGVMZW5ndGgoc3RyKVxuICBsZXQgZGlnaXRzID0gTWF0aC5mbG9vcihNYXRoLmxvZyhsZW4pIC8gTWF0aC5sb2coMTApKSArIDFcbiAgaWYgKGxlbiArIGRpZ2l0cyA+PSBNYXRoLnBvdygxMCwgZGlnaXRzKSkgZGlnaXRzKytcblxuICByZXR1cm4gKGxlbiArIGRpZ2l0cykgKyBzdHJcbn1cbiIsICJjb25zdCB7IFdyaXRhYmxlLCBSZWFkYWJsZSwgZ2V0U3RyZWFtRXJyb3IgfSA9IHJlcXVpcmUoJ3N0cmVhbXgnKVxuY29uc3QgRklGTyA9IHJlcXVpcmUoJ2Zhc3QtZmlmbycpXG5jb25zdCBiNGEgPSByZXF1aXJlKCdiNGEnKVxuY29uc3QgaGVhZGVycyA9IHJlcXVpcmUoJy4vaGVhZGVycycpXG5cbmNvbnN0IEVNUFRZID0gYjRhLmFsbG9jKDApXG5cbmNsYXNzIEJ1ZmZlckxpc3Qge1xuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgdGhpcy5idWZmZXJlZCA9IDBcbiAgICB0aGlzLnNoaWZ0ZWQgPSAwXG4gICAgdGhpcy5xdWV1ZSA9IG5ldyBGSUZPKClcblxuICAgIHRoaXMuX29mZnNldCA9IDBcbiAgfVxuXG4gIHB1c2ggKGJ1ZmZlcikge1xuICAgIHRoaXMuYnVmZmVyZWQgKz0gYnVmZmVyLmJ5dGVMZW5ndGhcbiAgICB0aGlzLnF1ZXVlLnB1c2goYnVmZmVyKVxuICB9XG5cbiAgc2hpZnRGaXJzdCAoc2l6ZSkge1xuICAgIHJldHVybiB0aGlzLl9idWZmZXJlZCA9PT0gMCA/IG51bGwgOiB0aGlzLl9uZXh0KHNpemUpXG4gIH1cblxuICBzaGlmdCAoc2l6ZSkge1xuICAgIGlmIChzaXplID4gdGhpcy5idWZmZXJlZCkgcmV0dXJuIG51bGxcbiAgICBpZiAoc2l6ZSA9PT0gMCkgcmV0dXJuIEVNUFRZXG5cbiAgICBsZXQgY2h1bmsgPSB0aGlzLl9uZXh0KHNpemUpXG5cbiAgICBpZiAoc2l6ZSA9PT0gY2h1bmsuYnl0ZUxlbmd0aCkgcmV0dXJuIGNodW5rIC8vIGxpa2VseSBjYXNlXG5cbiAgICBjb25zdCBjaHVua3MgPSBbY2h1bmtdXG5cbiAgICB3aGlsZSAoKHNpemUgLT0gY2h1bmsuYnl0ZUxlbmd0aCkgPiAwKSB7XG4gICAgICBjaHVuayA9IHRoaXMuX25leHQoc2l6ZSlcbiAgICAgIGNodW5rcy5wdXNoKGNodW5rKVxuICAgIH1cblxuICAgIHJldHVybiBiNGEuY29uY2F0KGNodW5rcylcbiAgfVxuXG4gIF9uZXh0IChzaXplKSB7XG4gICAgY29uc3QgYnVmID0gdGhpcy5xdWV1ZS5wZWVrKClcbiAgICBjb25zdCByZW0gPSBidWYuYnl0ZUxlbmd0aCAtIHRoaXMuX29mZnNldFxuXG4gICAgaWYgKHNpemUgPj0gcmVtKSB7XG4gICAgICBjb25zdCBzdWIgPSB0aGlzLl9vZmZzZXQgPyBidWYuc3ViYXJyYXkodGhpcy5fb2Zmc2V0LCBidWYuYnl0ZUxlbmd0aCkgOiBidWZcbiAgICAgIHRoaXMucXVldWUuc2hpZnQoKVxuICAgICAgdGhpcy5fb2Zmc2V0ID0gMFxuICAgICAgdGhpcy5idWZmZXJlZCAtPSByZW1cbiAgICAgIHRoaXMuc2hpZnRlZCArPSByZW1cbiAgICAgIHJldHVybiBzdWJcbiAgICB9XG5cbiAgICB0aGlzLmJ1ZmZlcmVkIC09IHNpemVcbiAgICB0aGlzLnNoaWZ0ZWQgKz0gc2l6ZVxuXG4gICAgcmV0dXJuIGJ1Zi5zdWJhcnJheSh0aGlzLl9vZmZzZXQsICh0aGlzLl9vZmZzZXQgKz0gc2l6ZSkpXG4gIH1cbn1cblxuY2xhc3MgU291cmNlIGV4dGVuZHMgUmVhZGFibGUge1xuICBjb25zdHJ1Y3RvciAoc2VsZiwgaGVhZGVyLCBvZmZzZXQpIHtcbiAgICBzdXBlcigpXG5cbiAgICB0aGlzLmhlYWRlciA9IGhlYWRlclxuICAgIHRoaXMub2Zmc2V0ID0gb2Zmc2V0XG5cbiAgICB0aGlzLl9wYXJlbnQgPSBzZWxmXG4gIH1cblxuICBfcmVhZCAoY2IpIHtcbiAgICBpZiAodGhpcy5oZWFkZXIuc2l6ZSA9PT0gMCkge1xuICAgICAgdGhpcy5wdXNoKG51bGwpXG4gICAgfVxuICAgIGlmICh0aGlzLl9wYXJlbnQuX3N0cmVhbSA9PT0gdGhpcykge1xuICAgICAgdGhpcy5fcGFyZW50Ll91cGRhdGUoKVxuICAgIH1cbiAgICBjYihudWxsKVxuICB9XG5cbiAgX3ByZWRlc3Ryb3kgKCkge1xuICAgIHRoaXMuX3BhcmVudC5kZXN0cm95KGdldFN0cmVhbUVycm9yKHRoaXMpKVxuICB9XG5cbiAgX2RldGFjaCAoKSB7XG4gICAgaWYgKHRoaXMuX3BhcmVudC5fc3RyZWFtID09PSB0aGlzKSB7XG4gICAgICB0aGlzLl9wYXJlbnQuX3N0cmVhbSA9IG51bGxcbiAgICAgIHRoaXMuX3BhcmVudC5fbWlzc2luZyA9IG92ZXJmbG93KHRoaXMuaGVhZGVyLnNpemUpXG4gICAgICB0aGlzLl9wYXJlbnQuX3VwZGF0ZSgpXG4gICAgfVxuICB9XG5cbiAgX2Rlc3Ryb3kgKGNiKSB7XG4gICAgdGhpcy5fZGV0YWNoKClcbiAgICBjYihudWxsKVxuICB9XG59XG5cbmNsYXNzIEV4dHJhY3QgZXh0ZW5kcyBXcml0YWJsZSB7XG4gIGNvbnN0cnVjdG9yIChvcHRzKSB7XG4gICAgc3VwZXIob3B0cylcblxuICAgIGlmICghb3B0cykgb3B0cyA9IHt9XG5cbiAgICB0aGlzLl9idWZmZXIgPSBuZXcgQnVmZmVyTGlzdCgpXG4gICAgdGhpcy5fb2Zmc2V0ID0gMFxuICAgIHRoaXMuX2hlYWRlciA9IG51bGxcbiAgICB0aGlzLl9zdHJlYW0gPSBudWxsXG4gICAgdGhpcy5fbWlzc2luZyA9IDBcbiAgICB0aGlzLl9sb25nSGVhZGVyID0gZmFsc2VcbiAgICB0aGlzLl9jYWxsYmFjayA9IG5vb3BcbiAgICB0aGlzLl9sb2NrZWQgPSBmYWxzZVxuICAgIHRoaXMuX2ZpbmlzaGVkID0gZmFsc2VcbiAgICB0aGlzLl9wYXggPSBudWxsXG4gICAgdGhpcy5fcGF4R2xvYmFsID0gbnVsbFxuICAgIHRoaXMuX2dudUxvbmdQYXRoID0gbnVsbFxuICAgIHRoaXMuX2dudUxvbmdMaW5rUGF0aCA9IG51bGxcbiAgICB0aGlzLl9maWxlbmFtZUVuY29kaW5nID0gb3B0cy5maWxlbmFtZUVuY29kaW5nIHx8ICd1dGYtOCdcbiAgICB0aGlzLl9hbGxvd1Vua25vd25Gb3JtYXQgPSAhIW9wdHMuYWxsb3dVbmtub3duRm9ybWF0XG4gICAgdGhpcy5fdW5sb2NrQm91bmQgPSB0aGlzLl91bmxvY2suYmluZCh0aGlzKVxuICB9XG5cbiAgX3VubG9jayAoZXJyKSB7XG4gICAgdGhpcy5fbG9ja2VkID0gZmFsc2VcblxuICAgIGlmIChlcnIpIHtcbiAgICAgIHRoaXMuZGVzdHJveShlcnIpXG4gICAgICB0aGlzLl9jb250aW51ZVdyaXRlKGVycilcbiAgICAgIHJldHVyblxuICAgIH1cblxuICAgIHRoaXMuX3VwZGF0ZSgpXG4gIH1cblxuICBfY29uc3VtZUhlYWRlciAoKSB7XG4gICAgaWYgKHRoaXMuX2xvY2tlZCkgcmV0dXJuIGZhbHNlXG5cbiAgICB0aGlzLl9vZmZzZXQgPSB0aGlzLl9idWZmZXIuc2hpZnRlZFxuXG4gICAgdHJ5IHtcbiAgICAgIHRoaXMuX2hlYWRlciA9IGhlYWRlcnMuZGVjb2RlKHRoaXMuX2J1ZmZlci5zaGlmdCg1MTIpLCB0aGlzLl9maWxlbmFtZUVuY29kaW5nLCB0aGlzLl9hbGxvd1Vua25vd25Gb3JtYXQpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLl9jb250aW51ZVdyaXRlKGVycilcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIGlmICghdGhpcy5faGVhZGVyKSByZXR1cm4gdHJ1ZVxuXG4gICAgc3dpdGNoICh0aGlzLl9oZWFkZXIudHlwZSkge1xuICAgICAgY2FzZSAnZ251LWxvbmctcGF0aCc6XG4gICAgICBjYXNlICdnbnUtbG9uZy1saW5rLXBhdGgnOlxuICAgICAgY2FzZSAncGF4LWdsb2JhbC1oZWFkZXInOlxuICAgICAgY2FzZSAncGF4LWhlYWRlcic6XG4gICAgICAgIHRoaXMuX2xvbmdIZWFkZXIgPSB0cnVlXG4gICAgICAgIHRoaXMuX21pc3NpbmcgPSB0aGlzLl9oZWFkZXIuc2l6ZVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgIH1cblxuICAgIHRoaXMuX2xvY2tlZCA9IHRydWVcbiAgICB0aGlzLl9hcHBseUxvbmdIZWFkZXJzKClcblxuICAgIGlmICh0aGlzLl9oZWFkZXIuc2l6ZSA9PT0gMCB8fCB0aGlzLl9oZWFkZXIudHlwZSA9PT0gJ2RpcmVjdG9yeScpIHtcbiAgICAgIHRoaXMuZW1pdCgnZW50cnknLCB0aGlzLl9oZWFkZXIsIHRoaXMuX2NyZWF0ZVN0cmVhbSgpLCB0aGlzLl91bmxvY2tCb3VuZClcbiAgICAgIHJldHVybiB0cnVlXG4gICAgfVxuXG4gICAgdGhpcy5fc3RyZWFtID0gdGhpcy5fY3JlYXRlU3RyZWFtKClcbiAgICB0aGlzLl9taXNzaW5nID0gdGhpcy5faGVhZGVyLnNpemVcblxuICAgIHRoaXMuZW1pdCgnZW50cnknLCB0aGlzLl9oZWFkZXIsIHRoaXMuX3N0cmVhbSwgdGhpcy5fdW5sb2NrQm91bmQpXG4gICAgcmV0dXJuIHRydWVcbiAgfVxuXG4gIF9hcHBseUxvbmdIZWFkZXJzICgpIHtcbiAgICBpZiAodGhpcy5fZ251TG9uZ1BhdGgpIHtcbiAgICAgIHRoaXMuX2hlYWRlci5uYW1lID0gdGhpcy5fZ251TG9uZ1BhdGhcbiAgICAgIHRoaXMuX2dudUxvbmdQYXRoID0gbnVsbFxuICAgIH1cblxuICAgIGlmICh0aGlzLl9nbnVMb25nTGlua1BhdGgpIHtcbiAgICAgIHRoaXMuX2hlYWRlci5saW5rbmFtZSA9IHRoaXMuX2dudUxvbmdMaW5rUGF0aFxuICAgICAgdGhpcy5fZ251TG9uZ0xpbmtQYXRoID0gbnVsbFxuICAgIH1cblxuICAgIGlmICh0aGlzLl9wYXgpIHtcbiAgICAgIGlmICh0aGlzLl9wYXgucGF0aCkgdGhpcy5faGVhZGVyLm5hbWUgPSB0aGlzLl9wYXgucGF0aFxuICAgICAgaWYgKHRoaXMuX3BheC5saW5rcGF0aCkgdGhpcy5faGVhZGVyLmxpbmtuYW1lID0gdGhpcy5fcGF4LmxpbmtwYXRoXG4gICAgICBpZiAodGhpcy5fcGF4LnNpemUpIHRoaXMuX2hlYWRlci5zaXplID0gcGFyc2VJbnQodGhpcy5fcGF4LnNpemUsIDEwKVxuICAgICAgdGhpcy5faGVhZGVyLnBheCA9IHRoaXMuX3BheFxuICAgICAgdGhpcy5fcGF4ID0gbnVsbFxuICAgIH1cbiAgfVxuXG4gIF9kZWNvZGVMb25nSGVhZGVyIChidWYpIHtcbiAgICBzd2l0Y2ggKHRoaXMuX2hlYWRlci50eXBlKSB7XG4gICAgICBjYXNlICdnbnUtbG9uZy1wYXRoJzpcbiAgICAgICAgdGhpcy5fZ251TG9uZ1BhdGggPSBoZWFkZXJzLmRlY29kZUxvbmdQYXRoKGJ1ZiwgdGhpcy5fZmlsZW5hbWVFbmNvZGluZylcbiAgICAgICAgYnJlYWtcbiAgICAgIGNhc2UgJ2dudS1sb25nLWxpbmstcGF0aCc6XG4gICAgICAgIHRoaXMuX2dudUxvbmdMaW5rUGF0aCA9IGhlYWRlcnMuZGVjb2RlTG9uZ1BhdGgoYnVmLCB0aGlzLl9maWxlbmFtZUVuY29kaW5nKVxuICAgICAgICBicmVha1xuICAgICAgY2FzZSAncGF4LWdsb2JhbC1oZWFkZXInOlxuICAgICAgICB0aGlzLl9wYXhHbG9iYWwgPSBoZWFkZXJzLmRlY29kZVBheChidWYpXG4gICAgICAgIGJyZWFrXG4gICAgICBjYXNlICdwYXgtaGVhZGVyJzpcbiAgICAgICAgdGhpcy5fcGF4ID0gdGhpcy5fcGF4R2xvYmFsID09PSBudWxsXG4gICAgICAgICAgPyBoZWFkZXJzLmRlY29kZVBheChidWYpXG4gICAgICAgICAgOiBPYmplY3QuYXNzaWduKHt9LCB0aGlzLl9wYXhHbG9iYWwsIGhlYWRlcnMuZGVjb2RlUGF4KGJ1ZikpXG4gICAgICAgIGJyZWFrXG4gICAgfVxuICB9XG5cbiAgX2NvbnN1bWVMb25nSGVhZGVyICgpIHtcbiAgICB0aGlzLl9sb25nSGVhZGVyID0gZmFsc2VcbiAgICB0aGlzLl9taXNzaW5nID0gb3ZlcmZsb3codGhpcy5faGVhZGVyLnNpemUpXG5cbiAgICBjb25zdCBidWYgPSB0aGlzLl9idWZmZXIuc2hpZnQodGhpcy5faGVhZGVyLnNpemUpXG5cbiAgICB0cnkge1xuICAgICAgdGhpcy5fZGVjb2RlTG9uZ0hlYWRlcihidWYpXG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aGlzLl9jb250aW51ZVdyaXRlKGVycilcbiAgICAgIHJldHVybiBmYWxzZVxuICAgIH1cblxuICAgIHJldHVybiB0cnVlXG4gIH1cblxuICBfY29uc3VtZVN0cmVhbSAoKSB7XG4gICAgY29uc3QgYnVmID0gdGhpcy5fYnVmZmVyLnNoaWZ0Rmlyc3QodGhpcy5fbWlzc2luZylcbiAgICBpZiAoYnVmID09PSBudWxsKSByZXR1cm4gZmFsc2VcblxuICAgIHRoaXMuX21pc3NpbmcgLT0gYnVmLmJ5dGVMZW5ndGhcbiAgICBjb25zdCBkcmFpbmVkID0gdGhpcy5fc3RyZWFtLnB1c2goYnVmKVxuXG4gICAgaWYgKHRoaXMuX21pc3NpbmcgPT09IDApIHtcbiAgICAgIHRoaXMuX3N0cmVhbS5wdXNoKG51bGwpXG4gICAgICBpZiAoZHJhaW5lZCkgdGhpcy5fc3RyZWFtLl9kZXRhY2goKVxuICAgICAgcmV0dXJuIGRyYWluZWQgJiYgdGhpcy5fbG9ja2VkID09PSBmYWxzZVxuICAgIH1cblxuICAgIHJldHVybiBkcmFpbmVkXG4gIH1cblxuICBfY3JlYXRlU3RyZWFtICgpIHtcbiAgICByZXR1cm4gbmV3IFNvdXJjZSh0aGlzLCB0aGlzLl9oZWFkZXIsIHRoaXMuX29mZnNldClcbiAgfVxuXG4gIF91cGRhdGUgKCkge1xuICAgIHdoaWxlICh0aGlzLl9idWZmZXIuYnVmZmVyZWQgPiAwICYmICF0aGlzLmRlc3Ryb3lpbmcpIHtcbiAgICAgIGlmICh0aGlzLl9taXNzaW5nID4gMCkge1xuICAgICAgICBpZiAodGhpcy5fc3RyZWFtICE9PSBudWxsKSB7XG4gICAgICAgICAgaWYgKHRoaXMuX2NvbnN1bWVTdHJlYW0oKSA9PT0gZmFsc2UpIHJldHVyblxuICAgICAgICAgIGNvbnRpbnVlXG4gICAgICAgIH1cblxuICAgICAgICBpZiAodGhpcy5fbG9uZ0hlYWRlciA9PT0gdHJ1ZSkge1xuICAgICAgICAgIGlmICh0aGlzLl9taXNzaW5nID4gdGhpcy5fYnVmZmVyLmJ1ZmZlcmVkKSBicmVha1xuICAgICAgICAgIGlmICh0aGlzLl9jb25zdW1lTG9uZ0hlYWRlcigpID09PSBmYWxzZSkgcmV0dXJuIGZhbHNlXG4gICAgICAgICAgY29udGludWVcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IGlnbm9yZSA9IHRoaXMuX2J1ZmZlci5zaGlmdEZpcnN0KHRoaXMuX21pc3NpbmcpXG4gICAgICAgIGlmIChpZ25vcmUgIT09IG51bGwpIHRoaXMuX21pc3NpbmcgLT0gaWdub3JlLmJ5dGVMZW5ndGhcbiAgICAgICAgY29udGludWVcbiAgICAgIH1cblxuICAgICAgaWYgKHRoaXMuX2J1ZmZlci5idWZmZXJlZCA8IDUxMikgYnJlYWtcbiAgICAgIGlmICh0aGlzLl9zdHJlYW0gIT09IG51bGwgfHwgdGhpcy5fY29uc3VtZUhlYWRlcigpID09PSBmYWxzZSkgcmV0dXJuXG4gICAgfVxuXG4gICAgdGhpcy5fY29udGludWVXcml0ZShudWxsKVxuICB9XG5cbiAgX2NvbnRpbnVlV3JpdGUgKGVycikge1xuICAgIGNvbnN0IGNiID0gdGhpcy5fY2FsbGJhY2tcbiAgICB0aGlzLl9jYWxsYmFjayA9IG5vb3BcbiAgICBjYihlcnIpXG4gIH1cblxuICBfd3JpdGUgKGRhdGEsIGNiKSB7XG4gICAgdGhpcy5fY2FsbGJhY2sgPSBjYlxuICAgIHRoaXMuX2J1ZmZlci5wdXNoKGRhdGEpXG4gICAgdGhpcy5fdXBkYXRlKClcbiAgfVxuXG4gIF9maW5hbCAoY2IpIHtcbiAgICB0aGlzLl9maW5pc2hlZCA9IHRoaXMuX21pc3NpbmcgPT09IDAgJiYgdGhpcy5fYnVmZmVyLmJ1ZmZlcmVkID09PSAwXG4gICAgY2IodGhpcy5fZmluaXNoZWQgPyBudWxsIDogbmV3IEVycm9yKCdVbmV4cGVjdGVkIGVuZCBvZiBkYXRhJykpXG4gIH1cblxuICBfcHJlZGVzdHJveSAoKSB7XG4gICAgdGhpcy5fY29udGludWVXcml0ZShudWxsKVxuICB9XG5cbiAgX2Rlc3Ryb3kgKGNiKSB7XG4gICAgaWYgKHRoaXMuX3N0cmVhbSkgdGhpcy5fc3RyZWFtLmRlc3Ryb3koZ2V0U3RyZWFtRXJyb3IodGhpcykpXG4gICAgY2IobnVsbClcbiAgfVxuXG4gIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gKCkge1xuICAgIGxldCBlcnJvciA9IG51bGxcblxuICAgIGxldCBwcm9taXNlUmVzb2x2ZSA9IG51bGxcbiAgICBsZXQgcHJvbWlzZVJlamVjdCA9IG51bGxcblxuICAgIGxldCBlbnRyeVN0cmVhbSA9IG51bGxcbiAgICBsZXQgZW50cnlDYWxsYmFjayA9IG51bGxcblxuICAgIGNvbnN0IGV4dHJhY3QgPSB0aGlzXG5cbiAgICB0aGlzLm9uKCdlbnRyeScsIG9uZW50cnkpXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyKSA9PiB7IGVycm9yID0gZXJyIH0pXG4gICAgdGhpcy5vbignY2xvc2UnLCBvbmNsb3NlKVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0gKCkge1xuICAgICAgICByZXR1cm4gdGhpc1xuICAgICAgfSxcbiAgICAgIG5leHQgKCkge1xuICAgICAgICByZXR1cm4gbmV3IFByb21pc2Uob25uZXh0KVxuICAgICAgfSxcbiAgICAgIHJldHVybiAoKSB7XG4gICAgICAgIHJldHVybiBkZXN0cm95KG51bGwpXG4gICAgICB9LFxuICAgICAgdGhyb3cgKGVycikge1xuICAgICAgICByZXR1cm4gZGVzdHJveShlcnIpXG4gICAgICB9XG4gICAgfVxuXG4gICAgZnVuY3Rpb24gY29uc3VtZUNhbGxiYWNrIChlcnIpIHtcbiAgICAgIGlmICghZW50cnlDYWxsYmFjaykgcmV0dXJuXG4gICAgICBjb25zdCBjYiA9IGVudHJ5Q2FsbGJhY2tcbiAgICAgIGVudHJ5Q2FsbGJhY2sgPSBudWxsXG4gICAgICBjYihlcnIpXG4gICAgfVxuXG4gICAgZnVuY3Rpb24gb25uZXh0IChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgIGlmIChlcnJvcikge1xuICAgICAgICByZXR1cm4gcmVqZWN0KGVycm9yKVxuICAgICAgfVxuXG4gICAgICBpZiAoZW50cnlTdHJlYW0pIHtcbiAgICAgICAgcmVzb2x2ZSh7IHZhbHVlOiBlbnRyeVN0cmVhbSwgZG9uZTogZmFsc2UgfSlcbiAgICAgICAgZW50cnlTdHJlYW0gPSBudWxsXG4gICAgICAgIHJldHVyblxuICAgICAgfVxuXG4gICAgICBwcm9taXNlUmVzb2x2ZSA9IHJlc29sdmVcbiAgICAgIHByb21pc2VSZWplY3QgPSByZWplY3RcblxuICAgICAgY29uc3VtZUNhbGxiYWNrKG51bGwpXG5cbiAgICAgIGlmIChleHRyYWN0Ll9maW5pc2hlZCAmJiBwcm9taXNlUmVzb2x2ZSkge1xuICAgICAgICBwcm9taXNlUmVzb2x2ZSh7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfSlcbiAgICAgICAgcHJvbWlzZVJlc29sdmUgPSBwcm9taXNlUmVqZWN0ID0gbnVsbFxuICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIG9uZW50cnkgKGhlYWRlciwgc3RyZWFtLCBjYWxsYmFjaykge1xuICAgICAgZW50cnlDYWxsYmFjayA9IGNhbGxiYWNrXG4gICAgICBzdHJlYW0ub24oJ2Vycm9yJywgbm9vcCkgLy8gbm8gd2F5IGFyb3VuZCB0aGlzIGR1ZSB0byB0aWNrIHNpbGx5bmVzc1xuXG4gICAgICBpZiAocHJvbWlzZVJlc29sdmUpIHtcbiAgICAgICAgcHJvbWlzZVJlc29sdmUoeyB2YWx1ZTogc3RyZWFtLCBkb25lOiBmYWxzZSB9KVxuICAgICAgICBwcm9taXNlUmVzb2x2ZSA9IHByb21pc2VSZWplY3QgPSBudWxsXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBlbnRyeVN0cmVhbSA9IHN0cmVhbVxuICAgICAgfVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIG9uY2xvc2UgKCkge1xuICAgICAgY29uc3VtZUNhbGxiYWNrKGVycm9yKVxuICAgICAgaWYgKCFwcm9taXNlUmVzb2x2ZSkgcmV0dXJuXG4gICAgICBpZiAoZXJyb3IpIHByb21pc2VSZWplY3QoZXJyb3IpXG4gICAgICBlbHNlIHByb21pc2VSZXNvbHZlKHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9KVxuICAgICAgcHJvbWlzZVJlc29sdmUgPSBwcm9taXNlUmVqZWN0ID0gbnVsbFxuICAgIH1cblxuICAgIGZ1bmN0aW9uIGRlc3Ryb3kgKGVycikge1xuICAgICAgZXh0cmFjdC5kZXN0cm95KGVycilcbiAgICAgIGNvbnN1bWVDYWxsYmFjayhlcnIpXG4gICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICBpZiAoZXh0cmFjdC5kZXN0cm95ZWQpIHJldHVybiByZXNvbHZlKHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9KVxuICAgICAgICBleHRyYWN0Lm9uY2UoJ2Nsb3NlJywgZnVuY3Rpb24gKCkge1xuICAgICAgICAgIGlmIChlcnIpIHJlamVjdChlcnIpXG4gICAgICAgICAgZWxzZSByZXNvbHZlKHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9KVxuICAgICAgICB9KVxuICAgICAgfSlcbiAgICB9XG4gIH1cbn1cblxubW9kdWxlLmV4cG9ydHMgPSBmdW5jdGlvbiBleHRyYWN0IChvcHRzKSB7XG4gIHJldHVybiBuZXcgRXh0cmFjdChvcHRzKVxufVxuXG5mdW5jdGlvbiBub29wICgpIHt9XG5cbmZ1bmN0aW9uIG92ZXJmbG93IChzaXplKSB7XG4gIHNpemUgJj0gNTExXG4gIHJldHVybiBzaXplICYmIDUxMiAtIHNpemVcbn1cbiIsICJjb25zdCBjb25zdGFudHMgPSB7IC8vIGp1c3QgZm9yIGVudnMgd2l0aG91dCBmc1xuICBTX0lGTVQ6IDYxNDQwLFxuICBTX0lGRElSOiAxNjM4NCxcbiAgU19JRkNIUjogODE5MixcbiAgU19JRkJMSzogMjQ1NzYsXG4gIFNfSUZJRk86IDQwOTYsXG4gIFNfSUZMTks6IDQwOTYwXG59XG5cbnRyeSB7XG4gIG1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnZnMnKS5jb25zdGFudHMgfHwgY29uc3RhbnRzXG59IGNhdGNoIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBjb25zdGFudHNcbn1cbiIsICJjb25zdCB7IFJlYWRhYmxlLCBXcml0YWJsZSwgZ2V0U3RyZWFtRXJyb3IgfSA9IHJlcXVpcmUoJ3N0cmVhbXgnKVxuY29uc3QgYjRhID0gcmVxdWlyZSgnYjRhJylcblxuY29uc3QgY29uc3RhbnRzID0gcmVxdWlyZSgnLi9jb25zdGFudHMnKVxuY29uc3QgaGVhZGVycyA9IHJlcXVpcmUoJy4vaGVhZGVycycpXG5cbmNvbnN0IERNT0RFID0gMG83NTVcbmNvbnN0IEZNT0RFID0gMG82NDRcblxuY29uc3QgRU5EX09GX1RBUiA9IGI0YS5hbGxvYygxMDI0KVxuXG5jbGFzcyBTaW5rIGV4dGVuZHMgV3JpdGFibGUge1xuICBjb25zdHJ1Y3RvciAocGFjaywgaGVhZGVyLCBjYWxsYmFjaykge1xuICAgIHN1cGVyKHsgbWFwV3JpdGFibGUsIGVhZ2VyT3BlbjogdHJ1ZSB9KVxuXG4gICAgdGhpcy53cml0dGVuID0gMFxuICAgIHRoaXMuaGVhZGVyID0gaGVhZGVyXG5cbiAgICB0aGlzLl9jYWxsYmFjayA9IGNhbGxiYWNrXG4gICAgdGhpcy5fbGlua25hbWUgPSBudWxsXG4gICAgdGhpcy5faXNMaW5rbmFtZSA9IGhlYWRlci50eXBlID09PSAnc3ltbGluaycgJiYgIWhlYWRlci5saW5rbmFtZVxuICAgIHRoaXMuX2lzVm9pZCA9IGhlYWRlci50eXBlICE9PSAnZmlsZScgJiYgaGVhZGVyLnR5cGUgIT09ICdjb250aWd1b3VzLWZpbGUnXG4gICAgdGhpcy5fZmluaXNoZWQgPSBmYWxzZVxuICAgIHRoaXMuX3BhY2sgPSBwYWNrXG4gICAgdGhpcy5fb3BlbkNhbGxiYWNrID0gbnVsbFxuXG4gICAgaWYgKHRoaXMuX3BhY2suX3N0cmVhbSA9PT0gbnVsbCkgdGhpcy5fcGFjay5fc3RyZWFtID0gdGhpc1xuICAgIGVsc2UgdGhpcy5fcGFjay5fcGVuZGluZy5wdXNoKHRoaXMpXG4gIH1cblxuICBfb3BlbiAoY2IpIHtcbiAgICB0aGlzLl9vcGVuQ2FsbGJhY2sgPSBjYlxuICAgIGlmICh0aGlzLl9wYWNrLl9zdHJlYW0gPT09IHRoaXMpIHRoaXMuX2NvbnRpbnVlT3BlbigpXG4gIH1cblxuICBfY29udGludWVQYWNrIChlcnIpIHtcbiAgICBpZiAodGhpcy5fY2FsbGJhY2sgPT09IG51bGwpIHJldHVyblxuXG4gICAgY29uc3QgY2FsbGJhY2sgPSB0aGlzLl9jYWxsYmFja1xuICAgIHRoaXMuX2NhbGxiYWNrID0gbnVsbFxuXG4gICAgY2FsbGJhY2soZXJyKVxuICB9XG5cbiAgX2NvbnRpbnVlT3BlbiAoKSB7XG4gICAgaWYgKHRoaXMuX3BhY2suX3N0cmVhbSA9PT0gbnVsbCkgdGhpcy5fcGFjay5fc3RyZWFtID0gdGhpc1xuXG4gICAgY29uc3QgY2IgPSB0aGlzLl9vcGVuQ2FsbGJhY2tcbiAgICB0aGlzLl9vcGVuQ2FsbGJhY2sgPSBudWxsXG4gICAgaWYgKGNiID09PSBudWxsKSByZXR1cm5cblxuICAgIGlmICh0aGlzLl9wYWNrLmRlc3Ryb3lpbmcpIHJldHVybiBjYihuZXcgRXJyb3IoJ3BhY2sgc3RyZWFtIGRlc3Ryb3llZCcpKVxuICAgIGlmICh0aGlzLl9wYWNrLl9maW5hbGl6ZWQpIHJldHVybiBjYihuZXcgRXJyb3IoJ3BhY2sgc3RyZWFtIGlzIGFscmVhZHkgZmluYWxpemVkJykpXG5cbiAgICB0aGlzLl9wYWNrLl9zdHJlYW0gPSB0aGlzXG5cbiAgICBpZiAoIXRoaXMuX2lzTGlua25hbWUpIHtcbiAgICAgIHRoaXMuX3BhY2suX2VuY29kZSh0aGlzLmhlYWRlcilcbiAgICB9XG5cbiAgICBpZiAodGhpcy5faXNWb2lkKSB7XG4gICAgICB0aGlzLl9maW5pc2goKVxuICAgICAgdGhpcy5fY29udGludWVQYWNrKG51bGwpXG4gICAgfVxuXG4gICAgY2IobnVsbClcbiAgfVxuXG4gIF93cml0ZSAoZGF0YSwgY2IpIHtcbiAgICBpZiAodGhpcy5faXNMaW5rbmFtZSkge1xuICAgICAgdGhpcy5fbGlua25hbWUgPSB0aGlzLl9saW5rbmFtZSA/IGI0YS5jb25jYXQoW3RoaXMuX2xpbmtuYW1lLCBkYXRhXSkgOiBkYXRhXG4gICAgICByZXR1cm4gY2IobnVsbClcbiAgICB9XG5cbiAgICBpZiAodGhpcy5faXNWb2lkKSB7XG4gICAgICBpZiAoZGF0YS5ieXRlTGVuZ3RoID4gMCkge1xuICAgICAgICByZXR1cm4gY2IobmV3IEVycm9yKCdObyBib2R5IGFsbG93ZWQgZm9yIHRoaXMgZW50cnknKSlcbiAgICAgIH1cbiAgICAgIHJldHVybiBjYigpXG4gICAgfVxuXG4gICAgdGhpcy53cml0dGVuICs9IGRhdGEuYnl0ZUxlbmd0aFxuICAgIGlmICh0aGlzLl9wYWNrLnB1c2goZGF0YSkpIHJldHVybiBjYigpXG4gICAgdGhpcy5fcGFjay5fZHJhaW4gPSBjYlxuICB9XG5cbiAgX2ZpbmlzaCAoKSB7XG4gICAgaWYgKHRoaXMuX2ZpbmlzaGVkKSByZXR1cm5cbiAgICB0aGlzLl9maW5pc2hlZCA9IHRydWVcblxuICAgIGlmICh0aGlzLl9pc0xpbmtuYW1lKSB7XG4gICAgICB0aGlzLmhlYWRlci5saW5rbmFtZSA9IHRoaXMuX2xpbmtuYW1lID8gYjRhLnRvU3RyaW5nKHRoaXMuX2xpbmtuYW1lLCAndXRmLTgnKSA6ICcnXG4gICAgICB0aGlzLl9wYWNrLl9lbmNvZGUodGhpcy5oZWFkZXIpXG4gICAgfVxuXG4gICAgb3ZlcmZsb3codGhpcy5fcGFjaywgdGhpcy5oZWFkZXIuc2l6ZSlcblxuICAgIHRoaXMuX3BhY2suX2RvbmUodGhpcylcbiAgfVxuXG4gIF9maW5hbCAoY2IpIHtcbiAgICBpZiAodGhpcy53cml0dGVuICE9PSB0aGlzLmhlYWRlci5zaXplKSB7IC8vIGNvcnJ1cHRpbmcgdGFyXG4gICAgICByZXR1cm4gY2IobmV3IEVycm9yKCdTaXplIG1pc21hdGNoJykpXG4gICAgfVxuXG4gICAgdGhpcy5fZmluaXNoKClcbiAgICBjYihudWxsKVxuICB9XG5cbiAgX2dldEVycm9yICgpIHtcbiAgICByZXR1cm4gZ2V0U3RyZWFtRXJyb3IodGhpcykgfHwgbmV3IEVycm9yKCd0YXIgZW50cnkgZGVzdHJveWVkJylcbiAgfVxuXG4gIF9wcmVkZXN0cm95ICgpIHtcbiAgICB0aGlzLl9wYWNrLmRlc3Ryb3kodGhpcy5fZ2V0RXJyb3IoKSlcbiAgfVxuXG4gIF9kZXN0cm95IChjYikge1xuICAgIHRoaXMuX3BhY2suX2RvbmUodGhpcylcblxuICAgIHRoaXMuX2NvbnRpbnVlUGFjayh0aGlzLl9maW5pc2hlZCA/IG51bGwgOiB0aGlzLl9nZXRFcnJvcigpKVxuXG4gICAgY2IoKVxuICB9XG59XG5cbmNsYXNzIFBhY2sgZXh0ZW5kcyBSZWFkYWJsZSB7XG4gIGNvbnN0cnVjdG9yIChvcHRzKSB7XG4gICAgc3VwZXIob3B0cylcbiAgICB0aGlzLl9kcmFpbiA9IG5vb3BcbiAgICB0aGlzLl9maW5hbGl6ZWQgPSBmYWxzZVxuICAgIHRoaXMuX2ZpbmFsaXppbmcgPSBmYWxzZVxuICAgIHRoaXMuX3BlbmRpbmcgPSBbXVxuICAgIHRoaXMuX3N0cmVhbSA9IG51bGxcbiAgfVxuXG4gIGVudHJ5IChoZWFkZXIsIGJ1ZmZlciwgY2FsbGJhY2spIHtcbiAgICBpZiAodGhpcy5fZmluYWxpemVkIHx8IHRoaXMuZGVzdHJveWluZykgdGhyb3cgbmV3IEVycm9yKCdhbHJlYWR5IGZpbmFsaXplZCBvciBkZXN0cm95ZWQnKVxuXG4gICAgaWYgKHR5cGVvZiBidWZmZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgIGNhbGxiYWNrID0gYnVmZmVyXG4gICAgICBidWZmZXIgPSBudWxsXG4gICAgfVxuXG4gICAgaWYgKCFjYWxsYmFjaykgY2FsbGJhY2sgPSBub29wXG5cbiAgICBpZiAoIWhlYWRlci5zaXplIHx8IGhlYWRlci50eXBlID09PSAnc3ltbGluaycpIGhlYWRlci5zaXplID0gMFxuICAgIGlmICghaGVhZGVyLnR5cGUpIGhlYWRlci50eXBlID0gbW9kZVRvVHlwZShoZWFkZXIubW9kZSlcbiAgICBpZiAoIWhlYWRlci5tb2RlKSBoZWFkZXIubW9kZSA9IGhlYWRlci50eXBlID09PSAnZGlyZWN0b3J5JyA/IERNT0RFIDogRk1PREVcbiAgICBpZiAoIWhlYWRlci51aWQpIGhlYWRlci51aWQgPSAwXG4gICAgaWYgKCFoZWFkZXIuZ2lkKSBoZWFkZXIuZ2lkID0gMFxuICAgIGlmICghaGVhZGVyLm10aW1lKSBoZWFkZXIubXRpbWUgPSBuZXcgRGF0ZSgpXG5cbiAgICBpZiAodHlwZW9mIGJ1ZmZlciA9PT0gJ3N0cmluZycpIGJ1ZmZlciA9IGI0YS5mcm9tKGJ1ZmZlcilcblxuICAgIGNvbnN0IHNpbmsgPSBuZXcgU2luayh0aGlzLCBoZWFkZXIsIGNhbGxiYWNrKVxuXG4gICAgaWYgKGI0YS5pc0J1ZmZlcihidWZmZXIpKSB7XG4gICAgICBoZWFkZXIuc2l6ZSA9IGJ1ZmZlci5ieXRlTGVuZ3RoXG4gICAgICBzaW5rLndyaXRlKGJ1ZmZlcilcbiAgICAgIHNpbmsuZW5kKClcbiAgICAgIHJldHVybiBzaW5rXG4gICAgfVxuXG4gICAgaWYgKHNpbmsuX2lzVm9pZCkge1xuICAgICAgcmV0dXJuIHNpbmtcbiAgICB9XG5cbiAgICByZXR1cm4gc2lua1xuICB9XG5cbiAgZmluYWxpemUgKCkge1xuICAgIGlmICh0aGlzLl9zdHJlYW0gfHwgdGhpcy5fcGVuZGluZy5sZW5ndGggPiAwKSB7XG4gICAgICB0aGlzLl9maW5hbGl6aW5nID0gdHJ1ZVxuICAgICAgcmV0dXJuXG4gICAgfVxuXG4gICAgaWYgKHRoaXMuX2ZpbmFsaXplZCkgcmV0dXJuXG4gICAgdGhpcy5fZmluYWxpemVkID0gdHJ1ZVxuXG4gICAgdGhpcy5wdXNoKEVORF9PRl9UQVIpXG4gICAgdGhpcy5wdXNoKG51bGwpXG4gIH1cblxuICBfZG9uZSAoc3RyZWFtKSB7XG4gICAgaWYgKHN0cmVhbSAhPT0gdGhpcy5fc3RyZWFtKSByZXR1cm5cblxuICAgIHRoaXMuX3N0cmVhbSA9IG51bGxcblxuICAgIGlmICh0aGlzLl9maW5hbGl6aW5nKSB0aGlzLmZpbmFsaXplKClcbiAgICBpZiAodGhpcy5fcGVuZGluZy5sZW5ndGgpIHRoaXMuX3BlbmRpbmcuc2hpZnQoKS5fY29udGludWVPcGVuKClcbiAgfVxuXG4gIF9lbmNvZGUgKGhlYWRlcikge1xuICAgIGlmICghaGVhZGVyLnBheCkge1xuICAgICAgY29uc3QgYnVmID0gaGVhZGVycy5lbmNvZGUoaGVhZGVyKVxuICAgICAgaWYgKGJ1Zikge1xuICAgICAgICB0aGlzLnB1c2goYnVmKVxuICAgICAgICByZXR1cm5cbiAgICAgIH1cbiAgICB9XG4gICAgdGhpcy5fZW5jb2RlUGF4KGhlYWRlcilcbiAgfVxuXG4gIF9lbmNvZGVQYXggKGhlYWRlcikge1xuICAgIGNvbnN0IHBheEhlYWRlciA9IGhlYWRlcnMuZW5jb2RlUGF4KHtcbiAgICAgIG5hbWU6IGhlYWRlci5uYW1lLFxuICAgICAgbGlua25hbWU6IGhlYWRlci5saW5rbmFtZSxcbiAgICAgIHBheDogaGVhZGVyLnBheFxuICAgIH0pXG5cbiAgICBjb25zdCBuZXdIZWFkZXIgPSB7XG4gICAgICBuYW1lOiAnUGF4SGVhZGVyJyxcbiAgICAgIG1vZGU6IGhlYWRlci5tb2RlLFxuICAgICAgdWlkOiBoZWFkZXIudWlkLFxuICAgICAgZ2lkOiBoZWFkZXIuZ2lkLFxuICAgICAgc2l6ZTogcGF4SGVhZGVyLmJ5dGVMZW5ndGgsXG4gICAgICBtdGltZTogaGVhZGVyLm10aW1lLFxuICAgICAgdHlwZTogJ3BheC1oZWFkZXInLFxuICAgICAgbGlua25hbWU6IGhlYWRlci5saW5rbmFtZSAmJiAnUGF4SGVhZGVyJyxcbiAgICAgIHVuYW1lOiBoZWFkZXIudW5hbWUsXG4gICAgICBnbmFtZTogaGVhZGVyLmduYW1lLFxuICAgICAgZGV2bWFqb3I6IGhlYWRlci5kZXZtYWpvcixcbiAgICAgIGRldm1pbm9yOiBoZWFkZXIuZGV2bWlub3JcbiAgICB9XG5cbiAgICB0aGlzLnB1c2goaGVhZGVycy5lbmNvZGUobmV3SGVhZGVyKSlcbiAgICB0aGlzLnB1c2gocGF4SGVhZGVyKVxuICAgIG92ZXJmbG93KHRoaXMsIHBheEhlYWRlci5ieXRlTGVuZ3RoKVxuXG4gICAgbmV3SGVhZGVyLnNpemUgPSBoZWFkZXIuc2l6ZVxuICAgIG5ld0hlYWRlci50eXBlID0gaGVhZGVyLnR5cGVcbiAgICB0aGlzLnB1c2goaGVhZGVycy5lbmNvZGUobmV3SGVhZGVyKSlcbiAgfVxuXG4gIF9kb0RyYWluICgpIHtcbiAgICBjb25zdCBkcmFpbiA9IHRoaXMuX2RyYWluXG4gICAgdGhpcy5fZHJhaW4gPSBub29wXG4gICAgZHJhaW4oKVxuICB9XG5cbiAgX3ByZWRlc3Ryb3kgKCkge1xuICAgIGNvbnN0IGVyciA9IGdldFN0cmVhbUVycm9yKHRoaXMpXG5cbiAgICBpZiAodGhpcy5fc3RyZWFtKSB0aGlzLl9zdHJlYW0uZGVzdHJveShlcnIpXG5cbiAgICB3aGlsZSAodGhpcy5fcGVuZGluZy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHN0cmVhbSA9IHRoaXMuX3BlbmRpbmcuc2hpZnQoKVxuICAgICAgc3RyZWFtLmRlc3Ryb3koZXJyKVxuICAgICAgc3RyZWFtLl9jb250aW51ZU9wZW4oKVxuICAgIH1cblxuICAgIHRoaXMuX2RvRHJhaW4oKVxuICB9XG5cbiAgX3JlYWQgKGNiKSB7XG4gICAgdGhpcy5fZG9EcmFpbigpXG4gICAgY2IoKVxuICB9XG59XG5cbm1vZHVsZS5leHBvcnRzID0gZnVuY3Rpb24gcGFjayAob3B0cykge1xuICByZXR1cm4gbmV3IFBhY2sob3B0cylcbn1cblxuZnVuY3Rpb24gbW9kZVRvVHlwZSAobW9kZSkge1xuICBzd2l0Y2ggKG1vZGUgJiBjb25zdGFudHMuU19JRk1UKSB7XG4gICAgY2FzZSBjb25zdGFudHMuU19JRkJMSzogcmV0dXJuICdibG9jay1kZXZpY2UnXG4gICAgY2FzZSBjb25zdGFudHMuU19JRkNIUjogcmV0dXJuICdjaGFyYWN0ZXItZGV2aWNlJ1xuICAgIGNhc2UgY29uc3RhbnRzLlNfSUZESVI6IHJldHVybiAnZGlyZWN0b3J5J1xuICAgIGNhc2UgY29uc3RhbnRzLlNfSUZJRk86IHJldHVybiAnZmlmbydcbiAgICBjYXNlIGNvbnN0YW50cy5TX0lGTE5LOiByZXR1cm4gJ3N5bWxpbmsnXG4gIH1cblxuICByZXR1cm4gJ2ZpbGUnXG59XG5cbmZ1bmN0aW9uIG5vb3AgKCkge31cblxuZnVuY3Rpb24gb3ZlcmZsb3cgKHNlbGYsIHNpemUpIHtcbiAgc2l6ZSAmPSA1MTFcbiAgaWYgKHNpemUpIHNlbGYucHVzaChFTkRfT0ZfVEFSLnN1YmFycmF5KDAsIDUxMiAtIHNpemUpKVxufVxuXG5mdW5jdGlvbiBtYXBXcml0YWJsZSAoYnVmKSB7XG4gIHJldHVybiBiNGEuaXNCdWZmZXIoYnVmKSA/IGJ1ZiA6IGI0YS5mcm9tKGJ1Zilcbn1cbiIsICJleHBvcnRzLmV4dHJhY3QgPSByZXF1aXJlKCcuL2V4dHJhY3QnKVxuZXhwb3J0cy5wYWNrID0gcmVxdWlyZSgnLi9wYWNrJylcbiIsICJpbXBvcnQgdGFyIGZyb20gXCJ0YXItc3RyZWFtXCI7XG5pbXBvcnQgeyBoYW5kbGVJbWFnZSwgSW1hZ2VSZWYsIE1vbml0b3IgfSBmcm9tIFwiLi4vbGliL2ltZ3B1bGxcIjtcblxuLy9AdHMtaWdub3JlXG5pbXBvcnQgeyBmcm9tV2ViLCB0b1dlYiB9IGZyb20gXCJzdHJlYW14LXdlYnN0cmVhbVwiO1xuXG5jb25zdCBpdGVtczogTW9uaXRvcltdID0gW107XG5cbmV4cG9ydCB0eXBlIFF1ZXJ5U3RhdHVzUmVxdWVzdCA9IHsgdHlwZTogJ3F1ZXJ5X3N0YXR1cycgfVxuZXhwb3J0IHR5cGUgRHJ5UnVuUmVxdWVzdCA9IHsgdHlwZTogJ2RyeXJ1bicsIGltYWdlOiBzdHJpbmcgfVxuZXhwb3J0IHR5cGUgSXRlbVN0YXR1cyA9IHtcbiAgbmFtZTogc3RyaW5nLFxuICBpZDogc3RyaW5nLFxuICBlcnJvcjogc3RyaW5nLFxuICBhcmNoOiBzdHJpbmcsXG4gIGxheWVyczogUmVjb3JkPHN0cmluZywgW251bWJlciwgbnVtYmVyXSB8IG51bGw+XG5cbn1cbmV4cG9ydCB0eXBlIFN0YXR1c1Jlc3BvbnNlID0geyB0eXBlOiAnc3RhdHVzJywgaXRlbXM6IEl0ZW1TdGF0dXNbXSB9XG5leHBvcnQgdHlwZSBEcnlydW5SZXNwb25zZSA9IHsgdHlwZTogJ2RyeXJ1bicsIG9rOiBib29sZWFuLCBlcnJvcj86IHN0cmluZyB9XG5jaHJvbWUucnVudGltZS5vbk1lc3NhZ2UuYWRkTGlzdGVuZXIoKHJlcXVlc3QsIF9zZW5kZXIsIHNlbmRSZXNwb25zZSkgPT4ge1xuICBpZiAocmVxdWVzdC50eXBlID09PSAncXVlcnlfc3RhdHVzJykge1xuICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICB0eXBlOiAnc3RhdHVzJyxcbiAgICAgIGl0ZW1zOiBpdGVtcy5tYXAobSA9PiAoe1xuICAgICAgICBuYW1lOiBtLm5hbWUsXG4gICAgICAgIGlkOiBtLmlkLFxuICAgICAgICBhcmNoOiBtLmFyY2gsXG4gICAgICAgIGxheWVyczogbS5sYXllcnMsXG4gICAgICAgIGVycm9yOiBtLmVycm9yXG4gICAgICB9KSlcbiAgICB9KVxuICB9IGVsc2UgaWYgKHJlcXVlc3QudHlwZSA9PT0gJ2RyeXJ1bicpIHtcbiAgICAoYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcGFjayA9IHRhci5wYWNrKCk7XG4gICAgICAgIGF3YWl0IGhhbmRsZUltYWdlKEltYWdlUmVmLnBhcnNlKHJlcXVlc3QuaW1hZ2UpLCBwYWNrLCB7IGFyY2g6IHJlcXVlc3QuYXJjaCA/PyAnYW1kNjQnLCBkcnlydW46IHRydWUgfSlcbiAgICAgICAgc2VuZFJlc3BvbnNlKHsgdHlwZTogJ2RyeXJ1bicsIG9rOiB0cnVlIH0pXG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHNlbmRSZXNwb25zZSh7IHR5cGU6ICdkcnlydW4nLCBvazogZmFsc2UsIGVycm9yOiAoZSBhcyBFcnJvcikubWVzc2FnZSB9KVxuICAgICAgfVxuICAgIH0pKClcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBlbHNlIGlmIChyZXF1ZXN0LnR5cGUgPT09ICdjbGVhcicpIHtcbiAgICBpdGVtcy5zcGxpY2UoMClcbiAgfSBlbHNlIHtcbiAgICBzZW5kUmVzcG9uc2Uoe30pXG4gIH1cblxufSk7XG5cbnNlbGYuYWRkRXZlbnRMaXN0ZW5lcihcImZldGNoXCIsIChldmVudDogRmV0Y2hFdmVudCkgPT4ge1xuICBjb25zdCB1cmwgPSBuZXcgVVJMKGV2ZW50LnJlcXVlc3QudXJsKTtcbiAgaWYgKCF1cmwucGF0aG5hbWUuc3RhcnRzV2l0aChcIi9wdWxsL1wiKSkge1xuICAgIHJldHVybjtcbiAgICB1cmwucHJvdG9jb2wgPSAnaHR0cCdcbiAgICB1cmwuaG9zdCA9ICdsb2NhbGhvc3QnXG4gICAgdXJsLnBvcnQgPSAnNTE3MydcbiAgICBjb25zdCByZXNwUHJvbWlzZSA9IGZldGNoKHVybCwgeyBib2R5OiBldmVudC5yZXF1ZXN0LmJvZHksIGhlYWRlcnM6IGV2ZW50LnJlcXVlc3QuaGVhZGVycyB9KVxuICAgIHJldHVybiBldmVudC5yZXNwb25kV2l0aChyZXNwUHJvbWlzZSlcblxuICB9XG4gIGNvbnN0IG5hbWUgPSB1cmwucGF0aG5hbWUuc2xpY2UoNik7XG4gIGNvbnN0IHBhY2sgPSB0YXIucGFjaygpO1xuICBjb25zdCBhcmNoID0gdXJsLnNlYXJjaFBhcmFtcy5nZXQoJ2FyY2gnKSA/PyAnYW1kNjQnXG5cbiAgY29uc3QgbW9uaXRvciA9IG5ldyBNb25pdG9yKG5hbWUsIGFyY2gpO1xuICBpdGVtcy5wdXNoKG1vbml0b3IpO1xuXG4gIGxldCBfY29udHJvbGxlcjogVHJhbnNmb3JtU3RyZWFtRGVmYXVsdENvbnRyb2xsZXI7XG4gIGNvbnN0IHRyID0gbmV3IFRyYW5zZm9ybVN0cmVhbSh7XG4gICAgc3RhcnQoY29udHJvbGxlcikge1xuICAgICAgX2NvbnRyb2xsZXIgPSBjb250cm9sbGVyO1xuICAgIH0sXG4gIH0pO1xuICBoYW5kbGVJbWFnZShJbWFnZVJlZi5wYXJzZShuYW1lKSwgcGFjaywgeyBhcmNoLCBtb25pdG9yIH0pXG4gICAgLnRoZW4oKCkgPT4ge1xuICAgICAgcGFjay5maW5hbGl6ZSgpO1xuICAgIH0pXG4gICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICBjb25zb2xlLmVycm9yKGUpO1xuICAgICAgcGFjay5kZXN0cm95KGUpO1xuICAgICAgX2NvbnRyb2xsZXIuZXJyb3IoZSk7XG4gICAgICBtb25pdG9yLnNldEVycm9yKGU/Lm1lc3NhZ2UpO1xuICAgIH0pO1xuXG4gIHBhY2sucGlwZShmcm9tV2ViKHRyLndyaXRhYmxlLCB0cnVlKSk7XG5cbiAgbGV0IGZpbGVuYW1lID0gbmFtZS5yZXBsYWNlQWxsKC9bOkAvXS9nLCBcIl9cIik7XG4gIGlmIChhcmNoICE9PSAnYW1kNjQnKSB7XG4gICAgZmlsZW5hbWUgKz0gXCJfXCIgKyBhcmNoO1xuICB9XG4gIGV2ZW50LnJlc3BvbmRXaXRoKFxuICAgIG5ldyBSZXNwb25zZSh0ci5yZWFkYWJsZSwge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICBcIlRyYW5zZmVyLUVuY29kaW5nXCI6IFwiY2h1bmtlZFwiLFxuICAgICAgICBcIkNvbnRlbnQtVHlwZVwiOiBcImFwcGxpY2F0aW9uL3gtdGFyXCIsXG4gICAgICAgIFwiQ29udGVudC1EaXNwb3NpdGlvblwiOiBgYXR0YWNobWVudDsgZmlsZW5hbWU9XCIke2ZpbGVuYW1lfS50YXJgLFxuICAgICAgfSxcbiAgICB9KVxuICApO1xufSk7XG4iLCAiaW1wb3J0IHR5cGUge05vcm1hbGl6ZWRPcHRpb25zfSBmcm9tICcuLi90eXBlcy9vcHRpb25zLmpzJztcbmltcG9ydCB0eXBlIHtLeVJlcXVlc3R9IGZyb20gJy4uL3R5cGVzL3JlcXVlc3QuanMnO1xuaW1wb3J0IHR5cGUge0t5UmVzcG9uc2V9IGZyb20gJy4uL3R5cGVzL3Jlc3BvbnNlLmpzJztcblxuZXhwb3J0IGNsYXNzIEhUVFBFcnJvcjxUID0gdW5rbm93bj4gZXh0ZW5kcyBFcnJvciB7XG5cdHB1YmxpYyByZXNwb25zZTogS3lSZXNwb25zZTxUPjtcblx0cHVibGljIHJlcXVlc3Q6IEt5UmVxdWVzdDtcblx0cHVibGljIG9wdGlvbnM6IE5vcm1hbGl6ZWRPcHRpb25zO1xuXG5cdGNvbnN0cnVjdG9yKHJlc3BvbnNlOiBSZXNwb25zZSwgcmVxdWVzdDogUmVxdWVzdCwgb3B0aW9uczogTm9ybWFsaXplZE9wdGlvbnMpIHtcblx0XHRjb25zdCBjb2RlID0gKHJlc3BvbnNlLnN0YXR1cyB8fCByZXNwb25zZS5zdGF0dXMgPT09IDApID8gcmVzcG9uc2Uuc3RhdHVzIDogJyc7XG5cdFx0Y29uc3QgdGl0bGUgPSByZXNwb25zZS5zdGF0dXNUZXh0IHx8ICcnO1xuXHRcdGNvbnN0IHN0YXR1cyA9IGAke2NvZGV9ICR7dGl0bGV9YC50cmltKCk7XG5cdFx0Y29uc3QgcmVhc29uID0gc3RhdHVzID8gYHN0YXR1cyBjb2RlICR7c3RhdHVzfWAgOiAnYW4gdW5rbm93biBlcnJvcic7XG5cblx0XHRzdXBlcihgUmVxdWVzdCBmYWlsZWQgd2l0aCAke3JlYXNvbn06ICR7cmVxdWVzdC5tZXRob2R9ICR7cmVxdWVzdC51cmx9YCk7XG5cblx0XHR0aGlzLm5hbWUgPSAnSFRUUEVycm9yJztcblx0XHR0aGlzLnJlc3BvbnNlID0gcmVzcG9uc2U7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gcmVxdWVzdDtcblx0XHR0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuXHR9XG59XG4iLCAiaW1wb3J0IHR5cGUge0t5UmVxdWVzdH0gZnJvbSAnLi4vdHlwZXMvcmVxdWVzdC5qcyc7XG5cbmV4cG9ydCBjbGFzcyBUaW1lb3V0RXJyb3IgZXh0ZW5kcyBFcnJvciB7XG5cdHB1YmxpYyByZXF1ZXN0OiBLeVJlcXVlc3Q7XG5cblx0Y29uc3RydWN0b3IocmVxdWVzdDogUmVxdWVzdCkge1xuXHRcdHN1cGVyKGBSZXF1ZXN0IHRpbWVkIG91dDogJHtyZXF1ZXN0Lm1ldGhvZH0gJHtyZXF1ZXN0LnVybH1gKTtcblx0XHR0aGlzLm5hbWUgPSAnVGltZW91dEVycm9yJztcblx0XHR0aGlzLnJlcXVlc3QgPSByZXF1ZXN0O1xuXHR9XG59XG4iLCAiLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9iYW4tdHlwZXNcbmV4cG9ydCBjb25zdCBpc09iamVjdCA9ICh2YWx1ZTogdW5rbm93bik6IHZhbHVlIGlzIG9iamVjdCA9PiB2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnO1xuIiwgImltcG9ydCB0eXBlIHtLeUhlYWRlcnNJbml0LCBPcHRpb25zfSBmcm9tICcuLi90eXBlcy9vcHRpb25zLmpzJztcbmltcG9ydCB0eXBlIHtIb29rc30gZnJvbSAnLi4vdHlwZXMvaG9va3MuanMnO1xuaW1wb3J0IHtpc09iamVjdH0gZnJvbSAnLi9pcy5qcyc7XG5cbmV4cG9ydCBjb25zdCB2YWxpZGF0ZUFuZE1lcmdlID0gKC4uLnNvdXJjZXM6IEFycmF5PFBhcnRpYWw8T3B0aW9ucz4gfCB1bmRlZmluZWQ+KTogUGFydGlhbDxPcHRpb25zPiA9PiB7XG5cdGZvciAoY29uc3Qgc291cmNlIG9mIHNvdXJjZXMpIHtcblx0XHRpZiAoKCFpc09iamVjdChzb3VyY2UpIHx8IEFycmF5LmlzQXJyYXkoc291cmNlKSkgJiYgc291cmNlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSBgb3B0aW9uc2AgYXJndW1lbnQgbXVzdCBiZSBhbiBvYmplY3QnKTtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gZGVlcE1lcmdlKHt9LCAuLi5zb3VyY2VzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBtZXJnZUhlYWRlcnMgPSAoc291cmNlMTogS3lIZWFkZXJzSW5pdCA9IHt9LCBzb3VyY2UyOiBLeUhlYWRlcnNJbml0ID0ge30pID0+IHtcblx0Y29uc3QgcmVzdWx0ID0gbmV3IGdsb2JhbFRoaXMuSGVhZGVycyhzb3VyY2UxIGFzIFJlcXVlc3RJbml0WydoZWFkZXJzJ10pO1xuXHRjb25zdCBpc0hlYWRlcnNJbnN0YW5jZSA9IHNvdXJjZTIgaW5zdGFuY2VvZiBnbG9iYWxUaGlzLkhlYWRlcnM7XG5cdGNvbnN0IHNvdXJjZSA9IG5ldyBnbG9iYWxUaGlzLkhlYWRlcnMoc291cmNlMiBhcyBSZXF1ZXN0SW5pdFsnaGVhZGVycyddKTtcblxuXHRmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBzb3VyY2UuZW50cmllcygpKSB7XG5cdFx0aWYgKChpc0hlYWRlcnNJbnN0YW5jZSAmJiB2YWx1ZSA9PT0gJ3VuZGVmaW5lZCcpIHx8IHZhbHVlID09PSB1bmRlZmluZWQpIHtcblx0XHRcdHJlc3VsdC5kZWxldGUoa2V5KTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0cmVzdWx0LnNldChrZXksIHZhbHVlKTtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gcmVzdWx0O1xufTtcblxuZnVuY3Rpb24gbmV3SG9va1ZhbHVlPEsgZXh0ZW5kcyBrZXlvZiBIb29rcz4ob3JpZ2luYWw6IEhvb2tzLCBpbmNvbWluZzogSG9va3MsIHByb3BlcnR5OiBLKTogUmVxdWlyZWQ8SG9va3M+W0tdIHtcblx0cmV0dXJuIChPYmplY3QuaGFzT3duKGluY29taW5nLCBwcm9wZXJ0eSkgJiYgaW5jb21pbmdbcHJvcGVydHldID09PSB1bmRlZmluZWQpXG5cdFx0PyBbXVxuXHRcdDogZGVlcE1lcmdlPFJlcXVpcmVkPEhvb2tzPltLXT4ob3JpZ2luYWxbcHJvcGVydHldID8/IFtdLCBpbmNvbWluZ1twcm9wZXJ0eV0gPz8gW10pO1xufVxuXG5leHBvcnQgY29uc3QgbWVyZ2VIb29rcyA9IChvcmlnaW5hbDogSG9va3MgPSB7fSwgaW5jb21pbmc6IEhvb2tzID0ge30pOiBSZXF1aXJlZDxIb29rcz4gPT4gKFxuXHR7XG5cdFx0YmVmb3JlUmVxdWVzdDogbmV3SG9va1ZhbHVlKG9yaWdpbmFsLCBpbmNvbWluZywgJ2JlZm9yZVJlcXVlc3QnKSxcblx0XHRiZWZvcmVSZXRyeTogbmV3SG9va1ZhbHVlKG9yaWdpbmFsLCBpbmNvbWluZywgJ2JlZm9yZVJldHJ5JyksXG5cdFx0YWZ0ZXJSZXNwb25zZTogbmV3SG9va1ZhbHVlKG9yaWdpbmFsLCBpbmNvbWluZywgJ2FmdGVyUmVzcG9uc2UnKSxcblx0XHRiZWZvcmVFcnJvcjogbmV3SG9va1ZhbHVlKG9yaWdpbmFsLCBpbmNvbWluZywgJ2JlZm9yZUVycm9yJyksXG5cdH1cbik7XG5cbi8vIFRPRE86IE1ha2UgdGhpcyBzdHJvbmdseS10eXBlZCAobm8gYGFueWApLlxuZXhwb3J0IGNvbnN0IGRlZXBNZXJnZSA9IDxUPiguLi5zb3VyY2VzOiBBcnJheTxQYXJ0aWFsPFQ+IHwgdW5kZWZpbmVkPik6IFQgPT4ge1xuXHRsZXQgcmV0dXJuVmFsdWU6IGFueSA9IHt9O1xuXHRsZXQgaGVhZGVycyA9IHt9O1xuXHRsZXQgaG9va3MgPSB7fTtcblxuXHRmb3IgKGNvbnN0IHNvdXJjZSBvZiBzb3VyY2VzKSB7XG5cdFx0aWYgKEFycmF5LmlzQXJyYXkoc291cmNlKSkge1xuXHRcdFx0aWYgKCFBcnJheS5pc0FycmF5KHJldHVyblZhbHVlKSkge1xuXHRcdFx0XHRyZXR1cm5WYWx1ZSA9IFtdO1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm5WYWx1ZSA9IFsuLi5yZXR1cm5WYWx1ZSwgLi4uc291cmNlXTtcblx0XHR9IGVsc2UgaWYgKGlzT2JqZWN0KHNvdXJjZSkpIHtcblx0XHRcdGZvciAobGV0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhzb3VyY2UpKSB7XG5cdFx0XHRcdGlmIChpc09iamVjdCh2YWx1ZSkgJiYga2V5IGluIHJldHVyblZhbHVlKSB7XG5cdFx0XHRcdFx0dmFsdWUgPSBkZWVwTWVyZ2UocmV0dXJuVmFsdWVba2V5XSwgdmFsdWUpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0cmV0dXJuVmFsdWUgPSB7Li4ucmV0dXJuVmFsdWUsIFtrZXldOiB2YWx1ZX07XG5cdFx0XHR9XG5cblx0XHRcdGlmIChpc09iamVjdCgoc291cmNlIGFzIGFueSkuaG9va3MpKSB7XG5cdFx0XHRcdGhvb2tzID0gbWVyZ2VIb29rcyhob29rcywgKHNvdXJjZSBhcyBhbnkpLmhvb2tzKTtcblx0XHRcdFx0cmV0dXJuVmFsdWUuaG9va3MgPSBob29rcztcblx0XHRcdH1cblxuXHRcdFx0aWYgKGlzT2JqZWN0KChzb3VyY2UgYXMgYW55KS5oZWFkZXJzKSkge1xuXHRcdFx0XHRoZWFkZXJzID0gbWVyZ2VIZWFkZXJzKGhlYWRlcnMsIChzb3VyY2UgYXMgYW55KS5oZWFkZXJzKTtcblx0XHRcdFx0cmV0dXJuVmFsdWUuaGVhZGVycyA9IGhlYWRlcnM7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIHJldHVyblZhbHVlO1xufTtcbiIsICJpbXBvcnQgdHlwZSB7RXhwZWN0LCBFcXVhbH0gZnJvbSAnQHR5cGUtY2hhbGxlbmdlcy91dGlscyc7XG5pbXBvcnQge3R5cGUgSHR0cE1ldGhvZCwgdHlwZSBLeU9wdGlvbnNSZWdpc3RyeX0gZnJvbSAnLi4vdHlwZXMvb3B0aW9ucy5qcyc7XG5pbXBvcnQge3R5cGUgUmVxdWVzdEluaXRSZWdpc3RyeX0gZnJvbSAnLi4vdHlwZXMvcmVxdWVzdC5qcyc7XG5cbmV4cG9ydCBjb25zdCBzdXBwb3J0c1JlcXVlc3RTdHJlYW1zID0gKCgpID0+IHtcblx0bGV0IGR1cGxleEFjY2Vzc2VkID0gZmFsc2U7XG5cdGxldCBoYXNDb250ZW50VHlwZSA9IGZhbHNlO1xuXHRjb25zdCBzdXBwb3J0c1JlYWRhYmxlU3RyZWFtID0gdHlwZW9mIGdsb2JhbFRoaXMuUmVhZGFibGVTdHJlYW0gPT09ICdmdW5jdGlvbic7XG5cdGNvbnN0IHN1cHBvcnRzUmVxdWVzdCA9IHR5cGVvZiBnbG9iYWxUaGlzLlJlcXVlc3QgPT09ICdmdW5jdGlvbic7XG5cblx0aWYgKHN1cHBvcnRzUmVhZGFibGVTdHJlYW0gJiYgc3VwcG9ydHNSZXF1ZXN0KSB7XG5cdFx0dHJ5IHtcblx0XHRcdGhhc0NvbnRlbnRUeXBlID0gbmV3IGdsb2JhbFRoaXMuUmVxdWVzdCgnaHR0cHM6Ly9lbXB0eS5pbnZhbGlkJywge1xuXHRcdFx0XHRib2R5OiBuZXcgZ2xvYmFsVGhpcy5SZWFkYWJsZVN0cmVhbSgpLFxuXHRcdFx0XHRtZXRob2Q6ICdQT1NUJyxcblx0XHRcdFx0Ly8gQHRzLWV4cGVjdC1lcnJvciAtIFR5cGVzIGFyZSBvdXRkYXRlZC5cblx0XHRcdFx0Z2V0IGR1cGxleCgpIHtcblx0XHRcdFx0XHRkdXBsZXhBY2Nlc3NlZCA9IHRydWU7XG5cdFx0XHRcdFx0cmV0dXJuICdoYWxmJztcblx0XHRcdFx0fSxcblx0XHRcdH0pLmhlYWRlcnMuaGFzKCdDb250ZW50LVR5cGUnKTtcblx0XHR9IGNhdGNoIChlcnJvcikge1xuXHRcdFx0Ly8gUVFCcm93c2VyIG9uIGlPUyB0aHJvd3MgXCJ1bnN1cHBvcnRlZCBCb2R5SW5pdCB0eXBlXCIgZXJyb3IgKHNlZSBpc3N1ZSAjNTgxKVxuXHRcdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubWVzc2FnZSA9PT0gJ3Vuc3VwcG9ydGVkIEJvZHlJbml0IHR5cGUnKSB7XG5cdFx0XHRcdHJldHVybiBmYWxzZTtcblx0XHRcdH1cblxuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIGR1cGxleEFjY2Vzc2VkICYmICFoYXNDb250ZW50VHlwZTtcbn0pKCk7XG5cbmV4cG9ydCBjb25zdCBzdXBwb3J0c0Fib3J0Q29udHJvbGxlciA9IHR5cGVvZiBnbG9iYWxUaGlzLkFib3J0Q29udHJvbGxlciA9PT0gJ2Z1bmN0aW9uJztcbmV4cG9ydCBjb25zdCBzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtcyA9IHR5cGVvZiBnbG9iYWxUaGlzLlJlYWRhYmxlU3RyZWFtID09PSAnZnVuY3Rpb24nO1xuZXhwb3J0IGNvbnN0IHN1cHBvcnRzRm9ybURhdGEgPSB0eXBlb2YgZ2xvYmFsVGhpcy5Gb3JtRGF0YSA9PT0gJ2Z1bmN0aW9uJztcblxuZXhwb3J0IGNvbnN0IHJlcXVlc3RNZXRob2RzID0gWydnZXQnLCAncG9zdCcsICdwdXQnLCAncGF0Y2gnLCAnaGVhZCcsICdkZWxldGUnXSBhcyBjb25zdDtcblxuY29uc3QgdmFsaWRhdGUgPSA8VCBleHRlbmRzIEFycmF5PHRydWU+PigpID0+IHVuZGVmaW5lZCBhcyB1bmtub3duIGFzIFQ7XG52YWxpZGF0ZTxbXG5cdEV4cGVjdDxFcXVhbDx0eXBlb2YgcmVxdWVzdE1ldGhvZHNbbnVtYmVyXSwgSHR0cE1ldGhvZD4+LFxuXT4oKTtcblxuZXhwb3J0IGNvbnN0IHJlc3BvbnNlVHlwZXMgPSB7XG5cdGpzb246ICdhcHBsaWNhdGlvbi9qc29uJyxcblx0dGV4dDogJ3RleHQvKicsXG5cdGZvcm1EYXRhOiAnbXVsdGlwYXJ0L2Zvcm0tZGF0YScsXG5cdGFycmF5QnVmZmVyOiAnKi8qJyxcblx0YmxvYjogJyovKicsXG59IGFzIGNvbnN0O1xuXG4vLyBUaGUgbWF4aW11bSB2YWx1ZSBvZiBhIDMyYml0IGludCAoc2VlIGlzc3VlICMxMTcpXG5leHBvcnQgY29uc3QgbWF4U2FmZVRpbWVvdXQgPSAyXzE0N180ODNfNjQ3O1xuXG5leHBvcnQgY29uc3Qgc3RvcCA9IFN5bWJvbCgnc3RvcCcpO1xuXG5leHBvcnQgY29uc3Qga3lPcHRpb25LZXlzOiBLeU9wdGlvbnNSZWdpc3RyeSA9IHtcblx0anNvbjogdHJ1ZSxcblx0cGFyc2VKc29uOiB0cnVlLFxuXHRzdHJpbmdpZnlKc29uOiB0cnVlLFxuXHRzZWFyY2hQYXJhbXM6IHRydWUsXG5cdHByZWZpeFVybDogdHJ1ZSxcblx0cmV0cnk6IHRydWUsXG5cdHRpbWVvdXQ6IHRydWUsXG5cdGhvb2tzOiB0cnVlLFxuXHR0aHJvd0h0dHBFcnJvcnM6IHRydWUsXG5cdG9uRG93bmxvYWRQcm9ncmVzczogdHJ1ZSxcblx0ZmV0Y2g6IHRydWUsXG59O1xuXG5leHBvcnQgY29uc3QgcmVxdWVzdE9wdGlvbnNSZWdpc3RyeTogUmVxdWVzdEluaXRSZWdpc3RyeSA9IHtcblx0bWV0aG9kOiB0cnVlLFxuXHRoZWFkZXJzOiB0cnVlLFxuXHRib2R5OiB0cnVlLFxuXHRtb2RlOiB0cnVlLFxuXHRjcmVkZW50aWFsczogdHJ1ZSxcblx0Y2FjaGU6IHRydWUsXG5cdHJlZGlyZWN0OiB0cnVlLFxuXHRyZWZlcnJlcjogdHJ1ZSxcblx0cmVmZXJyZXJQb2xpY3k6IHRydWUsXG5cdGludGVncml0eTogdHJ1ZSxcblx0a2VlcGFsaXZlOiB0cnVlLFxuXHRzaWduYWw6IHRydWUsXG5cdHdpbmRvdzogdHJ1ZSxcblx0ZGlzcGF0Y2hlcjogdHJ1ZSxcblx0ZHVwbGV4OiB0cnVlLFxuXHRwcmlvcml0eTogdHJ1ZSxcbn07XG4iLCAiaW1wb3J0IHtyZXF1ZXN0TWV0aG9kc30gZnJvbSAnLi4vY29yZS9jb25zdGFudHMuanMnO1xuaW1wb3J0IHR5cGUge0h0dHBNZXRob2R9IGZyb20gJy4uL3R5cGVzL29wdGlvbnMuanMnO1xuaW1wb3J0IHR5cGUge1JldHJ5T3B0aW9uc30gZnJvbSAnLi4vdHlwZXMvcmV0cnkuanMnO1xuXG5leHBvcnQgY29uc3Qgbm9ybWFsaXplUmVxdWVzdE1ldGhvZCA9IChpbnB1dDogc3RyaW5nKTogc3RyaW5nID0+XG5cdHJlcXVlc3RNZXRob2RzLmluY2x1ZGVzKGlucHV0IGFzIEh0dHBNZXRob2QpID8gaW5wdXQudG9VcHBlckNhc2UoKSA6IGlucHV0O1xuXG5jb25zdCByZXRyeU1ldGhvZHMgPSBbJ2dldCcsICdwdXQnLCAnaGVhZCcsICdkZWxldGUnLCAnb3B0aW9ucycsICd0cmFjZSddO1xuXG5jb25zdCByZXRyeVN0YXR1c0NvZGVzID0gWzQwOCwgNDEzLCA0MjksIDUwMCwgNTAyLCA1MDMsIDUwNF07XG5cbmNvbnN0IHJldHJ5QWZ0ZXJTdGF0dXNDb2RlcyA9IFs0MTMsIDQyOSwgNTAzXTtcblxuY29uc3QgZGVmYXVsdFJldHJ5T3B0aW9uczogUmVxdWlyZWQ8UmV0cnlPcHRpb25zPiA9IHtcblx0bGltaXQ6IDIsXG5cdG1ldGhvZHM6IHJldHJ5TWV0aG9kcyxcblx0c3RhdHVzQ29kZXM6IHJldHJ5U3RhdHVzQ29kZXMsXG5cdGFmdGVyU3RhdHVzQ29kZXM6IHJldHJ5QWZ0ZXJTdGF0dXNDb2Rlcyxcblx0bWF4UmV0cnlBZnRlcjogTnVtYmVyLlBPU0lUSVZFX0lORklOSVRZLFxuXHRiYWNrb2ZmTGltaXQ6IE51bWJlci5QT1NJVElWRV9JTkZJTklUWSxcblx0ZGVsYXk6IGF0dGVtcHRDb3VudCA9PiAwLjMgKiAoMiAqKiAoYXR0ZW1wdENvdW50IC0gMSkpICogMTAwMCxcbn07XG5cbmV4cG9ydCBjb25zdCBub3JtYWxpemVSZXRyeU9wdGlvbnMgPSAocmV0cnk6IG51bWJlciB8IFJldHJ5T3B0aW9ucyA9IHt9KTogUmVxdWlyZWQ8UmV0cnlPcHRpb25zPiA9PiB7XG5cdGlmICh0eXBlb2YgcmV0cnkgPT09ICdudW1iZXInKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdC4uLmRlZmF1bHRSZXRyeU9wdGlvbnMsXG5cdFx0XHRsaW1pdDogcmV0cnksXG5cdFx0fTtcblx0fVxuXG5cdGlmIChyZXRyeS5tZXRob2RzICYmICFBcnJheS5pc0FycmF5KHJldHJ5Lm1ldGhvZHMpKSB7XG5cdFx0dGhyb3cgbmV3IEVycm9yKCdyZXRyeS5tZXRob2RzIG11c3QgYmUgYW4gYXJyYXknKTtcblx0fVxuXG5cdGlmIChyZXRyeS5zdGF0dXNDb2RlcyAmJiAhQXJyYXkuaXNBcnJheShyZXRyeS5zdGF0dXNDb2RlcykpIHtcblx0XHR0aHJvdyBuZXcgRXJyb3IoJ3JldHJ5LnN0YXR1c0NvZGVzIG11c3QgYmUgYW4gYXJyYXknKTtcblx0fVxuXG5cdHJldHVybiB7XG5cdFx0Li4uZGVmYXVsdFJldHJ5T3B0aW9ucyxcblx0XHQuLi5yZXRyeSxcblx0fTtcbn07XG4iLCAiaW1wb3J0IHtUaW1lb3V0RXJyb3J9IGZyb20gJy4uL2Vycm9ycy9UaW1lb3V0RXJyb3IuanMnO1xuXG5leHBvcnQgdHlwZSBUaW1lb3V0T3B0aW9ucyA9IHtcblx0dGltZW91dDogbnVtYmVyO1xuXHRmZXRjaDogdHlwZW9mIGZldGNoO1xufTtcblxuLy8gYFByb21pc2UucmFjZSgpYCB3b3JrYXJvdW5kICgjOTEpXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiB0aW1lb3V0KFxuXHRyZXF1ZXN0OiBSZXF1ZXN0LFxuXHRpbml0OiBSZXF1ZXN0SW5pdCxcblx0YWJvcnRDb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIgfCB1bmRlZmluZWQsXG5cdG9wdGlvbnM6IFRpbWVvdXRPcHRpb25zLFxuKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGNvbnN0IHRpbWVvdXRJZCA9IHNldFRpbWVvdXQoKCkgPT4ge1xuXHRcdFx0aWYgKGFib3J0Q29udHJvbGxlcikge1xuXHRcdFx0XHRhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdH1cblxuXHRcdFx0cmVqZWN0KG5ldyBUaW1lb3V0RXJyb3IocmVxdWVzdCkpO1xuXHRcdH0sIG9wdGlvbnMudGltZW91dCk7XG5cblx0XHR2b2lkIG9wdGlvbnNcblx0XHRcdC5mZXRjaChyZXF1ZXN0LCBpbml0KVxuXHRcdFx0LnRoZW4ocmVzb2x2ZSlcblx0XHRcdC5jYXRjaChyZWplY3QpXG5cdFx0XHQudGhlbigoKSA9PiB7XG5cdFx0XHRcdGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXHRcdFx0fSk7XG5cdH0pO1xufVxuIiwgIi8vIGh0dHBzOi8vZ2l0aHViLmNvbS9zaW5kcmVzb3JodXMvZGVsYXkvdHJlZS9hYjk4YWU4ZGZjYjM4ZTE1OTMyODZjOTRkOTM0ZTcwZDE0YTRlMTExXG5cbmltcG9ydCB7dHlwZSBJbnRlcm5hbE9wdGlvbnN9IGZyb20gJy4uL3R5cGVzL29wdGlvbnMuanMnO1xuXG5leHBvcnQgdHlwZSBEZWxheU9wdGlvbnMgPSB7XG5cdHNpZ25hbD86IEludGVybmFsT3B0aW9uc1snc2lnbmFsJ107XG59O1xuXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBkZWxheShcblx0bXM6IG51bWJlcixcblx0e3NpZ25hbH06IERlbGF5T3B0aW9ucyxcbik6IFByb21pc2U8dm9pZD4ge1xuXHRyZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdGlmIChzaWduYWwpIHtcblx0XHRcdHNpZ25hbC50aHJvd0lmQWJvcnRlZCgpO1xuXHRcdFx0c2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgYWJvcnRIYW5kbGVyLCB7b25jZTogdHJ1ZX0pO1xuXHRcdH1cblxuXHRcdGZ1bmN0aW9uIGFib3J0SGFuZGxlcigpIHtcblx0XHRcdGNsZWFyVGltZW91dCh0aW1lb3V0SWQpO1xuXHRcdFx0cmVqZWN0KHNpZ25hbCEucmVhc29uIGFzIEVycm9yKTtcblx0XHR9XG5cblx0XHRjb25zdCB0aW1lb3V0SWQgPSBzZXRUaW1lb3V0KCgpID0+IHtcblx0XHRcdHNpZ25hbD8ucmVtb3ZlRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydEhhbmRsZXIpO1xuXHRcdFx0cmVzb2x2ZSgpO1xuXHRcdH0sIG1zKTtcblx0fSk7XG59XG4iLCAiaW1wb3J0IHtreU9wdGlvbktleXMsIHJlcXVlc3RPcHRpb25zUmVnaXN0cnl9IGZyb20gJy4uL2NvcmUvY29uc3RhbnRzLmpzJztcblxuZXhwb3J0IGNvbnN0IGZpbmRVbmtub3duT3B0aW9ucyA9IChcblx0cmVxdWVzdDogUmVxdWVzdCxcblx0b3B0aW9uczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4sXG4pOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9PiB7XG5cdGNvbnN0IHVua25vd25PcHRpb25zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiA9IHt9O1xuXG5cdGZvciAoY29uc3Qga2V5IGluIG9wdGlvbnMpIHtcblx0XHRpZiAoIShrZXkgaW4gcmVxdWVzdE9wdGlvbnNSZWdpc3RyeSkgJiYgIShrZXkgaW4ga3lPcHRpb25LZXlzKSAmJiAhKGtleSBpbiByZXF1ZXN0KSkge1xuXHRcdFx0dW5rbm93bk9wdGlvbnNba2V5XSA9IG9wdGlvbnNba2V5XTtcblx0XHR9XG5cdH1cblxuXHRyZXR1cm4gdW5rbm93bk9wdGlvbnM7XG59O1xuIiwgImltcG9ydCB7SFRUUEVycm9yfSBmcm9tICcuLi9lcnJvcnMvSFRUUEVycm9yLmpzJztcbmltcG9ydCB7VGltZW91dEVycm9yfSBmcm9tICcuLi9lcnJvcnMvVGltZW91dEVycm9yLmpzJztcbmltcG9ydCB0eXBlIHtcblx0SW5wdXQsXG5cdEludGVybmFsT3B0aW9ucyxcblx0Tm9ybWFsaXplZE9wdGlvbnMsXG5cdE9wdGlvbnMsXG5cdFNlYXJjaFBhcmFtc0luaXQsXG59IGZyb20gJy4uL3R5cGVzL29wdGlvbnMuanMnO1xuaW1wb3J0IHt0eXBlIFJlc3BvbnNlUHJvbWlzZX0gZnJvbSAnLi4vdHlwZXMvUmVzcG9uc2VQcm9taXNlLmpzJztcbmltcG9ydCB7bWVyZ2VIZWFkZXJzLCBtZXJnZUhvb2tzfSBmcm9tICcuLi91dGlscy9tZXJnZS5qcyc7XG5pbXBvcnQge25vcm1hbGl6ZVJlcXVlc3RNZXRob2QsIG5vcm1hbGl6ZVJldHJ5T3B0aW9uc30gZnJvbSAnLi4vdXRpbHMvbm9ybWFsaXplLmpzJztcbmltcG9ydCB0aW1lb3V0LCB7dHlwZSBUaW1lb3V0T3B0aW9uc30gZnJvbSAnLi4vdXRpbHMvdGltZW91dC5qcyc7XG5pbXBvcnQgZGVsYXkgZnJvbSAnLi4vdXRpbHMvZGVsYXkuanMnO1xuaW1wb3J0IHt0eXBlIE9iamVjdEVudHJpZXN9IGZyb20gJy4uL3V0aWxzL3R5cGVzLmpzJztcbmltcG9ydCB7ZmluZFVua25vd25PcHRpb25zfSBmcm9tICcuLi91dGlscy9vcHRpb25zLmpzJztcbmltcG9ydCB7XG5cdG1heFNhZmVUaW1lb3V0LFxuXHRyZXNwb25zZVR5cGVzLFxuXHRzdG9wLFxuXHRzdXBwb3J0c0Fib3J0Q29udHJvbGxlcixcblx0c3VwcG9ydHNGb3JtRGF0YSxcblx0c3VwcG9ydHNSZXNwb25zZVN0cmVhbXMsXG5cdHN1cHBvcnRzUmVxdWVzdFN0cmVhbXMsXG59IGZyb20gJy4vY29uc3RhbnRzLmpzJztcblxuZXhwb3J0IGNsYXNzIEt5IHtcblx0c3RhdGljIGNyZWF0ZShpbnB1dDogSW5wdXQsIG9wdGlvbnM6IE9wdGlvbnMpOiBSZXNwb25zZVByb21pc2Uge1xuXHRcdGNvbnN0IGt5ID0gbmV3IEt5KGlucHV0LCBvcHRpb25zKTtcblxuXHRcdGNvbnN0IGZ1bmN0aW9uXyA9IGFzeW5jICgpOiBQcm9taXNlPFJlc3BvbnNlPiA9PiB7XG5cdFx0XHRpZiAodHlwZW9mIGt5Ll9vcHRpb25zLnRpbWVvdXQgPT09ICdudW1iZXInICYmIGt5Ll9vcHRpb25zLnRpbWVvdXQgPiBtYXhTYWZlVGltZW91dCkge1xuXHRcdFx0XHR0aHJvdyBuZXcgUmFuZ2VFcnJvcihgVGhlIFxcYHRpbWVvdXRcXGAgb3B0aW9uIGNhbm5vdCBiZSBncmVhdGVyIHRoYW4gJHttYXhTYWZlVGltZW91dH1gKTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gRGVsYXkgdGhlIGZldGNoIHNvIHRoYXQgYm9keSBtZXRob2Qgc2hvcnRjdXRzIGNhbiBzZXQgdGhlIEFjY2VwdCBoZWFkZXJcblx0XHRcdGF3YWl0IFByb21pc2UucmVzb2x2ZSgpO1xuXHRcdFx0bGV0IHJlc3BvbnNlID0gYXdhaXQga3kuX2ZldGNoKCk7XG5cblx0XHRcdGZvciAoY29uc3QgaG9vayBvZiBreS5fb3B0aW9ucy5ob29rcy5hZnRlclJlc3BvbnNlKSB7XG5cdFx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1hd2FpdC1pbi1sb29wXG5cdFx0XHRcdGNvbnN0IG1vZGlmaWVkUmVzcG9uc2UgPSBhd2FpdCBob29rKFxuXHRcdFx0XHRcdGt5LnJlcXVlc3QsXG5cdFx0XHRcdFx0a3kuX29wdGlvbnMgYXMgTm9ybWFsaXplZE9wdGlvbnMsXG5cdFx0XHRcdFx0a3kuX2RlY29yYXRlUmVzcG9uc2UocmVzcG9uc2UuY2xvbmUoKSksXG5cdFx0XHRcdCk7XG5cblx0XHRcdFx0aWYgKG1vZGlmaWVkUmVzcG9uc2UgaW5zdGFuY2VvZiBnbG9iYWxUaGlzLlJlc3BvbnNlKSB7XG5cdFx0XHRcdFx0cmVzcG9uc2UgPSBtb2RpZmllZFJlc3BvbnNlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdGt5Ll9kZWNvcmF0ZVJlc3BvbnNlKHJlc3BvbnNlKTtcblxuXHRcdFx0aWYgKCFyZXNwb25zZS5vayAmJiBreS5fb3B0aW9ucy50aHJvd0h0dHBFcnJvcnMpIHtcblx0XHRcdFx0bGV0IGVycm9yID0gbmV3IEhUVFBFcnJvcihyZXNwb25zZSwga3kucmVxdWVzdCwga3kuX29wdGlvbnMgYXMgTm9ybWFsaXplZE9wdGlvbnMpO1xuXG5cdFx0XHRcdGZvciAoY29uc3QgaG9vayBvZiBreS5fb3B0aW9ucy5ob29rcy5iZWZvcmVFcnJvcikge1xuXHRcdFx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1hd2FpdC1pbi1sb29wXG5cdFx0XHRcdFx0ZXJyb3IgPSBhd2FpdCBob29rKGVycm9yKTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0fVxuXG5cdFx0XHQvLyBJZiBgb25Eb3dubG9hZFByb2dyZXNzYCBpcyBwYXNzZWQsIGl0IHVzZXMgdGhlIHN0cmVhbSBBUEkgaW50ZXJuYWxseVxuXHRcdFx0LyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cblx0XHRcdGlmIChreS5fb3B0aW9ucy5vbkRvd25sb2FkUHJvZ3Jlc3MpIHtcblx0XHRcdFx0aWYgKHR5cGVvZiBreS5fb3B0aW9ucy5vbkRvd25sb2FkUHJvZ3Jlc3MgIT09ICdmdW5jdGlvbicpIHtcblx0XHRcdFx0XHR0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGUgYG9uRG93bmxvYWRQcm9ncmVzc2Agb3B0aW9uIG11c3QgYmUgYSBmdW5jdGlvbicpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0aWYgKCFzdXBwb3J0c1Jlc3BvbnNlU3RyZWFtcykge1xuXHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcignU3RyZWFtcyBhcmUgbm90IHN1cHBvcnRlZCBpbiB5b3VyIGVudmlyb25tZW50LiBgUmVhZGFibGVTdHJlYW1gIGlzIG1pc3NpbmcuJyk7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZXR1cm4ga3kuX3N0cmVhbShyZXNwb25zZS5jbG9uZSgpLCBreS5fb3B0aW9ucy5vbkRvd25sb2FkUHJvZ3Jlc3MpO1xuXHRcdFx0fVxuXG5cdFx0XHRyZXR1cm4gcmVzcG9uc2U7XG5cdFx0fTtcblxuXHRcdGNvbnN0IGlzUmV0cmlhYmxlTWV0aG9kID0ga3kuX29wdGlvbnMucmV0cnkubWV0aG9kcy5pbmNsdWRlcyhreS5yZXF1ZXN0Lm1ldGhvZC50b0xvd2VyQ2FzZSgpKTtcblx0XHRjb25zdCByZXN1bHQgPSAoaXNSZXRyaWFibGVNZXRob2QgPyBreS5fcmV0cnkoZnVuY3Rpb25fKSA6IGZ1bmN0aW9uXygpKSBhcyBSZXNwb25zZVByb21pc2U7XG5cblx0XHRmb3IgKGNvbnN0IFt0eXBlLCBtaW1lVHlwZV0gb2YgT2JqZWN0LmVudHJpZXMocmVzcG9uc2VUeXBlcykgYXMgT2JqZWN0RW50cmllczx0eXBlb2YgcmVzcG9uc2VUeXBlcz4pIHtcblx0XHRcdHJlc3VsdFt0eXBlXSA9IGFzeW5jICgpID0+IHtcblx0XHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9wcmVmZXItbnVsbGlzaC1jb2FsZXNjaW5nXG5cdFx0XHRcdGt5LnJlcXVlc3QuaGVhZGVycy5zZXQoJ2FjY2VwdCcsIGt5LnJlcXVlc3QuaGVhZGVycy5nZXQoJ2FjY2VwdCcpIHx8IG1pbWVUeXBlKTtcblxuXHRcdFx0XHRjb25zdCByZXNwb25zZSA9IGF3YWl0IHJlc3VsdDtcblxuXHRcdFx0XHRpZiAodHlwZSA9PT0gJ2pzb24nKSB7XG5cdFx0XHRcdFx0aWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gMjA0KSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gJyc7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0Y29uc3QgYXJyYXlCdWZmZXIgPSBhd2FpdCByZXNwb25zZS5jbG9uZSgpLmFycmF5QnVmZmVyKCk7XG5cdFx0XHRcdFx0Y29uc3QgcmVzcG9uc2VTaXplID0gYXJyYXlCdWZmZXIuYnl0ZUxlbmd0aDtcblx0XHRcdFx0XHRpZiAocmVzcG9uc2VTaXplID09PSAwKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gJyc7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0aWYgKG9wdGlvbnMucGFyc2VKc29uKSB7XG5cdFx0XHRcdFx0XHRyZXR1cm4gb3B0aW9ucy5wYXJzZUpzb24oYXdhaXQgcmVzcG9uc2UudGV4dCgpKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRyZXR1cm4gcmVzcG9uc2VbdHlwZV0oKTtcblx0XHRcdH07XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHJlc3VsdDtcblx0fVxuXG5cdHB1YmxpYyByZXF1ZXN0OiBSZXF1ZXN0O1xuXHRwcm90ZWN0ZWQgYWJvcnRDb250cm9sbGVyPzogQWJvcnRDb250cm9sbGVyO1xuXHRwcm90ZWN0ZWQgX3JldHJ5Q291bnQgPSAwO1xuXHRwcm90ZWN0ZWQgX2lucHV0OiBJbnB1dDtcblx0cHJvdGVjdGVkIF9vcHRpb25zOiBJbnRlcm5hbE9wdGlvbnM7XG5cblx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNvbXBsZXhpdHlcblx0Y29uc3RydWN0b3IoaW5wdXQ6IElucHV0LCBvcHRpb25zOiBPcHRpb25zID0ge30pIHtcblx0XHR0aGlzLl9pbnB1dCA9IGlucHV0O1xuXG5cdFx0dGhpcy5fb3B0aW9ucyA9IHtcblx0XHRcdC4uLm9wdGlvbnMsXG5cdFx0XHRoZWFkZXJzOiBtZXJnZUhlYWRlcnMoKHRoaXMuX2lucHV0IGFzIFJlcXVlc3QpLmhlYWRlcnMsIG9wdGlvbnMuaGVhZGVycyksXG5cdFx0XHRob29rczogbWVyZ2VIb29rcyhcblx0XHRcdFx0e1xuXHRcdFx0XHRcdGJlZm9yZVJlcXVlc3Q6IFtdLFxuXHRcdFx0XHRcdGJlZm9yZVJldHJ5OiBbXSxcblx0XHRcdFx0XHRiZWZvcmVFcnJvcjogW10sXG5cdFx0XHRcdFx0YWZ0ZXJSZXNwb25zZTogW10sXG5cdFx0XHRcdH0sXG5cdFx0XHRcdG9wdGlvbnMuaG9va3MsXG5cdFx0XHQpLFxuXHRcdFx0bWV0aG9kOiBub3JtYWxpemVSZXF1ZXN0TWV0aG9kKG9wdGlvbnMubWV0aG9kID8/ICh0aGlzLl9pbnB1dCBhcyBSZXF1ZXN0KS5tZXRob2QpLFxuXHRcdFx0Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9wcmVmZXItbnVsbGlzaC1jb2FsZXNjaW5nXG5cdFx0XHRwcmVmaXhVcmw6IFN0cmluZyhvcHRpb25zLnByZWZpeFVybCB8fCAnJyksXG5cdFx0XHRyZXRyeTogbm9ybWFsaXplUmV0cnlPcHRpb25zKG9wdGlvbnMucmV0cnkpLFxuXHRcdFx0dGhyb3dIdHRwRXJyb3JzOiBvcHRpb25zLnRocm93SHR0cEVycm9ycyAhPT0gZmFsc2UsXG5cdFx0XHR0aW1lb3V0OiBvcHRpb25zLnRpbWVvdXQgPz8gMTBfMDAwLFxuXHRcdFx0ZmV0Y2g6IG9wdGlvbnMuZmV0Y2ggPz8gZ2xvYmFsVGhpcy5mZXRjaC5iaW5kKGdsb2JhbFRoaXMpLFxuXHRcdH07XG5cblx0XHRpZiAodHlwZW9mIHRoaXMuX2lucHV0ICE9PSAnc3RyaW5nJyAmJiAhKHRoaXMuX2lucHV0IGluc3RhbmNlb2YgVVJMIHx8IHRoaXMuX2lucHV0IGluc3RhbmNlb2YgZ2xvYmFsVGhpcy5SZXF1ZXN0KSkge1xuXHRcdFx0dGhyb3cgbmV3IFR5cGVFcnJvcignYGlucHV0YCBtdXN0IGJlIGEgc3RyaW5nLCBVUkwsIG9yIFJlcXVlc3QnKTtcblx0XHR9XG5cblx0XHRpZiAodGhpcy5fb3B0aW9ucy5wcmVmaXhVcmwgJiYgdHlwZW9mIHRoaXMuX2lucHV0ID09PSAnc3RyaW5nJykge1xuXHRcdFx0aWYgKHRoaXMuX2lucHV0LnN0YXJ0c1dpdGgoJy8nKSkge1xuXHRcdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ2BpbnB1dGAgbXVzdCBub3QgYmVnaW4gd2l0aCBhIHNsYXNoIHdoZW4gdXNpbmcgYHByZWZpeFVybGAnKTtcblx0XHRcdH1cblxuXHRcdFx0aWYgKCF0aGlzLl9vcHRpb25zLnByZWZpeFVybC5lbmRzV2l0aCgnLycpKSB7XG5cdFx0XHRcdHRoaXMuX29wdGlvbnMucHJlZml4VXJsICs9ICcvJztcblx0XHRcdH1cblxuXHRcdFx0dGhpcy5faW5wdXQgPSB0aGlzLl9vcHRpb25zLnByZWZpeFVybCArIHRoaXMuX2lucHV0O1xuXHRcdH1cblxuXHRcdGlmIChzdXBwb3J0c0Fib3J0Q29udHJvbGxlcikge1xuXHRcdFx0dGhpcy5hYm9ydENvbnRyb2xsZXIgPSBuZXcgZ2xvYmFsVGhpcy5BYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdGNvbnN0IG9yaWdpbmFsU2lnbmFsID0gdGhpcy5fb3B0aW9ucy5zaWduYWwgPz8gKHRoaXMuX2lucHV0IGFzIFJlcXVlc3QpLnNpZ25hbDtcblx0XHRcdGlmIChvcmlnaW5hbFNpZ25hbD8uYWJvcnRlZCkge1xuXHRcdFx0XHR0aGlzLmFib3J0Q29udHJvbGxlci5hYm9ydChvcmlnaW5hbFNpZ25hbD8ucmVhc29uKTtcblx0XHRcdH1cblxuXHRcdFx0b3JpZ2luYWxTaWduYWw/LmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4ge1xuXHRcdFx0XHR0aGlzLmFib3J0Q29udHJvbGxlciEuYWJvcnQob3JpZ2luYWxTaWduYWwucmVhc29uKTtcblx0XHRcdH0pO1xuXHRcdFx0dGhpcy5fb3B0aW9ucy5zaWduYWwgPSB0aGlzLmFib3J0Q29udHJvbGxlci5zaWduYWw7XG5cdFx0fVxuXG5cdFx0aWYgKHN1cHBvcnRzUmVxdWVzdFN0cmVhbXMpIHtcblx0XHRcdC8vIEB0cy1leHBlY3QtZXJyb3IgLSBUeXBlcyBhcmUgb3V0ZGF0ZWQuXG5cdFx0XHR0aGlzLl9vcHRpb25zLmR1cGxleCA9ICdoYWxmJztcblx0XHR9XG5cblx0XHRpZiAodGhpcy5fb3B0aW9ucy5qc29uICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdHRoaXMuX29wdGlvbnMuYm9keSA9IHRoaXMuX29wdGlvbnMuc3RyaW5naWZ5SnNvbj8uKHRoaXMuX29wdGlvbnMuanNvbikgPz8gSlNPTi5zdHJpbmdpZnkodGhpcy5fb3B0aW9ucy5qc29uKTtcblx0XHRcdHRoaXMuX29wdGlvbnMuaGVhZGVycy5zZXQoJ2NvbnRlbnQtdHlwZScsIHRoaXMuX29wdGlvbnMuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpID8/ICdhcHBsaWNhdGlvbi9qc29uJyk7XG5cdFx0fVxuXG5cdFx0dGhpcy5yZXF1ZXN0ID0gbmV3IGdsb2JhbFRoaXMuUmVxdWVzdCh0aGlzLl9pbnB1dCwgdGhpcy5fb3B0aW9ucyk7XG5cblx0XHRpZiAodGhpcy5fb3B0aW9ucy5zZWFyY2hQYXJhbXMpIHtcblx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSB1bmljb3JuL3ByZXZlbnQtYWJicmV2aWF0aW9uc1xuXHRcdFx0Y29uc3QgdGV4dFNlYXJjaFBhcmFtcyA9IHR5cGVvZiB0aGlzLl9vcHRpb25zLnNlYXJjaFBhcmFtcyA9PT0gJ3N0cmluZydcblx0XHRcdFx0PyB0aGlzLl9vcHRpb25zLnNlYXJjaFBhcmFtcy5yZXBsYWNlKC9eXFw/LywgJycpXG5cdFx0XHRcdDogbmV3IFVSTFNlYXJjaFBhcmFtcyh0aGlzLl9vcHRpb25zLnNlYXJjaFBhcmFtcyBhcyB1bmtub3duIGFzIFNlYXJjaFBhcmFtc0luaXQpLnRvU3RyaW5nKCk7XG5cdFx0XHQvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgdW5pY29ybi9wcmV2ZW50LWFiYnJldmlhdGlvbnNcblx0XHRcdGNvbnN0IHNlYXJjaFBhcmFtcyA9ICc/JyArIHRleHRTZWFyY2hQYXJhbXM7XG5cdFx0XHRjb25zdCB1cmwgPSB0aGlzLnJlcXVlc3QudXJsLnJlcGxhY2UoLyg/OlxcPy4qPyk/KD89I3wkKS8sIHNlYXJjaFBhcmFtcyk7XG5cblx0XHRcdC8vIFRvIHByb3ZpZGUgY29ycmVjdCBmb3JtIGJvdW5kYXJ5LCBDb250ZW50LVR5cGUgaGVhZGVyIHNob3VsZCBiZSBkZWxldGVkIGVhY2ggdGltZSB3aGVuIG5ldyBSZXF1ZXN0IGluc3RhbnRpYXRlZCBmcm9tIGFub3RoZXIgb25lXG5cdFx0XHRpZiAoXG5cdFx0XHRcdCgoc3VwcG9ydHNGb3JtRGF0YSAmJiB0aGlzLl9vcHRpb25zLmJvZHkgaW5zdGFuY2VvZiBnbG9iYWxUaGlzLkZvcm1EYXRhKVxuXHRcdFx0XHRcdHx8IHRoaXMuX29wdGlvbnMuYm9keSBpbnN0YW5jZW9mIFVSTFNlYXJjaFBhcmFtcykgJiYgISh0aGlzLl9vcHRpb25zLmhlYWRlcnMgJiYgKHRoaXMuX29wdGlvbnMuaGVhZGVycyBhcyBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+KVsnY29udGVudC10eXBlJ10pXG5cdFx0XHQpIHtcblx0XHRcdFx0dGhpcy5yZXF1ZXN0LmhlYWRlcnMuZGVsZXRlKCdjb250ZW50LXR5cGUnKTtcblx0XHRcdH1cblxuXHRcdFx0Ly8gVGhlIHNwcmVhZCBvZiBgdGhpcy5yZXF1ZXN0YCBpcyByZXF1aXJlZCBhcyBvdGhlcndpc2UgaXQgbWlzc2VzIHRoZSBgZHVwbGV4YCBvcHRpb24gZm9yIHNvbWUgcmVhc29uIGFuZCB0aHJvd3MuXG5cdFx0XHR0aGlzLnJlcXVlc3QgPSBuZXcgZ2xvYmFsVGhpcy5SZXF1ZXN0KG5ldyBnbG9iYWxUaGlzLlJlcXVlc3QodXJsLCB7Li4udGhpcy5yZXF1ZXN0fSksIHRoaXMuX29wdGlvbnMgYXMgUmVxdWVzdEluaXQpO1xuXHRcdH1cblx0fVxuXG5cdHByb3RlY3RlZCBfY2FsY3VsYXRlUmV0cnlEZWxheShlcnJvcjogdW5rbm93bikge1xuXHRcdHRoaXMuX3JldHJ5Q291bnQrKztcblxuXHRcdGlmICh0aGlzLl9yZXRyeUNvdW50ID4gdGhpcy5fb3B0aW9ucy5yZXRyeS5saW1pdCB8fCBlcnJvciBpbnN0YW5jZW9mIFRpbWVvdXRFcnJvcikge1xuXHRcdFx0dGhyb3cgZXJyb3I7XG5cdFx0fVxuXG5cdFx0aWYgKGVycm9yIGluc3RhbmNlb2YgSFRUUEVycm9yKSB7XG5cdFx0XHRpZiAoIXRoaXMuX29wdGlvbnMucmV0cnkuc3RhdHVzQ29kZXMuaW5jbHVkZXMoZXJyb3IucmVzcG9uc2Uuc3RhdHVzKSkge1xuXHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdH1cblxuXHRcdFx0Y29uc3QgcmV0cnlBZnRlciA9IGVycm9yLnJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdSZXRyeS1BZnRlcicpXG5cdFx0XHRcdD8/IGVycm9yLnJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdSYXRlTGltaXQtUmVzZXQnKVxuXHRcdFx0XHQ/PyBlcnJvci5yZXNwb25zZS5oZWFkZXJzLmdldCgnWC1SYXRlTGltaXQtUmVzZXQnKSAvLyBHaXRIdWJcblx0XHRcdFx0Pz8gZXJyb3IucmVzcG9uc2UuaGVhZGVycy5nZXQoJ1gtUmF0ZS1MaW1pdC1SZXNldCcpOyAvLyBUd2l0dGVyXG5cdFx0XHRpZiAocmV0cnlBZnRlciAmJiB0aGlzLl9vcHRpb25zLnJldHJ5LmFmdGVyU3RhdHVzQ29kZXMuaW5jbHVkZXMoZXJyb3IucmVzcG9uc2Uuc3RhdHVzKSkge1xuXHRcdFx0XHRsZXQgYWZ0ZXIgPSBOdW1iZXIocmV0cnlBZnRlcikgKiAxMDAwO1xuXHRcdFx0XHRpZiAoTnVtYmVyLmlzTmFOKGFmdGVyKSkge1xuXHRcdFx0XHRcdGFmdGVyID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVyKSAtIERhdGUubm93KCk7XG5cdFx0XHRcdH0gZWxzZSBpZiAoYWZ0ZXIgPj0gRGF0ZS5wYXJzZSgnMjAyNC0wMS0wMScpKSB7XG5cdFx0XHRcdFx0Ly8gQSBsYXJnZSBudW1iZXIgaXMgdHJlYXRlZCBhcyBhIHRpbWVzdGFtcCAoZml4ZWQgdGhyZXNob2xkIHByb3RlY3RzIGFnYWluc3QgY2xvY2sgc2tldylcblx0XHRcdFx0XHRhZnRlciAtPSBEYXRlLm5vdygpO1xuXHRcdFx0XHR9XG5cblx0XHRcdFx0Y29uc3QgbWF4ID0gdGhpcy5fb3B0aW9ucy5yZXRyeS5tYXhSZXRyeUFmdGVyID8/IGFmdGVyO1xuXHRcdFx0XHRyZXR1cm4gYWZ0ZXIgPCBtYXggPyBhZnRlciA6IG1heDtcblx0XHRcdH1cblxuXHRcdFx0aWYgKGVycm9yLnJlc3BvbnNlLnN0YXR1cyA9PT0gNDEzKSB7XG5cdFx0XHRcdHRocm93IGVycm9yO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGNvbnN0IHJldHJ5RGVsYXkgPSB0aGlzLl9vcHRpb25zLnJldHJ5LmRlbGF5KHRoaXMuX3JldHJ5Q291bnQpO1xuXHRcdHJldHVybiBNYXRoLm1pbih0aGlzLl9vcHRpb25zLnJldHJ5LmJhY2tvZmZMaW1pdCwgcmV0cnlEZWxheSk7XG5cdH1cblxuXHRwcm90ZWN0ZWQgX2RlY29yYXRlUmVzcG9uc2UocmVzcG9uc2U6IFJlc3BvbnNlKTogUmVzcG9uc2Uge1xuXHRcdGlmICh0aGlzLl9vcHRpb25zLnBhcnNlSnNvbikge1xuXHRcdFx0cmVzcG9uc2UuanNvbiA9IGFzeW5jICgpID0+IHRoaXMuX29wdGlvbnMucGFyc2VKc29uIShhd2FpdCByZXNwb25zZS50ZXh0KCkpO1xuXHRcdH1cblxuXHRcdHJldHVybiByZXNwb25zZTtcblx0fVxuXG5cdHByb3RlY3RlZCBhc3luYyBfcmV0cnk8VCBleHRlbmRzICguLi5hcmd1bWVudHNfOiBhbnkpID0+IFByb21pc2U8YW55Pj4oZnVuY3Rpb25fOiBUKTogUHJvbWlzZTxSZXR1cm5UeXBlPFQ+IHwgdm9pZD4ge1xuXHRcdHRyeSB7XG5cdFx0XHRyZXR1cm4gYXdhaXQgZnVuY3Rpb25fKCk7XG5cdFx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRcdGNvbnN0IG1zID0gTWF0aC5taW4odGhpcy5fY2FsY3VsYXRlUmV0cnlEZWxheShlcnJvciksIG1heFNhZmVUaW1lb3V0KTtcblx0XHRcdGlmICh0aGlzLl9yZXRyeUNvdW50IDwgMSkge1xuXHRcdFx0XHR0aHJvdyBlcnJvcjtcblx0XHRcdH1cblxuXHRcdFx0YXdhaXQgZGVsYXkobXMsIHtzaWduYWw6IHRoaXMuX29wdGlvbnMuc2lnbmFsfSk7XG5cblx0XHRcdGZvciAoY29uc3QgaG9vayBvZiB0aGlzLl9vcHRpb25zLmhvb2tzLmJlZm9yZVJldHJ5KSB7XG5cdFx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1hd2FpdC1pbi1sb29wXG5cdFx0XHRcdGNvbnN0IGhvb2tSZXN1bHQgPSBhd2FpdCBob29rKHtcblx0XHRcdFx0XHRyZXF1ZXN0OiB0aGlzLnJlcXVlc3QsXG5cdFx0XHRcdFx0b3B0aW9uczogKHRoaXMuX29wdGlvbnMgYXMgdW5rbm93bikgYXMgTm9ybWFsaXplZE9wdGlvbnMsXG5cdFx0XHRcdFx0ZXJyb3I6IGVycm9yIGFzIEVycm9yLFxuXHRcdFx0XHRcdHJldHJ5Q291bnQ6IHRoaXMuX3JldHJ5Q291bnQsXG5cdFx0XHRcdH0pO1xuXG5cdFx0XHRcdC8vIElmIGBzdG9wYCBpcyByZXR1cm5lZCBmcm9tIHRoZSBob29rLCB0aGUgcmV0cnkgcHJvY2VzcyBpcyBzdG9wcGVkXG5cdFx0XHRcdGlmIChob29rUmVzdWx0ID09PSBzdG9wKSB7XG5cdFx0XHRcdFx0cmV0dXJuO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiB0aGlzLl9yZXRyeShmdW5jdGlvbl8pO1xuXHRcdH1cblx0fVxuXG5cdHByb3RlY3RlZCBhc3luYyBfZmV0Y2goKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuXHRcdGZvciAoY29uc3QgaG9vayBvZiB0aGlzLl9vcHRpb25zLmhvb2tzLmJlZm9yZVJlcXVlc3QpIHtcblx0XHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1hd2FpdC1pbi1sb29wXG5cdFx0XHRjb25zdCByZXN1bHQgPSBhd2FpdCBob29rKHRoaXMucmVxdWVzdCwgKHRoaXMuX29wdGlvbnMgYXMgdW5rbm93bikgYXMgTm9ybWFsaXplZE9wdGlvbnMpO1xuXG5cdFx0XHRpZiAocmVzdWx0IGluc3RhbmNlb2YgUmVxdWVzdCkge1xuXHRcdFx0XHR0aGlzLnJlcXVlc3QgPSByZXN1bHQ7XG5cdFx0XHRcdGJyZWFrO1xuXHRcdFx0fVxuXG5cdFx0XHRpZiAocmVzdWx0IGluc3RhbmNlb2YgUmVzcG9uc2UpIHtcblx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdH1cblx0XHR9XG5cblx0XHRjb25zdCBub25SZXF1ZXN0T3B0aW9ucyA9IGZpbmRVbmtub3duT3B0aW9ucyh0aGlzLnJlcXVlc3QsIHRoaXMuX29wdGlvbnMpO1xuXG5cdFx0Ly8gQ2xvbmluZyBpcyBkb25lIGhlcmUgdG8gcHJlcGFyZSBpbiBhZHZhbmNlIGZvciByZXRyaWVzXG5cdFx0Y29uc3QgbWFpblJlcXVlc3QgPSB0aGlzLnJlcXVlc3Q7XG5cdFx0dGhpcy5yZXF1ZXN0ID0gbWFpblJlcXVlc3QuY2xvbmUoKTtcblxuXHRcdGlmICh0aGlzLl9vcHRpb25zLnRpbWVvdXQgPT09IGZhbHNlKSB7XG5cdFx0XHRyZXR1cm4gdGhpcy5fb3B0aW9ucy5mZXRjaChtYWluUmVxdWVzdCwgbm9uUmVxdWVzdE9wdGlvbnMpO1xuXHRcdH1cblxuXHRcdHJldHVybiB0aW1lb3V0KG1haW5SZXF1ZXN0LCBub25SZXF1ZXN0T3B0aW9ucywgdGhpcy5hYm9ydENvbnRyb2xsZXIsIHRoaXMuX29wdGlvbnMgYXMgVGltZW91dE9wdGlvbnMpO1xuXHR9XG5cblx0LyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cblx0cHJvdGVjdGVkIF9zdHJlYW0ocmVzcG9uc2U6IFJlc3BvbnNlLCBvbkRvd25sb2FkUHJvZ3Jlc3M6IE9wdGlvbnNbJ29uRG93bmxvYWRQcm9ncmVzcyddKSB7XG5cdFx0Y29uc3QgdG90YWxCeXRlcyA9IE51bWJlcihyZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC1sZW5ndGgnKSkgfHwgMDtcblx0XHRsZXQgdHJhbnNmZXJyZWRCeXRlcyA9IDA7XG5cblx0XHRpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDQpIHtcblx0XHRcdGlmIChvbkRvd25sb2FkUHJvZ3Jlc3MpIHtcblx0XHRcdFx0b25Eb3dubG9hZFByb2dyZXNzKHtwZXJjZW50OiAxLCB0b3RhbEJ5dGVzLCB0cmFuc2ZlcnJlZEJ5dGVzfSwgbmV3IFVpbnQ4QXJyYXkoKSk7XG5cdFx0XHR9XG5cblx0XHRcdHJldHVybiBuZXcgZ2xvYmFsVGhpcy5SZXNwb25zZShcblx0XHRcdFx0bnVsbCxcblx0XHRcdFx0e1xuXHRcdFx0XHRcdHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuXHRcdFx0XHRcdHN0YXR1c1RleHQ6IHJlc3BvbnNlLnN0YXR1c1RleHQsXG5cdFx0XHRcdFx0aGVhZGVyczogcmVzcG9uc2UuaGVhZGVycyxcblx0XHRcdFx0fSxcblx0XHRcdCk7XG5cdFx0fVxuXG5cdFx0cmV0dXJuIG5ldyBnbG9iYWxUaGlzLlJlc3BvbnNlKFxuXHRcdFx0bmV3IGdsb2JhbFRoaXMuUmVhZGFibGVTdHJlYW0oe1xuXHRcdFx0XHRhc3luYyBzdGFydChjb250cm9sbGVyKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmVhZGVyID0gcmVzcG9uc2UuYm9keSEuZ2V0UmVhZGVyKCk7XG5cblx0XHRcdFx0XHRpZiAob25Eb3dubG9hZFByb2dyZXNzKSB7XG5cdFx0XHRcdFx0XHRvbkRvd25sb2FkUHJvZ3Jlc3Moe3BlcmNlbnQ6IDAsIHRyYW5zZmVycmVkQnl0ZXM6IDAsIHRvdGFsQnl0ZXN9LCBuZXcgVWludDhBcnJheSgpKTtcblx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRhc3luYyBmdW5jdGlvbiByZWFkKCkge1xuXHRcdFx0XHRcdFx0Y29uc3Qge2RvbmUsIHZhbHVlfSA9IGF3YWl0IHJlYWRlci5yZWFkKCk7XG5cdFx0XHRcdFx0XHRpZiAoZG9uZSkge1xuXHRcdFx0XHRcdFx0XHRjb250cm9sbGVyLmNsb3NlKCk7XG5cdFx0XHRcdFx0XHRcdHJldHVybjtcblx0XHRcdFx0XHRcdH1cblxuXHRcdFx0XHRcdFx0aWYgKG9uRG93bmxvYWRQcm9ncmVzcykge1xuXHRcdFx0XHRcdFx0XHR0cmFuc2ZlcnJlZEJ5dGVzICs9IHZhbHVlLmJ5dGVMZW5ndGg7XG5cdFx0XHRcdFx0XHRcdGNvbnN0IHBlcmNlbnQgPSB0b3RhbEJ5dGVzID09PSAwID8gMCA6IHRyYW5zZmVycmVkQnl0ZXMgLyB0b3RhbEJ5dGVzO1xuXHRcdFx0XHRcdFx0XHRvbkRvd25sb2FkUHJvZ3Jlc3Moe3BlcmNlbnQsIHRyYW5zZmVycmVkQnl0ZXMsIHRvdGFsQnl0ZXN9LCB2YWx1ZSk7XG5cdFx0XHRcdFx0XHR9XG5cblx0XHRcdFx0XHRcdGNvbnRyb2xsZXIuZW5xdWV1ZSh2YWx1ZSk7XG5cdFx0XHRcdFx0XHRhd2FpdCByZWFkKCk7XG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0YXdhaXQgcmVhZCgpO1xuXHRcdFx0XHR9LFxuXHRcdFx0fSksXG5cdFx0XHR7XG5cdFx0XHRcdHN0YXR1czogcmVzcG9uc2Uuc3RhdHVzLFxuXHRcdFx0XHRzdGF0dXNUZXh0OiByZXNwb25zZS5zdGF0dXNUZXh0LFxuXHRcdFx0XHRoZWFkZXJzOiByZXNwb25zZS5oZWFkZXJzLFxuXHRcdFx0fSxcblx0XHQpO1xuXHR9XG59XG4iLCAiLyohIE1JVCBMaWNlbnNlIMKpIFNpbmRyZSBTb3JodXMgKi9cblxuaW1wb3J0IHtLeX0gZnJvbSAnLi9jb3JlL0t5LmpzJztcbmltcG9ydCB7cmVxdWVzdE1ldGhvZHMsIHN0b3B9IGZyb20gJy4vY29yZS9jb25zdGFudHMuanMnO1xuaW1wb3J0IHR5cGUge0t5SW5zdGFuY2V9IGZyb20gJy4vdHlwZXMva3kuanMnO1xuaW1wb3J0IHR5cGUge0lucHV0LCBPcHRpb25zfSBmcm9tICcuL3R5cGVzL29wdGlvbnMuanMnO1xuaW1wb3J0IHt2YWxpZGF0ZUFuZE1lcmdlfSBmcm9tICcuL3V0aWxzL21lcmdlLmpzJztcbmltcG9ydCB7dHlwZSBNdXRhYmxlfSBmcm9tICcuL3V0aWxzL3R5cGVzLmpzJztcblxuY29uc3QgY3JlYXRlSW5zdGFuY2UgPSAoZGVmYXVsdHM/OiBQYXJ0aWFsPE9wdGlvbnM+KTogS3lJbnN0YW5jZSA9PiB7XG5cdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvcHJvbWlzZS1mdW5jdGlvbi1hc3luY1xuXHRjb25zdCBreTogUGFydGlhbDxNdXRhYmxlPEt5SW5zdGFuY2U+PiA9IChpbnB1dDogSW5wdXQsIG9wdGlvbnM/OiBPcHRpb25zKSA9PiBLeS5jcmVhdGUoaW5wdXQsIHZhbGlkYXRlQW5kTWVyZ2UoZGVmYXVsdHMsIG9wdGlvbnMpKTtcblxuXHRmb3IgKGNvbnN0IG1ldGhvZCBvZiByZXF1ZXN0TWV0aG9kcykge1xuXHRcdC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBAdHlwZXNjcmlwdC1lc2xpbnQvcHJvbWlzZS1mdW5jdGlvbi1hc3luY1xuXHRcdGt5W21ldGhvZF0gPSAoaW5wdXQ6IElucHV0LCBvcHRpb25zPzogT3B0aW9ucykgPT4gS3kuY3JlYXRlKGlucHV0LCB2YWxpZGF0ZUFuZE1lcmdlKGRlZmF1bHRzLCBvcHRpb25zLCB7bWV0aG9kfSkpO1xuXHR9XG5cblx0a3kuY3JlYXRlID0gKG5ld0RlZmF1bHRzPzogUGFydGlhbDxPcHRpb25zPikgPT4gY3JlYXRlSW5zdGFuY2UodmFsaWRhdGVBbmRNZXJnZShuZXdEZWZhdWx0cykpO1xuXHRreS5leHRlbmQgPSAobmV3RGVmYXVsdHM/OiBQYXJ0aWFsPE9wdGlvbnM+IHwgKChwYXJlbnREZWZhdWx0czogUGFydGlhbDxPcHRpb25zPikgPT4gUGFydGlhbDxPcHRpb25zPikpID0+IHtcblx0XHRpZiAodHlwZW9mIG5ld0RlZmF1bHRzID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRuZXdEZWZhdWx0cyA9IG5ld0RlZmF1bHRzKGRlZmF1bHRzID8/IHt9KTtcblx0XHR9XG5cblx0XHRyZXR1cm4gY3JlYXRlSW5zdGFuY2UodmFsaWRhdGVBbmRNZXJnZShkZWZhdWx0cywgbmV3RGVmYXVsdHMpKTtcblx0fTtcblxuXHRreS5zdG9wID0gc3RvcDtcblxuXHRyZXR1cm4ga3kgYXMgS3lJbnN0YW5jZTtcbn07XG5cbmNvbnN0IGt5ID0gY3JlYXRlSW5zdGFuY2UoKTtcblxuZXhwb3J0IGRlZmF1bHQga3k7XG5cbmV4cG9ydCB0eXBlIHtLeUluc3RhbmNlfSBmcm9tICcuL3R5cGVzL2t5LmpzJztcblxuZXhwb3J0IHR5cGUge1xuXHRJbnB1dCxcblx0T3B0aW9ucyxcblx0Tm9ybWFsaXplZE9wdGlvbnMsXG5cdFJldHJ5T3B0aW9ucyxcblx0U2VhcmNoUGFyYW1zT3B0aW9uLFxuXHREb3dubG9hZFByb2dyZXNzLFxufSBmcm9tICcuL3R5cGVzL29wdGlvbnMuanMnO1xuXG5leHBvcnQgdHlwZSB7XG5cdEhvb2tzLFxuXHRCZWZvcmVSZXF1ZXN0SG9vayxcblx0QmVmb3JlUmV0cnlIb29rLFxuXHRCZWZvcmVSZXRyeVN0YXRlLFxuXHRCZWZvcmVFcnJvckhvb2ssXG5cdEFmdGVyUmVzcG9uc2VIb29rLFxufSBmcm9tICcuL3R5cGVzL2hvb2tzLmpzJztcblxuZXhwb3J0IHR5cGUge1Jlc3BvbnNlUHJvbWlzZX0gZnJvbSAnLi90eXBlcy9SZXNwb25zZVByb21pc2UuanMnO1xuZXhwb3J0IHR5cGUge0t5UmVxdWVzdH0gZnJvbSAnLi90eXBlcy9yZXF1ZXN0LmpzJztcbmV4cG9ydCB0eXBlIHtLeVJlc3BvbnNlfSBmcm9tICcuL3R5cGVzL3Jlc3BvbnNlLmpzJztcbmV4cG9ydCB7SFRUUEVycm9yfSBmcm9tICcuL2Vycm9ycy9IVFRQRXJyb3IuanMnO1xuZXhwb3J0IHtUaW1lb3V0RXJyb3J9IGZyb20gJy4vZXJyb3JzL1RpbWVvdXRFcnJvci5qcyc7XG4iLCAiaW1wb3J0IGt5IGZyb20gXCJreVwiO1xuaW1wb3J0IHRhciBmcm9tIFwidGFyLXN0cmVhbVwiO1xuXG5leHBvcnQgY2xhc3MgTW9uaXRvciB7XG4gIGxheWVyczogUmVjb3JkPHN0cmluZywgW251bWJlciwgbnVtYmVyXSB8IG51bGw+ID0ge307XG4gIGVycm9yOiBzdHJpbmcgfCBudWxsID0gbnVsbDtcbiAgaWQgPSBjcnlwdG8ucmFuZG9tVVVJRCgpXG5cbiAgY29uc3RydWN0b3IocHVibGljIG5hbWU6IHN0cmluZywgcHVibGljIGFyY2g6IHN0cmluZykgeyB9XG5cbiAgc2V0TGF5ZXJzKGxheWVyczogc3RyaW5nW10pIHtcbiAgICBmb3IgKGNvbnN0IGxheWVyIG9mIGxheWVycykge1xuICAgICAgdGhpcy5sYXllcnNbbGF5ZXJdID0gWy0xLCAtMV07XG4gICAgfVxuICB9XG4gIHNldExheWVyUHJvZ3Jlc3MobGF5ZXI6IHN0cmluZywgZG93bmxvYWRlZDogbnVtYmVyLCB0b3RhbDogbnVtYmVyKSB7XG4gICAgdGhpcy5sYXllcnNbbGF5ZXJdID0gW2Rvd25sb2FkZWQsIHRvdGFsXTtcbiAgfVxuICBzZXRFcnJvcihlcnJvcjogc3RyaW5nKSB7XG4gICAgdGhpcy5lcnJvciA9IGVycm9yO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBJbWFnZVJlZiB7XG4gIGNvbnN0cnVjdG9yKFxuICAgIHB1YmxpYyBuYW1lc3BhY2U6IHN0cmluZyxcbiAgICBwdWJsaWMgbmFtZTogc3RyaW5nLFxuICAgIHB1YmxpYyB0YWc6IHN0cmluZyA9IFwibGF0ZXN0XCIsXG4gICAgcHVibGljIHJlZ2lzdHJ5Pzogc3RyaW5nLFxuICAgIHB1YmxpYyBkaWdlc3Q/OiBzdHJpbmdcbiAgKSB7IH1cblxuICBzdGF0aWMgcGFyc2UoaW1hZ2U6IHN0cmluZyk6IEltYWdlUmVmIHtcbiAgICBjb25zdCByZWdleCA9IC9eKD86KFteXFwvXSspXFwvKT8oPzooW15cXC9dKylcXC8pPyhbXkA6XSspKD86WzpAXSguKykpPyQvO1xuICAgIGNvbnN0IG1hdGNoZXMgPSBpbWFnZS5tYXRjaChyZWdleCk7XG4gICAgaWYgKCFtYXRjaGVzKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEludmFsaWQgaW1hZ2UgbmFtZTogJHtpbWFnZX1gKTtcbiAgICB9XG4gICAgbGV0IFssIHJlZ2lzdHJ5LCBuYW1lc3BhY2UsIG5hbWUsIHJlZmVyZW5jZV0gPSBtYXRjaGVzO1xuICAgIGlmICghbmFtZXNwYWNlICYmIHJlZ2lzdHJ5KSB7XG4gICAgICBuYW1lc3BhY2UgPSByZWdpc3RyeVxuICAgICAgcmVnaXN0cnkgPSBcIlwiXG4gICAgfVxuICAgIGlmIChyZWZlcmVuY2U/LnN0YXJ0c1dpdGgoXCJzaGEyNTY6XCIpKSB7XG4gICAgICByZXR1cm4gbmV3IEltYWdlUmVmKFxuICAgICAgICBuYW1lc3BhY2UgfHwgXCJsaWJyYXJ5XCIsXG4gICAgICAgIG5hbWUsXG4gICAgICAgIFwibGF0ZXN0XCIsXG4gICAgICAgIHJlZ2lzdHJ5LFxuICAgICAgICByZWZlcmVuY2VcbiAgICAgICk7XG4gICAgfVxuICAgIHJldHVybiBuZXcgSW1hZ2VSZWYoXG4gICAgICBuYW1lc3BhY2UgfHwgXCJsaWJyYXJ5XCIsXG4gICAgICBuYW1lLFxuICAgICAgcmVmZXJlbmNlIHx8IFwibGF0ZXN0XCIsXG4gICAgICByZWdpc3RyeVxuICAgICk7XG4gIH1cblxuICBpbWFnZU5hbWUoKTogc3RyaW5nIHtcbiAgICBsZXQgb3V0ID0gXCJcIjtcbiAgICBpZiAodGhpcy5yZWdpc3RyeSkge1xuICAgICAgb3V0ICs9IGAke3RoaXMucmVnaXN0cnl9L2A7XG4gICAgfVxuICAgIGlmICh0aGlzLm5hbWVzcGFjZSAhPT0gXCJsaWJyYXJ5XCIpIHtcbiAgICAgIG91dCArPSBgJHt0aGlzLm5hbWVzcGFjZX0vYDtcbiAgICB9XG4gICAgb3V0ICs9IHRoaXMubmFtZTtcbiAgICByZXR1cm4gb3V0O1xuICB9XG5cbiAgdG9TdHJpbmcoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCR7dGhpcy5pbWFnZU5hbWUoKX06JHt0aGlzLnRhZ31gO1xuICB9XG5cbiAgcmVnaXN0cnlVcmwoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gdGhpcy5yZWdpc3RyeVxuICAgICAgPyBgaHR0cHM6Ly8ke3RoaXMucmVnaXN0cnl9YFxuICAgICAgOiBcImh0dHBzOi8vcmVnaXN0cnktMS5kb2NrZXIuaW9cIjtcbiAgfVxuICBhc3luYyBkZXRlY3RBdXRoU2VydmVyKCk6IFByb21pc2U8XG4gICAgeyByZWFsbTogc3RyaW5nOyBzZXJ2aWNlOiBzdHJpbmcgfSB8IHVuZGVmaW5lZFxuICA+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcCA9IGF3YWl0IGZldGNoKGAke3RoaXMucmVnaXN0cnlVcmwoKX0vdjIvYCk7XG5cbiAgICAgIGlmIChyZXNwLm9rKSB7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICB9XG5cbiAgICAgIGlmIChNYXRoLmZsb29yKHJlc3Auc3RhdHVzIC8gMTAwKSA9PT0gNCkge1xuICAgICAgICBjb25zdCB3d3dhdXRoID0gcmVzcC5oZWFkZXJzLmdldChcInd3dy1hdXRoZW50aWNhdGVcIik/LnRyaW0oKTtcbiAgICAgICAgaWYgKCF3d3dhdXRoKSB7XG4gICAgICAgICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IEJFQVJFUl9QUkVGSVggPSBcIkJlYXJlciBcIjtcbiAgICAgICAgY29uc3QgU0VSVklDRV9QUkVGSVggPSAnc2VydmljZT1cIic7XG4gICAgICAgIGNvbnN0IFJFQUxNX1BSRUZJWCA9ICdyZWFsbT1cIic7XG5cbiAgICAgICAgaWYgKCF3d3dhdXRoLnN0YXJ0c1dpdGgoQkVBUkVSX1BSRUZJWCkpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFVua25vd24gd3d3LWF1dGhlbnRpY2F0ZSAke3d3d2F1dGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICBsZXQgcmVhbG0gPSBcIlwiO1xuICAgICAgICBsZXQgc2VydmljZSA9IFwiXCI7XG5cbiAgICAgICAgY29uc3QgcGFydHMgPSB3d3dhdXRoLnNsaWNlKEJFQVJFUl9QUkVGSVgubGVuZ3RoKS5zcGxpdCgvWzssXS8pO1xuICAgICAgICBmb3IgKGNvbnN0IGt2IG9mIHBhcnRzKSB7XG4gICAgICAgICAgaWYgKGt2LnN0YXJ0c1dpdGgoU0VSVklDRV9QUkVGSVgpKSB7XG4gICAgICAgICAgICBzZXJ2aWNlID0ga3Yuc2xpY2UoU0VSVklDRV9QUkVGSVgubGVuZ3RoLCAtMSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChrdi5zdGFydHNXaXRoKFJFQUxNX1BSRUZJWCkpIHtcbiAgICAgICAgICAgIHJlYWxtID0ga3Yuc2xpY2UoUkVBTE1fUFJFRklYLmxlbmd0aCwgLTEpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIHJldHVybiB7IHJlYWxtLCBzZXJ2aWNlIH07XG4gICAgICB9XG5cbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBkZXRlY3QgYXV0aCBzZXJ2ZXI6ICR7ZXJyfWApO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZ2V0VG9rZW4oXG4gIGltYWdlOiBJbWFnZVJlZixcbiAgb3B0OiB7IHJlYWxtOiBzdHJpbmc7IHNlcnZpY2U6IHN0cmluZyB9XG4pOiBQcm9taXNlPHN0cmluZz4ge1xuICBjb25zdCB1cmwgPSBgJHtvcHQucmVhbG19P3NlcnZpY2U9JHtvcHQuc2VydmljZX0mc2NvcGU9cmVwb3NpdG9yeToke2ltYWdlLm5hbWVzcGFjZX0vJHtpbWFnZS5uYW1lfTpwdWxsYDtcblxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGt5LmdldCh1cmwpO1xuICBjb25zdCByZXN1bHQ6IGFueSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICBpZiAocmVzdWx0LnRva2VuICYmIHR5cGVvZiByZXN1bHQudG9rZW4gPT09IFwic3RyaW5nXCIpIHtcbiAgICByZXR1cm4gcmVzdWx0LnRva2VuO1xuICB9XG5cbiAgdGhyb3cgbmV3IEVycm9yKFwiRmFpbGVkIHRvIHBhcnNlIHRva2VuIHJlc3BvbnNlXCIpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hNYW5pZmVzdChcbiAgaW1hZ2U6IEltYWdlUmVmLFxuICBvcHQ6IHsgdG9rZW4/OiBzdHJpbmc7IHJlZmVyZW5jZT86IHN0cmluZyB9XG4pOiBQcm9taXNlPGFueT4ge1xuICBjb25zdCByZWZlcmVuY2UgPSBvcHQucmVmZXJlbmNlID8/IGltYWdlLnRhZztcbiAgY29uc3QgcmVnaXN0cnkgPSBpbWFnZS5yZWdpc3RyeVVybCgpO1xuXG4gIGNvbnN0IHVybCA9IGAke3JlZ2lzdHJ5fS92Mi8ke2ltYWdlLm5hbWVzcGFjZX0vJHtpbWFnZS5uYW1lfS9tYW5pZmVzdHMvJHtyZWZlcmVuY2V9YDtcblxuICBjb25zdCBoZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge1xuICAgIEFjY2VwdDogW1xuICAgICAgXCJhcHBsaWNhdGlvbi92bmQub2NpLmltYWdlLm1hbmlmZXN0LnYxK2pzb25cIixcbiAgICAgIFwiYXBwbGljYXRpb24vdm5kLm9jaS5pbWFnZS5pbmRleC52MStqc29uXCIsXG4gICAgICBcImFwcGxpY2F0aW9uL3ZuZC5kb2NrZXIuZGlzdHJpYnV0aW9uLm1hbmlmZXN0LnYyK2pzb25cIixcbiAgICAgIFwiYXBwbGljYXRpb24vdm5kLmRvY2tlci5kaXN0cmlidXRpb24ubWFuaWZlc3QubGlzdC52Mitqc29uXCIsXG4gICAgICBcImFwcGxpY2F0aW9uL3ZuZC5kb2NrZXIuZGlzdHJpYnV0aW9uLm1hbmlmZXN0LnYxK2pzb25cIixcbiAgICBdLmpvaW4oXCIsXCIpLFxuICB9O1xuXG4gIGlmIChvcHQudG9rZW4pIHtcbiAgICBoZWFkZXJzW1wiQXV0aG9yaXphdGlvblwiXSA9IGBCZWFyZXIgJHtvcHQudG9rZW59YDtcbiAgfVxuXG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQga3kuZ2V0KHVybCwgeyBoZWFkZXJzIH0pO1xuICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gZmV0Y2hCbG9iKFxuICBpbWFnZTogSW1hZ2VSZWYsXG4gIGZpbGVwYXRoOiBzdHJpbmcsXG4gIG9wdDogeyB0b2tlbj86IHN0cmluZzsgZGlnZXN0OiBzdHJpbmc7IHBhY2s/OiB0YXIuUGFjazsgbW9uaXRvcj86IE1vbml0b3IgfVxuKTogUHJvbWlzZTxzdHJpbmcgfCB1bmRlZmluZWQ+IHtcbiAgY29uc29sZS5sb2coYGZldGNoaW5nIGJsb2I6ICR7b3B0LmRpZ2VzdC5zbGljZSg3LCAyMyl9YCk7XG5cbiAgY29uc3QgdXJsID0gYCR7aW1hZ2UucmVnaXN0cnlVcmwoKX0vdjIvJHtpbWFnZS5uYW1lc3BhY2V9LyR7aW1hZ2UubmFtZVxuICAgIH0vYmxvYnMvJHtvcHQuZGlnZXN0fWA7XG5cbiAgY29uc3QgaGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICBpZiAob3B0LnRva2VuKSB7XG4gICAgaGVhZGVyc1tcIkF1dGhvcml6YXRpb25cIl0gPSBgQmVhcmVyICR7b3B0LnRva2VufWA7XG4gIH1cblxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGt5LmdldCh1cmwsIHtcbiAgICBoZWFkZXJzLFxuICAgIG9uRG93bmxvYWRQcm9ncmVzczogKHByb2dyZXNzKSA9PiB7XG4gICAgICBvcHQubW9uaXRvcj8uc2V0TGF5ZXJQcm9ncmVzcyhcbiAgICAgICAgb3B0LmRpZ2VzdCxcbiAgICAgICAgcHJvZ3Jlc3MudHJhbnNmZXJyZWRCeXRlcyxcbiAgICAgICAgcHJvZ3Jlc3MudG90YWxCeXRlc1xuICAgICAgKTtcbiAgICB9LFxuXG4gIH0pO1xuXG4gIGNvbnN0IGNvbnRlbnRTaXplID0gcGFyc2VJbnQoXG4gICAgcmVzcG9uc2UuaGVhZGVycy5nZXQoXCJDb250ZW50LUxlbmd0aFwiKSA/PyBcIjBcIixcbiAgICAxMFxuICApO1xuICAvLyBjb25zb2xlLmxvZyhcInNpemUgaXNcIiwgY29udGVudFNpemUpO1xuICBpZiAoIW9wdC5wYWNrKSB7XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLnRleHQoKTtcbiAgfSBlbHNlIHtcbiAgICBjb25zdCB3cml0YWJsZSA9IG9wdC5wYWNrLmVudHJ5KHtcbiAgICAgIG5hbWU6IGZpbGVwYXRoLFxuICAgICAgdHlwZTogXCJmaWxlXCIsXG4gICAgICBzaXplOiBjb250ZW50U2l6ZSxcbiAgICB9KTtcbiAgICBjb25zdCByZHIgPSByZXNwb25zZS5ib2R5IS5nZXRSZWFkZXIoKTtcbiAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgLy8gY29uc29sZS5sb2coJ3JlYWQnKVxuICAgICAgY29uc3QgeyBkb25lLCB2YWx1ZSB9ID0gYXdhaXQgcmRyLnJlYWQoKTtcbiAgICAgIGlmIChkb25lKSB7XG4gICAgICAgIHdyaXRhYmxlLmVuZCgpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIC8vIGNvbnNvbGUubG9nKCdub3QgZG9uZScpXG4gICAgICB3cml0YWJsZS53cml0ZSh2YWx1ZSwpO1xuICAgICAgLy8gYXdhaXQgbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT5cbiAgICAgIC8vICAge1xuICAgICAgLy8gICAgIGNvbnNvbGUubG9nKCdzdGFydCBpbm5lcicpXG4gICAgICAvLyAgICAgcmV0dXJuIFxuICAgICAgLy8gICB9XG4gICAgICAvLyApO1xuICAgIH1cbiAgICBvcHQubW9uaXRvcj8uc2V0TGF5ZXJQcm9ncmVzcyhcbiAgICAgIG9wdC5kaWdlc3QsXG4gICAgICBjb250ZW50U2l6ZSxcbiAgICAgIGNvbnRlbnRTaXplXG4gICAgKTtcbiAgfVxufVxuXG5pbnRlcmZhY2UgTWFuaWZlc3RJdGVtIHtcbiAgQ29uZmlnOiBzdHJpbmc7XG4gIFJlcG9UYWdzOiBzdHJpbmdbXTtcbiAgTGF5ZXJzOiBzdHJpbmdbXTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNpbmdsZU1hbmlmZXN0VjIoXG4gIGltYWdlOiBJbWFnZVJlZixcbiAgcGFjazogdGFyLlBhY2ssXG4gIG9wdDogeyBtYW5pZmVzdEpzb246IGFueTsgdG9rZW4/OiBzdHJpbmc7IG1vbml0b3I/OiBNb25pdG9yIH1cbik6IFByb21pc2U8W01hbmlmZXN0SXRlbSwgc3RyaW5nXT4ge1xuICBjb25zdCBjb25maWdEaWdlc3QgPSBvcHQubWFuaWZlc3RKc29uLmNvbmZpZy5kaWdlc3Q7XG4gIGNvbnN0IGltYWdlSWQgPSBjb25maWdEaWdlc3QucmVwbGFjZShcInNoYTI1NjpcIiwgXCJcIik7XG5cbiAgbGV0IGxheWVySWQgPSBcIlwiO1xuICBsZXQgbGF5ZXJKc29uOiBhbnkgPSB7fTtcbiAgY29uc3QgbGF5ZXJGaWxlczogc3RyaW5nW10gPSBbXTtcbiAgY29uc3QgY29uZmlnRmlsZSA9IGAke2ltYWdlSWR9Lmpzb25gO1xuICBjb25zdCBjb25maWdGaWxlQ29udGVudCA9IGF3YWl0IGZldGNoQmxvYihpbWFnZSwgY29uZmlnRmlsZSwge1xuICAgIHRva2VuOiBvcHQudG9rZW4sXG4gICAgZGlnZXN0OiBjb25maWdEaWdlc3QsXG4gIH0pO1xuICBwYWNrLmVudHJ5KHsgbmFtZTogY29uZmlnRmlsZSwgdHlwZTogXCJmaWxlXCIgfSwgY29uZmlnRmlsZUNvbnRlbnQpO1xuICAvLyBjb25zdCBjb25maWdGaWxlSGFuZGxlID0gYXdhaXQgZGlyLmdldEZpbGVIYW5kbGUoY29uZmlnRmlsZSwge1xuICAvLyAgICAgY3JlYXRlOiB0cnVlLFxuICAvLyB9KTtcblxuICBjb25zdCBsYXllcnMgPSBvcHQubWFuaWZlc3RKc29uLmxheWVycztcbiAgb3B0Lm1vbml0b3I/LnNldExheWVycyhsYXllcnMubWFwKChsOiBhbnkpID0+IGwuZGlnZXN0KSk7XG4gIGZvciAoY29uc3QgbGF5ZXIgb2YgbGF5ZXJzKSB7XG4gICAgY29uc3QgbGF5ZXJNZWRpYVR5cGUgPSBsYXllci5tZWRpYVR5cGU7XG4gICAgY29uc3QgbGF5ZXJEaWdlc3QgPSBsYXllci5kaWdlc3Q7XG4gICAgY29uc3QgcGFyZW50SWQgPSBsYXllcklkO1xuXG4gICAgLy8gQ2FsY3VsYXRlIG5ldyBsYXllciBJRFxuICAgIGNvbnN0IGhhc2ggPSBhd2FpdCBjcnlwdG8uc3VidGxlLmRpZ2VzdChcbiAgICAgIFwiU0hBLTI1NlwiLFxuICAgICAgbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGAke2xheWVySWR9XFxuJHtsYXllckRpZ2VzdH1gKVxuICAgICk7XG4gICAgbGF5ZXJJZCA9IEFycmF5LmZyb20obmV3IFVpbnQ4QXJyYXkoaGFzaCkpXG4gICAgICAubWFwKChiKSA9PiBiLnRvU3RyaW5nKDE2KS5wYWRTdGFydCgyLCBcIjBcIikpXG4gICAgICAuam9pbihcIlwiKTtcblxuICAgIC8vIGNvbnN0IGxheWVyRGlyID0gYXdhaXQgZGlyLmdldERpcmVjdG9yeUhhbmRsZShsYXllcklkLCB7XG4gICAgLy8gICBjcmVhdGU6IHRydWUsXG4gICAgLy8gfSk7XG4gICAgcGFjay5lbnRyeSh7IG5hbWU6IGxheWVySWQsIHR5cGU6IFwiZGlyZWN0b3J5XCIgfSk7XG4gICAgY29uc3QgbGF5ZXJEaXIgPSBsYXllcklkO1xuXG4gICAgLy8gY29uc3QgdmVyc2lvbkZpbGUgPSBhd2FpdCBsYXllckRpci5nZXRGaWxlSGFuZGxlKFwiVkVSU0lPTlwiLCB7XG4gICAgLy8gICBjcmVhdGU6IHRydWUsXG4gICAgLy8gfSk7XG4gICAgcGFjay5lbnRyeSh7IG5hbWU6IGAke2xheWVyRGlyfS9WRVJTSU9OYCwgdHlwZTogXCJmaWxlXCIgfSwgXCIxLjBcIik7XG4gICAgLy8gY29uc3QgdmVyc2lvbldyaXRhYmxlID0gYXdhaXQgdmVyc2lvbkZpbGUuY3JlYXRlV3JpdGFibGUoKTtcbiAgICAvLyBhd2FpdCB2ZXJzaW9uV3JpdGFibGUud3JpdGUoXCIxLjBcIik7XG4gICAgLy8gYXdhaXQgdmVyc2lvbldyaXRhYmxlLmNsb3NlKCk7XG5cbiAgICBjb25zdCBsYXllclRhciA9IGAke2xheWVySWR9L2xheWVyLnRhcmA7XG4gICAgbGF5ZXJGaWxlcy5wdXNoKGxheWVyVGFyKTtcblxuICAgIGxheWVySnNvbiA9IHtcbiAgICAgIGlkOiBsYXllcklkLFxuICAgICAgY3JlYXRlZDogXCIwMDAxLTAxLTAxVDAwOjAwOjAwWlwiLFxuICAgICAgY29udGFpbmVyX2NvbmZpZzoge1xuICAgICAgICBIb3N0bmFtZTogXCJcIixcbiAgICAgICAgRG9tYWlubmFtZTogXCJcIixcbiAgICAgICAgVXNlcjogXCJcIixcbiAgICAgICAgQXR0YWNoU3RkaW46IGZhbHNlLFxuICAgICAgICBBdHRhY2hTdGRvdXQ6IGZhbHNlLFxuICAgICAgICBBdHRhY2hTdGRlcnI6IGZhbHNlLFxuICAgICAgICBUdHk6IGZhbHNlLFxuICAgICAgICBPcGVuU3RkaW46IGZhbHNlLFxuICAgICAgICBTdGRpbk9uY2U6IGZhbHNlLFxuICAgICAgICBFbnY6IG51bGwsXG4gICAgICAgIENtZDogbnVsbCxcbiAgICAgICAgSW1hZ2U6IFwiXCIsXG4gICAgICAgIFZvbHVtZXM6IG51bGwsXG4gICAgICAgIFdvcmtpbmdEaXI6IFwiXCIsXG4gICAgICAgIEVudHJ5cG9pbnQ6IG51bGwsXG4gICAgICAgIE9uQnVpbGQ6IG51bGwsXG4gICAgICAgIExhYmVsczogbnVsbCxcbiAgICAgIH0sXG4gICAgfTtcblxuICAgIGlmIChwYXJlbnRJZCkge1xuICAgICAgbGF5ZXJKc29uLnBhcmVudElkID0gcGFyZW50SWQ7XG4gICAgfVxuXG4gICAgLy8gY29uc3QganNvbkZpbGUgPSBhd2FpdCBsYXllckRpci5nZXRGaWxlSGFuZGxlKFwianNvblwiLCB7IGNyZWF0ZTogdHJ1ZSB9KTtcbiAgICAvLyBjb25zdCBqc29uV3JpdGFibGUgPSBhd2FpdCBqc29uRmlsZS5jcmVhdGVXcml0YWJsZSgpO1xuICAgIC8vIGF3YWl0IGpzb25Xcml0YWJsZS53cml0ZShKU09OLnN0cmluZ2lmeShsYXllckpzb24pKTtcbiAgICAvLyBhd2FpdCBqc29uV3JpdGFibGUuY2xvc2UoKTtcbiAgICBwYWNrLmVudHJ5KFxuICAgICAgeyBuYW1lOiBgJHtsYXllckRpcn0vanNvbmAsIHR5cGU6IFwiZmlsZVwiIH0sXG4gICAgICBKU09OLnN0cmluZ2lmeShsYXllckpzb24pXG4gICAgKTtcblxuICAgIGlmIChcbiAgICAgIGxheWVyTWVkaWFUeXBlID09PSBcImFwcGxpY2F0aW9uL3ZuZC5vY2kuaW1hZ2UubGF5ZXIudjEudGFyK2d6aXBcIiB8fFxuICAgICAgbGF5ZXJNZWRpYVR5cGUgPT09IFwiYXBwbGljYXRpb24vdm5kLmRvY2tlci5pbWFnZS5yb290ZnMuZGlmZi50YXIuZ3ppcFwiXG4gICAgKSB7XG4gICAgICAvLyAgIGNvbnN0IGxheWVyRmlsZSA9IGF3YWl0IGRpci5nZXRGaWxlSGFuZGxlKGxheWVyVGFyLCB7XG4gICAgICAvLyAgICAgY3JlYXRlOiB0cnVlLFxuICAgICAgLy8gICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKGxheWVyVGFyKTtcbiAgICAgIGF3YWl0IGZldGNoQmxvYihpbWFnZSwgbGF5ZXJUYXIsIHtcbiAgICAgICAgdG9rZW46IG9wdC50b2tlbixcbiAgICAgICAgZGlnZXN0OiBsYXllckRpZ2VzdCxcbiAgICAgICAgcGFjayxcbiAgICAgICAgbW9uaXRvcjogb3B0Lm1vbml0b3IsXG4gICAgICB9KTtcbiAgICAgIGNvbnNvbGUubG9nKFwiZmV0Y2hlZFwiKTtcbiAgICB9IGVsc2Uge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgVW5rbm93biBtZWRpYSB0eXBlICgke2ltYWdlLm5hbWV9LCAke2xheWVyTWVkaWFUeXBlfSk6ICcke2xheWVySWR9J2BcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLy8gUmVhZCBhbmQgbW9kaWZ5IGNvbmZpZyBmaWxlXG4gIC8vICAgY29uc3QgY29uZmlnRmlsZVJlYWRlciA9IGF3YWl0IChcbiAgLy8gICAgIGF3YWl0IGRpci5nZXRGaWxlSGFuZGxlKGNvbmZpZ0ZpbGUpXG4gIC8vICAgKS5nZXRGaWxlKCk7XG4gIC8vICAgY29uc3QgY29uZmlnSnNvbiA9IEpTT04ucGFyc2UoYXdhaXQgY29uZmlnRmlsZVJlYWRlci50ZXh0KCkpO1xuICBjb25zdCBjb25maWdKc29uID0gSlNPTi5wYXJzZShjb25maWdGaWxlQ29udGVudCEpO1xuICBjb25maWdKc29uLmlkID0gbGF5ZXJKc29uLmlkO1xuICBpZiAobGF5ZXJKc29uLnBhcmVudElkKSB7XG4gICAgY29uZmlnSnNvbi5wYXJlbnRJZCA9IGxheWVySnNvbi5wYXJlbnRJZDtcbiAgfVxuICBkZWxldGUgY29uZmlnSnNvbi5oaXN0b3J5O1xuICBkZWxldGUgY29uZmlnSnNvbi5yb290ZnM7XG5cbiAgLy8gICBjb25zdCBsYXllckRpckhhbmRsZSA9IGF3YWl0IGRpci5nZXREaXJlY3RvcnlIYW5kbGUobGF5ZXJJZCk7XG5cbiAgcGFjay5lbnRyeShcbiAgICB7IG5hbWU6IGAke2xheWVySWR9L2pzb25gLCB0eXBlOiBcImZpbGVcIiB9LFxuICAgIEpTT04uc3RyaW5naWZ5KGNvbmZpZ0pzb24pXG4gICk7XG4gIC8vICAgY29uc3QgZmluYWxKc29uRmlsZSA9IGF3YWl0IGxheWVyRGlySGFuZGxlLmdldEZpbGVIYW5kbGUoXCJqc29uXCIsIHtcbiAgLy8gICAgIGNyZWF0ZTogdHJ1ZSxcbiAgLy8gICB9KTtcbiAgLy8gICBjb25zdCBmaW5hbEpzb25Xcml0YWJsZSA9IGF3YWl0IGZpbmFsSnNvbkZpbGUuY3JlYXRlV3JpdGFibGUoKTtcbiAgLy8gICBhd2FpdCBmaW5hbEpzb25Xcml0YWJsZS53cml0ZShKU09OLnN0cmluZ2lmeShjb25maWdKc29uKSk7XG4gIC8vICAgYXdhaXQgZmluYWxKc29uV3JpdGFibGUuY2xvc2UoKTtcblxuICBjb25zdCBtYW5pZmVzdCA9IHtcbiAgICBDb25maWc6IGNvbmZpZ0ZpbGUsXG4gICAgUmVwb1RhZ3M6IFtpbWFnZS50b1N0cmluZygpXSxcbiAgICBMYXllcnM6IGxheWVyRmlsZXMsXG4gIH07XG5cbiAgcmV0dXJuIFttYW5pZmVzdCwgbGF5ZXJJZF07XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBoYW5kbGVTaW5nbGVNYW5pZmVzdFYxKFxuICBpbWFnZTogSW1hZ2VSZWYsXG4gIHBhY2s6IHRhci5QYWNrLFxuICBvcHQ6IHsgbWFuaWZlc3RKc29uOiBhbnk7IHRva2VuPzogc3RyaW5nOyBtb25pdG9yPzogTW9uaXRvciB9XG4pOiBQcm9taXNlPFtNYW5pZmVzdEl0ZW0sIHN0cmluZ10+IHtcbiAgY29uc29sZS5sb2coYFN0YXJ0IHB1bGxpbmcgJHtpbWFnZS50b1N0cmluZygpfS4uLiAodjEpYCk7XG5cbiAgY29uc3QgaGlzdG9yeSA9IG9wdC5tYW5pZmVzdEpzb24uaGlzdG9yeTtcbiAgaWYgKCFBcnJheS5pc0FycmF5KGhpc3RvcnkpKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiaGlzdG9yeSBpcyBub3QgYSB2YWxpZCBhcnJheVwiKTtcbiAgfVxuXG4gIGNvbnN0IGZzTGF5ZXJzID0gb3B0Lm1hbmlmZXN0SnNvbi5mc0xheWVycztcbiAgaWYgKCFBcnJheS5pc0FycmF5KGZzTGF5ZXJzKSkge1xuICAgIHRocm93IG5ldyBFcnJvcihcImZzTGF5ZXJzIGlzIG5vdCBhIHZhbGlkIGFycmF5XCIpO1xuICB9XG5cbiAgb3B0Lm1vbml0b3I/LnNldExheWVycyhmc0xheWVycy5tYXAoKGw6IGFueSkgPT4gbC5ibG9iU3VtKSk7XG5cbiAgbGV0IGxheWVySWQgPSBcIlwiO1xuICBmb3IgKGxldCBpID0gMDsgaSA8IGZzTGF5ZXJzLmxlbmd0aDsgaSsrKSB7XG4gICAgY29uc3QgbGF5ZXIgPSBmc0xheWVyc1tpXTtcbiAgICBjb25zdCBkaWdlc3QgPSBsYXllci5ibG9iU3VtO1xuICAgIGlmICh0eXBlb2YgZGlnZXN0ICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJibG9iU3VtIGlzIG5vdCBhIHZhbGlkIHN0cmluZ1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCB2MUNvbXBhdGliaWxpdHkgPSBoaXN0b3J5W2ldLnYxQ29tcGF0aWJpbGl0eTtcbiAgICBpZiAodHlwZW9mIHYxQ29tcGF0aWJpbGl0eSAhPT0gXCJzdHJpbmdcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFwidjFDb21wYXRpYmlsaXR5IGlzIG5vdCBhIHZhbGlkIHN0cmluZ1wiKTtcbiAgICB9XG5cbiAgICBjb25zdCBpbWFnZUpzb24gPSBKU09OLnBhcnNlKHYxQ29tcGF0aWJpbGl0eSk7XG4gICAgbGF5ZXJJZCA9IGltYWdlSnNvbi5pZDtcblxuICAgIGNvbnN0IGxheWVyRGlyID0gbGF5ZXJJZDtcbiAgICBwYWNrLmVudHJ5KHsgbmFtZTogbGF5ZXJJZCwgdHlwZTogXCJkaXJlY3RvcnlcIiB9KTtcblxuICAgIC8vIGNvbnN0IHZlcnNpb25GaWxlID0gYXdhaXQgbGF5ZXJEaXIuZ2V0RmlsZUhhbmRsZShcIlZFUlNJT05cIiwge1xuICAgIC8vICAgY3JlYXRlOiB0cnVlLFxuICAgIC8vIH0pO1xuICAgIC8vIGNvbnN0IHZlcnNpb25Xcml0YWJsZSA9IGF3YWl0IHZlcnNpb25GaWxlLmNyZWF0ZVdyaXRhYmxlKCk7XG4gICAgLy8gYXdhaXQgdmVyc2lvbldyaXRhYmxlLndyaXRlKFwiMS4wXCIpO1xuICAgIC8vIGF3YWl0IHZlcnNpb25Xcml0YWJsZS5jbG9zZSgpO1xuICAgIHBhY2suZW50cnkoeyBuYW1lOiBgJHtsYXllckRpcn0vVkVSU0lPTmAsIHR5cGU6IFwiZmlsZVwiIH0sIFwiMS4wXCIpO1xuXG4gICAgLy8gY29uc3QganNvbkZpbGUgPSBhd2FpdCBsYXllckRpci5nZXRGaWxlSGFuZGxlKFwianNvblwiLCB7IGNyZWF0ZTogdHJ1ZSB9KTtcbiAgICAvLyBjb25zdCBqc29uV3JpdGFibGUgPSBhd2FpdCBqc29uRmlsZS5jcmVhdGVXcml0YWJsZSgpO1xuICAgIC8vIGF3YWl0IGpzb25Xcml0YWJsZS53cml0ZSh2MUNvbXBhdGliaWxpdHkpO1xuICAgIC8vIGF3YWl0IGpzb25Xcml0YWJsZS5jbG9zZSgpO1xuICAgIHBhY2suZW50cnkoeyBuYW1lOiBgJHtsYXllckRpcn0vanNvbmAsIHR5cGU6IFwiZmlsZVwiIH0sIHYxQ29tcGF0aWJpbGl0eSk7XG5cbiAgICAvLyBjb25zdCBsYXllckZpbGUgPSBhd2FpdCBsYXllckRpci5nZXRGaWxlSGFuZGxlKFwibGF5ZXIudGFyXCIsIHtcbiAgICAvLyAgIGNyZWF0ZTogdHJ1ZSxcbiAgICAvLyB9KTtcblxuICAgIGNvbnNvbGUubG9nKGAke2xheWVyRGlyfS9sYXllci50YXJgKTtcbiAgICBhd2FpdCBmZXRjaEJsb2IoaW1hZ2UsIGAke2xheWVyRGlyfS9sYXllci50YXJgLCB7XG4gICAgICB0b2tlbjogb3B0LnRva2VuLFxuICAgICAgZGlnZXN0OiBkaWdlc3QsXG4gICAgICBwYWNrLFxuICAgICAgbW9uaXRvcjogb3B0Lm1vbml0b3IsXG4gICAgfSk7XG4gIH1cblxuICByZXR1cm4gW1xuICAgIHtcbiAgICAgIENvbmZpZzogYCR7bGF5ZXJJZH0vanNvbmAsXG4gICAgICBSZXBvVGFnczogW2ltYWdlLnRvU3RyaW5nKCldLFxuICAgICAgTGF5ZXJzOiBmc0xheWVycy5tYXAoKGxheWVyKSA9PiBgJHtsYXllci5pZH0vbGF5ZXIudGFyYCksXG4gICAgfSxcbiAgICBsYXllcklkLFxuICBdO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlSW1hZ2UoXG4gIGltYWdlOiBJbWFnZVJlZixcbiAgcGFjazogdGFyLlBhY2ssXG4gIG9wdDogeyByZWdpc3RyeT86IHN0cmluZzsgYXJjaD86IHN0cmluZzsgbW9uaXRvcj86IE1vbml0b3IsIGRyeXJ1bj86IGJvb2xlYW4gfVxuKTogUHJvbWlzZTx2b2lkPiB7XG4gIGNvbnN0IG1hbmlmZXN0T3V0OiBNYW5pZmVzdEl0ZW1bXSA9IFtdO1xuICBjb25zdCByZXBvc2l0b3JpZXM6IFJlY29yZDxzdHJpbmcsIFJlY29yZDxzdHJpbmcsIHN0cmluZz4+ID0ge307XG4gIGNvbnN0IGF1dGhTZXJ2ZXIgPSBhd2FpdCBpbWFnZS5kZXRlY3RBdXRoU2VydmVyKCk7XG4gIGNvbnN0IHRva2VuID0gYXV0aFNlcnZlciA/IGF3YWl0IGdldFRva2VuKGltYWdlLCBhdXRoU2VydmVyKSA6IHVuZGVmaW5lZDtcbiAgY29uc3QgbWFuaWZlc3QgPSBhd2FpdCBmZXRjaE1hbmlmZXN0KGltYWdlLCB7IHRva2VuIH0pO1xuXG4gIGNvbnN0IHNjaGVtYVZlcnNpb24gPSBtYW5pZmVzdC5zY2hlbWFWZXJzaW9uO1xuICBpZiAodHlwZW9mIHNjaGVtYVZlcnNpb24gIT09IFwibnVtYmVyXCIpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJzY2hlbWFWZXJzaW9uIGlzIG5vdCBhIHZhbGlkIG51bWJlclwiKTtcbiAgfVxuXG4gIGlmIChzY2hlbWFWZXJzaW9uID09PSAyKSB7XG4gICAgY29uc3QgbWVkaWFUeXBlID0gbWFuaWZlc3QubWVkaWFUeXBlO1xuICAgIGlmICh0eXBlb2YgbWVkaWFUeXBlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXCJtZWRpYVR5cGUgaXMgbm90IGEgdmFsaWQgc3RyaW5nXCIpO1xuICAgIH1cblxuICAgIGxldCBvdXQ6IFtNYW5pZmVzdEl0ZW0sIHN0cmluZ10gfCB1bmRlZmluZWQ7XG5cbiAgICBpZiAoXG4gICAgICBtZWRpYVR5cGUgPT09IFwiYXBwbGljYXRpb24vdm5kLm9jaS5pbWFnZS5tYW5pZmVzdC52MStqc29uXCIgfHxcbiAgICAgIG1lZGlhVHlwZSA9PT0gXCJhcHBsaWNhdGlvbi92bmQuZG9ja2VyLmRpc3RyaWJ1dGlvbi5tYW5pZmVzdC52Mitqc29uXCJcbiAgICApIHtcbiAgICAgIGNvbnNvbGUubG9nKGBTdGFydCBwdWxsaW5nICR7aW1hZ2UudG9TdHJpbmcoKX0uLi4gKHYyKWApO1xuICAgICAgaWYgKG9wdC5kcnlydW4pIHJldHVybjtcbiAgICAgIG91dCA9IGF3YWl0IGhhbmRsZVNpbmdsZU1hbmlmZXN0VjIoaW1hZ2UsIHBhY2ssIHtcbiAgICAgICAgbWFuaWZlc3RKc29uOiBtYW5pZmVzdCxcbiAgICAgICAgdG9rZW4sXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKFxuICAgICAgbWVkaWFUeXBlID09PSBcImFwcGxpY2F0aW9uL3ZuZC5vY2kuaW1hZ2UuaW5kZXgudjEranNvblwiIHx8XG4gICAgICBtZWRpYVR5cGUgPT09IFwiYXBwbGljYXRpb24vdm5kLmRvY2tlci5kaXN0cmlidXRpb24ubWFuaWZlc3QubGlzdC52Mitqc29uXCJcbiAgICApIHtcbiAgICAgIGxldCBmb3VuZCA9IGZhbHNlO1xuICAgICAgZm9yIChjb25zdCBtIG9mIG1hbmlmZXN0Lm1hbmlmZXN0cykge1xuICAgICAgICBpZiAobS5wbGF0Zm9ybT8uYXJjaGl0ZWN0dXJlPy5zcGxpdChcIi9cIikuaW5jbHVkZXMob3B0LmFyY2gpKSB7XG4gICAgICAgICAgZm91bmQgPSB0cnVlO1xuICAgICAgICAgIGNvbnN0IG1hbmlmZXN0SnNvbiA9IGF3YWl0IGZldGNoTWFuaWZlc3QoaW1hZ2UsIHtcbiAgICAgICAgICAgIHRva2VuLFxuICAgICAgICAgICAgcmVmZXJlbmNlOiBtLmRpZ2VzdCxcblxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGlmIChvcHQuZHJ5cnVuKSByZXR1cm47XG4gICAgICAgICAgY29uc29sZS5sb2coYFN0YXJ0IHB1bGxpbmcgJHtpbWFnZS50b1N0cmluZygpfS4uLiAodjI6JHtvcHQuYXJjaH06JHttLnBsYXRmb3JtPy5hcmNoaXRlY3R1cmV9KWApO1xuICAgICAgICAgIG91dCA9IGF3YWl0IGhhbmRsZVNpbmdsZU1hbmlmZXN0VjIoaW1hZ2UsIHBhY2ssIHtcbiAgICAgICAgICAgIG1hbmlmZXN0SnNvbixcbiAgICAgICAgICAgIHRva2VuLFxuICAgICAgICAgICAgbW9uaXRvcjogb3B0Lm1vbml0b3JcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKCFmb3VuZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYG1hbmlmZXN0IGZvciAoJHtvcHQuYXJjaH0pIGlzIG5vdCBmb3VuZGApO1xuICAgICAgfVxuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGB1bmtub3duIG1hbmlmZXN0IG1lZGlhVHlwZSAoJHtpbWFnZS5uYW1lfSk6ICcke21lZGlhVHlwZX0nYFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBpZiAoIW91dCkgdGhyb3cgbmV3IEVycm9yKFwiTm8gbWFuaWZlc3QgcHJvY2Vzc2VkXCIpO1xuXG4gICAgY29uc3QgW21hbmlmZXN0SXRlbSwgbGF5ZXJJZF0gPSBvdXQ7XG4gICAgY29uc3QgdGFnTWFwOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gICAgdGFnTWFwW2ltYWdlLnRhZ10gPSBsYXllcklkO1xuICAgIHJlcG9zaXRvcmllc1tpbWFnZS5uYW1lXSA9IHRhZ01hcDtcbiAgICBtYW5pZmVzdE91dC5wdXNoKG1hbmlmZXN0SXRlbSk7XG4gIH0gZWxzZSBpZiAoc2NoZW1hVmVyc2lvbiA9PT0gMSkge1xuICAgIGlmIChvcHQuZHJ5cnVuKSByZXR1cm47XG4gICAgY29uc29sZS5sb2coYFN0YXJ0IHB1bGxpbmcgJHtpbWFnZS50b1N0cmluZygpfS4uLiAodjEpYCk7XG4gICAgY29uc3QgW21hbmlmZXN0SXRlbSwgbGF5ZXJJZF0gPSBhd2FpdCBoYW5kbGVTaW5nbGVNYW5pZmVzdFYxKGltYWdlLCBwYWNrLCB7XG4gICAgICBtYW5pZmVzdEpzb246IG1hbmlmZXN0LFxuICAgICAgdG9rZW4sXG4gICAgICBtb25pdG9yOiBvcHQubW9uaXRvclxuICAgIH0pO1xuICAgIGNvbnN0IHRhZ01hcDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgIHRhZ01hcFtpbWFnZS50YWddID0gbGF5ZXJJZDtcbiAgICByZXBvc2l0b3JpZXNbaW1hZ2UubmFtZV0gPSB0YWdNYXA7XG4gICAgbWFuaWZlc3RPdXQucHVzaChtYW5pZmVzdEl0ZW0pO1xuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihgdW5zdXBwb3J0ZWQgc2NoZW1hIHZlcnNpb246ICR7c2NoZW1hVmVyc2lvbn1gKTtcbiAgfVxuXG4gIC8vIFdyaXRlIHJlcG9zaXRvcmllcyBmaWxlXG4gIC8vICAgY29uc3QgcmVwb3NpdG9yaWVzRmlsZSA9IGF3YWl0IGRpci5nZXRGaWxlSGFuZGxlKFwicmVwb3NpdG9yaWVzXCIsIHtcbiAgLy8gICAgIGNyZWF0ZTogdHJ1ZSxcbiAgLy8gICB9KTtcbiAgLy8gICBjb25zdCByZXBvc2l0b3JpZXNXcml0YWJsZSA9IGF3YWl0IHJlcG9zaXRvcmllc0ZpbGUuY3JlYXRlV3JpdGFibGUoKTtcbiAgLy8gICBhd2FpdCByZXBvc2l0b3JpZXNXcml0YWJsZS53cml0ZShKU09OLnN0cmluZ2lmeShyZXBvc2l0b3JpZXMpKTtcbiAgLy8gICBhd2FpdCByZXBvc2l0b3JpZXNXcml0YWJsZS5jbG9zZSgpO1xuICBwYWNrLmVudHJ5KFxuICAgIHsgbmFtZTogXCJyZXBvc2l0b3JpZXNcIiwgdHlwZTogXCJmaWxlXCIgfSxcbiAgICBKU09OLnN0cmluZ2lmeShyZXBvc2l0b3JpZXMpXG4gICk7XG5cbiAgLy8gV3JpdGUgbWFuaWZlc3QuanNvbiBmaWxlXG4gIC8vICAgY29uc3QgbWFuaWZlc3RGaWxlID0gYXdhaXQgZGlyLmdldEZpbGVIYW5kbGUoXCJtYW5pZmVzdC5qc29uXCIsIHtcbiAgLy8gICAgIGNyZWF0ZTogdHJ1ZSxcbiAgLy8gICB9KTtcbiAgLy8gICBjb25zdCBtYW5pZmVzdFdyaXRhYmxlID0gYXdhaXQgbWFuaWZlc3RGaWxlLmNyZWF0ZVdyaXRhYmxlKCk7XG4gIC8vICAgYXdhaXQgbWFuaWZlc3RXcml0YWJsZS53cml0ZShKU09OLnN0cmluZ2lmeShtYW5pZmVzdE91dCkpO1xuICAvLyAgIGF3YWl0IG1hbmlmZXN0V3JpdGFibGUuY2xvc2UoKTtcbiAgcGFjay5lbnRyeShcbiAgICB7IG5hbWU6IFwibWFuaWZlc3QuanNvblwiLCB0eXBlOiBcImZpbGVcIiB9LFxuICAgIEpTT04uc3RyaW5naWZ5KG1hbmlmZXN0T3V0KVxuICApO1xufVxuIiwgImltcG9ydCB7IFJlYWRhYmxlLCBXcml0YWJsZSwgRHVwbGV4IH0gZnJvbSBcInN0cmVhbXhcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGZyb21XZWIod2ViU3RyZWFtLCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAod2ViU3RyZWFtIGluc3RhbmNlb2YgUmVhZGFibGVTdHJlYW0gJiYgd2ViU3RyZWFtIGluc3RhbmNlb2YgV3JpdGFibGVTdHJlYW0pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBEdXBsZXhXZWJTdHJlYW0od2ViU3RyZWFtLCB3ZWJTdHJlYW0sIG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAod2ViU3RyZWFtIGluc3RhbmNlb2YgUmVhZGFibGVTdHJlYW0pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZWFkYWJsZVdlYlN0cmVhbSh3ZWJTdHJlYW0sIG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAod2ViU3RyZWFtIGluc3RhbmNlb2YgV3JpdGFibGVTdHJlYW0pIHtcbiAgICAgICAgcmV0dXJuIG5ldyBXcml0YWJsZVdlYlN0cmVhbSh3ZWJTdHJlYW0sIG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAod2ViU3RyZWFtLnJlYWRhYmxlICYmIHdlYlN0cmVhbS53cml0YWJsZSkge1xuICAgICAgICByZXR1cm4gbmV3IER1cGxleFdlYlN0cmVhbSh3ZWJTdHJlYW0ucmVhZGFibGUsIHdlYlN0cmVhbS53cml0YWJsZSwgb3B0aW9ucyk7XG4gICAgfSBlbHNlIGlmICh3ZWJTdHJlYW0ucmVhZGFibGUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBSZWFkYWJsZVdlYlN0cmVhbSh3ZWJTdHJlYW0ucmVhZGFibGUsIG9wdGlvbnMpO1xuICAgIH0gZWxzZSBpZiAod2ViU3RyZWFtLndyaXRhYmxlKSB7XG4gICAgICAgIHJldHVybiBuZXcgV3JpdGFibGVXZWJTdHJlYW0od2ViU3RyZWFtLndyaXRhYmxlLCBvcHRpb25zKTtcbiAgICB9IGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJmcm9tV2ViOiBSZXF1aXJlcyBhdCBsZWFzdCBhIHJlYWRhYmxlIG9yIHdyaXRhYmxlIHN0cmVhbS5cIik7XG4gICAgfVxufVxuXG5jbGFzcyBSZWFkYWJsZVdlYlN0cmVhbSBleHRlbmRzIFJlYWRhYmxlIHtcbiAgICBjb25zdHJ1Y3RvcihyZWFkYWJsZVN0cmVhbSwgb3B0aW9ucykge1xuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5fcmVhZGVyID0gcmVhZGFibGVTdHJlYW0uZ2V0UmVhZGVyKCk7XG4gICAgICAgIHRoaXMuX2F0dGFjaEVycm9ySGFuZGxlcigpO1xuICAgIH1cblxuICAgIF9hdHRhY2hFcnJvckhhbmRsZXIoKSB7XG4gICAgICAgIHRoaXMuX3JlYWRlci5jbG9zZWQuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95KGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgYXN5bmMgX3JlYWQoY2IpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IHRoaXMuX3JlYWRlci5yZWFkKCk7XG4gICAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgICAgIHRoaXMucHVzaChudWxsKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNiKCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmRlc3Ryb3koZXJyb3IpO1xuICAgICAgICAgICAgY2IoZXJyb3IpOyAvLyBFbnN1cmUgY2FsbGJhY2sgaXMgY2FsbGVkIHdpdGggdGhlIGVycm9yXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBfZGVzdHJveShjYikge1xuICAgICAgICB0aGlzLl9yZWFkZXIucmVsZWFzZUxvY2soKTtcbiAgICAgICAgY2IoKTtcbiAgICB9XG59XG5cbmNsYXNzIFdyaXRhYmxlV2ViU3RyZWFtIGV4dGVuZHMgV3JpdGFibGUge1xuICAgIGNvbnN0cnVjdG9yKHdyaXRhYmxlU3RyZWFtLCBvcHRpb25zKSB7XG4gICAgICAgIHN1cGVyKG9wdGlvbnMpO1xuICAgICAgICB0aGlzLl93cml0ZXIgPSB3cml0YWJsZVN0cmVhbS5nZXRXcml0ZXIoKTtcbiAgICB9XG5cbiAgICBhc3luYyBfd3JpdGUoY2h1bmssIGNiKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLl93cml0ZXIud3JpdGUoY2h1bmspO1xuICAgICAgICAgICAgY2IoKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMuZGVzdHJveShlcnJvcik7XG4gICAgICAgICAgICBjYihlcnJvcik7IC8vIEVuc3VyZSBjYWxsYmFjayBpcyBjYWxsZWQgd2l0aCB0aGUgZXJyb3JcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGFzeW5jIF9maW5hbChjYikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fd3JpdGVyLmNsb3NlKCk7XG4gICAgICAgICAgICBjYigpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95KGVycm9yKTtcbiAgICAgICAgICAgIGNiKGVycm9yKTsgLy8gRW5zdXJlIGNhbGxiYWNrIGlzIGNhbGxlZCB3aXRoIHRoZSBlcnJvclxuICAgICAgICB9XG4gICAgfVxuXG4gICAgX2Rlc3Ryb3koY2IpIHtcbiAgICAgICAgdGhpcy5fd3JpdGVyLnJlbGVhc2VMb2NrKCk7XG4gICAgICAgIGNiKCk7XG4gICAgfVxufVxuXG5jbGFzcyBEdXBsZXhXZWJTdHJlYW0gZXh0ZW5kcyBEdXBsZXgge1xuICAgIGNvbnN0cnVjdG9yKHJlYWRhYmxlU3RyZWFtLCB3cml0YWJsZVN0cmVhbSwgb3B0aW9ucykge1xuICAgICAgICBzdXBlcihvcHRpb25zKTtcbiAgICAgICAgdGhpcy5fcmVhZGVyID0gcmVhZGFibGVTdHJlYW0uZ2V0UmVhZGVyKCk7XG4gICAgICAgIHRoaXMuX3dyaXRlciA9IHdyaXRhYmxlU3RyZWFtLmdldFdyaXRlcigpO1xuICAgICAgICB0aGlzLl9hdHRhY2hFcnJvckhhbmRsZXIoKTtcbiAgICAgICAgdGhpcy5faGFuZGxlQ29tcGxldGlvbigpO1xuICAgIH1cblxuICAgIF9hdHRhY2hFcnJvckhhbmRsZXIoKSB7XG4gICAgICAgIHRoaXMuX3JlYWRlci5jbG9zZWQuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95KGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRoaXMuX3dyaXRlci5jbG9zZWQuY2F0Y2goZXJyb3IgPT4ge1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95KGVycm9yKTtcbiAgICAgICAgfSk7XG4gICAgfVxuXG4gICAgYXN5bmMgX3JlYWQoY2IpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHsgZG9uZSwgdmFsdWUgfSA9IGF3YWl0IHRoaXMuX3JlYWRlci5yZWFkKCk7XG4gICAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgICAgIHRoaXMucHVzaChudWxsKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgdGhpcy5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNiKCk7XG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICB0aGlzLmRlc3Ryb3koZXJyb3IpO1xuICAgICAgICAgICAgY2IoZXJyb3IpOyAvLyBFbnN1cmUgY2FsbGJhY2sgaXMgY2FsbGVkIHdpdGggdGhlIGVycm9yXG4gICAgICAgIH1cbiAgICB9XG5cbiAgICBhc3luYyBfd3JpdGUoY2h1bmssIGNiKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLl93cml0ZXIud3JpdGUoY2h1bmspO1xuICAgICAgICAgICAgY2IoKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMuZGVzdHJveShlcnJvcik7XG4gICAgICAgICAgICBjYihlcnJvcik7IC8vIEVuc3VyZSBjYWxsYmFjayBpcyBjYWxsZWQgd2l0aCB0aGUgZXJyb3JcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGFzeW5jIF9maW5hbChjYikge1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgYXdhaXQgdGhpcy5fd3JpdGVyLmNsb3NlKCk7XG4gICAgICAgICAgICBjYigpO1xuICAgICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgdGhpcy5kZXN0cm95KGVycm9yKTtcbiAgICAgICAgICAgIGNiKGVycm9yKTsgLy8gRW5zdXJlIGNhbGxiYWNrIGlzIGNhbGxlZCB3aXRoIHRoZSBlcnJvclxuICAgICAgICB9XG4gICAgfVxuXG4gICAgX2Rlc3Ryb3koY2IpIHtcbiAgICAgICAgdGhpcy5fcmVhZGVyLnJlbGVhc2VMb2NrKCk7XG4gICAgICAgIHRoaXMuX3dyaXRlci5yZWxlYXNlTG9jaygpO1xuICAgICAgICBjYigpO1xuICAgIH1cblxuICAgIF9oYW5kbGVDb21wbGV0aW9uKCkge1xuICAgICAgICB0aGlzLm9uKCdmaW5pc2gnLCAoKSA9PiB7XG4gICAgICAgICAgICB0aGlzLmVtaXQoJ2VuZCcpO1xuICAgICAgICB9KTtcbiAgICB9XG59IiwgIi8vIFRISVMgSVMgTElGVEVEIHN0cmFpZ2h0IGZyb20gJ3N0cmVhbXgnIHdpdGggbWlub3IgdHdlYWtzIGNvZGUgZm9yIHRyZWUtc2hha2FiaWxpdHkgb2YgJ3RvV2ViJ1xuY29uc3QgV1JJVEVfV1JJVElORyAgICA9IDBiMDEwMDAwMDAwMCA8PCAxN1xuXG5leHBvcnQgZnVuY3Rpb24gZHJhaW5lZCAod3MsIGlzV3JpdGV2ID0gZmFsc2UpIHtcbiAgICBpZiAod3MuZGVzdHJveWVkKSByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGZhbHNlKVxuICAgIGNvbnN0IHN0YXRlID0gd3MuX3dyaXRhYmxlU3RhdGVcbiAgICBjb25zdCBwZW5kaW5nID0gKGlzV3JpdGV2ID8gTWF0aC5taW4oMSwgc3RhdGUucXVldWUubGVuZ3RoKSA6IHN0YXRlLnF1ZXVlLmxlbmd0aClcbiAgICBjb25zdCB3cml0ZXMgPSBwZW5kaW5nICsgKCh3cy5fZHVwbGV4U3RhdGUgJiBXUklURV9XUklUSU5HKSA/IDEgOiAwKVxuICAgIGlmICh3cml0ZXMgPT09IDApIHJldHVybiBQcm9taXNlLnJlc29sdmUodHJ1ZSlcbiAgICBpZiAoc3RhdGUuZHJhaW5zID09PSBudWxsKSBzdGF0ZS5kcmFpbnMgPSBbXVxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICBzdGF0ZS5kcmFpbnMucHVzaCh7IHdyaXRlcywgcmVzb2x2ZSB9KVxuICAgIH0pXG59XG4iLCAiaW1wb3J0IHtcbiAgICBpc1N0cmVhbXgsXG4gICAgaXNSZWFkYWJsZVN0cmVhbSxcbiAgICBpc1dyaXRhYmxlU3RyZWFtXG59IGZyb20gXCIuL2lzU3RyZWFtLmpzXCI7XG5pbXBvcnQge2RyYWluZWR9IGZyb20gXCIuL2RyYWluZWQuanNcIjtcbmltcG9ydCBiNGEgZnJvbSBcImI0YVwiO1xuXG5mdW5jdGlvbiBoYW5kbGVSZWFkYWJsZShzdHJlYW0sIGFzQnl0ZXMpIHtcbiAgICBsZXQgZGVzdHJveWVkID0gZmFsc2U7XG4gICAgY29uc3QgZXZlbnRIYW5kbGVycyA9IHt9O1xuXG4gICAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgICAgIHN0YXJ0KGNvbnRyb2xsZXIpIHtcbiAgICAgICAgICAgIGV2ZW50SGFuZGxlcnNbJ2RhdGEnXSA9IG9uRGF0YTtcbiAgICAgICAgICAgIGV2ZW50SGFuZGxlcnNbJ2VuZCddID0gb25DbG9zZTtcbiAgICAgICAgICAgIGV2ZW50SGFuZGxlcnNbJ2Nsb3NlJ10gPSBvbkNsb3NlO1xuICAgICAgICAgICAgZXZlbnRIYW5kbGVyc1snZXJyb3InXSA9IG9uRXJyb3I7XG5cbiAgICAgICAgICAgIGZvciAoY29uc3QgZXZlbnROYW1lIGluIGV2ZW50SGFuZGxlcnMpIHtcbiAgICAgICAgICAgICAgICBzdHJlYW0ub24oZXZlbnROYW1lLCBldmVudEhhbmRsZXJzW2V2ZW50TmFtZV0pO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBzdHJlYW0ucGF1c2UoKTtcblxuICAgICAgICAgICAgZnVuY3Rpb24gb25EYXRhKGNodW5rKSB7XG4gICAgICAgICAgICAgICAgaWYgKGRlc3Ryb3llZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGlmIChjaHVuayA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICBvbkNsb3NlKCk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgY29udHJvbGxlci5lbnF1ZXVlKHR5cGVvZiBjaHVuayA9PT0gJ3N0cmluZycgPyBiNGEuZnJvbShjaHVuaykgOiBjaHVuayk7XG4gICAgICAgICAgICAgICAgICAgIHN0cmVhbS5wYXVzZSgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgZnVuY3Rpb24gb25DbG9zZSgpIHtcbiAgICAgICAgICAgICAgICBjbGVhbnVwKCk7XG4gICAgICAgICAgICAgICAgY29udHJvbGxlci5jbG9zZSgpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBmdW5jdGlvbiBvbkVycm9yKGVycikge1xuICAgICAgICAgICAgICAgIGNsZWFudXAoKTtcbiAgICAgICAgICAgICAgICBjb250cm9sbGVyLmVycm9yKGVycik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGZ1bmN0aW9uIGNsZWFudXAoKSB7XG4gICAgICAgICAgICAgICAgaWYgKGRlc3Ryb3llZCkgcmV0dXJuO1xuICAgICAgICAgICAgICAgIGRlc3Ryb3llZCA9IHRydWU7XG4gICAgICAgICAgICAgICAgZm9yIChjb25zdCBldmVudE5hbWUgaW4gZXZlbnRIYW5kbGVycykge1xuICAgICAgICAgICAgICAgICAgICBzdHJlYW0ub2ZmKGV2ZW50TmFtZSwgZXZlbnRIYW5kbGVyc1tldmVudE5hbWVdKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHB1bGwoKSB7XG4gICAgICAgICAgICBpZiAoIWRlc3Ryb3llZCkgc3RyZWFtLnJlc3VtZSgpO1xuICAgICAgICB9LFxuICAgICAgICBjYW5jZWwoKSB7XG4gICAgICAgICAgICBkZXN0cm95ZWQgPSB0cnVlO1xuICAgICAgICAgICAgZm9yIChjb25zdCBldmVudE5hbWUgaW4gZXZlbnRIYW5kbGVycykge1xuICAgICAgICAgICAgICAgIHN0cmVhbS5vZmYoZXZlbnROYW1lLCBldmVudEhhbmRsZXJzW2V2ZW50TmFtZV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHN0cmVhbS5kZXN0cm95KSB7XG4gICAgICAgICAgICAgICAgc3RyZWFtLmRlc3Ryb3koKTtcbiAgICAgICAgICAgIH0gZWxzZSBpZiAoc3RyZWFtLmNsb3NlKSB7XG4gICAgICAgICAgICAgICAgc3RyZWFtLmNsb3NlKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIHR5cGU6IGFzQnl0ZXMgPyAnYnl0ZXMnIDogdW5kZWZpbmVkXG4gICAgfSk7XG59XG5cbmZ1bmN0aW9uIGhhbmRsZVdyaXRhYmxlKHdyaXRhYmxlU3RyZWFtWCkge1xuICAgIHJldHVybiBuZXcgV3JpdGFibGVTdHJlYW0oe1xuICAgICAgICBhc3luYyB3cml0ZShkYXRhKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGNodW5rID0gdHlwZW9mIGRhdGEgPT09IFwic3RyaW5nXCIgPyBiNGEuZnJvbShkYXRhKSA6IGRhdGE7XG4gICAgICAgICAgICAgICAgaWYgKCF3cml0YWJsZVN0cmVhbVgud3JpdGUoY2h1bmspKSB7XG4gICAgICAgICAgICAgICAgICAgIGF3YWl0IGRyYWluZWQod3JpdGFibGVTdHJlYW1YLCBmYWxzZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgICAgICB3cml0YWJsZVN0cmVhbVguZGVzdHJveShlcnJvcik7IC8vIFByb3BhZ2F0ZSBlcnJvclxuICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoKCkgPT4gd3JpdGFibGVTdHJlYW1YLmVtaXQoJ2Vycm9yJywgZXJyb3IpLCAwKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgY2xvc2UoKSB7XG4gICAgICAgICAgICBpZiAod3JpdGFibGVTdHJlYW1YLmVuZCkge1xuICAgICAgICAgICAgICAgIHdyaXRhYmxlU3RyZWFtWC5lbmQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgYWJvcnQoZXJyKSB7XG4gICAgICAgICAgICBpZiAod3JpdGFibGVTdHJlYW1YLmRlc3Ryb3kpIHtcbiAgICAgICAgICAgICAgICB3cml0YWJsZVN0cmVhbVguZGVzdHJveShlcnIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2V0VGltZW91dCgoKSA9PiB3cml0YWJsZVN0cmVhbVguZW1pdCgnZXJyb3InLCBlcnIpLCAwKTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuXG5leHBvcnQgZnVuY3Rpb24gdG9XZWIoc3RyZWFtLCBhc0J5dGVzKSB7XG4gICAgbGV0IHdyaXRhYmxlU3RyZWFtWDtcblxuICAgIGlmIChzdHJlYW0gJiYgIWlzU3RyZWFteChzdHJlYW0pKSB7XG4gICAgICAgIGxldCBkdXBsZXg7XG4gICAgICAgICh7XG4gICAgICAgICAgICByZWFkYWJsZTogc3RyZWFtLFxuICAgICAgICAgICAgd3JpdGFibGU6IHdyaXRhYmxlU3RyZWFtWCxcbiAgICAgICAgICAgIGR1cGxleFxuICAgICAgICB9ID0gc3RyZWFtKTtcbiAgICAgICAgaWYgKGR1cGxleCAmJiAhc3RyZWFtICYmICF3cml0YWJsZVN0cmVhbVgpIHtcbiAgICAgICAgICAgIHN0cmVhbSA9IGR1cGxleDtcbiAgICAgICAgICAgIHdyaXRhYmxlU3RyZWFtWCA9IGR1cGxleDtcbiAgICAgICAgfVxuICAgIH0gZWxzZSBpZiAoaXNSZWFkYWJsZVN0cmVhbShzdHJlYW0pICYmIGlzV3JpdGFibGVTdHJlYW0oc3RyZWFtKSkge1xuICAgICAgICAvLyBJZiBpdCdzIGJvdGggcmVhZGFibGUgYW5kIHdyaXRhYmxlLCB0cmVhdCBhcyBkdXBsZXhcbiAgICAgICAgd3JpdGFibGVTdHJlYW1YID0gc3RyZWFtO1xuICAgIH0gZWxzZSBpZiAoaXNSZWFkYWJsZVN0cmVhbShzdHJlYW0pKSB7XG4gICAgICAgIC8vIElmIGl0J3Mgb25seSByZWFkYWJsZVxuICAgICAgICB3cml0YWJsZVN0cmVhbVggPSBudWxsO1xuICAgIH0gZWxzZSBpZiAoaXNXcml0YWJsZVN0cmVhbShzdHJlYW0pKSB7XG4gICAgICAgIC8vIElmIGl0J3Mgb25seSB3cml0YWJsZVxuICAgICAgICB3cml0YWJsZVN0cmVhbVggPSBzdHJlYW07XG4gICAgICAgIHN0cmVhbSA9IG51bGw7XG4gICAgfVxuXG4gICAgaWYgKCFzdHJlYW0gJiYgIXdyaXRhYmxlU3RyZWFtWCkge1xuICAgICAgICBjb25zdCBlcnJvck1lc3NhZ2UgPSBcIkludmFsaWQgc3RyZWFtXCI7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihlcnJvck1lc3NhZ2UpO1xuICAgIH1cblxuICAgIGxldCByZWFkYWJsZVN0cmVhbVdlYjtcbiAgICBsZXQgd3JpdGFibGVTdHJlYW1XZWI7XG5cbiAgICBpZiAoc3RyZWFtKSB7XG4gICAgICAgIHJlYWRhYmxlU3RyZWFtV2ViID0gaGFuZGxlUmVhZGFibGUoc3RyZWFtLCBhc0J5dGVzKTtcbiAgICB9XG4gICAgaWYgKHdyaXRhYmxlU3RyZWFtWCkge1xuICAgICAgICB3cml0YWJsZVN0cmVhbVdlYiA9IGhhbmRsZVdyaXRhYmxlKHdyaXRhYmxlU3RyZWFtWCk7XG4gICAgfVxuXG4gICAgaWYgKHJlYWRhYmxlU3RyZWFtV2ViICYmIHdyaXRhYmxlU3RyZWFtV2ViKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICByZWFkYWJsZTogcmVhZGFibGVTdHJlYW1XZWIsXG4gICAgICAgICAgICB3cml0YWJsZTogd3JpdGFibGVTdHJlYW1XZWJcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICByZXR1cm4gcmVhZGFibGVTdHJlYW1XZWIgfHwgd3JpdGFibGVTdHJlYW1XZWI7XG59Il0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFBQTtBQUFBLFdBQU8sVUFBVSxNQUFNLDBCQUEwQixNQUFNO0FBQUEsTUFDckQsWUFBYSxLQUFLLE1BQU0sS0FBSyxtQkFBbUIsTUFBTTtBQUNwRCxjQUFNLEdBQUcsSUFBSSxLQUFLLEdBQUcsSUFBSSxJQUFJO0FBQzdCLGFBQUssT0FBTztBQUVaLFlBQUksTUFBTSxtQkFBbUI7QUFDM0IsZ0JBQU0sa0JBQWtCLE1BQU0sRUFBRTtBQUFBLFFBQ2xDO0FBQUEsTUFDRjtBQUFBLE1BRUEsSUFBSSxPQUFRO0FBQ1YsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLE9BQU8sa0JBQW1CLE9BQU8sTUFBTSxxQkFBcUI7QUFDMUQsZUFBTyxJQUFJLGtCQUFrQixLQUFLLHFCQUFxQixrQkFBa0IsbUJBQW1CLEVBQUUsTUFBTSxDQUFDO0FBQUEsTUFDdkc7QUFBQSxNQUVBLE9BQU8sZ0JBQWlCLE9BQU8sTUFBTSxtQkFBbUI7QUFDdEQsZUFBTyxJQUFJLGtCQUFrQixLQUFLLG1CQUFtQixrQkFBa0IsaUJBQWlCLEVBQUUsTUFBTSxDQUFDO0FBQUEsTUFDbkc7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDckJBO0FBQUE7QUFBQSxRQUFNLFNBQVM7QUFFZixRQUFNLGdCQUFOLE1BQW9CO0FBQUEsTUFDbEIsY0FBZTtBQUNiLGFBQUssT0FBTyxDQUFDO0FBQ2IsYUFBSyxRQUFRO0FBQUEsTUFDZjtBQUFBLE1BRUEsT0FBUSxLQUFLLE1BQU0sSUFBSSxNQUFNO0FBQzNCLGFBQUs7QUFDTCxZQUFJLEtBQUssZUFBZSxNQUFNLEVBQUU7QUFDaEMsYUFBSyxLQUFLLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQztBQUFBLE1BQzNCO0FBQUEsTUFFQSxRQUFTLEtBQUssTUFBTSxJQUFJLE1BQU07QUFDNUIsYUFBSztBQUNMLFlBQUksS0FBSyxlQUFlLE1BQU0sRUFBRTtBQUNoQyxhQUFLLEtBQUssUUFBUSxDQUFDLElBQUksSUFBSSxDQUFDO0FBQUEsTUFDOUI7QUFBQSxNQUVBLE9BQVEsS0FBSyxNQUFNLElBQUk7QUFDckIsaUJBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLLFFBQVEsSUFBSSxHQUFHLEtBQUs7QUFDaEQsZ0JBQU0sSUFBSSxLQUFLLEtBQUssQ0FBQztBQUVyQixjQUFJLEVBQUUsQ0FBQyxNQUFNLElBQUk7QUFDZixpQkFBSyxLQUFLLE9BQU8sR0FBRyxDQUFDO0FBRXJCLGdCQUFJLEtBQUssVUFBVSxFQUFHLFFBQU8sSUFBSSxRQUFRLElBQUk7QUFFN0MsZ0JBQUksS0FBSyxrQkFBa0IsTUFBTSxFQUFFO0FBRW5DLGlCQUFLO0FBQ0w7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxNQUVBLFVBQVcsS0FBSyxNQUFNO0FBQ3BCLGNBQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJO0FBQzFCLGFBQUssT0FBTyxDQUFDO0FBRWIsWUFBSSxLQUFLLFVBQVUsS0FBSyxPQUFRLFFBQU8sSUFBSSxRQUFRLElBQUk7QUFFdkQsaUJBQVMsSUFBSSxLQUFLLFNBQVMsR0FBRyxLQUFLLEdBQUcsS0FBSztBQUN6QyxjQUFJLEtBQUssa0JBQWtCLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQUEsUUFDN0M7QUFFQSxhQUFLLFNBQVMsS0FBSztBQUFBLE1BQ3JCO0FBQUEsTUFFQSxLQUFNLEtBQUssU0FBUyxNQUFNO0FBQ3hCLGNBQU0sT0FBTyxDQUFDLEdBQUcsS0FBSyxJQUFJO0FBRTFCLGlCQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxJQUFJLEdBQUcsS0FBSztBQUMzQyxnQkFBTSxJQUFJLEtBQUssQ0FBQztBQUVoQixjQUFJLEVBQUUsQ0FBQyxNQUFNLEtBQU0sTUFBSyxPQUFPLEtBQUssTUFBTSxFQUFFLENBQUMsQ0FBQztBQUU5QyxZQUFFLENBQUMsRUFBRSxLQUFLLEtBQUssR0FBRyxJQUFJO0FBQUEsUUFDeEI7QUFFQSxlQUFPLEtBQUssU0FBUztBQUFBLE1BQ3ZCO0FBQUEsSUFDRjtBQUVBLGFBQVMsZUFBZ0IsS0FBSyxNQUFNLElBQUksTUFBTTtBQUM1QyxZQUFNLElBQUksSUFBSSxRQUFRLElBQUksTUFBTSxJQUFJLFFBQVEsSUFBSSxJQUFJLElBQUksY0FBYztBQUN0RSxRQUFFLE9BQU8sS0FBSyxNQUFNLElBQUksSUFBSTtBQUM1QixhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsZ0JBQWlCLEtBQUssTUFBTSxJQUFJLE1BQU07QUFDN0MsWUFBTSxJQUFJLElBQUksUUFBUSxJQUFJLE1BQU0sSUFBSSxRQUFRLElBQUksSUFBSSxJQUFJLGNBQWM7QUFDdEUsUUFBRSxRQUFRLEtBQUssTUFBTSxJQUFJLElBQUk7QUFDN0IsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLGVBQWdCLEtBQUssTUFBTSxJQUFJO0FBQ3RDLFlBQU0sSUFBSSxJQUFJLFFBQVEsSUFBSTtBQUMxQixVQUFJLE1BQU0sT0FBVyxHQUFFLE9BQU8sS0FBSyxNQUFNLEVBQUU7QUFDM0MsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLHVCQUF3QixNQUFNO0FBQ3JDLFVBQUk7QUFFSixVQUFJLEtBQUssU0FBUyxFQUFHLE9BQU0sS0FBSyxDQUFDO0FBRWpDLFVBQUksZUFBZSxVQUFVLE1BQU8sT0FBTSxPQUFPLGdCQUFnQixHQUFHO0FBRXBFLFVBQUksTUFBTSxtQkFBbUI7QUFDM0IsY0FBTSxrQkFBa0IsS0FBSyxRQUFRLFVBQVUsSUFBSTtBQUFBLE1BQ3JEO0FBRUEscUJBQWUsTUFBTTtBQUFFLGNBQU07QUFBQSxNQUFJLENBQUM7QUFBQSxJQUNwQztBQUVBLFdBQU8sVUFBVSxVQUFVLE1BQU0sYUFBYTtBQUFBLE1BQzVDLGNBQWU7QUFDYixhQUFLLFVBQVUsdUJBQU8sT0FBTyxJQUFJO0FBQUEsTUFDbkM7QUFBQSxNQUVBLFlBQWEsTUFBTSxJQUFJO0FBQ3JCLGVBQU8sZUFBZSxNQUFNLE1BQU0sSUFBSSxLQUFLO0FBQUEsTUFDN0M7QUFBQSxNQUVBLGdCQUFpQixNQUFNLElBQUk7QUFDekIsZUFBTyxlQUFlLE1BQU0sTUFBTSxJQUFJLElBQUk7QUFBQSxNQUM1QztBQUFBLE1BRUEsZ0JBQWlCLE1BQU0sSUFBSTtBQUN6QixlQUFPLGdCQUFnQixNQUFNLE1BQU0sSUFBSSxLQUFLO0FBQUEsTUFDOUM7QUFBQSxNQUVBLG9CQUFxQixNQUFNLElBQUk7QUFDN0IsZUFBTyxnQkFBZ0IsTUFBTSxNQUFNLElBQUksSUFBSTtBQUFBLE1BQzdDO0FBQUEsTUFFQSxlQUFnQixNQUFNLElBQUk7QUFDeEIsZUFBTyxlQUFlLE1BQU0sTUFBTSxFQUFFO0FBQUEsTUFDdEM7QUFBQSxNQUVBLEdBQUksTUFBTSxJQUFJO0FBQ1osZUFBTyxlQUFlLE1BQU0sTUFBTSxJQUFJLEtBQUs7QUFBQSxNQUM3QztBQUFBLE1BRUEsS0FBTSxNQUFNLElBQUk7QUFDZCxlQUFPLGVBQWUsTUFBTSxNQUFNLElBQUksSUFBSTtBQUFBLE1BQzVDO0FBQUEsTUFFQSxJQUFLLE1BQU0sSUFBSTtBQUNiLGVBQU8sZUFBZSxNQUFNLE1BQU0sRUFBRTtBQUFBLE1BQ3RDO0FBQUEsTUFFQSxLQUFNLFNBQVMsTUFBTTtBQUNuQixZQUFJLFNBQVMsV0FBVyxLQUFLLFFBQVEsVUFBVSxPQUFXLHFCQUFvQixHQUFHLElBQUk7QUFDckYsY0FBTSxJQUFJLEtBQUssUUFBUSxJQUFJO0FBQzNCLGVBQU8sTUFBTSxTQUFZLFFBQVEsRUFBRSxLQUFLLE1BQU0sTUFBTSxHQUFHLElBQUk7QUFBQSxNQUM3RDtBQUFBLE1BRUEsVUFBVyxNQUFNO0FBQ2YsY0FBTSxJQUFJLEtBQUssUUFBUSxJQUFJO0FBQzNCLGVBQU8sTUFBTSxTQUFZLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxJQUFJO0FBQUEsTUFDMUM7QUFBQSxNQUVBLGNBQWUsTUFBTTtBQUNuQixjQUFNLElBQUksS0FBSyxRQUFRLElBQUk7QUFDM0IsZUFBTyxNQUFNLFNBQVksSUFBSSxFQUFFLEtBQUs7QUFBQSxNQUN0QztBQUFBLE1BRUEsa0JBQW1CO0FBQ2pCLGVBQU8sYUFBYTtBQUFBLE1BQ3RCO0FBQUEsTUFFQSxnQkFBaUIsR0FBRztBQUFBLE1BQUM7QUFBQSxNQUVyQixtQkFBb0IsTUFBTTtBQUN4QixZQUFJLFVBQVUsV0FBVyxHQUFHO0FBQzFCLHFCQUFXLE9BQU8sUUFBUSxRQUFRLEtBQUssT0FBTyxHQUFHO0FBQy9DLGdCQUFJLFFBQVEsaUJBQWtCO0FBQzlCLGlCQUFLLG1CQUFtQixHQUFHO0FBQUEsVUFDN0I7QUFDQSxlQUFLLG1CQUFtQixnQkFBZ0I7QUFBQSxRQUMxQyxPQUFPO0FBQ0wsZ0JBQU0sSUFBSSxLQUFLLFFBQVEsSUFBSTtBQUMzQixjQUFJLE1BQU0sT0FBVyxHQUFFLFVBQVUsTUFBTSxJQUFJO0FBQUEsUUFDN0M7QUFDQSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxZQUFRLGVBQWU7QUFFdkIsWUFBUSxTQUFTO0FBRWpCLFlBQVEsc0JBQXNCO0FBRTlCLFlBQVEsS0FBSyxTQUFTLEdBQUksU0FBUyxNQUFNLE9BQU8sQ0FBQyxHQUFHO0FBQ2xELFlBQU07QUFBQSxRQUNKO0FBQUEsTUFDRixJQUFJO0FBRUosVUFBSSxVQUFVLE9BQU8sU0FBUztBQUM1QixjQUFNLE9BQU8sa0JBQWtCLE9BQU8sTUFBTTtBQUFBLE1BQzlDO0FBRUEsVUFBSSxRQUFRO0FBQ1osVUFBSSxPQUFPO0FBRVgsWUFBTSxTQUFTLENBQUM7QUFDaEIsWUFBTSxXQUFXLENBQUM7QUFFbEIsY0FBUSxHQUFHLE1BQU0sT0FBTztBQUV4QixVQUFJLFNBQVMsUUFBUyxTQUFRLEdBQUcsU0FBUyxPQUFPO0FBRWpELFVBQUksT0FBUSxRQUFPLGlCQUFpQixTQUFTLE9BQU87QUFFcEQsYUFBTztBQUFBLFFBQ0wsT0FBUTtBQUNOLGNBQUksT0FBTyxRQUFRO0FBQ2pCLG1CQUFPLFFBQVEsUUFBUSxFQUFFLE9BQU8sT0FBTyxNQUFNLEdBQUcsTUFBTSxNQUFNLENBQUM7QUFBQSxVQUMvRDtBQUVBLGNBQUksT0FBTztBQUNULGtCQUFNLE1BQU07QUFFWixvQkFBUTtBQUVSLG1CQUFPLFFBQVEsT0FBTyxHQUFHO0FBQUEsVUFDM0I7QUFFQSxjQUFJLEtBQU0sUUFBTyxRQUFRO0FBRXpCLGlCQUFPLElBQUk7QUFBQSxZQUFRLENBQUMsU0FBUyxXQUMzQixTQUFTLEtBQUssRUFBRSxTQUFTLE9BQU8sQ0FBQztBQUFBLFVBQ25DO0FBQUEsUUFDRjtBQUFBLFFBRUEsU0FBVTtBQUNSLGlCQUFPLFFBQVE7QUFBQSxRQUNqQjtBQUFBLFFBRUEsTUFBTyxLQUFLO0FBQ1YsaUJBQU8sUUFBUSxHQUFHO0FBQUEsUUFDcEI7QUFBQSxRQUVBLENBQUMsT0FBTyxhQUFhLElBQUs7QUFDeEIsaUJBQU87QUFBQSxRQUNUO0FBQUEsTUFDRjtBQUVBLGVBQVMsV0FBWSxNQUFNO0FBQ3pCLFlBQUksU0FBUyxRQUFRO0FBQ25CLG1CQUFTLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxNQUFNLE1BQU0sTUFBTSxDQUFDO0FBQUEsUUFDdkQsT0FBTztBQUNMLGlCQUFPLEtBQUssSUFBSTtBQUFBLFFBQ2xCO0FBQUEsTUFDRjtBQUVBLGVBQVMsUUFBUyxLQUFLO0FBQ3JCLFlBQUksU0FBUyxRQUFRO0FBQ25CLG1CQUFTLE1BQU0sRUFBRSxPQUFPLEdBQUc7QUFBQSxRQUM3QixPQUFPO0FBQ0wsa0JBQVE7QUFBQSxRQUNWO0FBRUEsZUFBTyxRQUFRLFFBQVEsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUFBLE1BQ3ZDO0FBRUEsZUFBUyxVQUFXO0FBQ2xCLGdCQUFRLE9BQU8sa0JBQWtCLE9BQU8sTUFBTSxDQUFDO0FBQUEsTUFDakQ7QUFFQSxlQUFTLFVBQVc7QUFDbEIsZ0JBQVEsSUFBSSxNQUFNLE9BQU87QUFFekIsWUFBSSxTQUFTLFFBQVMsU0FBUSxJQUFJLFNBQVMsT0FBTztBQUVsRCxZQUFJLE9BQVEsUUFBTyxvQkFBb0IsU0FBUyxPQUFPO0FBRXZELGVBQU87QUFFUCxZQUFJLFNBQVMsT0FBUSxVQUFTLE1BQU0sRUFBRSxRQUFRLEVBQUUsTUFBTSxLQUFLLENBQUM7QUFFNUQsZUFBTyxRQUFRLFFBQVEsRUFBRSxNQUFNLEtBQUssQ0FBQztBQUFBLE1BQ3ZDO0FBQUEsSUFDRjtBQUVBLFlBQVEsT0FBTyxTQUFTLEtBQU0sU0FBUyxNQUFNLE9BQU8sQ0FBQyxHQUFHO0FBQ3RELFlBQU07QUFBQSxRQUNKO0FBQUEsTUFDRixJQUFJO0FBRUosVUFBSSxVQUFVLE9BQU8sU0FBUztBQUM1QixjQUFNLE9BQU8sa0JBQWtCLE9BQU8sTUFBTTtBQUFBLE1BQzlDO0FBRUEsYUFBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVc7QUFDdEMsWUFBSSxTQUFTLFFBQVMsU0FBUSxHQUFHLFNBQVMsT0FBTztBQUVqRCxZQUFJLE9BQVEsUUFBTyxpQkFBaUIsU0FBUyxPQUFPO0FBRXBELGdCQUFRLEtBQUssTUFBTSxJQUFJLFNBQVM7QUFDOUIsY0FBSSxTQUFTLFFBQVMsU0FBUSxJQUFJLFNBQVMsT0FBTztBQUVsRCxjQUFJLE9BQVEsUUFBTyxvQkFBb0IsU0FBUyxPQUFPO0FBRXZELGtCQUFRLElBQUk7QUFBQSxRQUNkLENBQUM7QUFFRCxpQkFBUyxRQUFTLEtBQUs7QUFDckIsa0JBQVEsSUFBSSxTQUFTLE9BQU87QUFFNUIsaUJBQU8sR0FBRztBQUFBLFFBQ1o7QUFFQSxpQkFBUyxVQUFXO0FBQ2xCLGlCQUFPLG9CQUFvQixTQUFTLE9BQU87QUFFM0Msa0JBQVEsT0FBTyxrQkFBa0IsT0FBTyxNQUFNLENBQUM7QUFBQSxRQUNqRDtBQUFBLE1BQ0YsQ0FBQztBQUFBLElBQ0g7QUFFQSxZQUFRLFVBQVUsU0FBUyxRQUFTLE1BQU0sSUFBSSxPQUFPLE9BQU8sQ0FBQyxHQUFHO0FBQzlELFVBQUksT0FBTyxVQUFVLFNBQVUsU0FBUSxDQUFDLEtBQUs7QUFFN0MsWUFBTTtBQUFBLFFBQ0osT0FBTyxHQUFHLEtBQUssS0FBSyxFQUFFO0FBQUEsTUFDeEIsSUFBSTtBQUVKLFlBQU0sWUFBWSxNQUFNLElBQUksQ0FBQyxTQUFTLFNBQVMsV0FBWSxNQUFNO0FBQy9ELGFBQUssTUFBTSxHQUFHLElBQUk7QUFBQSxNQUNwQixDQUFDO0FBRUQsU0FDRyxHQUFHLGVBQWUsQ0FBQyxTQUFTO0FBQzNCLGNBQU0sSUFBSSxNQUFNLFFBQVEsSUFBSTtBQUU1QixZQUFJLE1BQU0sTUFBTSxHQUFHLGNBQWMsSUFBSSxNQUFNLEdBQUc7QUFDNUMsZUFBSyxHQUFHLE1BQU0sVUFBVSxDQUFDLENBQUM7QUFBQSxRQUM1QjtBQUFBLE1BQ0YsQ0FBQyxFQUNBLEdBQUcsa0JBQWtCLENBQUMsU0FBUztBQUM5QixjQUFNLElBQUksTUFBTSxRQUFRLElBQUk7QUFFNUIsWUFBSSxNQUFNLE1BQU0sR0FBRyxjQUFjLElBQUksTUFBTSxHQUFHO0FBQzVDLGVBQUssSUFBSSxNQUFNLFVBQVUsQ0FBQyxDQUFDO0FBQUEsUUFDN0I7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNMO0FBRUEsWUFBUSxnQkFBZ0IsU0FBUyxjQUFlLFNBQVMsTUFBTTtBQUM3RCxhQUFPLFFBQVEsY0FBYyxJQUFJO0FBQUEsSUFDbkM7QUFBQTtBQUFBOzs7QUMvVUE7QUFBQTtBQUFBLFdBQU8sVUFBVSxPQUFPLG1CQUFtQixhQUFhLGlCQUFpQixDQUFDLE9BQU8sUUFBUSxRQUFRLEVBQUUsS0FBSyxFQUFFO0FBQUE7QUFBQTs7O0FDQTFHO0FBQUE7QUFBQSxXQUFPLFVBQVUsTUFBTSxVQUFVO0FBQUEsTUFDL0IsWUFBYSxLQUFLO0FBQ2hCLFlBQUksRUFBRSxNQUFNLE9BQVEsTUFBTSxJQUFLLFNBQVMsRUFBRyxPQUFNLElBQUksTUFBTSxtREFBbUQ7QUFDOUcsYUFBSyxTQUFTLElBQUksTUFBTSxHQUFHO0FBQzNCLGFBQUssT0FBTyxNQUFNO0FBQ2xCLGFBQUssTUFBTTtBQUNYLGFBQUssTUFBTTtBQUNYLGFBQUssT0FBTztBQUFBLE1BQ2Q7QUFBQSxNQUVBLFFBQVM7QUFDUCxhQUFLLE1BQU0sS0FBSyxNQUFNO0FBQ3RCLGFBQUssT0FBTztBQUNaLGFBQUssT0FBTyxLQUFLLE1BQVM7QUFBQSxNQUM1QjtBQUFBLE1BRUEsS0FBTSxNQUFNO0FBQ1YsWUFBSSxLQUFLLE9BQU8sS0FBSyxHQUFHLE1BQU0sT0FBVyxRQUFPO0FBQ2hELGFBQUssT0FBTyxLQUFLLEdBQUcsSUFBSTtBQUN4QixhQUFLLE1BQU8sS0FBSyxNQUFNLElBQUssS0FBSztBQUNqQyxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsUUFBUztBQUNQLGNBQU0sT0FBTyxLQUFLLE9BQU8sS0FBSyxHQUFHO0FBQ2pDLFlBQUksU0FBUyxPQUFXLFFBQU87QUFDL0IsYUFBSyxPQUFPLEtBQUssR0FBRyxJQUFJO0FBQ3hCLGFBQUssTUFBTyxLQUFLLE1BQU0sSUFBSyxLQUFLO0FBQ2pDLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxPQUFRO0FBQ04sZUFBTyxLQUFLLE9BQU8sS0FBSyxHQUFHO0FBQUEsTUFDN0I7QUFBQSxNQUVBLFVBQVc7QUFDVCxlQUFPLEtBQUssT0FBTyxLQUFLLEdBQUcsTUFBTTtBQUFBLE1BQ25DO0FBQUEsSUFDRjtBQUFBO0FBQUE7OztBQ3RDQTtBQUFBO0FBQUEsUUFBTSxZQUFZO0FBRWxCLFdBQU8sVUFBVSxNQUFNLFNBQVM7QUFBQSxNQUM5QixZQUFhLEtBQUs7QUFDaEIsYUFBSyxNQUFNLE9BQU87QUFDbEIsYUFBSyxPQUFPLElBQUksVUFBVSxLQUFLLEdBQUc7QUFDbEMsYUFBSyxPQUFPLEtBQUs7QUFDakIsYUFBSyxTQUFTO0FBQUEsTUFDaEI7QUFBQSxNQUVBLFFBQVM7QUFDUCxhQUFLLE9BQU8sS0FBSztBQUNqQixhQUFLLEtBQUssTUFBTTtBQUNoQixhQUFLLFNBQVM7QUFBQSxNQUNoQjtBQUFBLE1BRUEsS0FBTSxLQUFLO0FBQ1QsYUFBSztBQUNMLFlBQUksQ0FBQyxLQUFLLEtBQUssS0FBSyxHQUFHLEdBQUc7QUFDeEIsZ0JBQU0sT0FBTyxLQUFLO0FBQ2xCLGVBQUssT0FBTyxLQUFLLE9BQU8sSUFBSSxVQUFVLElBQUksS0FBSyxLQUFLLE9BQU8sTUFBTTtBQUNqRSxlQUFLLEtBQUssS0FBSyxHQUFHO0FBQUEsUUFDcEI7QUFBQSxNQUNGO0FBQUEsTUFFQSxRQUFTO0FBQ1AsWUFBSSxLQUFLLFdBQVcsRUFBRyxNQUFLO0FBQzVCLGNBQU0sTUFBTSxLQUFLLEtBQUssTUFBTTtBQUM1QixZQUFJLFFBQVEsVUFBYSxLQUFLLEtBQUssTUFBTTtBQUN2QyxnQkFBTSxPQUFPLEtBQUssS0FBSztBQUN2QixlQUFLLEtBQUssT0FBTztBQUNqQixlQUFLLE9BQU87QUFDWixpQkFBTyxLQUFLLEtBQUssTUFBTTtBQUFBLFFBQ3pCO0FBRUEsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLE9BQVE7QUFDTixjQUFNLE1BQU0sS0FBSyxLQUFLLEtBQUs7QUFDM0IsWUFBSSxRQUFRLFVBQWEsS0FBSyxLQUFLLEtBQU0sUUFBTyxLQUFLLEtBQUssS0FBSyxLQUFLO0FBQ3BFLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxVQUFXO0FBQ1QsZUFBTyxLQUFLLFdBQVc7QUFBQSxNQUN6QjtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUMvQ0E7QUFBQTtBQUFBLFdBQU8sVUFBVSxNQUFNLGVBQWU7QUFBQSxNQUNwQyxZQUFhLFVBQVU7QUFDckIsYUFBSyxVQUFVLElBQUksWUFBWSxhQUFhLFlBQVksYUFBYSxRQUFRO0FBQUEsTUFDL0U7QUFBQSxNQUVBLElBQUksWUFBYTtBQUNmLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxPQUFRLE1BQU07QUFDWixlQUFPLEtBQUssUUFBUSxPQUFPLE1BQU0sRUFBRSxRQUFRLEtBQUssQ0FBQztBQUFBLE1BQ25EO0FBQUEsTUFFQSxRQUFTO0FBQ1AsZUFBTyxLQUFLLFFBQVEsT0FBTyxJQUFJLFdBQVcsQ0FBQyxDQUFDO0FBQUEsTUFDOUM7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDaEJBO0FBQUE7QUFBQSxRQUFNLHFCQUFxQjtBQUMzQixRQUFNLGNBQWM7QUFFcEIsV0FBTyxVQUFVLE1BQU0sWUFBWTtBQUFBLE1BQ2pDLFlBQWEsV0FBVyxRQUFRO0FBQzlCLGFBQUssV0FBVyxrQkFBa0IsUUFBUTtBQUUxQyxnQkFBUSxLQUFLLFVBQVU7QUFBQSxVQUNyQixLQUFLO0FBQ0gsaUJBQUssVUFBVSxJQUFJLFlBQVk7QUFDL0I7QUFBQSxVQUNGLEtBQUs7QUFBQSxVQUNMLEtBQUs7QUFDSCxrQkFBTSxJQUFJLE1BQU0sMkJBQTJCLEtBQUssUUFBUTtBQUFBLFVBQzFEO0FBQ0UsaUJBQUssVUFBVSxJQUFJLG1CQUFtQixLQUFLLFFBQVE7QUFBQSxRQUN2RDtBQUFBLE1BQ0Y7QUFBQSxNQUVBLElBQUksWUFBYTtBQUNmLGVBQU8sS0FBSyxRQUFRO0FBQUEsTUFDdEI7QUFBQSxNQUVBLEtBQU0sTUFBTTtBQUNWLFlBQUksT0FBTyxTQUFTLFNBQVUsUUFBTztBQUNyQyxlQUFPLEtBQUssUUFBUSxPQUFPLElBQUk7QUFBQSxNQUNqQztBQUFBO0FBQUEsTUFHQSxNQUFPLE1BQU07QUFDWCxlQUFPLEtBQUssS0FBSyxJQUFJO0FBQUEsTUFDdkI7QUFBQSxNQUVBLElBQUssTUFBTTtBQUNULFlBQUksU0FBUztBQUNiLFlBQUksS0FBTSxVQUFTLEtBQUssS0FBSyxJQUFJO0FBQ2pDLGtCQUFVLEtBQUssUUFBUSxNQUFNO0FBQzdCLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLGFBQVMsa0JBQW1CLFVBQVU7QUFDcEMsaUJBQVcsU0FBUyxZQUFZO0FBRWhDLGNBQVEsVUFBVTtBQUFBLFFBQ2hCLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1Q7QUFDRSxnQkFBTSxJQUFJLE1BQU0sdUJBQXVCLFFBQVE7QUFBQSxNQUNuRDtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUMvREE7QUFBQTtBQUFBLFFBQU0sRUFBRSxhQUFhLElBQUk7QUFDekIsUUFBTSxtQkFBbUIsSUFBSSxNQUFNLHNCQUFzQjtBQUN6RCxRQUFNLGtCQUFrQixJQUFJLE1BQU0saUJBQWlCO0FBRW5ELFFBQU0sWUFBWTtBQUNsQixRQUFNLE9BQU87QUFDYixRQUFNQSxlQUFjO0FBS3BCLFFBQU0sT0FBUSxLQUFLLE1BQU07QUFHekIsUUFBTSxVQUFnQjtBQUN0QixRQUFNLGdCQUFnQjtBQUN0QixRQUFNLGFBQWdCO0FBQ3RCLFFBQU0sWUFBZ0I7QUFFdEIsUUFBTSxjQUFjLE1BQU07QUFDMUIsUUFBTSxvQkFBb0IsTUFBTTtBQUdoQyxRQUFNLGNBQXdCLEtBQW9CO0FBQ2xELFFBQU0sZ0JBQXdCLEtBQW9CO0FBQ2xELFFBQU0sZUFBd0IsS0FBb0I7QUFDbEQsUUFBTSxjQUF3QixLQUFvQjtBQUNsRCxRQUFNLGVBQXdCLE1BQW9CO0FBQ2xELFFBQU0sb0JBQXdCLE1BQW9CO0FBQ2xELFFBQU0sY0FBd0IsTUFBb0I7QUFDbEQsUUFBTSxpQkFBd0IsT0FBb0I7QUFDbEQsUUFBTSxxQkFBd0IsT0FBb0I7QUFDbEQsUUFBTSx3QkFBd0IsT0FBb0I7QUFDbEQsUUFBTSxZQUF3QixRQUFvQjtBQUNsRCxRQUFNLGlCQUF3QixRQUFvQjtBQUNsRCxRQUFNLGtCQUF3QixRQUFvQjtBQUNsRCxRQUFNLGtCQUF3QixRQUFvQjtBQUdsRCxRQUFNLGVBQWUsZUFBZTtBQUNwQyxRQUFNLDZCQUE2QixjQUFjO0FBQ2pELFFBQU0sMEJBQTBCLGVBQWU7QUFDL0MsUUFBTSxnQ0FBZ0MscUJBQXFCO0FBQzNELFFBQU0sMEJBQTBCLGVBQWU7QUFFL0MsUUFBTSxrQkFBOEIsTUFBTTtBQUMxQyxRQUFNLG1CQUE4QixNQUFNO0FBQzFDLFFBQU0sOEJBQThCLE9BQU8sZUFBZTtBQUMxRCxRQUFNLGNBQThCLE1BQU07QUFDMUMsUUFBTSxjQUE4QixNQUFNO0FBQzFDLFFBQU0sa0JBQThCLE9BQU8sY0FBYztBQUN6RCxRQUFNLGtCQUE4QixNQUFNO0FBQzFDLFFBQU0sd0JBQThCLE1BQU07QUFDMUMsUUFBTSxxQkFBOEIsTUFBTTtBQUMxQyxRQUFNLG9CQUE4QixNQUFNO0FBQzFDLFFBQU0scUJBQThCLE1BQU07QUFDMUMsUUFBTSw0QkFBOEIsTUFBTTtBQUcxQyxRQUFNLGVBQW1CLEtBQWlCO0FBQzFDLFFBQU0saUJBQW1CLEtBQWlCO0FBQzFDLFFBQU0sZ0JBQW1CLEtBQWlCO0FBQzFDLFFBQU0sZUFBbUIsS0FBaUI7QUFDMUMsUUFBTSxrQkFBbUIsTUFBaUI7QUFDMUMsUUFBTSxhQUFtQixNQUFpQjtBQUMxQyxRQUFNLG1CQUFtQixNQUFpQjtBQUMxQyxRQUFNLGtCQUFtQixPQUFpQjtBQUMxQyxRQUFNQyxpQkFBbUIsT0FBaUI7QUFDMUMsUUFBTSxrQkFBbUIsT0FBaUI7QUFDMUMsUUFBTSxlQUFtQixRQUFpQjtBQUUxQyxRQUFNLG1CQUFzQixPQUFPLGVBQWVBO0FBQ2xELFFBQU0sb0JBQXNCLE1BQU07QUFDbEMsUUFBTSxzQkFBc0IsT0FBTyxlQUFlO0FBQ2xELFFBQU0sZ0JBQXNCLE1BQU07QUFDbEMsUUFBTSxtQkFBc0IsTUFBTTtBQUNsQyxRQUFNLHNCQUFzQixNQUFNO0FBQ2xDLFFBQU0scUJBQXNCLE1BQU07QUFDbEMsUUFBTSxtQkFBc0IsTUFBTTtBQUdsQyxRQUFNLFNBQVMsY0FBYztBQUM3QixRQUFNLGFBQWEsTUFBTTtBQUN6QixRQUFNLE9BQU8sWUFBWTtBQUN6QixRQUFNLGlCQUFpQixhQUFhLFlBQVk7QUFDaEQsUUFBTSxjQUFjLGlCQUFpQjtBQUNyQyxRQUFNLGVBQWUsaUJBQWlCO0FBQ3RDLFFBQU0sY0FBYyxvQkFBb0I7QUFDeEMsUUFBTSxvQkFBb0Isa0JBQWtCO0FBQzVDLFFBQU0sVUFBVSxvQkFBb0I7QUFDcEMsUUFBTSxhQUFhLGNBQWM7QUFHakMsUUFBTSxzQkFBc0IsY0FBYyxjQUFjO0FBQ3hELFFBQU0sY0FBYyxjQUFjLFlBQVk7QUFDOUMsUUFBTSxxQkFBcUIsY0FBYyxjQUFjO0FBQ3ZELFFBQU0sdUJBQXVCLGNBQWMscUJBQXFCLGNBQWM7QUFDOUUsUUFBTSxrQkFBa0IsY0FBYyxjQUFjLGNBQWMsWUFBWSxrQkFBa0I7QUFDaEcsUUFBTSwyQkFBMkIsaUJBQWlCLGNBQWM7QUFDaEUsUUFBTSwwQkFBMEIsZ0JBQWdCLGNBQWMsaUJBQWlCO0FBQy9FLFFBQU0sNEJBQTRCLGlCQUFpQjtBQUduRCxRQUFNLHVCQUF1QixjQUFjLGtCQUFrQjtBQUM3RCxRQUFNLDZCQUE2QixlQUFlO0FBQ2xELFFBQU0sMEJBQTBCLGVBQWU7QUFDL0MsUUFBTSxxQkFBcUIsZUFBZSxrQkFBa0IsY0FBYztBQUMxRSxRQUFNLGVBQWUsY0FBYyxlQUFlLGVBQWU7QUFDakUsUUFBTSwyQkFBMkIsZ0JBQWdCO0FBQ2pELFFBQU0sMkJBQTJCLGVBQWVBO0FBQ2hELFFBQU0seUJBQXlCLGNBQWMsa0JBQWtCLDBCQUEwQjtBQUN6RixRQUFNLDRCQUE0QixrQkFBa0IsaUJBQWlCLGtCQUFrQjtBQUN2RixRQUFNLDJCQUEyQixpQkFBaUIsY0FBYyxrQkFBa0I7QUFDbEYsUUFBTSxrQkFBa0Isa0JBQWtCLGFBQWE7QUFFdkQsUUFBTSxnQkFBZ0IsT0FBTyxpQkFBaUIsT0FBTyxlQUFlO0FBRXBFLFFBQU0sZ0JBQU4sTUFBb0I7QUFBQSxNQUNsQixZQUFhLFFBQVEsRUFBRSxnQkFBZ0IsT0FBTyxNQUFNLE1BQU0sYUFBYSxZQUFZLG1CQUFtQixJQUFJLENBQUMsR0FBRztBQUM1RyxhQUFLLFNBQVM7QUFDZCxhQUFLLFFBQVEsSUFBSSxLQUFLO0FBQ3RCLGFBQUssZ0JBQWdCO0FBQ3JCLGFBQUssV0FBVztBQUNoQixhQUFLLFFBQVE7QUFDYixhQUFLLFdBQVc7QUFDaEIsYUFBSyxTQUFTO0FBQ2QsYUFBSyxhQUFhLHNCQUFzQixjQUFjO0FBQ3RELGFBQUssTUFBTSxlQUFlO0FBQzFCLGFBQUssYUFBYSxXQUFXLEtBQUssSUFBSTtBQUN0QyxhQUFLLHNCQUFzQixjQUFjLEtBQUssSUFBSTtBQUFBLE1BQ3BEO0FBQUEsTUFFQSxJQUFJLFFBQVM7QUFDWCxnQkFBUSxLQUFLLE9BQU8sZUFBZSxnQkFBZ0I7QUFBQSxNQUNyRDtBQUFBLE1BRUEsS0FBTSxNQUFNO0FBQ1YsYUFBSyxLQUFLLE9BQU8sZUFBZSxxQkFBcUIsRUFBRyxRQUFPO0FBQy9ELFlBQUksS0FBSyxRQUFRLEtBQU0sUUFBTyxLQUFLLElBQUksSUFBSTtBQUUzQyxhQUFLLFlBQVksS0FBSyxXQUFXLElBQUk7QUFDckMsYUFBSyxNQUFNLEtBQUssSUFBSTtBQUVwQixZQUFJLEtBQUssV0FBVyxLQUFLLGVBQWU7QUFDdEMsZUFBSyxPQUFPLGdCQUFnQjtBQUM1QixpQkFBTztBQUFBLFFBQ1Q7QUFFQSxhQUFLLE9BQU8sZ0JBQWdCO0FBQzVCLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxRQUFTO0FBQ1AsY0FBTSxPQUFPLEtBQUssTUFBTSxNQUFNO0FBRTlCLGFBQUssWUFBWSxLQUFLLFdBQVcsSUFBSTtBQUNyQyxZQUFJLEtBQUssYUFBYSxFQUFHLE1BQUssT0FBTyxnQkFBZ0I7QUFFckQsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLElBQUssTUFBTTtBQUNULFlBQUksT0FBTyxTQUFTLFdBQVksTUFBSyxPQUFPLEtBQUssVUFBVSxJQUFJO0FBQUEsaUJBQ3RELFNBQVMsVUFBYSxTQUFTLEtBQU0sTUFBSyxLQUFLLElBQUk7QUFDNUQsYUFBSyxPQUFPLGdCQUFnQixLQUFLLE9BQU8sZUFBZSxtQkFBbUI7QUFBQSxNQUM1RTtBQUFBLE1BRUEsVUFBVyxNQUFNLElBQUk7QUFDbkIsY0FBTSxTQUFTLENBQUM7QUFDaEIsY0FBTSxTQUFTLEtBQUs7QUFFcEIsZUFBTyxLQUFLLElBQUk7QUFDaEIsZ0JBQVEsT0FBTyxlQUFlLGtCQUFrQix5QkFBeUI7QUFDdkUsaUJBQU8sS0FBSyxPQUFPLGVBQWUsTUFBTSxDQUFDO0FBQUEsUUFDM0M7QUFFQSxhQUFLLE9BQU8sZUFBZSxpQkFBaUIsRUFBRyxRQUFPLEdBQUcsSUFBSTtBQUM3RCxlQUFPLFFBQVEsUUFBUSxFQUFFO0FBQUEsTUFDM0I7QUFBQSxNQUVBLFNBQVU7QUFDUixjQUFNLFNBQVMsS0FBSztBQUVwQixlQUFPLGdCQUFnQjtBQUV2QixXQUFHO0FBQ0Qsa0JBQVEsT0FBTyxlQUFlLGtCQUFrQixjQUFjO0FBQzVELGtCQUFNLE9BQU8sS0FBSyxNQUFNO0FBQ3hCLG1CQUFPLGdCQUFnQjtBQUN2QixtQkFBTyxPQUFPLE1BQU0sS0FBSyxVQUFVO0FBQUEsVUFDckM7QUFFQSxlQUFLLE9BQU8sZUFBZSw4QkFBOEIsRUFBRyxNQUFLLGlCQUFpQjtBQUFBLFFBQ3BGLFNBQVMsS0FBSyxlQUFlLE1BQU07QUFFbkMsZUFBTyxnQkFBZ0I7QUFBQSxNQUN6QjtBQUFBLE1BRUEsbUJBQW9CO0FBQ2xCLGNBQU0sU0FBUyxLQUFLO0FBRXBCLGFBQUssT0FBTyxlQUFlLDRCQUE0QixpQkFBaUI7QUFDdEUsaUJBQU8sZUFBZSxPQUFPLGVBQWU7QUFDNUMsaUJBQU8sT0FBTyxXQUFXLEtBQUssSUFBSSxDQUFDO0FBQ25DO0FBQUEsUUFDRjtBQUVBLGFBQUssT0FBTyxlQUFlLG9CQUFvQixZQUFZO0FBQ3pELGVBQUssT0FBTyxlQUFlLHVCQUF1QixHQUFHO0FBQ25ELG1CQUFPLGdCQUFnQjtBQUN2QixtQkFBTyxTQUFTLGFBQWEsS0FBSyxJQUFJLENBQUM7QUFBQSxVQUN6QztBQUNBO0FBQUEsUUFDRjtBQUVBLGFBQUssT0FBTyxlQUFlLGdCQUFnQixTQUFTO0FBQ2xELGlCQUFPLGdCQUFnQixPQUFPLGVBQWUsVUFBVTtBQUN2RCxpQkFBTyxNQUFNLFVBQVUsS0FBSyxJQUFJLENBQUM7QUFBQSxRQUNuQztBQUFBLE1BQ0Y7QUFBQSxNQUVBLGlCQUFrQjtBQUNoQixhQUFLLEtBQUssT0FBTyxlQUFlLHFCQUFxQixFQUFHLFFBQU87QUFDL0QsYUFBSyxPQUFPLGdCQUFnQjtBQUM1QixlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsaUJBQWtCO0FBQ2hCLGFBQUssS0FBSyxPQUFPLGVBQWUsOEJBQThCLGNBQWUsTUFBSyxPQUFPO0FBQUEsWUFDcEYsTUFBSyxlQUFlO0FBQUEsTUFDM0I7QUFBQSxNQUVBLGlCQUFrQjtBQUNoQixhQUFLLEtBQUssT0FBTyxlQUFlLHFCQUFxQixFQUFHO0FBQ3hELGFBQUssT0FBTyxnQkFBZ0I7QUFDNUIsYUFBSyxLQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRyxXQUFVLEtBQUssbUJBQW1CO0FBQUEsTUFDM0Y7QUFBQSxJQUNGO0FBRUEsUUFBTSxnQkFBTixNQUFvQjtBQUFBLE1BQ2xCLFlBQWEsUUFBUSxFQUFFLGdCQUFnQixPQUFPLE1BQU0sTUFBTSxhQUFhLFlBQVksbUJBQW1CLElBQUksQ0FBQyxHQUFHO0FBQzVHLGFBQUssU0FBUztBQUNkLGFBQUssUUFBUSxJQUFJLEtBQUs7QUFDdEIsYUFBSyxnQkFBZ0Isa0JBQWtCLElBQUksSUFBSTtBQUMvQyxhQUFLLFdBQVc7QUFDaEIsYUFBSyxZQUFZLGdCQUFnQjtBQUNqQyxhQUFLLFFBQVE7QUFDYixhQUFLLFdBQVc7QUFDaEIsYUFBSyxhQUFhLHNCQUFzQixjQUFjO0FBQ3RELGFBQUssTUFBTSxlQUFlO0FBQzFCLGFBQUssU0FBUztBQUNkLGFBQUssWUFBWSxVQUFVLEtBQUssSUFBSTtBQUNwQyxhQUFLLHNCQUFzQixhQUFhLEtBQUssSUFBSTtBQUFBLE1BQ25EO0FBQUEsTUFFQSxJQUFJLFFBQVM7QUFDWCxnQkFBUSxLQUFLLE9BQU8sZUFBZSxlQUFlO0FBQUEsTUFDcEQ7QUFBQSxNQUVBLEtBQU0sUUFBUSxJQUFJO0FBQ2hCLFlBQUksS0FBSyxXQUFXLEtBQU0sT0FBTSxJQUFJLE1BQU0sa0NBQWtDO0FBQzVFLFlBQUksT0FBTyxPQUFPLFdBQVksTUFBSztBQUVuQyxhQUFLLE9BQU8sZ0JBQWdCO0FBQzVCLGFBQUssU0FBUztBQUNkLGFBQUssV0FBVyxJQUFJLFNBQVMsS0FBSyxRQUFRLFFBQVEsRUFBRTtBQUVwRCxZQUFJLEdBQUksTUFBSyxPQUFPLEdBQUcsU0FBUyxJQUFJO0FBRXBDLFlBQUlDLFdBQVUsTUFBTSxHQUFHO0FBQ3JCLGlCQUFPLGVBQWUsV0FBVyxLQUFLO0FBQ3RDLGNBQUksR0FBSSxRQUFPLEdBQUcsU0FBUyxJQUFJO0FBQy9CLGlCQUFPLEdBQUcsVUFBVSxLQUFLLFNBQVMsU0FBUyxLQUFLLEtBQUssUUFBUSxDQUFDO0FBQUEsUUFDaEUsT0FBTztBQUNMLGdCQUFNLFVBQVUsS0FBSyxTQUFTLEtBQUssS0FBSyxLQUFLLFVBQVUsTUFBTTtBQUM3RCxnQkFBTSxVQUFVLEtBQUssU0FBUyxLQUFLLEtBQUssS0FBSyxVQUFVLFFBQVEsSUFBSTtBQUNuRSxpQkFBTyxHQUFHLFNBQVMsT0FBTztBQUMxQixpQkFBTyxHQUFHLFNBQVMsT0FBTztBQUMxQixpQkFBTyxHQUFHLFVBQVUsS0FBSyxTQUFTLFNBQVMsS0FBSyxLQUFLLFFBQVEsQ0FBQztBQUFBLFFBQ2hFO0FBRUEsZUFBTyxHQUFHLFNBQVMsV0FBVyxLQUFLLElBQUksQ0FBQztBQUN4QyxhQUFLLE9BQU8sS0FBSyxVQUFVLE1BQU07QUFDakMsZUFBTyxLQUFLLFFBQVEsS0FBSyxNQUFNO0FBQUEsTUFDakM7QUFBQSxNQUVBLEtBQU0sTUFBTTtBQUNWLGNBQU0sU0FBUyxLQUFLO0FBRXBCLFlBQUksU0FBUyxNQUFNO0FBQ2pCLGVBQUssZ0JBQWdCO0FBQ3JCLGlCQUFPLGdCQUFnQixPQUFPLGVBQWUsZUFBZTtBQUM1RCxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLEtBQUssUUFBUSxNQUFNO0FBQ3JCLGlCQUFPLEtBQUssSUFBSSxJQUFJO0FBQ3BCLGNBQUksU0FBUyxNQUFNO0FBQ2pCLG1CQUFPLGdCQUFnQjtBQUN2QixtQkFBTyxLQUFLLFdBQVcsS0FBSztBQUFBLFVBQzlCO0FBQUEsUUFDRjtBQUVBLGFBQUssWUFBWSxLQUFLLFdBQVcsSUFBSTtBQUNyQyxhQUFLLE1BQU0sS0FBSyxJQUFJO0FBRXBCLGVBQU8sZ0JBQWdCLE9BQU8sZUFBZSxlQUFlO0FBRTVELGVBQU8sS0FBSyxXQUFXLEtBQUs7QUFBQSxNQUM5QjtBQUFBLE1BRUEsUUFBUztBQUNQLGNBQU0sT0FBTyxLQUFLLE1BQU0sTUFBTTtBQUU5QixhQUFLLFlBQVksS0FBSyxXQUFXLElBQUk7QUFDckMsWUFBSSxLQUFLLGFBQWEsRUFBRyxNQUFLLE9BQU8sZ0JBQWdCO0FBQ3JELGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxRQUFTLE1BQU07QUFDYixjQUFNLFVBQVUsQ0FBQyxLQUFLLFFBQVEsT0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLElBQUk7QUFDMUQsZUFBTyxLQUFLLFdBQVcsRUFBRyxTQUFRLEtBQUssS0FBSyxNQUFNLENBQUM7QUFFbkQsaUJBQVMsSUFBSSxHQUFHLElBQUksUUFBUSxTQUFTLEdBQUcsS0FBSztBQUMzQyxnQkFBTUMsUUFBTyxRQUFRLENBQUM7QUFDdEIsZUFBSyxZQUFZLEtBQUssV0FBV0EsS0FBSTtBQUNyQyxlQUFLLE1BQU0sS0FBS0EsS0FBSTtBQUFBLFFBQ3RCO0FBRUEsYUFBSyxLQUFLLFFBQVEsUUFBUSxTQUFTLENBQUMsQ0FBQztBQUFBLE1BQ3ZDO0FBQUEsTUFFQSxPQUFRO0FBQ04sY0FBTSxTQUFTLEtBQUs7QUFFcEIsYUFBSyxPQUFPLGVBQWUsaUJBQWlCLGFBQWE7QUFDdkQsZ0JBQU0sT0FBTyxLQUFLLE1BQU07QUFDeEIsY0FBSSxLQUFLLFdBQVcsUUFBUSxLQUFLLE9BQU8sTUFBTSxJQUFJLE1BQU0sTUFBTyxRQUFPLGdCQUFnQjtBQUN0RixlQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRyxRQUFPLEtBQUssUUFBUSxJQUFJO0FBQzFFLGlCQUFPO0FBQUEsUUFDVDtBQUVBLFlBQUksS0FBSyxjQUFjLE9BQU87QUFDNUIsaUJBQU8sZ0JBQWdCO0FBQ3ZCLGVBQUssZUFBZTtBQUFBLFFBQ3RCO0FBRUEsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLFFBQVM7QUFDUCxjQUFNLFNBQVMsS0FBSztBQUVwQixnQkFBUSxPQUFPLGVBQWUsaUJBQWlCLGdCQUFnQixPQUFPLGVBQWUsa0JBQWtCLEdBQUc7QUFDeEcsZ0JBQU0sT0FBTyxLQUFLLE1BQU07QUFDeEIsY0FBSSxLQUFLLFdBQVcsUUFBUSxLQUFLLE9BQU8sTUFBTSxJQUFJLE1BQU0sTUFBTyxRQUFPLGdCQUFnQjtBQUN0RixlQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRyxRQUFPLEtBQUssUUFBUSxJQUFJO0FBQUEsUUFDNUU7QUFBQSxNQUNGO0FBQUEsTUFFQSxTQUFVO0FBQ1IsY0FBTSxTQUFTLEtBQUs7QUFFcEIsZUFBTyxnQkFBZ0I7QUFFdkIsV0FBRztBQUNELGVBQUssTUFBTTtBQUVYLGlCQUFPLEtBQUssV0FBVyxLQUFLLGtCQUFrQixPQUFPLGVBQWUscUJBQXFCLGlCQUFpQjtBQUN4RyxtQkFBTyxnQkFBZ0I7QUFDdkIsbUJBQU8sTUFBTSxLQUFLLFNBQVM7QUFDM0IsaUJBQUssTUFBTTtBQUFBLFVBQ2I7QUFFQSxlQUFLLE9BQU8sZUFBZSwwQkFBMEIsK0JBQStCO0FBQ2xGLG1CQUFPLGdCQUFnQjtBQUN2QixtQkFBTyxLQUFLLFVBQVU7QUFBQSxVQUN4QjtBQUVBLGVBQUssT0FBTyxlQUFlLDZCQUE2QixFQUFHLE1BQUssaUJBQWlCO0FBQUEsUUFDbkYsU0FBUyxLQUFLLGVBQWUsTUFBTTtBQUVuQyxlQUFPLGdCQUFnQjtBQUFBLE1BQ3pCO0FBQUEsTUFFQSxtQkFBb0I7QUFDbEIsY0FBTSxTQUFTLEtBQUs7QUFFcEIsYUFBSyxPQUFPLGVBQWUsd0JBQXdCLGFBQWE7QUFDOUQsaUJBQU8sZ0JBQWdCLE9BQU8sZUFBZSxhQUFhO0FBQzFELGlCQUFPLEtBQUssS0FBSztBQUNqQixlQUFLLE9BQU8sZUFBZSxrQkFBa0IsS0FBTSxRQUFPLGdCQUFnQjtBQUMxRSxjQUFJLEtBQUssV0FBVyxLQUFNLE1BQUssT0FBTyxJQUFJO0FBQUEsUUFDNUM7QUFFQSxhQUFLLE9BQU8sZUFBZSxvQkFBb0IsWUFBWTtBQUN6RCxlQUFLLE9BQU8sZUFBZSx1QkFBdUIsR0FBRztBQUNuRCxtQkFBTyxnQkFBZ0I7QUFDdkIsbUJBQU8sU0FBUyxhQUFhLEtBQUssSUFBSSxDQUFDO0FBQUEsVUFDekM7QUFDQTtBQUFBLFFBQ0Y7QUFFQSxhQUFLLE9BQU8sZUFBZSxnQkFBZ0IsU0FBUztBQUNsRCxpQkFBTyxnQkFBZ0IsT0FBTyxlQUFlLFVBQVU7QUFDdkQsaUJBQU8sTUFBTSxVQUFVLEtBQUssSUFBSSxDQUFDO0FBQUEsUUFDbkM7QUFBQSxNQUNGO0FBQUEsTUFFQSxpQkFBa0I7QUFDaEIsYUFBSyxLQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRyxRQUFPO0FBQzlELGFBQUssT0FBTyxnQkFBZ0I7QUFDNUIsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLGlCQUFrQjtBQUNoQixhQUFLLEtBQUssT0FBTyxlQUFlLDZCQUE2QixhQUFjLE1BQUssT0FBTztBQUFBLFlBQ2xGLE1BQUssZUFBZTtBQUFBLE1BQzNCO0FBQUEsTUFFQSx1QkFBd0I7QUFDdEIsYUFBSyxLQUFLLE9BQU8sZUFBZSwrQkFBK0IsRUFBRztBQUNsRSxhQUFLLE9BQU8sZ0JBQWdCO0FBQzVCLGFBQUssS0FBSyxPQUFPLGVBQWUsbUJBQW1CLEVBQUcsV0FBVSxLQUFLLG1CQUFtQjtBQUFBLE1BQzFGO0FBQUEsTUFFQSxpQkFBa0I7QUFDaEIsYUFBSyxLQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRztBQUN2RCxhQUFLLE9BQU8sZ0JBQWdCO0FBQzVCLGFBQUssS0FBSyxPQUFPLGVBQWUsbUJBQW1CLEVBQUcsV0FBVSxLQUFLLG1CQUFtQjtBQUFBLE1BQzFGO0FBQUEsSUFDRjtBQUVBLFFBQU0saUJBQU4sTUFBcUI7QUFBQSxNQUNuQixZQUFhLFFBQVE7QUFDbkIsYUFBSyxPQUFPO0FBQ1osYUFBSyxpQkFBaUIsZUFBZSxLQUFLLE1BQU07QUFDaEQsYUFBSyxhQUFhO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBRUEsUUFBTSxXQUFOLE1BQWU7QUFBQSxNQUNiLFlBQWEsS0FBSyxLQUFLLElBQUk7QUFDekIsYUFBSyxPQUFPO0FBQ1osYUFBSyxLQUFLO0FBQ1YsYUFBSyxZQUFZO0FBQ2pCLGFBQUssUUFBUTtBQUNiLGFBQUssaUJBQWlCO0FBQUEsTUFDeEI7QUFBQSxNQUVBLFdBQVk7QUFDVixhQUFLLGlCQUFpQjtBQUFBLE1BQ3hCO0FBQUEsTUFFQSxLQUFNLFFBQVEsS0FBSztBQUNqQixZQUFJLElBQUssTUFBSyxRQUFRO0FBRXRCLFlBQUksV0FBVyxLQUFLLElBQUk7QUFDdEIsZUFBSyxLQUFLO0FBRVYsY0FBSSxLQUFLLFNBQVMsTUFBTTtBQUN0QixpQkFBSyxLQUFLLEtBQUssZUFBZSxlQUFlLEtBQUssQ0FBQyxLQUFLLGdCQUFnQjtBQUN0RSxtQkFBSyxLQUFLLFFBQVEsS0FBSyxTQUFTLElBQUksTUFBTSxvQ0FBb0MsQ0FBQztBQUFBLFlBQ2pGO0FBQ0E7QUFBQSxVQUNGO0FBQUEsUUFDRjtBQUVBLFlBQUksV0FBVyxLQUFLLE1BQU07QUFDeEIsZUFBSyxPQUFPO0FBRVosY0FBSSxLQUFLLE9BQU8sTUFBTTtBQUNwQixpQkFBSyxPQUFPLGVBQWUsZUFBZSxHQUFHO0FBQzNDLG1CQUFLLEdBQUcsUUFBUSxLQUFLLFNBQVMsSUFBSSxNQUFNLHNDQUFzQyxDQUFDO0FBQUEsWUFDakY7QUFDQTtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBRUEsWUFBSSxLQUFLLGNBQWMsS0FBTSxNQUFLLFVBQVUsS0FBSyxLQUFLO0FBQ3RELGFBQUssS0FBSyxLQUFLLE9BQU8sS0FBSyxZQUFZO0FBQUEsTUFDekM7QUFBQSxJQUNGO0FBRUEsYUFBUyxhQUFjO0FBQ3JCLFdBQUssT0FBTyxnQkFBZ0I7QUFDNUIsV0FBSyxlQUFlO0FBQUEsSUFDdEI7QUFFQSxhQUFTLFdBQVksS0FBSztBQUN4QixZQUFNLFNBQVMsS0FBSztBQUNwQixVQUFJLElBQUssUUFBTyxRQUFRLEdBQUc7QUFDM0IsV0FBSyxPQUFPLGVBQWUsb0JBQW9CLEdBQUc7QUFDaEQsZUFBTyxnQkFBZ0I7QUFDdkIsZUFBTyxLQUFLLFFBQVE7QUFBQSxNQUN0QjtBQUNBLFdBQUssT0FBTyxlQUFlLGtCQUFrQixNQUFNO0FBQ2pELGVBQU8sZ0JBQWdCO0FBQUEsTUFDekI7QUFFQSxhQUFPLGdCQUFnQjtBQUd2QixXQUFLLE9BQU8sZUFBZSxvQkFBb0IsRUFBRyxNQUFLLE9BQU87QUFBQSxVQUN6RCxNQUFLLGVBQWU7QUFBQSxJQUMzQjtBQUVBLGFBQVMsYUFBYyxLQUFLO0FBQzFCLFlBQU0sU0FBUyxLQUFLO0FBRXBCLFVBQUksQ0FBQyxPQUFPLEtBQUssVUFBVSxpQkFBa0IsT0FBTSxLQUFLO0FBQ3hELFVBQUksSUFBSyxRQUFPLEtBQUssU0FBUyxHQUFHO0FBQ2pDLGFBQU8sZ0JBQWdCO0FBQ3ZCLGFBQU8sS0FBSyxPQUFPO0FBRW5CLFlBQU0sS0FBSyxPQUFPO0FBQ2xCLFlBQU0sS0FBSyxPQUFPO0FBRWxCLFVBQUksT0FBTyxRQUFRLEdBQUcsYUFBYSxLQUFNLElBQUcsU0FBUyxLQUFLLFFBQVEsR0FBRztBQUVyRSxVQUFJLE9BQU8sTUFBTTtBQUNmLGVBQU8sR0FBRyxXQUFXLFFBQVEsR0FBRyxPQUFPLFNBQVMsRUFBRyxJQUFHLE9BQU8sTUFBTSxFQUFFLFFBQVEsS0FBSztBQUNsRixZQUFJLEdBQUcsYUFBYSxLQUFNLElBQUcsU0FBUyxLQUFLLFFBQVEsR0FBRztBQUFBLE1BQ3hEO0FBQUEsSUFDRjtBQUVBLGFBQVMsV0FBWSxLQUFLO0FBQ3hCLFlBQU0sU0FBUyxLQUFLO0FBRXBCLFVBQUksSUFBSyxRQUFPLFFBQVEsR0FBRztBQUMzQixhQUFPLGdCQUFnQjtBQUV2QixVQUFJLEtBQUssV0FBVyxLQUFNLFlBQVcsS0FBSyxNQUFNO0FBRWhELFdBQUssT0FBTyxlQUFlLHdCQUF3QixpQkFBaUI7QUFDbEUsZUFBTyxnQkFBZ0I7QUFDdkIsYUFBSyxPQUFPLGVBQWUsc0JBQXNCLGtCQUFrQjtBQUNqRSxpQkFBTyxLQUFLLE9BQU87QUFBQSxRQUNyQjtBQUFBLE1BQ0Y7QUFFQSxXQUFLLGVBQWU7QUFBQSxJQUN0QjtBQUVBLGFBQVMsVUFBVyxLQUFLO0FBQ3ZCLFVBQUksSUFBSyxNQUFLLE9BQU8sUUFBUSxHQUFHO0FBQ2hDLFdBQUssT0FBTyxnQkFBZ0I7QUFDNUIsVUFBSSxLQUFLLGNBQWMsVUFBVSxLQUFLLE9BQU8sZUFBZSxrQkFBa0IsRUFBRyxNQUFLLE9BQU8sZ0JBQWdCO0FBQzdHLFdBQUssZUFBZTtBQUFBLElBQ3RCO0FBRUEsYUFBUyxlQUFnQjtBQUN2QixXQUFLLEtBQUssT0FBTyxlQUFlLG1CQUFtQixHQUFHO0FBQ3BELGFBQUssT0FBTyxnQkFBZ0I7QUFDNUIsYUFBSyxPQUFPO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFFQSxhQUFTLGdCQUFpQjtBQUN4QixXQUFLLEtBQUssT0FBTyxlQUFlLG9CQUFvQixHQUFHO0FBQ3JELGFBQUssT0FBTyxnQkFBZ0I7QUFDNUIsYUFBSyxPQUFPO0FBQUEsTUFDZDtBQUFBLElBQ0Y7QUFFQSxhQUFTLFdBQVksUUFBUTtBQUMzQixlQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxLQUFLO0FBRXRDLFlBQUksRUFBRSxPQUFPLENBQUMsRUFBRSxXQUFXLEdBQUc7QUFDNUIsaUJBQU8sTUFBTSxFQUFFLFFBQVEsSUFBSTtBQUMzQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLGFBQVMsVUFBVyxLQUFLO0FBQ3ZCLFlBQU0sU0FBUyxLQUFLO0FBRXBCLFVBQUksSUFBSyxRQUFPLFFBQVEsR0FBRztBQUUzQixXQUFLLE9BQU8sZUFBZSxnQkFBZ0IsR0FBRztBQUM1QyxhQUFLLE9BQU8sZUFBZSx5QkFBeUIsRUFBRyxRQUFPLGdCQUFnQjtBQUM5RSxhQUFLLE9BQU8sZUFBZSwwQkFBMEIsRUFBRyxRQUFPLGdCQUFnQjtBQUMvRSxlQUFPLEtBQUssTUFBTTtBQUFBLE1BQ3BCO0FBRUEsYUFBTyxnQkFBZ0I7QUFFdkIsVUFBSSxPQUFPLG1CQUFtQixNQUFNO0FBQ2xDLGVBQU8sZUFBZSxlQUFlO0FBQUEsTUFDdkM7QUFFQSxVQUFJLE9BQU8sbUJBQW1CLE1BQU07QUFDbEMsZUFBTyxlQUFlLGVBQWU7QUFBQSxNQUN2QztBQUFBLElBQ0Y7QUFFQSxhQUFTLGVBQWdCLEtBQUssTUFBTTtBQUNsQyxVQUFJLFNBQVMsVUFBYSxTQUFTLEtBQU0sTUFBSyxLQUFLLElBQUk7QUFDdkQsV0FBSyxlQUFlLFdBQVcsR0FBRztBQUFBLElBQ3BDO0FBRUEsYUFBUyxZQUFhLE1BQU07QUFDMUIsVUFBSSxLQUFLLG1CQUFtQixNQUFNO0FBQ2hDLFlBQUksU0FBUyxRQUFRO0FBQ25CLGVBQUssZ0JBQWlCLGlCQUFpQjtBQUN2QyxlQUFLLGVBQWUsZUFBZTtBQUFBLFFBQ3JDO0FBQ0EsWUFBSSxTQUFTLFlBQVk7QUFDdkIsZUFBSyxnQkFBZ0I7QUFDckIsZUFBSyxlQUFlLGVBQWU7QUFBQSxRQUNyQztBQUFBLE1BQ0Y7QUFFQSxVQUFJLEtBQUssbUJBQW1CLE1BQU07QUFDaEMsWUFBSSxTQUFTLFNBQVM7QUFDcEIsZUFBSyxnQkFBZ0I7QUFDckIsZUFBSyxlQUFlLGVBQWU7QUFBQSxRQUNyQztBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsUUFBTSxTQUFOLGNBQXFCLGFBQWE7QUFBQSxNQUNoQyxZQUFhLE1BQU07QUFDakIsY0FBTTtBQUVOLGFBQUssZUFBZTtBQUNwQixhQUFLLGlCQUFpQjtBQUN0QixhQUFLLGlCQUFpQjtBQUV0QixZQUFJLE1BQU07QUFDUixjQUFJLEtBQUssS0FBTSxNQUFLLFFBQVEsS0FBSztBQUNqQyxjQUFJLEtBQUssUUFBUyxNQUFLLFdBQVcsS0FBSztBQUN2QyxjQUFJLEtBQUssV0FBWSxNQUFLLGNBQWMsS0FBSztBQUM3QyxjQUFJLEtBQUssUUFBUTtBQUNmLGlCQUFLLE9BQU8saUJBQWlCLFNBQVMsTUFBTSxLQUFLLElBQUksQ0FBQztBQUFBLFVBQ3hEO0FBQUEsUUFDRjtBQUVBLGFBQUssR0FBRyxlQUFlLFdBQVc7QUFBQSxNQUNwQztBQUFBLE1BRUEsTUFBTyxJQUFJO0FBQ1QsV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsU0FBVSxJQUFJO0FBQ1osV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsY0FBZTtBQUFBLE1BRWY7QUFBQSxNQUVBLElBQUksV0FBWTtBQUNkLGVBQU8sS0FBSyxtQkFBbUIsT0FBTyxPQUFPO0FBQUEsTUFDL0M7QUFBQSxNQUVBLElBQUksV0FBWTtBQUNkLGVBQU8sS0FBSyxtQkFBbUIsT0FBTyxPQUFPO0FBQUEsTUFDL0M7QUFBQSxNQUVBLElBQUksWUFBYTtBQUNmLGdCQUFRLEtBQUssZUFBZSxlQUFlO0FBQUEsTUFDN0M7QUFBQSxNQUVBLElBQUksYUFBYztBQUNoQixnQkFBUSxLQUFLLGVBQWUsb0JBQW9CO0FBQUEsTUFDbEQ7QUFBQSxNQUVBLFFBQVMsS0FBSztBQUNaLGFBQUssS0FBSyxlQUFlLG9CQUFvQixHQUFHO0FBQzlDLGNBQUksQ0FBQyxJQUFLLE9BQU07QUFDaEIsZUFBSyxnQkFBZ0IsS0FBSyxlQUFlLGNBQWM7QUFFdkQsY0FBSSxLQUFLLG1CQUFtQixNQUFNO0FBQ2hDLGlCQUFLLGVBQWUsZ0JBQWdCO0FBQ3BDLGlCQUFLLGVBQWUsUUFBUTtBQUFBLFVBQzlCO0FBQ0EsY0FBSSxLQUFLLG1CQUFtQixNQUFNO0FBQ2hDLGlCQUFLLGVBQWUsZ0JBQWdCO0FBQ3BDLGlCQUFLLGVBQWUsUUFBUTtBQUFBLFVBQzlCO0FBRUEsZUFBSyxnQkFBZ0I7QUFDckIsZUFBSyxZQUFZO0FBQ2pCLGVBQUssZ0JBQWdCO0FBRXJCLGNBQUksS0FBSyxtQkFBbUIsS0FBTSxNQUFLLGVBQWUsZUFBZTtBQUNyRSxjQUFJLEtBQUssbUJBQW1CLEtBQU0sTUFBSyxlQUFlLGVBQWU7QUFBQSxRQUN2RTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsUUFBTUMsWUFBTixNQUFNLGtCQUFpQixPQUFPO0FBQUEsTUFDNUIsWUFBYSxNQUFNO0FBQ2pCLGNBQU0sSUFBSTtBQUVWLGFBQUssZ0JBQWdCLFVBQVUsYUFBYTtBQUM1QyxhQUFLLGlCQUFpQixJQUFJLGNBQWMsTUFBTSxJQUFJO0FBRWxELFlBQUksTUFBTTtBQUNSLGNBQUksS0FBSyxlQUFlLGNBQWMsTUFBTyxNQUFLLGdCQUFnQjtBQUNsRSxjQUFJLEtBQUssS0FBTSxNQUFLLFFBQVEsS0FBSztBQUNqQyxjQUFJLEtBQUssVUFBVyxNQUFLLGVBQWUsZUFBZTtBQUN2RCxjQUFJLEtBQUssU0FBVSxNQUFLLFlBQVksS0FBSyxRQUFRO0FBQUEsUUFDbkQ7QUFBQSxNQUNGO0FBQUEsTUFFQSxZQUFhLFVBQVU7QUFDckIsY0FBTSxNQUFNLElBQUlKLGFBQVksUUFBUTtBQUNwQyxjQUFNLE1BQU0sS0FBSyxlQUFlLE9BQU87QUFDdkMsYUFBSyxlQUFlLE1BQU07QUFDMUIsZUFBTztBQUVQLGlCQUFTLFVBQVcsTUFBTTtBQUN4QixnQkFBTSxPQUFPLElBQUksS0FBSyxJQUFJO0FBQzFCLGlCQUFPLFNBQVMsT0FBTyxLQUFLLGVBQWUsS0FBSyxJQUFJLFlBQVksS0FBSyxPQUFPLElBQUksSUFBSTtBQUFBLFFBQ3RGO0FBQUEsTUFDRjtBQUFBLE1BRUEsTUFBTyxJQUFJO0FBQ1QsV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsS0FBTSxNQUFNLElBQUk7QUFDZCxhQUFLLGVBQWUsZUFBZTtBQUNuQyxhQUFLLGVBQWUsS0FBSyxNQUFNLEVBQUU7QUFDakMsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLE9BQVE7QUFDTixhQUFLLGVBQWUsZUFBZTtBQUNuQyxlQUFPLEtBQUssZUFBZSxLQUFLO0FBQUEsTUFDbEM7QUFBQSxNQUVBLEtBQU0sTUFBTTtBQUNWLGFBQUssZUFBZSxxQkFBcUI7QUFDekMsZUFBTyxLQUFLLGVBQWUsS0FBSyxJQUFJO0FBQUEsTUFDdEM7QUFBQSxNQUVBLFFBQVMsTUFBTTtBQUNiLGFBQUssZUFBZSxxQkFBcUI7QUFDekMsZUFBTyxLQUFLLGVBQWUsUUFBUSxJQUFJO0FBQUEsTUFDekM7QUFBQSxNQUVBLFNBQVU7QUFDUixhQUFLLGdCQUFnQjtBQUNyQixhQUFLLGVBQWUsZUFBZTtBQUNuQyxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsUUFBUztBQUNQLGFBQUssZ0JBQWlCLEtBQUssZUFBZSxjQUFjLFFBQVEsNEJBQTRCO0FBQzVGLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxPQUFPLG1CQUFvQixLQUFLLE1BQU07QUFDcEMsWUFBSTtBQUVKLGNBQU0sS0FBSyxJQUFJLFVBQVM7QUFBQSxVQUN0QixHQUFHO0FBQUEsVUFDSCxLQUFNLElBQUk7QUFDUixnQkFBSSxLQUFLLEVBQUUsS0FBSyxJQUFJLEVBQUUsS0FBSyxHQUFHLEtBQUssTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUU7QUFBQSxVQUMxRDtBQUFBLFVBQ0EsYUFBYztBQUNaLHNCQUFVLElBQUksT0FBTztBQUFBLFVBQ3ZCO0FBQUEsVUFDQSxRQUFTLElBQUk7QUFDWCxnQkFBSSxDQUFDLFFBQVMsUUFBTyxHQUFHLElBQUk7QUFDNUIsb0JBQVEsS0FBSyxHQUFHLEtBQUssTUFBTSxJQUFJLENBQUMsRUFBRSxNQUFNLEVBQUU7QUFBQSxVQUM1QztBQUFBLFFBQ0YsQ0FBQztBQUVELGVBQU87QUFFUCxpQkFBUyxLQUFNLE1BQU07QUFDbkIsY0FBSSxLQUFLLEtBQU0sSUFBRyxLQUFLLElBQUk7QUFBQSxjQUN0QixJQUFHLEtBQUssS0FBSyxLQUFLO0FBQUEsUUFDekI7QUFBQSxNQUNGO0FBQUEsTUFFQSxPQUFPLEtBQU0sTUFBTSxNQUFNO0FBQ3ZCLFlBQUksY0FBYyxJQUFJLEVBQUcsUUFBTztBQUNoQyxZQUFJLEtBQUssYUFBYSxFQUFHLFFBQU8sS0FBSyxtQkFBbUIsS0FBSyxhQUFhLEVBQUUsR0FBRyxJQUFJO0FBQ25GLFlBQUksQ0FBQyxNQUFNLFFBQVEsSUFBSSxFQUFHLFFBQU8sU0FBUyxTQUFZLENBQUMsSUFBSSxDQUFDLElBQUk7QUFFaEUsWUFBSSxJQUFJO0FBQ1IsZUFBTyxJQUFJLFVBQVM7QUFBQSxVQUNsQixHQUFHO0FBQUEsVUFDSCxLQUFNLElBQUk7QUFDUixpQkFBSyxLQUFLLE1BQU0sS0FBSyxTQUFTLE9BQU8sS0FBSyxHQUFHLENBQUM7QUFDOUMsZUFBRyxJQUFJO0FBQUEsVUFDVDtBQUFBLFFBQ0YsQ0FBQztBQUFBLE1BQ0g7QUFBQSxNQUVBLE9BQU8sZ0JBQWlCLElBQUk7QUFDMUIsZ0JBQVEsR0FBRyxlQUFlLDhCQUE4QixLQUFLLEdBQUcsZUFBZSxZQUFZLEdBQUcsZUFBZTtBQUFBLE1BQy9HO0FBQUEsTUFFQSxPQUFPLFNBQVUsSUFBSTtBQUNuQixnQkFBUSxHQUFHLGVBQWUsa0JBQWtCO0FBQUEsTUFDOUM7QUFBQSxNQUVBLENBQUMsYUFBYSxJQUFLO0FBQ2pCLGNBQU0sU0FBUztBQUVmLFlBQUksUUFBUTtBQUNaLFlBQUksaUJBQWlCO0FBQ3JCLFlBQUksZ0JBQWdCO0FBRXBCLGFBQUssR0FBRyxTQUFTLENBQUMsUUFBUTtBQUFFLGtCQUFRO0FBQUEsUUFBSSxDQUFDO0FBQ3pDLGFBQUssR0FBRyxZQUFZLFVBQVU7QUFDOUIsYUFBSyxHQUFHLFNBQVMsT0FBTztBQUV4QixlQUFPO0FBQUEsVUFDTCxDQUFDLGFBQWEsSUFBSztBQUNqQixtQkFBTztBQUFBLFVBQ1Q7QUFBQSxVQUNBLE9BQVE7QUFDTixtQkFBTyxJQUFJLFFBQVEsU0FBVSxTQUFTLFFBQVE7QUFDNUMsK0JBQWlCO0FBQ2pCLDhCQUFnQjtBQUNoQixvQkFBTSxPQUFPLE9BQU8sS0FBSztBQUN6QixrQkFBSSxTQUFTLEtBQU0sUUFBTyxJQUFJO0FBQUEsd0JBQ3BCLE9BQU8sZUFBZSxlQUFlLEVBQUcsUUFBTyxJQUFJO0FBQUEsWUFDL0QsQ0FBQztBQUFBLFVBQ0g7QUFBQSxVQUNBLFNBQVU7QUFDUixtQkFBTyxRQUFRLElBQUk7QUFBQSxVQUNyQjtBQUFBLFVBQ0EsTUFBTyxLQUFLO0FBQ1YsbUJBQU8sUUFBUSxHQUFHO0FBQUEsVUFDcEI7QUFBQSxRQUNGO0FBRUEsaUJBQVMsYUFBYztBQUNyQixjQUFJLG1CQUFtQixLQUFNLFFBQU8sT0FBTyxLQUFLLENBQUM7QUFBQSxRQUNuRDtBQUVBLGlCQUFTLFVBQVc7QUFDbEIsY0FBSSxtQkFBbUIsS0FBTSxRQUFPLElBQUk7QUFBQSxRQUMxQztBQUVBLGlCQUFTLE9BQVEsTUFBTTtBQUNyQixjQUFJLGtCQUFrQixLQUFNO0FBQzVCLGNBQUksTUFBTyxlQUFjLEtBQUs7QUFBQSxtQkFDckIsU0FBUyxTQUFTLE9BQU8sZUFBZSxlQUFlLEVBQUcsZUFBYyxnQkFBZ0I7QUFBQSxjQUM1RixnQkFBZSxFQUFFLE9BQU8sTUFBTSxNQUFNLFNBQVMsS0FBSyxDQUFDO0FBQ3hELDBCQUFnQixpQkFBaUI7QUFBQSxRQUNuQztBQUVBLGlCQUFTLFFBQVMsS0FBSztBQUNyQixpQkFBTyxRQUFRLEdBQUc7QUFDbEIsaUJBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ3RDLGdCQUFJLE9BQU8sZUFBZSxVQUFXLFFBQU8sUUFBUSxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUssQ0FBQztBQUNwRixtQkFBTyxLQUFLLFNBQVMsV0FBWTtBQUMvQixrQkFBSSxJQUFLLFFBQU8sR0FBRztBQUFBLGtCQUNkLFNBQVEsRUFBRSxPQUFPLFFBQVcsTUFBTSxLQUFLLENBQUM7QUFBQSxZQUMvQyxDQUFDO0FBQUEsVUFDSCxDQUFDO0FBQUEsUUFDSDtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBRUEsUUFBTUssWUFBTixjQUF1QixPQUFPO0FBQUEsTUFDNUIsWUFBYSxNQUFNO0FBQ2pCLGNBQU0sSUFBSTtBQUVWLGFBQUssZ0JBQWdCLFVBQVU7QUFDL0IsYUFBSyxpQkFBaUIsSUFBSSxjQUFjLE1BQU0sSUFBSTtBQUVsRCxZQUFJLE1BQU07QUFDUixjQUFJLEtBQUssT0FBUSxNQUFLLFVBQVUsS0FBSztBQUNyQyxjQUFJLEtBQUssTUFBTyxNQUFLLFNBQVMsS0FBSztBQUNuQyxjQUFJLEtBQUssTUFBTyxNQUFLLFNBQVMsS0FBSztBQUNuQyxjQUFJLEtBQUssVUFBVyxNQUFLLGVBQWUsZUFBZTtBQUFBLFFBQ3pEO0FBQUEsTUFDRjtBQUFBLE1BRUEsT0FBUTtBQUNOLGFBQUssZ0JBQWdCO0FBQUEsTUFDdkI7QUFBQSxNQUVBLFNBQVU7QUFDUixhQUFLLGdCQUFnQjtBQUNyQixhQUFLLGVBQWUsZUFBZTtBQUFBLE1BQ3JDO0FBQUEsTUFFQSxRQUFTLE9BQU8sSUFBSTtBQUNsQixXQUFHLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFFQSxPQUFRLE1BQU0sSUFBSTtBQUNoQixhQUFLLGVBQWUsVUFBVSxNQUFNLEVBQUU7QUFBQSxNQUN4QztBQUFBLE1BRUEsT0FBUSxJQUFJO0FBQ1YsV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsT0FBTyxnQkFBaUIsSUFBSTtBQUMxQixnQkFBUSxHQUFHLGVBQWUsK0JBQStCO0FBQUEsTUFDM0Q7QUFBQSxNQUVBLE9BQU8sUUFBUyxJQUFJO0FBQ2xCLFlBQUksR0FBRyxVQUFXLFFBQU8sUUFBUSxRQUFRLEtBQUs7QUFDOUMsY0FBTSxRQUFRLEdBQUc7QUFDakIsY0FBTSxVQUFXLFNBQVMsRUFBRSxJQUFJLEtBQUssSUFBSSxHQUFHLE1BQU0sTUFBTSxNQUFNLElBQUksTUFBTSxNQUFNO0FBQzlFLGNBQU0sU0FBUyxXQUFZLEdBQUcsZUFBZUosaUJBQWlCLElBQUk7QUFDbEUsWUFBSSxXQUFXLEVBQUcsUUFBTyxRQUFRLFFBQVEsSUFBSTtBQUM3QyxZQUFJLE1BQU0sV0FBVyxLQUFNLE9BQU0sU0FBUyxDQUFDO0FBQzNDLGVBQU8sSUFBSSxRQUFRLENBQUMsWUFBWTtBQUM5QixnQkFBTSxPQUFPLEtBQUssRUFBRSxRQUFRLFFBQVEsQ0FBQztBQUFBLFFBQ3ZDLENBQUM7QUFBQSxNQUNIO0FBQUEsTUFFQSxNQUFPLE1BQU07QUFDWCxhQUFLLGVBQWUsZUFBZTtBQUNuQyxlQUFPLEtBQUssZUFBZSxLQUFLLElBQUk7QUFBQSxNQUN0QztBQUFBLE1BRUEsSUFBSyxNQUFNO0FBQ1QsYUFBSyxlQUFlLGVBQWU7QUFDbkMsYUFBSyxlQUFlLElBQUksSUFBSTtBQUM1QixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFNSyxVQUFOLGNBQXFCRixVQUFTO0FBQUE7QUFBQSxNQUM1QixZQUFhLE1BQU07QUFDakIsY0FBTSxJQUFJO0FBRVYsYUFBSyxlQUFlLFVBQVcsS0FBSyxlQUFlO0FBQ25ELGFBQUssaUJBQWlCLElBQUksY0FBYyxNQUFNLElBQUk7QUFFbEQsWUFBSSxNQUFNO0FBQ1IsY0FBSSxLQUFLLE9BQVEsTUFBSyxVQUFVLEtBQUs7QUFDckMsY0FBSSxLQUFLLE1BQU8sTUFBSyxTQUFTLEtBQUs7QUFDbkMsY0FBSSxLQUFLLE1BQU8sTUFBSyxTQUFTLEtBQUs7QUFBQSxRQUNyQztBQUFBLE1BQ0Y7QUFBQSxNQUVBLE9BQVE7QUFDTixhQUFLLGdCQUFnQjtBQUFBLE1BQ3ZCO0FBQUEsTUFFQSxTQUFVO0FBQ1IsYUFBSyxnQkFBZ0I7QUFDckIsYUFBSyxlQUFlLGVBQWU7QUFBQSxNQUNyQztBQUFBLE1BRUEsUUFBUyxPQUFPLElBQUk7QUFDbEIsV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsT0FBUSxNQUFNLElBQUk7QUFDaEIsYUFBSyxlQUFlLFVBQVUsTUFBTSxFQUFFO0FBQUEsTUFDeEM7QUFBQSxNQUVBLE9BQVEsSUFBSTtBQUNWLFdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUVBLE1BQU8sTUFBTTtBQUNYLGFBQUssZUFBZSxlQUFlO0FBQ25DLGVBQU8sS0FBSyxlQUFlLEtBQUssSUFBSTtBQUFBLE1BQ3RDO0FBQUEsTUFFQSxJQUFLLE1BQU07QUFDVCxhQUFLLGVBQWUsZUFBZTtBQUNuQyxhQUFLLGVBQWUsSUFBSSxJQUFJO0FBQzVCLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFFBQU0sWUFBTixjQUF3QkUsUUFBTztBQUFBLE1BQzdCLFlBQWEsTUFBTTtBQUNqQixjQUFNLElBQUk7QUFDVixhQUFLLGtCQUFrQixJQUFJLGVBQWUsSUFBSTtBQUU5QyxZQUFJLE1BQU07QUFDUixjQUFJLEtBQUssVUFBVyxNQUFLLGFBQWEsS0FBSztBQUMzQyxjQUFJLEtBQUssTUFBTyxNQUFLLFNBQVMsS0FBSztBQUFBLFFBQ3JDO0FBQUEsTUFDRjtBQUFBLE1BRUEsT0FBUSxNQUFNLElBQUk7QUFDaEIsWUFBSSxLQUFLLGVBQWUsWUFBWSxLQUFLLGVBQWUsZUFBZTtBQUNyRSxlQUFLLGdCQUFnQixPQUFPO0FBQUEsUUFDOUIsT0FBTztBQUNMLGVBQUssV0FBVyxNQUFNLEtBQUssZ0JBQWdCLGNBQWM7QUFBQSxRQUMzRDtBQUFBLE1BQ0Y7QUFBQSxNQUVBLE1BQU8sSUFBSTtBQUNULFlBQUksS0FBSyxnQkFBZ0IsU0FBUyxNQUFNO0FBQ3RDLGdCQUFNLE9BQU8sS0FBSyxnQkFBZ0I7QUFDbEMsZUFBSyxnQkFBZ0IsT0FBTztBQUM1QixhQUFHLElBQUk7QUFDUCxlQUFLLFdBQVcsTUFBTSxLQUFLLGdCQUFnQixjQUFjO0FBQUEsUUFDM0QsT0FBTztBQUNMLGFBQUcsSUFBSTtBQUFBLFFBQ1Q7QUFBQSxNQUNGO0FBQUEsTUFFQSxRQUFTLEtBQUs7QUFDWixjQUFNLFFBQVEsR0FBRztBQUNqQixZQUFJLEtBQUssZ0JBQWdCLFNBQVMsTUFBTTtBQUN0QyxlQUFLLGdCQUFnQixPQUFPO0FBQzVCLGVBQUssZ0JBQWdCLGVBQWU7QUFBQSxRQUN0QztBQUFBLE1BQ0Y7QUFBQSxNQUVBLFdBQVksTUFBTSxJQUFJO0FBQ3BCLFdBQUcsTUFBTSxJQUFJO0FBQUEsTUFDZjtBQUFBLE1BRUEsT0FBUSxJQUFJO0FBQ1YsV0FBRyxJQUFJO0FBQUEsTUFDVDtBQUFBLE1BRUEsT0FBUSxJQUFJO0FBQ1YsYUFBSyxnQkFBZ0IsYUFBYTtBQUNsQyxhQUFLLE9BQU8sb0JBQW9CLEtBQUssSUFBSSxDQUFDO0FBQUEsTUFDNUM7QUFBQSxJQUNGO0FBRUEsUUFBTSxjQUFOLGNBQTBCLFVBQVU7QUFBQSxJQUFDO0FBRXJDLGFBQVMsb0JBQXFCLEtBQUssTUFBTTtBQUN2QyxZQUFNLEtBQUssS0FBSyxnQkFBZ0I7QUFDaEMsVUFBSSxJQUFLLFFBQU8sR0FBRyxHQUFHO0FBQ3RCLFVBQUksU0FBUyxRQUFRLFNBQVMsT0FBVyxNQUFLLEtBQUssSUFBSTtBQUN2RCxXQUFLLEtBQUssSUFBSTtBQUNkLFNBQUcsSUFBSTtBQUFBLElBQ1Q7QUFFQSxhQUFTLG1CQUFvQixTQUFTO0FBQ3BDLGFBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFXO0FBQ3RDLGVBQU8sU0FBUyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ25DLGNBQUksSUFBSyxRQUFPLE9BQU8sR0FBRztBQUMxQixrQkFBUTtBQUFBLFFBQ1YsQ0FBQztBQUFBLE1BQ0gsQ0FBQztBQUFBLElBQ0g7QUFFQSxhQUFTLFNBQVUsV0FBVyxTQUFTO0FBQ3JDLFlBQU0sTUFBTSxNQUFNLFFBQVEsTUFBTSxJQUFJLENBQUMsR0FBRyxRQUFRLEdBQUcsT0FBTyxJQUFJLENBQUMsUUFBUSxHQUFHLE9BQU87QUFDakYsWUFBTSxPQUFRLElBQUksVUFBVSxPQUFPLElBQUksSUFBSSxTQUFTLENBQUMsTUFBTSxhQUFjLElBQUksSUFBSSxJQUFJO0FBRXJGLFVBQUksSUFBSSxTQUFTLEVBQUcsT0FBTSxJQUFJLE1BQU0sc0NBQXNDO0FBRTFFLFVBQUksTUFBTSxJQUFJLENBQUM7QUFDZixVQUFJLE9BQU87QUFDWCxVQUFJLFFBQVE7QUFFWixlQUFTLElBQUksR0FBRyxJQUFJLElBQUksUUFBUSxLQUFLO0FBQ25DLGVBQU8sSUFBSSxDQUFDO0FBRVosWUFBSUosV0FBVSxHQUFHLEdBQUc7QUFDbEIsY0FBSSxLQUFLLE1BQU0sT0FBTztBQUFBLFFBQ3hCLE9BQU87QUFDTCxzQkFBWSxLQUFLLE1BQU0sSUFBSSxHQUFHLE9BQU87QUFDckMsY0FBSSxLQUFLLElBQUk7QUFBQSxRQUNmO0FBRUEsY0FBTTtBQUFBLE1BQ1I7QUFFQSxVQUFJLE1BQU07QUFDUixZQUFJLE1BQU07QUFFVixjQUFNLGNBQWNBLFdBQVUsSUFBSSxLQUFLLENBQUMsRUFBRSxLQUFLLGtCQUFrQixLQUFLLGVBQWU7QUFFckYsYUFBSyxHQUFHLFNBQVMsQ0FBQyxRQUFRO0FBQ3hCLGNBQUksVUFBVSxLQUFNLFNBQVE7QUFBQSxRQUM5QixDQUFDO0FBRUQsYUFBSyxHQUFHLFVBQVUsTUFBTTtBQUN0QixnQkFBTTtBQUNOLGNBQUksQ0FBQyxZQUFhLE1BQUssS0FBSztBQUFBLFFBQzlCLENBQUM7QUFFRCxZQUFJLGFBQWE7QUFDZixlQUFLLEdBQUcsU0FBUyxNQUFNLEtBQUssVUFBVSxNQUFNLE9BQU8sZ0JBQWdCLENBQUM7QUFBQSxRQUN0RTtBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBRVAsZUFBUyxZQUFhLEdBQUcsSUFBSSxJQUFJSyxVQUFTO0FBQ3hDLFVBQUUsR0FBRyxTQUFTQSxRQUFPO0FBQ3JCLFVBQUUsR0FBRyxTQUFTLE9BQU87QUFFckIsaUJBQVMsVUFBVztBQUNsQixjQUFJLE1BQU0sRUFBRSxrQkFBa0IsQ0FBQyxFQUFFLGVBQWUsTUFBTyxRQUFPQSxTQUFRLGVBQWU7QUFDckYsY0FBSSxNQUFNLEVBQUUsa0JBQWtCLENBQUMsRUFBRSxlQUFlLE1BQU8sUUFBT0EsU0FBUSxlQUFlO0FBQUEsUUFDdkY7QUFBQSxNQUNGO0FBRUEsZUFBUyxRQUFTLEtBQUs7QUFDckIsWUFBSSxDQUFDLE9BQU8sTUFBTztBQUNuQixnQkFBUTtBQUVSLG1CQUFXLEtBQUssS0FBSztBQUNuQixZQUFFLFFBQVEsR0FBRztBQUFBLFFBQ2Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLGFBQVMsS0FBTSxHQUFHO0FBQ2hCLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBU0MsVUFBVSxRQUFRO0FBQ3pCLGFBQU8sQ0FBQyxDQUFDLE9BQU8sa0JBQWtCLENBQUMsQ0FBQyxPQUFPO0FBQUEsSUFDN0M7QUFFQSxhQUFTTixXQUFXLFFBQVE7QUFDMUIsYUFBTyxPQUFPLE9BQU8saUJBQWlCLFlBQVlNLFVBQVMsTUFBTTtBQUFBLElBQ25FO0FBRUEsYUFBUyxRQUFTLFFBQVE7QUFDeEIsYUFBTyxDQUFDLENBQUMsT0FBTyxrQkFBa0IsT0FBTyxlQUFlO0FBQUEsSUFDMUQ7QUFFQSxhQUFTLFdBQVksUUFBUTtBQUMzQixhQUFPLENBQUMsQ0FBQyxPQUFPLGtCQUFrQixPQUFPLGVBQWU7QUFBQSxJQUMxRDtBQUVBLGFBQVMsZUFBZ0IsUUFBUSxPQUFPLENBQUMsR0FBRztBQUMxQyxZQUFNLE1BQU8sT0FBTyxrQkFBa0IsT0FBTyxlQUFlLFNBQVcsT0FBTyxrQkFBa0IsT0FBTyxlQUFlO0FBR3RILGFBQVEsQ0FBQyxLQUFLLE9BQU8sUUFBUSxtQkFBb0IsT0FBTztBQUFBLElBQzFEO0FBRUEsYUFBUyxjQUFlLFFBQVE7QUFDOUIsYUFBT04sV0FBVSxNQUFNLEtBQUssT0FBTztBQUFBLElBQ3JDO0FBRUEsYUFBUyxZQUFhLFFBQVE7QUFDNUIsY0FBUSxPQUFPLGVBQWUsYUFBYSxZQUFZLE9BQU8sZUFBZSx1QkFBdUI7QUFBQSxJQUN0RztBQUVBLGFBQVMsYUFBYyxNQUFNO0FBQzNCLGFBQU8sT0FBTyxTQUFTLFlBQVksU0FBUyxRQUFRLE9BQU8sS0FBSyxlQUFlO0FBQUEsSUFDakY7QUFFQSxhQUFTLGtCQUFtQixNQUFNO0FBQ2hDLGFBQU8sYUFBYSxJQUFJLElBQUksS0FBSyxhQUFhO0FBQUEsSUFDaEQ7QUFFQSxhQUFTLE9BQVE7QUFBQSxJQUFDO0FBRWxCLGFBQVMsUUFBUztBQUNoQixXQUFLLFFBQVEsSUFBSSxNQUFNLGlCQUFpQixDQUFDO0FBQUEsSUFDM0M7QUFFQSxhQUFTLFNBQVUsR0FBRztBQUNwQixhQUFPLEVBQUUsWUFBWUcsVUFBUyxVQUFVLFdBQVcsRUFBRSxZQUFZQyxRQUFPLFVBQVU7QUFBQSxJQUNwRjtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2Y7QUFBQSxNQUNBO0FBQUEsTUFDQSxVQUFBRTtBQUFBLE1BQ0EsV0FBQU47QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0EsVUFBQUc7QUFBQSxNQUNBLFVBQUFEO0FBQUEsTUFDQSxRQUFBRTtBQUFBLE1BQ0E7QUFBQTtBQUFBLE1BRUE7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDN3BDQTtBQUFBO0FBQUEsYUFBUyxXQUFZLFFBQVE7QUFDM0IsYUFBTyxPQUFPO0FBQUEsSUFDaEI7QUFFQSxhQUFTLFNBQVUsUUFBUTtBQUN6QixZQUFNLE1BQU0sT0FBTztBQUVuQixVQUFJLFNBQVM7QUFFYixlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSztBQUM1QixrQkFBVSxPQUFPLGFBQWEsT0FBTyxDQUFDLENBQUM7QUFBQSxNQUN6QztBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxNQUFPLFFBQVEsUUFBUSxTQUFTLEdBQUcsU0FBUyxXQUFXLE1BQU0sR0FBRztBQUN2RSxZQUFNLE1BQU0sS0FBSyxJQUFJLFFBQVEsT0FBTyxhQUFhLE1BQU07QUFFdkQsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7QUFDNUIsZUFBTyxTQUFTLENBQUMsSUFBSSxPQUFPLFdBQVcsQ0FBQztBQUFBLE1BQzFDO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxXQUFPLFVBQVU7QUFBQSxNQUNmO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUE7QUFBQTs7O0FDOUJBO0FBQUE7QUFBQSxRQUFNLFdBQVc7QUFFakIsUUFBTSxRQUFRLElBQUksV0FBVyxHQUFHO0FBRWhDLGFBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDeEMsWUFBTSxTQUFTLFdBQVcsQ0FBQyxDQUFDLElBQUk7QUFBQSxJQUNsQztBQUVBO0FBQUE7QUFBQSxNQUFjO0FBQUEsSUFBSSxJQUFJO0FBQ3RCO0FBQUE7QUFBQSxNQUFjO0FBQUEsSUFBSSxJQUFJO0FBRXRCLGFBQVMsV0FBWSxRQUFRO0FBQzNCLFVBQUksTUFBTSxPQUFPO0FBRWpCLFVBQUksT0FBTyxXQUFXLE1BQU0sQ0FBQyxNQUFNLEdBQU07QUFDekMsVUFBSSxNQUFNLEtBQUssT0FBTyxXQUFXLE1BQU0sQ0FBQyxNQUFNLEdBQU07QUFFcEQsYUFBUSxNQUFNLE1BQU87QUFBQSxJQUN2QjtBQUVBLGFBQVMsU0FBVSxRQUFRO0FBQ3pCLFlBQU0sTUFBTSxPQUFPO0FBRW5CLFVBQUksU0FBUztBQUViLGVBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLLEdBQUc7QUFDL0Isa0JBQ0UsU0FBUyxPQUFPLENBQUMsS0FBSyxDQUFDLElBQ3ZCLFVBQVcsT0FBTyxDQUFDLElBQUksTUFBTSxJQUFNLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBRSxJQUN0RCxVQUFXLE9BQU8sSUFBSSxDQUFDLElBQUksT0FBTyxJQUFNLE9BQU8sSUFBSSxDQUFDLEtBQUssQ0FBRSxJQUMzRCxTQUFTLE9BQU8sSUFBSSxDQUFDLElBQUksRUFBRTtBQUFBLE1BRS9CO0FBRUEsVUFBSSxNQUFNLE1BQU0sR0FBRztBQUNqQixpQkFBUyxPQUFPLFVBQVUsR0FBRyxPQUFPLFNBQVMsQ0FBQyxJQUFJO0FBQUEsTUFDcEQsV0FBVyxNQUFNLE1BQU0sR0FBRztBQUN4QixpQkFBUyxPQUFPLFVBQVUsR0FBRyxPQUFPLFNBQVMsQ0FBQyxJQUFJO0FBQUEsTUFDcEQ7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsTUFBTyxRQUFRLFFBQVEsU0FBUyxHQUFHLFNBQVMsV0FBVyxNQUFNLEdBQUc7QUFDdkUsWUFBTSxNQUFNLEtBQUssSUFBSSxRQUFRLE9BQU8sYUFBYSxNQUFNO0FBRXZELGVBQVMsSUFBSSxHQUFHLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxHQUFHO0FBQ3RDLGNBQU0sSUFBSSxNQUFNLE9BQU8sV0FBVyxDQUFDLENBQUM7QUFDcEMsY0FBTSxJQUFJLE1BQU0sT0FBTyxXQUFXLElBQUksQ0FBQyxDQUFDO0FBQ3hDLGNBQU0sSUFBSSxNQUFNLE9BQU8sV0FBVyxJQUFJLENBQUMsQ0FBQztBQUN4QyxjQUFNLElBQUksTUFBTSxPQUFPLFdBQVcsSUFBSSxDQUFDLENBQUM7QUFFeEMsZUFBTyxHQUFHLElBQUssS0FBSyxJQUFNLEtBQUs7QUFDL0IsZUFBTyxHQUFHLEtBQU0sSUFBSSxPQUFPLElBQU0sS0FBSztBQUN0QyxlQUFPLEdBQUcsS0FBTSxJQUFJLE1BQU0sSUFBTSxJQUFJO0FBQUEsTUFDdEM7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUNoRUE7QUFBQTtBQUFBLGFBQVMsV0FBWSxRQUFRO0FBQzNCLGFBQU8sT0FBTyxXQUFXO0FBQUEsSUFDM0I7QUFFQSxhQUFTLFNBQVUsUUFBUTtBQUN6QixZQUFNLE1BQU0sT0FBTztBQUVuQixlQUFTLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLEdBQUc7QUFFM0QsVUFBSSxTQUFTO0FBQ2IsVUFBSSxJQUFJO0FBRVIsZUFBUyxJQUFJLE1BQU8sTUFBTSxHQUFJLElBQUksR0FBRyxLQUFLLEdBQUc7QUFDM0Msa0JBQVUsT0FBTyxVQUFVLENBQUMsRUFBRSxTQUFTLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztBQUFBLE1BQzVEO0FBRUEsYUFBTyxJQUFJLEtBQUssS0FBSztBQUNuQixrQkFBVSxPQUFPLFNBQVMsQ0FBQyxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHO0FBQUEsTUFDM0Q7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsTUFBTyxRQUFRLFFBQVEsU0FBUyxHQUFHLFNBQVMsV0FBVyxNQUFNLEdBQUc7QUFDdkUsWUFBTSxNQUFNLEtBQUssSUFBSSxRQUFRLE9BQU8sYUFBYSxNQUFNO0FBRXZELGVBQVMsSUFBSSxHQUFHLElBQUksS0FBSyxLQUFLO0FBQzVCLGNBQU0sSUFBSSxTQUFTLE9BQU8sV0FBVyxJQUFJLENBQUMsQ0FBQztBQUMzQyxjQUFNLElBQUksU0FBUyxPQUFPLFdBQVcsSUFBSSxJQUFJLENBQUMsQ0FBQztBQUUvQyxZQUFJLE1BQU0sVUFBYSxNQUFNLFFBQVc7QUFDdEMsaUJBQU8sT0FBTyxTQUFTLEdBQUcsQ0FBQztBQUFBLFFBQzdCO0FBRUEsZUFBTyxTQUFTLENBQUMsSUFBSyxLQUFLLElBQUs7QUFBQSxNQUNsQztBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTyxVQUFVO0FBQUEsTUFDZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUVBLGFBQVMsU0FBVSxNQUFNO0FBQ3ZCLFVBQUksUUFBUSxNQUFRLFFBQVEsR0FBTSxRQUFPLE9BQU87QUFDaEQsVUFBSSxRQUFRLE1BQVEsUUFBUSxHQUFNLFFBQU8sT0FBTyxLQUFPO0FBQ3ZELFVBQUksUUFBUSxNQUFRLFFBQVEsSUFBTSxRQUFPLE9BQU8sS0FBTztBQUFBLElBQ3pEO0FBQUE7QUFBQTs7O0FDbERBO0FBQUE7QUFBQSxhQUFTLFdBQVksUUFBUTtBQUMzQixVQUFJLFNBQVM7QUFFYixlQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxJQUFJLEdBQUcsS0FBSztBQUM3QyxjQUFNLE9BQU8sT0FBTyxXQUFXLENBQUM7QUFFaEMsWUFBSSxRQUFRLFNBQVUsUUFBUSxTQUFVLElBQUksSUFBSSxHQUFHO0FBQ2pELGdCQUFNRyxRQUFPLE9BQU8sV0FBVyxJQUFJLENBQUM7QUFFcEMsY0FBSUEsU0FBUSxTQUFVQSxTQUFRLE9BQVE7QUFDcEMsc0JBQVU7QUFDVjtBQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFFQSxZQUFJLFFBQVEsSUFBTSxXQUFVO0FBQUEsaUJBQ25CLFFBQVEsS0FBTyxXQUFVO0FBQUEsWUFDN0IsV0FBVTtBQUFBLE1BQ2pCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxRQUFJO0FBRUosUUFBSSxPQUFPLGdCQUFnQixhQUFhO0FBQ3RDLFlBQU0sVUFBVSxJQUFJLFlBQVk7QUFFaEMsaUJBQVcsU0FBU0MsVUFBVSxRQUFRO0FBQ3BDLGVBQU8sUUFBUSxPQUFPLE1BQU07QUFBQSxNQUM5QjtBQUFBLElBQ0YsT0FBTztBQUNMLGlCQUFXLFNBQVNBLFVBQVUsUUFBUTtBQUNwQyxjQUFNLE1BQU0sT0FBTztBQUVuQixZQUFJLFNBQVM7QUFDYixZQUFJLElBQUk7QUFFUixlQUFPLElBQUksS0FBSztBQUNkLGNBQUksT0FBTyxPQUFPLENBQUM7QUFFbkIsY0FBSSxRQUFRLEtBQU07QUFDaEIsc0JBQVUsT0FBTyxhQUFhLElBQUk7QUFDbEM7QUFDQTtBQUFBLFVBQ0Y7QUFFQSxjQUFJLGNBQWM7QUFDbEIsY0FBSSxZQUFZO0FBRWhCLGNBQUksUUFBUSxLQUFNO0FBQ2hCLDBCQUFjO0FBQ2Qsd0JBQVksT0FBTztBQUFBLFVBQ3JCLFdBQVcsUUFBUSxLQUFNO0FBQ3ZCLDBCQUFjO0FBQ2Qsd0JBQVksT0FBTztBQUFBLFVBQ3JCLFdBQVcsUUFBUSxLQUFNO0FBQ3ZCLDBCQUFjO0FBQ2Qsd0JBQVksT0FBTztBQUFBLFVBQ3JCO0FBRUEsY0FBSSxNQUFNLElBQUksY0FBYyxHQUFHO0FBQzdCLGdCQUFJLElBQUk7QUFFUixtQkFBTyxJQUFJLGFBQWE7QUFDdEIscUJBQU8sT0FBTyxJQUFJLElBQUksQ0FBQztBQUN2QiwwQkFBYSxhQUFhLElBQU0sT0FBTztBQUN2QyxtQkFBSztBQUFBLFlBQ1A7QUFBQSxVQUNGLE9BQU87QUFDTCx3QkFBWTtBQUNaLDBCQUFjLE1BQU07QUFBQSxVQUN0QjtBQUVBLG9CQUFVLE9BQU8sY0FBYyxTQUFTO0FBQ3hDLGVBQUssY0FBYztBQUFBLFFBQ3JCO0FBRUEsZUFBTztBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBSTtBQUVKLFFBQUksT0FBTyxnQkFBZ0IsYUFBYTtBQUN0QyxZQUFNLFVBQVUsSUFBSSxZQUFZO0FBRWhDLGNBQVEsU0FBU0MsT0FBTyxRQUFRLFFBQVEsU0FBUyxHQUFHLFNBQVMsV0FBVyxNQUFNLEdBQUc7QUFDL0UsY0FBTSxNQUFNLEtBQUssSUFBSSxRQUFRLE9BQU8sYUFBYSxNQUFNO0FBQ3ZELGdCQUFRLFdBQVcsUUFBUSxPQUFPLFNBQVMsUUFBUSxTQUFTLEdBQUcsQ0FBQztBQUNoRSxlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0YsT0FBTztBQUNMLGNBQVEsU0FBU0EsT0FBTyxRQUFRLFFBQVEsU0FBUyxHQUFHLFNBQVMsV0FBVyxNQUFNLEdBQUc7QUFDL0UsY0FBTSxNQUFNLEtBQUssSUFBSSxRQUFRLE9BQU8sYUFBYSxNQUFNO0FBRXZELGlCQUFTLE9BQU8sU0FBUyxRQUFRLFNBQVMsR0FBRztBQUU3QyxZQUFJLElBQUk7QUFDUixZQUFJLElBQUk7QUFFUixlQUFPLElBQUksT0FBTyxRQUFRO0FBQ3hCLGdCQUFNLE9BQU8sT0FBTyxZQUFZLENBQUM7QUFFakMsY0FBSSxRQUFRLEtBQU07QUFDaEIsbUJBQU8sR0FBRyxJQUFJO0FBQ2Q7QUFDQTtBQUFBLFVBQ0Y7QUFFQSxjQUFJLFFBQVE7QUFDWixjQUFJLE9BQU87QUFFWCxjQUFJLFFBQVEsTUFBTztBQUNqQixvQkFBUTtBQUNSLG1CQUFPO0FBQUEsVUFDVCxXQUFXLFFBQVEsT0FBUTtBQUN6QixvQkFBUTtBQUNSLG1CQUFPO0FBQUEsVUFDVCxXQUFXLFFBQVEsU0FBVTtBQUMzQixvQkFBUTtBQUNSLG1CQUFPO0FBQUEsVUFDVDtBQUVBLGlCQUFPLEdBQUcsSUFBSSxPQUFRLFFBQVE7QUFDOUIsbUJBQVM7QUFFVCxpQkFBTyxTQUFTLEdBQUc7QUFDakIsbUJBQU8sR0FBRyxJQUFJLE1BQVMsUUFBUSxRQUFTO0FBQ3hDLHFCQUFTO0FBQUEsVUFDWDtBQUVBLGVBQUssUUFBUSxRQUFVLElBQUk7QUFBQSxRQUM3QjtBQUVBLGVBQU87QUFBQSxNQUNUO0FBQUEsSUFDRjtBQUVBLFdBQU8sVUFBVTtBQUFBLE1BQ2Y7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0Y7QUFBQTtBQUFBOzs7QUNoSkE7QUFBQTtBQUFBLGFBQVMsV0FBWSxRQUFRO0FBQzNCLGFBQU8sT0FBTyxTQUFTO0FBQUEsSUFDekI7QUFFQSxhQUFTLFNBQVUsUUFBUTtBQUN6QixZQUFNLE1BQU0sT0FBTztBQUVuQixVQUFJLFNBQVM7QUFFYixlQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sR0FBRyxLQUFLLEdBQUc7QUFDbkMsa0JBQVUsT0FBTyxhQUFhLE9BQU8sQ0FBQyxJQUFLLE9BQU8sSUFBSSxDQUFDLElBQUksR0FBSTtBQUFBLE1BQ2pFO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLE1BQU8sUUFBUSxRQUFRLFNBQVMsR0FBRyxTQUFTLFdBQVcsTUFBTSxHQUFHO0FBQ3ZFLFlBQU0sTUFBTSxLQUFLLElBQUksUUFBUSxPQUFPLGFBQWEsTUFBTTtBQUV2RCxVQUFJLFFBQVE7QUFFWixlQUFTLElBQUksR0FBRyxJQUFJLE9BQU8sUUFBUSxFQUFFLEdBQUc7QUFDdEMsYUFBSyxTQUFTLEtBQUssRUFBRztBQUV0QixjQUFNLElBQUksT0FBTyxXQUFXLENBQUM7QUFDN0IsY0FBTSxLQUFLLEtBQUs7QUFDaEIsY0FBTSxLQUFLLElBQUk7QUFFZixlQUFPLFNBQVMsSUFBSSxDQUFDLElBQUk7QUFDekIsZUFBTyxTQUFTLElBQUksSUFBSSxDQUFDLElBQUk7QUFBQSxNQUMvQjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsV0FBTyxVQUFVO0FBQUEsTUFDZjtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBO0FBQUE7OztBQ3ZDQTtBQUFBO0FBQUEsUUFBTSxRQUFRO0FBQ2QsUUFBTSxTQUFTO0FBQ2YsUUFBTSxNQUFNO0FBQ1osUUFBTSxPQUFPO0FBQ2IsUUFBTSxVQUFVO0FBRWhCLFFBQU0sS0FBSyxJQUFJLFdBQVcsWUFBWSxHQUFHLEdBQUksRUFBRSxNQUFNLEVBQUUsQ0FBQyxNQUFNO0FBRTlELGFBQVMsU0FBVSxVQUFVO0FBQzNCLGNBQVEsVUFBVTtBQUFBLFFBQ2hCLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVDtBQUNFLGdCQUFNLElBQUksTUFBTSxxQkFBcUIsUUFBUSxFQUFFO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBRUEsYUFBUyxTQUFVLE9BQU87QUFDeEIsYUFBTyxpQkFBaUI7QUFBQSxJQUMxQjtBQUVBLGFBQVMsV0FBWSxVQUFVO0FBQzdCLFVBQUk7QUFDRixpQkFBUyxRQUFRO0FBQ2pCLGVBQU87QUFBQSxNQUNULFFBQVE7QUFDTixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxhQUFTLE1BQU8sTUFBTUMsT0FBTSxVQUFVO0FBQ3BDLFlBQU0sU0FBUyxJQUFJLFdBQVcsSUFBSTtBQUNsQyxVQUFJQSxVQUFTLE9BQVcsU0FBUSxLQUFLLFFBQVFBLE9BQU0sR0FBRyxPQUFPLFlBQVksUUFBUTtBQUNqRixhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsWUFBYSxNQUFNO0FBQzFCLGFBQU8sSUFBSSxXQUFXLElBQUk7QUFBQSxJQUM1QjtBQUVBLGFBQVMsZ0JBQWlCLE1BQU07QUFDOUIsYUFBTyxJQUFJLFdBQVcsSUFBSTtBQUFBLElBQzVCO0FBRUEsYUFBUyxXQUFZLFFBQVEsVUFBVTtBQUNyQyxhQUFPLFNBQVMsUUFBUSxFQUFFLFdBQVcsTUFBTTtBQUFBLElBQzdDO0FBRUEsYUFBUyxRQUFTLEdBQUcsR0FBRztBQUN0QixVQUFJLE1BQU0sRUFBRyxRQUFPO0FBRXBCLFlBQU0sTUFBTSxLQUFLLElBQUksRUFBRSxZQUFZLEVBQUUsVUFBVTtBQUUvQyxVQUFJLElBQUksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsVUFBVTtBQUNyRCxVQUFJLElBQUksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsVUFBVTtBQUVyRCxVQUFJLElBQUk7QUFFUixlQUFTLElBQUksTUFBTyxNQUFNLEdBQUksSUFBSSxHQUFHLEtBQUssR0FBRztBQUMzQyxjQUFNLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUMzQixjQUFNLElBQUksRUFBRSxVQUFVLEdBQUcsRUFBRTtBQUMzQixZQUFJLE1BQU0sRUFBRztBQUFBLE1BQ2Y7QUFFQSxhQUFPLElBQUksS0FBSyxLQUFLO0FBQ25CLGNBQU0sSUFBSSxFQUFFLFNBQVMsQ0FBQztBQUN0QixjQUFNLElBQUksRUFBRSxTQUFTLENBQUM7QUFDdEIsWUFBSSxJQUFJLEVBQUcsUUFBTztBQUNsQixZQUFJLElBQUksRUFBRyxRQUFPO0FBQUEsTUFDcEI7QUFFQSxhQUFPLEVBQUUsYUFBYSxFQUFFLGFBQWEsSUFBSSxFQUFFLGFBQWEsRUFBRSxhQUFhLEtBQUs7QUFBQSxJQUM5RTtBQUVBLGFBQVMsT0FBUSxTQUFTLGFBQWE7QUFDckMsVUFBSSxnQkFBZ0IsUUFBVztBQUM3QixzQkFBYyxRQUFRLE9BQU8sQ0FBQyxLQUFLLFdBQVcsTUFBTSxPQUFPLFlBQVksQ0FBQztBQUFBLE1BQzFFO0FBRUEsWUFBTSxTQUFTLElBQUksV0FBVyxXQUFXO0FBRXpDLFVBQUksU0FBUztBQUNiLGlCQUFXLFVBQVUsU0FBUztBQUM1QixZQUFJLFNBQVMsT0FBTyxhQUFhLE9BQU8sWUFBWTtBQUNsRCxnQkFBTSxNQUFNLE9BQU8sU0FBUyxHQUFHLE9BQU8sYUFBYSxNQUFNO0FBQ3pELGlCQUFPLElBQUksS0FBSyxNQUFNO0FBQ3RCLGlCQUFPO0FBQUEsUUFDVDtBQUNBLGVBQU8sSUFBSSxRQUFRLE1BQU07QUFDekIsa0JBQVUsT0FBTztBQUFBLE1BQ25CO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLEtBQU0sUUFBUSxRQUFRLGNBQWMsR0FBRyxRQUFRLEdBQUcsTUFBTSxPQUFPLFlBQVk7QUFDbEYsVUFBSSxNQUFNLEtBQUssTUFBTSxNQUFPLFFBQU87QUFDbkMsVUFBSSxRQUFRLE1BQU8sUUFBTztBQUMxQixVQUFJLE9BQU8sZUFBZSxLQUFLLE9BQU8sZUFBZSxFQUFHLFFBQU87QUFFL0QsVUFBSSxjQUFjLEVBQUcsT0FBTSxJQUFJLFdBQVcsNkJBQTZCO0FBQ3ZFLFVBQUksUUFBUSxLQUFLLFNBQVMsT0FBTyxXQUFZLE9BQU0sSUFBSSxXQUFXLDZCQUE2QjtBQUMvRixVQUFJLE1BQU0sRUFBRyxPQUFNLElBQUksV0FBVywyQkFBMkI7QUFFN0QsVUFBSSxlQUFlLE9BQU8sV0FBWSxlQUFjLE9BQU87QUFDM0QsVUFBSSxNQUFNLE9BQU8sV0FBWSxPQUFNLE9BQU87QUFDMUMsVUFBSSxPQUFPLGFBQWEsY0FBYyxNQUFNLE9BQU87QUFDakQsY0FBTSxPQUFPLFNBQVMsY0FBYztBQUFBLE1BQ3RDO0FBRUEsWUFBTSxNQUFNLE1BQU07QUFFbEIsVUFBSSxXQUFXLFFBQVE7QUFDckIsZUFBTyxXQUFXLGFBQWEsT0FBTyxHQUFHO0FBQUEsTUFDM0MsT0FBTztBQUNMLGVBQU8sSUFBSSxPQUFPLFNBQVMsT0FBTyxHQUFHLEdBQUcsV0FBVztBQUFBLE1BQ3JEO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLE9BQVEsR0FBRyxHQUFHO0FBQ3JCLFVBQUksTUFBTSxFQUFHLFFBQU87QUFDcEIsVUFBSSxFQUFFLGVBQWUsRUFBRSxXQUFZLFFBQU87QUFFMUMsWUFBTSxNQUFNLEVBQUU7QUFFZCxVQUFJLElBQUksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsVUFBVTtBQUNyRCxVQUFJLElBQUksU0FBUyxFQUFFLFFBQVEsRUFBRSxZQUFZLEVBQUUsVUFBVTtBQUVyRCxVQUFJLElBQUk7QUFFUixlQUFTLElBQUksTUFBTyxNQUFNLEdBQUksSUFBSSxHQUFHLEtBQUssR0FBRztBQUMzQyxZQUFJLEVBQUUsVUFBVSxHQUFHLEVBQUUsTUFBTSxFQUFFLFVBQVUsR0FBRyxFQUFFLEVBQUcsUUFBTztBQUFBLE1BQ3hEO0FBRUEsYUFBTyxJQUFJLEtBQUssS0FBSztBQUNuQixZQUFJLEVBQUUsU0FBUyxDQUFDLE1BQU0sRUFBRSxTQUFTLENBQUMsRUFBRyxRQUFPO0FBQUEsTUFDOUM7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsS0FBTSxRQUFRLE9BQU8sUUFBUSxLQUFLLFVBQVU7QUFDbkQsVUFBSSxPQUFPLFVBQVUsVUFBVTtBQUU3QixZQUFJLE9BQU8sV0FBVyxVQUFVO0FBQzlCLHFCQUFXO0FBQ1gsbUJBQVM7QUFDVCxnQkFBTSxPQUFPO0FBQUEsUUFHZixXQUFXLE9BQU8sUUFBUSxVQUFVO0FBQ2xDLHFCQUFXO0FBQ1gsZ0JBQU0sT0FBTztBQUFBLFFBQ2Y7QUFBQSxNQUNGLFdBQVcsT0FBTyxVQUFVLFVBQVU7QUFDcEMsZ0JBQVEsUUFBUTtBQUFBLE1BQ2xCLFdBQVcsT0FBTyxVQUFVLFdBQVc7QUFDckMsZ0JBQVEsQ0FBQztBQUFBLE1BQ1g7QUFFQSxVQUFJLFNBQVMsS0FBSyxPQUFPLGFBQWEsVUFBVSxPQUFPLGFBQWEsS0FBSztBQUN2RSxjQUFNLElBQUksV0FBVyxvQkFBb0I7QUFBQSxNQUMzQztBQUVBLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFDbkMsVUFBSSxRQUFRLE9BQVcsT0FBTSxPQUFPO0FBRXBDLFVBQUksT0FBTyxPQUFRLFFBQU87QUFFMUIsVUFBSSxDQUFDLE1BQU8sU0FBUTtBQUVwQixVQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLGlCQUFTLElBQUksUUFBUSxJQUFJLEtBQUssRUFBRSxHQUFHO0FBQ2pDLGlCQUFPLENBQUMsSUFBSTtBQUFBLFFBQ2Q7QUFBQSxNQUNGLE9BQU87QUFDTCxnQkFBUSxTQUFTLEtBQUssSUFBSSxRQUFRLEtBQUssT0FBTyxRQUFRO0FBRXRELGNBQU0sTUFBTSxNQUFNO0FBRWxCLGlCQUFTLElBQUksR0FBRyxJQUFJLE1BQU0sUUFBUSxFQUFFLEdBQUc7QUFDckMsaUJBQU8sSUFBSSxNQUFNLElBQUksTUFBTSxJQUFJLEdBQUc7QUFBQSxRQUNwQztBQUFBLE1BQ0Y7QUFFQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsS0FBTSxPQUFPLGtCQUFrQixRQUFRO0FBRTlDLFVBQUksT0FBTyxVQUFVLFNBQVUsUUFBTyxXQUFXLE9BQU8sZ0JBQWdCO0FBR3hFLFVBQUksTUFBTSxRQUFRLEtBQUssRUFBRyxRQUFPLFVBQVUsS0FBSztBQUdoRCxVQUFJLFlBQVksT0FBTyxLQUFLLEVBQUcsUUFBTyxXQUFXLEtBQUs7QUFHdEQsYUFBTyxnQkFBZ0IsT0FBTyxrQkFBa0IsTUFBTTtBQUFBLElBQ3hEO0FBRUEsYUFBUyxXQUFZLFFBQVEsVUFBVTtBQUNyQyxZQUFNLFFBQVEsU0FBUyxRQUFRO0FBQy9CLFlBQU0sU0FBUyxJQUFJLFdBQVcsTUFBTSxXQUFXLE1BQU0sQ0FBQztBQUN0RCxZQUFNLE1BQU0sUUFBUSxRQUFRLEdBQUcsT0FBTyxVQUFVO0FBQ2hELGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxVQUFXLE9BQU87QUFDekIsWUFBTSxTQUFTLElBQUksV0FBVyxNQUFNLE1BQU07QUFDMUMsYUFBTyxJQUFJLEtBQUs7QUFDaEIsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFdBQVksUUFBUTtBQUMzQixZQUFNQyxRQUFPLElBQUksV0FBVyxPQUFPLFVBQVU7QUFDN0MsTUFBQUEsTUFBSyxJQUFJLE1BQU07QUFDZixhQUFPQTtBQUFBLElBQ1Q7QUFFQSxhQUFTLGdCQUFpQixhQUFhLFlBQVksUUFBUTtBQUN6RCxhQUFPLElBQUksV0FBVyxhQUFhLFlBQVksTUFBTTtBQUFBLElBQ3ZEO0FBRUEsYUFBUyxTQUFVLFFBQVEsT0FBTyxZQUFZLFVBQVU7QUFDdEQsYUFBTyxRQUFRLFFBQVEsT0FBTyxZQUFZLFFBQVEsTUFBTTtBQUFBLElBQzFEO0FBRUEsYUFBUyxxQkFBc0IsUUFBUSxPQUFPLFlBQVksVUFBVSxPQUFPO0FBQ3pFLFVBQUksT0FBTyxlQUFlLEVBQUcsUUFBTztBQUVwQyxVQUFJLE9BQU8sZUFBZSxVQUFVO0FBQ2xDLG1CQUFXO0FBQ1gscUJBQWE7QUFBQSxNQUNmLFdBQVcsZUFBZSxRQUFXO0FBQ25DLHFCQUFhLFFBQVEsSUFBSyxPQUFPLFNBQVM7QUFBQSxNQUM1QyxXQUFXLGFBQWEsR0FBRztBQUN6QixzQkFBYyxPQUFPO0FBQUEsTUFDdkI7QUFFQSxVQUFJLGNBQWMsT0FBTyxZQUFZO0FBQ25DLFlBQUksTUFBTyxRQUFPO0FBQUEsWUFDYixjQUFhLE9BQU8sYUFBYTtBQUFBLE1BQ3hDLFdBQVcsYUFBYSxHQUFHO0FBQ3pCLFlBQUksTUFBTyxjQUFhO0FBQUEsWUFDbkIsUUFBTztBQUFBLE1BQ2Q7QUFFQSxVQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLGdCQUFRLEtBQUssT0FBTyxRQUFRO0FBQUEsTUFDOUIsV0FBVyxPQUFPLFVBQVUsVUFBVTtBQUNwQyxnQkFBUSxRQUFRO0FBRWhCLFlBQUksT0FBTztBQUNULGlCQUFPLE9BQU8sUUFBUSxPQUFPLFVBQVU7QUFBQSxRQUN6QyxPQUFPO0FBQ0wsaUJBQU8sT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUFBLFFBQzdDO0FBQUEsTUFDRjtBQUVBLFVBQUksTUFBTSxlQUFlLEVBQUcsUUFBTztBQUVuQyxVQUFJLE9BQU87QUFDVCxZQUFJLGFBQWE7QUFFakIsaUJBQVMsSUFBSSxZQUFZLElBQUksT0FBTyxZQUFZLEtBQUs7QUFDbkQsY0FBSSxPQUFPLENBQUMsTUFBTSxNQUFNLGVBQWUsS0FBSyxJQUFJLElBQUksVUFBVSxHQUFHO0FBQy9ELGdCQUFJLGVBQWUsR0FBSSxjQUFhO0FBQ3BDLGdCQUFJLElBQUksYUFBYSxNQUFNLE1BQU0sV0FBWSxRQUFPO0FBQUEsVUFDdEQsT0FBTztBQUNMLGdCQUFJLGVBQWUsR0FBSSxNQUFLLElBQUk7QUFDaEMseUJBQWE7QUFBQSxVQUNmO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLFlBQUksYUFBYSxNQUFNLGFBQWEsT0FBTyxZQUFZO0FBQ3JELHVCQUFhLE9BQU8sYUFBYSxNQUFNO0FBQUEsUUFDekM7QUFFQSxpQkFBUyxJQUFJLFlBQVksS0FBSyxHQUFHLEtBQUs7QUFDcEMsY0FBSSxRQUFRO0FBRVosbUJBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxZQUFZLEtBQUs7QUFDekMsZ0JBQUksT0FBTyxJQUFJLENBQUMsTUFBTSxNQUFNLENBQUMsR0FBRztBQUM5QixzQkFBUTtBQUNSO0FBQUEsWUFDRjtBQUFBLFVBQ0Y7QUFFQSxjQUFJLE1BQU8sUUFBTztBQUFBLFFBQ3BCO0FBQUEsTUFDRjtBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxRQUFTLFFBQVEsT0FBTyxZQUFZLFVBQVU7QUFDckQsYUFBTztBQUFBLFFBQXFCO0FBQUEsUUFBUTtBQUFBLFFBQU87QUFBQSxRQUFZO0FBQUEsUUFBVTtBQUFBO0FBQUEsTUFBZ0I7QUFBQSxJQUNuRjtBQUVBLGFBQVMsWUFBYSxRQUFRLE9BQU8sWUFBWSxVQUFVO0FBQ3pELGFBQU87QUFBQSxRQUFxQjtBQUFBLFFBQVE7QUFBQSxRQUFPO0FBQUEsUUFBWTtBQUFBLFFBQVU7QUFBQTtBQUFBLE1BQWdCO0FBQUEsSUFDbkY7QUFFQSxhQUFTLEtBQU0sUUFBUSxHQUFHLEdBQUc7QUFDM0IsWUFBTSxJQUFJLE9BQU8sQ0FBQztBQUNsQixhQUFPLENBQUMsSUFBSSxPQUFPLENBQUM7QUFDcEIsYUFBTyxDQUFDLElBQUk7QUFBQSxJQUNkO0FBRUEsYUFBUyxPQUFRLFFBQVE7QUFDdkIsWUFBTSxNQUFNLE9BQU87QUFFbkIsVUFBSSxNQUFNLE1BQU0sRUFBRyxPQUFNLElBQUksV0FBVywyQ0FBMkM7QUFFbkYsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUssRUFBRyxNQUFLLFFBQVEsR0FBRyxJQUFJLENBQUM7QUFFdEQsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLE9BQVEsUUFBUTtBQUN2QixZQUFNLE1BQU0sT0FBTztBQUVuQixVQUFJLE1BQU0sTUFBTSxFQUFHLE9BQU0sSUFBSSxXQUFXLDJDQUEyQztBQUVuRixlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxHQUFHO0FBQy9CLGFBQUssUUFBUSxHQUFHLElBQUksQ0FBQztBQUNyQixhQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksQ0FBQztBQUFBLE1BQzNCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLE9BQVEsUUFBUTtBQUN2QixZQUFNLE1BQU0sT0FBTztBQUVuQixVQUFJLE1BQU0sTUFBTSxFQUFHLE9BQU0sSUFBSSxXQUFXLDJDQUEyQztBQUVuRixlQUFTLElBQUksR0FBRyxJQUFJLEtBQUssS0FBSyxHQUFHO0FBQy9CLGFBQUssUUFBUSxHQUFHLElBQUksQ0FBQztBQUNyQixhQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksQ0FBQztBQUN6QixhQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksQ0FBQztBQUN6QixhQUFLLFFBQVEsSUFBSSxHQUFHLElBQUksQ0FBQztBQUFBLE1BQzNCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFNBQVUsUUFBUTtBQUN6QixhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsU0FBVSxRQUFRLFVBQVUsUUFBUSxHQUFHLE1BQU0sT0FBTyxZQUFZO0FBQ3ZFLFlBQU0sTUFBTSxPQUFPO0FBRW5CLFVBQUksU0FBUyxJQUFLLFFBQU87QUFDekIsVUFBSSxPQUFPLE1BQU8sUUFBTztBQUN6QixVQUFJLFFBQVEsRUFBRyxTQUFRO0FBQ3ZCLFVBQUksTUFBTSxJQUFLLE9BQU07QUFFckIsVUFBSSxVQUFVLEtBQUssTUFBTSxJQUFLLFVBQVMsT0FBTyxTQUFTLE9BQU8sR0FBRztBQUVqRSxhQUFPLFNBQVMsUUFBUSxFQUFFLFNBQVMsTUFBTTtBQUFBLElBQzNDO0FBRUEsYUFBUyxNQUFPLFFBQVEsUUFBUSxRQUFRLFFBQVEsVUFBVTtBQUV4RCxVQUFJLFdBQVcsUUFBVztBQUN4QixtQkFBVztBQUFBLE1BR2IsV0FBVyxXQUFXLFVBQWEsT0FBTyxXQUFXLFVBQVU7QUFDN0QsbUJBQVc7QUFDWCxpQkFBUztBQUFBLE1BR1gsV0FBVyxhQUFhLFVBQWEsT0FBTyxXQUFXLFVBQVU7QUFDL0QsbUJBQVc7QUFDWCxpQkFBUztBQUFBLE1BQ1g7QUFFQSxhQUFPLFNBQVMsUUFBUSxFQUFFLE1BQU0sUUFBUSxRQUFRLFFBQVEsTUFBTTtBQUFBLElBQ2hFO0FBRUEsYUFBUyxjQUFlLFFBQVEsT0FBTyxRQUFRO0FBQzdDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUM3RSxXQUFLLFdBQVcsUUFBUSxPQUFPLElBQUk7QUFFbkMsYUFBTyxTQUFTO0FBQUEsSUFDbEI7QUFFQSxhQUFTLGFBQWMsUUFBUSxPQUFPLFFBQVE7QUFDNUMsVUFBSSxXQUFXLE9BQVcsVUFBUztBQUVuQyxZQUFNLE9BQU8sSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPLFlBQVksT0FBTyxVQUFVO0FBQzdFLFdBQUssV0FBVyxRQUFRLE9BQU8sSUFBSTtBQUVuQyxhQUFPLFNBQVM7QUFBQSxJQUNsQjtBQUVBLGFBQVMsY0FBZSxRQUFRLE9BQU8sUUFBUTtBQUM3QyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFDN0UsV0FBSyxVQUFVLFFBQVEsT0FBTyxJQUFJO0FBRWxDLGFBQU8sU0FBUztBQUFBLElBQ2xCO0FBRUEsYUFBUyxhQUFjLFFBQVEsT0FBTyxRQUFRO0FBQzVDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUM3RSxXQUFLLFNBQVMsUUFBUSxPQUFPLElBQUk7QUFFakMsYUFBTyxTQUFTO0FBQUEsSUFDbEI7QUFFQSxhQUFTLGFBQWMsUUFBUSxRQUFRO0FBQ3JDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUU3RSxhQUFPLEtBQUssV0FBVyxRQUFRLElBQUk7QUFBQSxJQUNyQztBQUVBLGFBQVMsWUFBYSxRQUFRLFFBQVE7QUFDcEMsVUFBSSxXQUFXLE9BQVcsVUFBUztBQUVuQyxZQUFNLE9BQU8sSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPLFlBQVksT0FBTyxVQUFVO0FBRTdFLGFBQU8sS0FBSyxXQUFXLFFBQVEsSUFBSTtBQUFBLElBQ3JDO0FBRUEsYUFBUyxhQUFjLFFBQVEsUUFBUTtBQUNyQyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFFN0UsYUFBTyxLQUFLLFVBQVUsUUFBUSxJQUFJO0FBQUEsSUFDcEM7QUFFQSxhQUFTLFlBQWEsUUFBUSxRQUFRO0FBQ3BDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUU3RSxhQUFPLEtBQUssU0FBUyxRQUFRLElBQUk7QUFBQSxJQUNuQztBQUVBLGFBQVMsY0FBZSxRQUFRLE9BQU8sUUFBUTtBQUM3QyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFDN0UsV0FBSyxXQUFXLFFBQVEsT0FBTyxLQUFLO0FBRXBDLGFBQU8sU0FBUztBQUFBLElBQ2xCO0FBRUEsYUFBUyxhQUFjLFFBQVEsT0FBTyxRQUFRO0FBQzVDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUM3RSxXQUFLLFdBQVcsUUFBUSxPQUFPLEtBQUs7QUFFcEMsYUFBTyxTQUFTO0FBQUEsSUFDbEI7QUFFQSxhQUFTLGNBQWUsUUFBUSxPQUFPLFFBQVE7QUFDN0MsVUFBSSxXQUFXLE9BQVcsVUFBUztBQUVuQyxZQUFNLE9BQU8sSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPLFlBQVksT0FBTyxVQUFVO0FBQzdFLFdBQUssVUFBVSxRQUFRLE9BQU8sS0FBSztBQUVuQyxhQUFPLFNBQVM7QUFBQSxJQUNsQjtBQUVBLGFBQVMsYUFBYyxRQUFRLE9BQU8sUUFBUTtBQUM1QyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFDN0UsV0FBSyxTQUFTLFFBQVEsT0FBTyxLQUFLO0FBRWxDLGFBQU8sU0FBUztBQUFBLElBQ2xCO0FBRUEsYUFBUyxhQUFjLFFBQVEsUUFBUTtBQUNyQyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFFN0UsYUFBTyxLQUFLLFdBQVcsUUFBUSxLQUFLO0FBQUEsSUFDdEM7QUFFQSxhQUFTLFlBQWEsUUFBUSxRQUFRO0FBQ3BDLFVBQUksV0FBVyxPQUFXLFVBQVM7QUFFbkMsWUFBTSxPQUFPLElBQUksU0FBUyxPQUFPLFFBQVEsT0FBTyxZQUFZLE9BQU8sVUFBVTtBQUU3RSxhQUFPLEtBQUssV0FBVyxRQUFRLEtBQUs7QUFBQSxJQUN0QztBQUVBLGFBQVMsYUFBYyxRQUFRLFFBQVE7QUFDckMsVUFBSSxXQUFXLE9BQVcsVUFBUztBQUVuQyxZQUFNLE9BQU8sSUFBSSxTQUFTLE9BQU8sUUFBUSxPQUFPLFlBQVksT0FBTyxVQUFVO0FBRTdFLGFBQU8sS0FBSyxVQUFVLFFBQVEsS0FBSztBQUFBLElBQ3JDO0FBRUEsYUFBUyxZQUFhLFFBQVEsUUFBUTtBQUNwQyxVQUFJLFdBQVcsT0FBVyxVQUFTO0FBRW5DLFlBQU0sT0FBTyxJQUFJLFNBQVMsT0FBTyxRQUFRLE9BQU8sWUFBWSxPQUFPLFVBQVU7QUFFN0UsYUFBTyxLQUFLLFNBQVMsUUFBUSxLQUFLO0FBQUEsSUFDcEM7QUFFQSxXQUFPLFVBQVUsVUFBVTtBQUFBLE1BQ3pCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUFBO0FBQUE7OztBQy9qQkE7QUFBQTtBQUFBLFFBQU1DLE9BQU07QUFFWixRQUFNLFFBQVE7QUFDZCxRQUFNLFNBQVM7QUFDZixRQUFNLGNBQWMsSUFBSSxXQUFXLENBQUM7QUFDcEMsUUFBTSxjQUFjQSxLQUFJLEtBQUssQ0FBQyxLQUFNLEtBQU0sS0FBTSxJQUFNLEtBQU0sQ0FBSSxDQUFDO0FBQ2pFLFFBQU0sWUFBWUEsS0FBSSxLQUFLLENBQUMsYUFBYSxXQUFXLENBQUM7QUFDckQsUUFBTSxZQUFZQSxLQUFJLEtBQUssQ0FBQyxLQUFNLEtBQU0sS0FBTSxJQUFNLEtBQU0sRUFBSSxDQUFDO0FBQy9ELFFBQU0sVUFBVUEsS0FBSSxLQUFLLENBQUMsSUFBTSxDQUFJLENBQUM7QUFDckMsUUFBTSxPQUFPO0FBQ2IsUUFBTSxlQUFlO0FBQ3JCLFFBQU0saUJBQWlCO0FBRXZCLFlBQVEsaUJBQWlCLFNBQVMsZUFBZ0IsS0FBSyxVQUFVO0FBQy9ELGFBQU8sVUFBVSxLQUFLLEdBQUcsSUFBSSxRQUFRLFFBQVE7QUFBQSxJQUMvQztBQUVBLFlBQVEsWUFBWSxTQUFTLFVBQVcsTUFBTTtBQUM1QyxVQUFJLFNBQVM7QUFDYixVQUFJLEtBQUssS0FBTSxXQUFVLFVBQVUsV0FBVyxLQUFLLE9BQU8sSUFBSTtBQUM5RCxVQUFJLEtBQUssU0FBVSxXQUFVLFVBQVUsZUFBZSxLQUFLLFdBQVcsSUFBSTtBQUMxRSxZQUFNLE1BQU0sS0FBSztBQUNqQixVQUFJLEtBQUs7QUFDUCxtQkFBVyxPQUFPLEtBQUs7QUFDckIsb0JBQVUsVUFBVSxNQUFNLE1BQU0sTUFBTSxJQUFJLEdBQUcsSUFBSSxJQUFJO0FBQUEsUUFDdkQ7QUFBQSxNQUNGO0FBQ0EsYUFBT0EsS0FBSSxLQUFLLE1BQU07QUFBQSxJQUN4QjtBQUVBLFlBQVEsWUFBWSxTQUFTLFVBQVcsS0FBSztBQUMzQyxZQUFNLFNBQVMsQ0FBQztBQUVoQixhQUFPLElBQUksUUFBUTtBQUNqQixZQUFJLElBQUk7QUFDUixlQUFPLElBQUksSUFBSSxVQUFVLElBQUksQ0FBQyxNQUFNLEdBQUk7QUFDeEMsY0FBTSxNQUFNLFNBQVNBLEtBQUksU0FBUyxJQUFJLFNBQVMsR0FBRyxDQUFDLENBQUMsR0FBRyxFQUFFO0FBQ3pELFlBQUksQ0FBQyxJQUFLLFFBQU87QUFFakIsY0FBTSxJQUFJQSxLQUFJLFNBQVMsSUFBSSxTQUFTLElBQUksR0FBRyxNQUFNLENBQUMsQ0FBQztBQUNuRCxjQUFNLFdBQVcsRUFBRSxRQUFRLEdBQUc7QUFDOUIsWUFBSSxhQUFhLEdBQUksUUFBTztBQUM1QixlQUFPLEVBQUUsTUFBTSxHQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxXQUFXLENBQUM7QUFFbkQsY0FBTSxJQUFJLFNBQVMsR0FBRztBQUFBLE1BQ3hCO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxZQUFRLFNBQVMsU0FBUyxPQUFRLE1BQU07QUFDdEMsWUFBTSxNQUFNQSxLQUFJLE1BQU0sR0FBRztBQUN6QixVQUFJLE9BQU8sS0FBSztBQUNoQixVQUFJLFNBQVM7QUFFYixVQUFJLEtBQUssYUFBYSxLQUFLLEtBQUssS0FBSyxTQUFTLENBQUMsTUFBTSxJQUFLLFNBQVE7QUFDbEUsVUFBSUEsS0FBSSxXQUFXLElBQUksTUFBTSxLQUFLLE9BQVEsUUFBTztBQUVqRCxhQUFPQSxLQUFJLFdBQVcsSUFBSSxJQUFJLEtBQUs7QUFDakMsY0FBTSxJQUFJLEtBQUssUUFBUSxHQUFHO0FBQzFCLFlBQUksTUFBTSxHQUFJLFFBQU87QUFDckIsa0JBQVUsU0FBUyxNQUFNLEtBQUssTUFBTSxHQUFHLENBQUMsSUFBSSxLQUFLLE1BQU0sR0FBRyxDQUFDO0FBQzNELGVBQU8sS0FBSyxNQUFNLElBQUksQ0FBQztBQUFBLE1BQ3pCO0FBRUEsVUFBSUEsS0FBSSxXQUFXLElBQUksSUFBSSxPQUFPQSxLQUFJLFdBQVcsTUFBTSxJQUFJLElBQUssUUFBTztBQUN2RSxVQUFJLEtBQUssWUFBWUEsS0FBSSxXQUFXLEtBQUssUUFBUSxJQUFJLElBQUssUUFBTztBQUVqRSxNQUFBQSxLQUFJLE1BQU0sS0FBSyxJQUFJO0FBQ25CLE1BQUFBLEtBQUksTUFBTSxLQUFLLFVBQVUsS0FBSyxPQUFPLE1BQU0sQ0FBQyxHQUFHLEdBQUc7QUFDbEQsTUFBQUEsS0FBSSxNQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssQ0FBQyxHQUFHLEdBQUc7QUFDMUMsTUFBQUEsS0FBSSxNQUFNLEtBQUssVUFBVSxLQUFLLEtBQUssQ0FBQyxHQUFHLEdBQUc7QUFDMUMsaUJBQVcsS0FBSyxNQUFNLEtBQUssR0FBRztBQUM5QixNQUFBQSxLQUFJLE1BQU0sS0FBSyxVQUFXLEtBQUssTUFBTSxRQUFRLElBQUksTUFBUSxHQUFHLEVBQUUsR0FBRyxHQUFHO0FBRXBFLFVBQUksR0FBRyxJQUFJLGNBQWMsV0FBVyxLQUFLLElBQUk7QUFFN0MsVUFBSSxLQUFLLFNBQVUsQ0FBQUEsS0FBSSxNQUFNLEtBQUssS0FBSyxVQUFVLEdBQUc7QUFFcEQsTUFBQUEsS0FBSSxLQUFLLGFBQWEsS0FBSyxZQUFZO0FBQ3ZDLE1BQUFBLEtBQUksS0FBSyxXQUFXLEtBQUssY0FBYztBQUN2QyxVQUFJLEtBQUssTUFBTyxDQUFBQSxLQUFJLE1BQU0sS0FBSyxLQUFLLE9BQU8sR0FBRztBQUM5QyxVQUFJLEtBQUssTUFBTyxDQUFBQSxLQUFJLE1BQU0sS0FBSyxLQUFLLE9BQU8sR0FBRztBQUM5QyxNQUFBQSxLQUFJLE1BQU0sS0FBSyxVQUFVLEtBQUssWUFBWSxHQUFHLENBQUMsR0FBRyxHQUFHO0FBQ3BELE1BQUFBLEtBQUksTUFBTSxLQUFLLFVBQVUsS0FBSyxZQUFZLEdBQUcsQ0FBQyxHQUFHLEdBQUc7QUFFcEQsVUFBSSxPQUFRLENBQUFBLEtBQUksTUFBTSxLQUFLLFFBQVEsR0FBRztBQUV0QyxNQUFBQSxLQUFJLE1BQU0sS0FBSyxVQUFVLE1BQU0sR0FBRyxHQUFHLENBQUMsR0FBRyxHQUFHO0FBRTVDLGFBQU87QUFBQSxJQUNUO0FBRUEsWUFBUSxTQUFTLFNBQVMsT0FBUSxLQUFLLGtCQUFrQixvQkFBb0I7QUFDM0UsVUFBSSxXQUFXLElBQUksR0FBRyxNQUFNLElBQUksSUFBSSxJQUFJLEdBQUcsSUFBSTtBQUUvQyxVQUFJLE9BQU8sVUFBVSxLQUFLLEdBQUcsS0FBSyxnQkFBZ0I7QUFDbEQsWUFBTSxPQUFPLFVBQVUsS0FBSyxLQUFLLENBQUM7QUFDbEMsWUFBTSxNQUFNLFVBQVUsS0FBSyxLQUFLLENBQUM7QUFDakMsWUFBTSxNQUFNLFVBQVUsS0FBSyxLQUFLLENBQUM7QUFDakMsWUFBTSxPQUFPLFVBQVUsS0FBSyxLQUFLLEVBQUU7QUFDbkMsWUFBTSxRQUFRLFVBQVUsS0FBSyxLQUFLLEVBQUU7QUFDcEMsWUFBTSxPQUFPLE9BQU8sUUFBUTtBQUM1QixZQUFNLFdBQVcsSUFBSSxHQUFHLE1BQU0sSUFBSSxPQUFPLFVBQVUsS0FBSyxLQUFLLEtBQUssZ0JBQWdCO0FBQ2xGLFlBQU0sUUFBUSxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ3BDLFlBQU0sUUFBUSxVQUFVLEtBQUssS0FBSyxFQUFFO0FBQ3BDLFlBQU0sV0FBVyxVQUFVLEtBQUssS0FBSyxDQUFDO0FBQ3RDLFlBQU0sV0FBVyxVQUFVLEtBQUssS0FBSyxDQUFDO0FBRXRDLFlBQU0sSUFBSSxNQUFNLEdBQUc7QUFHbkIsVUFBSSxNQUFNLElBQUksR0FBSSxRQUFPO0FBR3pCLFVBQUksTUFBTSxVQUFVLEtBQUssS0FBSyxDQUFDLEVBQUcsT0FBTSxJQUFJLE1BQU0sNkVBQTZFO0FBRS9ILFVBQUksUUFBUSxHQUFHLEdBQUc7QUFHaEIsWUFBSSxJQUFJLEdBQUcsRUFBRyxRQUFPLFVBQVUsS0FBSyxLQUFLLEtBQUssZ0JBQWdCLElBQUksTUFBTTtBQUFBLE1BQzFFLFdBQVcsTUFBTSxHQUFHLEdBQUc7QUFBQSxNQUd2QixPQUFPO0FBQ0wsWUFBSSxDQUFDLG9CQUFvQjtBQUN2QixnQkFBTSxJQUFJLE1BQU0scUNBQXFDO0FBQUEsUUFDdkQ7QUFBQSxNQUNGO0FBR0EsVUFBSSxhQUFhLEtBQUssUUFBUSxLQUFLLEtBQUssU0FBUyxDQUFDLE1BQU0sSUFBSyxZQUFXO0FBRXhFLGFBQU87QUFBQSxRQUNMO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsT0FBTyxJQUFJLEtBQUssTUFBTyxLQUFLO0FBQUEsUUFDNUI7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLFFBQ0EsS0FBSztBQUFBLE1BQ1A7QUFBQSxJQUNGO0FBRUEsYUFBUyxRQUFTLEtBQUs7QUFDckIsYUFBT0EsS0FBSSxPQUFPLGFBQWEsSUFBSSxTQUFTLGNBQWMsZUFBZSxDQUFDLENBQUM7QUFBQSxJQUM3RTtBQUVBLGFBQVMsTUFBTyxLQUFLO0FBQ25CLGFBQU9BLEtBQUksT0FBTyxXQUFXLElBQUksU0FBUyxjQUFjLGVBQWUsQ0FBQyxDQUFDLEtBQ3ZFQSxLQUFJLE9BQU8sU0FBUyxJQUFJLFNBQVMsZ0JBQWdCLGlCQUFpQixDQUFDLENBQUM7QUFBQSxJQUN4RTtBQUVBLGFBQVMsTUFBTyxPQUFPLEtBQUssY0FBYztBQUN4QyxVQUFJLE9BQU8sVUFBVSxTQUFVLFFBQU87QUFDdEMsY0FBUSxDQUFDLENBQUM7QUFDVixVQUFJLFNBQVMsSUFBSyxRQUFPO0FBQ3pCLFVBQUksU0FBUyxFQUFHLFFBQU87QUFDdkIsZUFBUztBQUNULFVBQUksU0FBUyxFQUFHLFFBQU87QUFDdkIsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLE9BQVEsTUFBTTtBQUNyQixjQUFRLE1BQU07QUFBQSxRQUNaLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQUEsUUFDTCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxNQUNYO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFdBQVksTUFBTTtBQUN6QixjQUFRLE1BQU07QUFBQSxRQUNaLEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxRQUNULEtBQUs7QUFDSCxpQkFBTztBQUFBLFFBQ1QsS0FBSztBQUNILGlCQUFPO0FBQUEsUUFDVCxLQUFLO0FBQ0gsaUJBQU87QUFBQSxNQUNYO0FBRUEsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFFBQVMsT0FBTyxLQUFLLFFBQVEsS0FBSztBQUN6QyxhQUFPLFNBQVMsS0FBSyxVQUFVO0FBQzdCLFlBQUksTUFBTSxNQUFNLE1BQU0sSUFBSyxRQUFPO0FBQUEsTUFDcEM7QUFDQSxhQUFPO0FBQUEsSUFDVDtBQUVBLGFBQVMsTUFBTyxPQUFPO0FBQ3JCLFVBQUksTUFBTSxJQUFJO0FBQ2QsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLElBQUssUUFBTyxNQUFNLENBQUM7QUFDNUMsZUFBUyxJQUFJLEtBQUssSUFBSSxLQUFLLElBQUssUUFBTyxNQUFNLENBQUM7QUFDOUMsYUFBTztBQUFBLElBQ1Q7QUFFQSxhQUFTLFVBQVcsS0FBSyxHQUFHO0FBQzFCLFlBQU0sSUFBSSxTQUFTLENBQUM7QUFDcEIsVUFBSSxJQUFJLFNBQVMsRUFBRyxRQUFPLE9BQU8sTUFBTSxHQUFHLENBQUMsSUFBSTtBQUNoRCxhQUFPLE1BQU0sTUFBTSxHQUFHLElBQUksSUFBSSxNQUFNLElBQUksTUFBTTtBQUFBLElBQ2hEO0FBRUEsYUFBUyxjQUFlLEtBQUssS0FBSyxLQUFLO0FBQ3JDLFVBQUksR0FBRyxJQUFJO0FBQ1gsZUFBUyxJQUFJLElBQUksSUFBSSxHQUFHLEtBQUs7QUFDM0IsWUFBSSxNQUFNLENBQUMsSUFBSSxNQUFNO0FBQ3JCLGNBQU0sS0FBSyxNQUFNLE1BQU0sR0FBSztBQUFBLE1BQzlCO0FBQUEsSUFDRjtBQUVBLGFBQVMsV0FBWSxLQUFLLEtBQUssS0FBSztBQUNsQyxVQUFJLElBQUksU0FBUyxDQUFDLEVBQUUsU0FBUyxJQUFJO0FBQy9CLHNCQUFjLEtBQUssS0FBSyxHQUFHO0FBQUEsTUFDN0IsT0FBTztBQUNMLFFBQUFBLEtBQUksTUFBTSxLQUFLLFVBQVUsS0FBSyxFQUFFLEdBQUcsR0FBRztBQUFBLE1BQ3hDO0FBQUEsSUFDRjtBQU9BLGFBQVMsU0FBVSxLQUFLO0FBR3RCLFVBQUk7QUFDSixVQUFJLElBQUksQ0FBQyxNQUFNLElBQU0sWUFBVztBQUFBLGVBQ3ZCLElBQUksQ0FBQyxNQUFNLElBQU0sWUFBVztBQUFBLFVBQ2hDLFFBQU87QUFHWixZQUFNLFFBQVEsQ0FBQztBQUNmLFVBQUk7QUFDSixXQUFLLElBQUksSUFBSSxTQUFTLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDbkMsY0FBTSxPQUFPLElBQUksQ0FBQztBQUNsQixZQUFJLFNBQVUsT0FBTSxLQUFLLElBQUk7QUFBQSxZQUN4QixPQUFNLEtBQUssTUFBTyxJQUFJO0FBQUEsTUFDN0I7QUFFQSxVQUFJLE1BQU07QUFDVixZQUFNLElBQUksTUFBTTtBQUNoQixXQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsS0FBSztBQUN0QixlQUFPLE1BQU0sQ0FBQyxJQUFJLEtBQUssSUFBSSxLQUFLLENBQUM7QUFBQSxNQUNuQztBQUVBLGFBQU8sV0FBVyxNQUFNLEtBQUs7QUFBQSxJQUMvQjtBQUVBLGFBQVMsVUFBVyxLQUFLLFFBQVEsUUFBUTtBQUN2QyxZQUFNLElBQUksU0FBUyxRQUFRLFNBQVMsTUFBTTtBQUMxQyxlQUFTO0FBR1QsVUFBSSxJQUFJLE1BQU0sSUFBSSxLQUFNO0FBQ3RCLGVBQU8sU0FBUyxHQUFHO0FBQUEsTUFDckIsT0FBTztBQUVMLGVBQU8sU0FBUyxJQUFJLFVBQVUsSUFBSSxNQUFNLE1BQU0sR0FBSTtBQUNsRCxjQUFNLE1BQU0sTUFBTSxRQUFRLEtBQUssSUFBSSxRQUFRLElBQUksTUFBTSxHQUFHLElBQUksUUFBUSxJQUFJLE1BQU07QUFDOUUsZUFBTyxTQUFTLE9BQU8sSUFBSSxNQUFNLE1BQU0sRUFBRztBQUMxQyxZQUFJLFFBQVEsT0FBUSxRQUFPO0FBQzNCLGVBQU8sU0FBU0EsS0FBSSxTQUFTLElBQUksU0FBUyxRQUFRLEdBQUcsQ0FBQyxHQUFHLENBQUM7QUFBQSxNQUM1RDtBQUFBLElBQ0Y7QUFFQSxhQUFTLFVBQVcsS0FBSyxRQUFRLFFBQVEsVUFBVTtBQUNqRCxhQUFPQSxLQUFJLFNBQVMsSUFBSSxTQUFTLFFBQVEsUUFBUSxLQUFLLEdBQUcsUUFBUSxTQUFTLE1BQU0sQ0FBQyxHQUFHLFFBQVE7QUFBQSxJQUM5RjtBQUVBLGFBQVMsVUFBVyxLQUFLO0FBQ3ZCLFlBQU0sTUFBTUEsS0FBSSxXQUFXLEdBQUc7QUFDOUIsVUFBSSxTQUFTLEtBQUssTUFBTSxLQUFLLElBQUksR0FBRyxJQUFJLEtBQUssSUFBSSxFQUFFLENBQUMsSUFBSTtBQUN4RCxVQUFJLE1BQU0sVUFBVSxLQUFLLElBQUksSUFBSSxNQUFNLEVBQUc7QUFFMUMsYUFBUSxNQUFNLFNBQVU7QUFBQSxJQUMxQjtBQUFBO0FBQUE7OztBQ2hVQTtBQUFBO0FBQUEsUUFBTSxFQUFFLFVBQUFDLFdBQVUsVUFBQUMsV0FBVSxlQUFlLElBQUk7QUFDL0MsUUFBTSxPQUFPO0FBQ2IsUUFBTUMsT0FBTTtBQUNaLFFBQU0sVUFBVTtBQUVoQixRQUFNLFFBQVFBLEtBQUksTUFBTSxDQUFDO0FBRXpCLFFBQU0sYUFBTixNQUFpQjtBQUFBLE1BQ2YsY0FBZTtBQUNiLGFBQUssV0FBVztBQUNoQixhQUFLLFVBQVU7QUFDZixhQUFLLFFBQVEsSUFBSSxLQUFLO0FBRXRCLGFBQUssVUFBVTtBQUFBLE1BQ2pCO0FBQUEsTUFFQSxLQUFNLFFBQVE7QUFDWixhQUFLLFlBQVksT0FBTztBQUN4QixhQUFLLE1BQU0sS0FBSyxNQUFNO0FBQUEsTUFDeEI7QUFBQSxNQUVBLFdBQVksTUFBTTtBQUNoQixlQUFPLEtBQUssY0FBYyxJQUFJLE9BQU8sS0FBSyxNQUFNLElBQUk7QUFBQSxNQUN0RDtBQUFBLE1BRUEsTUFBTyxNQUFNO0FBQ1gsWUFBSSxPQUFPLEtBQUssU0FBVSxRQUFPO0FBQ2pDLFlBQUksU0FBUyxFQUFHLFFBQU87QUFFdkIsWUFBSSxRQUFRLEtBQUssTUFBTSxJQUFJO0FBRTNCLFlBQUksU0FBUyxNQUFNLFdBQVksUUFBTztBQUV0QyxjQUFNLFNBQVMsQ0FBQyxLQUFLO0FBRXJCLGdCQUFRLFFBQVEsTUFBTSxjQUFjLEdBQUc7QUFDckMsa0JBQVEsS0FBSyxNQUFNLElBQUk7QUFDdkIsaUJBQU8sS0FBSyxLQUFLO0FBQUEsUUFDbkI7QUFFQSxlQUFPQSxLQUFJLE9BQU8sTUFBTTtBQUFBLE1BQzFCO0FBQUEsTUFFQSxNQUFPLE1BQU07QUFDWCxjQUFNLE1BQU0sS0FBSyxNQUFNLEtBQUs7QUFDNUIsY0FBTSxNQUFNLElBQUksYUFBYSxLQUFLO0FBRWxDLFlBQUksUUFBUSxLQUFLO0FBQ2YsZ0JBQU0sTUFBTSxLQUFLLFVBQVUsSUFBSSxTQUFTLEtBQUssU0FBUyxJQUFJLFVBQVUsSUFBSTtBQUN4RSxlQUFLLE1BQU0sTUFBTTtBQUNqQixlQUFLLFVBQVU7QUFDZixlQUFLLFlBQVk7QUFDakIsZUFBSyxXQUFXO0FBQ2hCLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGFBQUssWUFBWTtBQUNqQixhQUFLLFdBQVc7QUFFaEIsZUFBTyxJQUFJLFNBQVMsS0FBSyxTQUFVLEtBQUssV0FBVyxJQUFLO0FBQUEsTUFDMUQ7QUFBQSxJQUNGO0FBRUEsUUFBTSxTQUFOLGNBQXFCRCxVQUFTO0FBQUEsTUFDNUIsWUFBYUUsT0FBTSxRQUFRLFFBQVE7QUFDakMsY0FBTTtBQUVOLGFBQUssU0FBUztBQUNkLGFBQUssU0FBUztBQUVkLGFBQUssVUFBVUE7QUFBQSxNQUNqQjtBQUFBLE1BRUEsTUFBTyxJQUFJO0FBQ1QsWUFBSSxLQUFLLE9BQU8sU0FBUyxHQUFHO0FBQzFCLGVBQUssS0FBSyxJQUFJO0FBQUEsUUFDaEI7QUFDQSxZQUFJLEtBQUssUUFBUSxZQUFZLE1BQU07QUFDakMsZUFBSyxRQUFRLFFBQVE7QUFBQSxRQUN2QjtBQUNBLFdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUVBLGNBQWU7QUFDYixhQUFLLFFBQVEsUUFBUSxlQUFlLElBQUksQ0FBQztBQUFBLE1BQzNDO0FBQUEsTUFFQSxVQUFXO0FBQ1QsWUFBSSxLQUFLLFFBQVEsWUFBWSxNQUFNO0FBQ2pDLGVBQUssUUFBUSxVQUFVO0FBQ3ZCLGVBQUssUUFBUSxXQUFXLFNBQVMsS0FBSyxPQUFPLElBQUk7QUFDakQsZUFBSyxRQUFRLFFBQVE7QUFBQSxRQUN2QjtBQUFBLE1BQ0Y7QUFBQSxNQUVBLFNBQVUsSUFBSTtBQUNaLGFBQUssUUFBUTtBQUNiLFdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxJQUNGO0FBRUEsUUFBTSxVQUFOLGNBQXNCSCxVQUFTO0FBQUEsTUFDN0IsWUFBYSxNQUFNO0FBQ2pCLGNBQU0sSUFBSTtBQUVWLFlBQUksQ0FBQyxLQUFNLFFBQU8sQ0FBQztBQUVuQixhQUFLLFVBQVUsSUFBSSxXQUFXO0FBQzlCLGFBQUssVUFBVTtBQUNmLGFBQUssVUFBVTtBQUNmLGFBQUssVUFBVTtBQUNmLGFBQUssV0FBVztBQUNoQixhQUFLLGNBQWM7QUFDbkIsYUFBSyxZQUFZO0FBQ2pCLGFBQUssVUFBVTtBQUNmLGFBQUssWUFBWTtBQUNqQixhQUFLLE9BQU87QUFDWixhQUFLLGFBQWE7QUFDbEIsYUFBSyxlQUFlO0FBQ3BCLGFBQUssbUJBQW1CO0FBQ3hCLGFBQUssb0JBQW9CLEtBQUssb0JBQW9CO0FBQ2xELGFBQUssc0JBQXNCLENBQUMsQ0FBQyxLQUFLO0FBQ2xDLGFBQUssZUFBZSxLQUFLLFFBQVEsS0FBSyxJQUFJO0FBQUEsTUFDNUM7QUFBQSxNQUVBLFFBQVMsS0FBSztBQUNaLGFBQUssVUFBVTtBQUVmLFlBQUksS0FBSztBQUNQLGVBQUssUUFBUSxHQUFHO0FBQ2hCLGVBQUssZUFBZSxHQUFHO0FBQ3ZCO0FBQUEsUUFDRjtBQUVBLGFBQUssUUFBUTtBQUFBLE1BQ2Y7QUFBQSxNQUVBLGlCQUFrQjtBQUNoQixZQUFJLEtBQUssUUFBUyxRQUFPO0FBRXpCLGFBQUssVUFBVSxLQUFLLFFBQVE7QUFFNUIsWUFBSTtBQUNGLGVBQUssVUFBVSxRQUFRLE9BQU8sS0FBSyxRQUFRLE1BQU0sR0FBRyxHQUFHLEtBQUssbUJBQW1CLEtBQUssbUJBQW1CO0FBQUEsUUFDekcsU0FBUyxLQUFLO0FBQ1osZUFBSyxlQUFlLEdBQUc7QUFDdkIsaUJBQU87QUFBQSxRQUNUO0FBRUEsWUFBSSxDQUFDLEtBQUssUUFBUyxRQUFPO0FBRTFCLGdCQUFRLEtBQUssUUFBUSxNQUFNO0FBQUEsVUFDekIsS0FBSztBQUFBLFVBQ0wsS0FBSztBQUFBLFVBQ0wsS0FBSztBQUFBLFVBQ0wsS0FBSztBQUNILGlCQUFLLGNBQWM7QUFDbkIsaUJBQUssV0FBVyxLQUFLLFFBQVE7QUFDN0IsbUJBQU87QUFBQSxRQUNYO0FBRUEsYUFBSyxVQUFVO0FBQ2YsYUFBSyxrQkFBa0I7QUFFdkIsWUFBSSxLQUFLLFFBQVEsU0FBUyxLQUFLLEtBQUssUUFBUSxTQUFTLGFBQWE7QUFDaEUsZUFBSyxLQUFLLFNBQVMsS0FBSyxTQUFTLEtBQUssY0FBYyxHQUFHLEtBQUssWUFBWTtBQUN4RSxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxhQUFLLFVBQVUsS0FBSyxjQUFjO0FBQ2xDLGFBQUssV0FBVyxLQUFLLFFBQVE7QUFFN0IsYUFBSyxLQUFLLFNBQVMsS0FBSyxTQUFTLEtBQUssU0FBUyxLQUFLLFlBQVk7QUFDaEUsZUFBTztBQUFBLE1BQ1Q7QUFBQSxNQUVBLG9CQUFxQjtBQUNuQixZQUFJLEtBQUssY0FBYztBQUNyQixlQUFLLFFBQVEsT0FBTyxLQUFLO0FBQ3pCLGVBQUssZUFBZTtBQUFBLFFBQ3RCO0FBRUEsWUFBSSxLQUFLLGtCQUFrQjtBQUN6QixlQUFLLFFBQVEsV0FBVyxLQUFLO0FBQzdCLGVBQUssbUJBQW1CO0FBQUEsUUFDMUI7QUFFQSxZQUFJLEtBQUssTUFBTTtBQUNiLGNBQUksS0FBSyxLQUFLLEtBQU0sTUFBSyxRQUFRLE9BQU8sS0FBSyxLQUFLO0FBQ2xELGNBQUksS0FBSyxLQUFLLFNBQVUsTUFBSyxRQUFRLFdBQVcsS0FBSyxLQUFLO0FBQzFELGNBQUksS0FBSyxLQUFLLEtBQU0sTUFBSyxRQUFRLE9BQU8sU0FBUyxLQUFLLEtBQUssTUFBTSxFQUFFO0FBQ25FLGVBQUssUUFBUSxNQUFNLEtBQUs7QUFDeEIsZUFBSyxPQUFPO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFBQSxNQUVBLGtCQUFtQixLQUFLO0FBQ3RCLGdCQUFRLEtBQUssUUFBUSxNQUFNO0FBQUEsVUFDekIsS0FBSztBQUNILGlCQUFLLGVBQWUsUUFBUSxlQUFlLEtBQUssS0FBSyxpQkFBaUI7QUFDdEU7QUFBQSxVQUNGLEtBQUs7QUFDSCxpQkFBSyxtQkFBbUIsUUFBUSxlQUFlLEtBQUssS0FBSyxpQkFBaUI7QUFDMUU7QUFBQSxVQUNGLEtBQUs7QUFDSCxpQkFBSyxhQUFhLFFBQVEsVUFBVSxHQUFHO0FBQ3ZDO0FBQUEsVUFDRixLQUFLO0FBQ0gsaUJBQUssT0FBTyxLQUFLLGVBQWUsT0FDNUIsUUFBUSxVQUFVLEdBQUcsSUFDckIsT0FBTyxPQUFPLENBQUMsR0FBRyxLQUFLLFlBQVksUUFBUSxVQUFVLEdBQUcsQ0FBQztBQUM3RDtBQUFBLFFBQ0o7QUFBQSxNQUNGO0FBQUEsTUFFQSxxQkFBc0I7QUFDcEIsYUFBSyxjQUFjO0FBQ25CLGFBQUssV0FBVyxTQUFTLEtBQUssUUFBUSxJQUFJO0FBRTFDLGNBQU0sTUFBTSxLQUFLLFFBQVEsTUFBTSxLQUFLLFFBQVEsSUFBSTtBQUVoRCxZQUFJO0FBQ0YsZUFBSyxrQkFBa0IsR0FBRztBQUFBLFFBQzVCLFNBQVMsS0FBSztBQUNaLGVBQUssZUFBZSxHQUFHO0FBQ3ZCLGlCQUFPO0FBQUEsUUFDVDtBQUVBLGVBQU87QUFBQSxNQUNUO0FBQUEsTUFFQSxpQkFBa0I7QUFDaEIsY0FBTSxNQUFNLEtBQUssUUFBUSxXQUFXLEtBQUssUUFBUTtBQUNqRCxZQUFJLFFBQVEsS0FBTSxRQUFPO0FBRXpCLGFBQUssWUFBWSxJQUFJO0FBQ3JCLGNBQU1JLFdBQVUsS0FBSyxRQUFRLEtBQUssR0FBRztBQUVyQyxZQUFJLEtBQUssYUFBYSxHQUFHO0FBQ3ZCLGVBQUssUUFBUSxLQUFLLElBQUk7QUFDdEIsY0FBSUEsU0FBUyxNQUFLLFFBQVEsUUFBUTtBQUNsQyxpQkFBT0EsWUFBVyxLQUFLLFlBQVk7QUFBQSxRQUNyQztBQUVBLGVBQU9BO0FBQUEsTUFDVDtBQUFBLE1BRUEsZ0JBQWlCO0FBQ2YsZUFBTyxJQUFJLE9BQU8sTUFBTSxLQUFLLFNBQVMsS0FBSyxPQUFPO0FBQUEsTUFDcEQ7QUFBQSxNQUVBLFVBQVc7QUFDVCxlQUFPLEtBQUssUUFBUSxXQUFXLEtBQUssQ0FBQyxLQUFLLFlBQVk7QUFDcEQsY0FBSSxLQUFLLFdBQVcsR0FBRztBQUNyQixnQkFBSSxLQUFLLFlBQVksTUFBTTtBQUN6QixrQkFBSSxLQUFLLGVBQWUsTUFBTSxNQUFPO0FBQ3JDO0FBQUEsWUFDRjtBQUVBLGdCQUFJLEtBQUssZ0JBQWdCLE1BQU07QUFDN0Isa0JBQUksS0FBSyxXQUFXLEtBQUssUUFBUSxTQUFVO0FBQzNDLGtCQUFJLEtBQUssbUJBQW1CLE1BQU0sTUFBTyxRQUFPO0FBQ2hEO0FBQUEsWUFDRjtBQUVBLGtCQUFNLFNBQVMsS0FBSyxRQUFRLFdBQVcsS0FBSyxRQUFRO0FBQ3BELGdCQUFJLFdBQVcsS0FBTSxNQUFLLFlBQVksT0FBTztBQUM3QztBQUFBLFVBQ0Y7QUFFQSxjQUFJLEtBQUssUUFBUSxXQUFXLElBQUs7QUFDakMsY0FBSSxLQUFLLFlBQVksUUFBUSxLQUFLLGVBQWUsTUFBTSxNQUFPO0FBQUEsUUFDaEU7QUFFQSxhQUFLLGVBQWUsSUFBSTtBQUFBLE1BQzFCO0FBQUEsTUFFQSxlQUFnQixLQUFLO0FBQ25CLGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGFBQUssWUFBWTtBQUNqQixXQUFHLEdBQUc7QUFBQSxNQUNSO0FBQUEsTUFFQSxPQUFRLE1BQU0sSUFBSTtBQUNoQixhQUFLLFlBQVk7QUFDakIsYUFBSyxRQUFRLEtBQUssSUFBSTtBQUN0QixhQUFLLFFBQVE7QUFBQSxNQUNmO0FBQUEsTUFFQSxPQUFRLElBQUk7QUFDVixhQUFLLFlBQVksS0FBSyxhQUFhLEtBQUssS0FBSyxRQUFRLGFBQWE7QUFDbEUsV0FBRyxLQUFLLFlBQVksT0FBTyxJQUFJLE1BQU0sd0JBQXdCLENBQUM7QUFBQSxNQUNoRTtBQUFBLE1BRUEsY0FBZTtBQUNiLGFBQUssZUFBZSxJQUFJO0FBQUEsTUFDMUI7QUFBQSxNQUVBLFNBQVUsSUFBSTtBQUNaLFlBQUksS0FBSyxRQUFTLE1BQUssUUFBUSxRQUFRLGVBQWUsSUFBSSxDQUFDO0FBQzNELFdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUVBLENBQUMsT0FBTyxhQUFhLElBQUs7QUFDeEIsWUFBSSxRQUFRO0FBRVosWUFBSSxpQkFBaUI7QUFDckIsWUFBSSxnQkFBZ0I7QUFFcEIsWUFBSSxjQUFjO0FBQ2xCLFlBQUksZ0JBQWdCO0FBRXBCLGNBQU0sVUFBVTtBQUVoQixhQUFLLEdBQUcsU0FBUyxPQUFPO0FBQ3hCLGFBQUssR0FBRyxTQUFTLENBQUMsUUFBUTtBQUFFLGtCQUFRO0FBQUEsUUFBSSxDQUFDO0FBQ3pDLGFBQUssR0FBRyxTQUFTLE9BQU87QUFFeEIsZUFBTztBQUFBLFVBQ0wsQ0FBQyxPQUFPLGFBQWEsSUFBSztBQUN4QixtQkFBTztBQUFBLFVBQ1Q7QUFBQSxVQUNBLE9BQVE7QUFDTixtQkFBTyxJQUFJLFFBQVEsTUFBTTtBQUFBLFVBQzNCO0FBQUEsVUFDQSxTQUFVO0FBQ1IsbUJBQU8sUUFBUSxJQUFJO0FBQUEsVUFDckI7QUFBQSxVQUNBLE1BQU8sS0FBSztBQUNWLG1CQUFPLFFBQVEsR0FBRztBQUFBLFVBQ3BCO0FBQUEsUUFDRjtBQUVBLGlCQUFTLGdCQUFpQixLQUFLO0FBQzdCLGNBQUksQ0FBQyxjQUFlO0FBQ3BCLGdCQUFNLEtBQUs7QUFDWCwwQkFBZ0I7QUFDaEIsYUFBRyxHQUFHO0FBQUEsUUFDUjtBQUVBLGlCQUFTLE9BQVEsU0FBUyxRQUFRO0FBQ2hDLGNBQUksT0FBTztBQUNULG1CQUFPLE9BQU8sS0FBSztBQUFBLFVBQ3JCO0FBRUEsY0FBSSxhQUFhO0FBQ2Ysb0JBQVEsRUFBRSxPQUFPLGFBQWEsTUFBTSxNQUFNLENBQUM7QUFDM0MsMEJBQWM7QUFDZDtBQUFBLFVBQ0Y7QUFFQSwyQkFBaUI7QUFDakIsMEJBQWdCO0FBRWhCLDBCQUFnQixJQUFJO0FBRXBCLGNBQUksUUFBUSxhQUFhLGdCQUFnQjtBQUN2QywyQkFBZSxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUssQ0FBQztBQUMvQyw2QkFBaUIsZ0JBQWdCO0FBQUEsVUFDbkM7QUFBQSxRQUNGO0FBRUEsaUJBQVMsUUFBUyxRQUFRLFFBQVEsVUFBVTtBQUMxQywwQkFBZ0I7QUFDaEIsaUJBQU8sR0FBRyxTQUFTLElBQUk7QUFFdkIsY0FBSSxnQkFBZ0I7QUFDbEIsMkJBQWUsRUFBRSxPQUFPLFFBQVEsTUFBTSxNQUFNLENBQUM7QUFDN0MsNkJBQWlCLGdCQUFnQjtBQUFBLFVBQ25DLE9BQU87QUFDTCwwQkFBYztBQUFBLFVBQ2hCO0FBQUEsUUFDRjtBQUVBLGlCQUFTLFVBQVc7QUFDbEIsMEJBQWdCLEtBQUs7QUFDckIsY0FBSSxDQUFDLGVBQWdCO0FBQ3JCLGNBQUksTUFBTyxlQUFjLEtBQUs7QUFBQSxjQUN6QixnQkFBZSxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUssQ0FBQztBQUNwRCwyQkFBaUIsZ0JBQWdCO0FBQUEsUUFDbkM7QUFFQSxpQkFBUyxRQUFTLEtBQUs7QUFDckIsa0JBQVEsUUFBUSxHQUFHO0FBQ25CLDBCQUFnQixHQUFHO0FBQ25CLGlCQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVztBQUN0QyxnQkFBSSxRQUFRLFVBQVcsUUFBTyxRQUFRLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSyxDQUFDO0FBQ3RFLG9CQUFRLEtBQUssU0FBUyxXQUFZO0FBQ2hDLGtCQUFJLElBQUssUUFBTyxHQUFHO0FBQUEsa0JBQ2QsU0FBUSxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUssQ0FBQztBQUFBLFlBQy9DLENBQUM7QUFBQSxVQUNILENBQUM7QUFBQSxRQUNIO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFFQSxXQUFPLFVBQVUsU0FBUyxRQUFTLE1BQU07QUFDdkMsYUFBTyxJQUFJLFFBQVEsSUFBSTtBQUFBLElBQ3pCO0FBRUEsYUFBUyxPQUFRO0FBQUEsSUFBQztBQUVsQixhQUFTLFNBQVUsTUFBTTtBQUN2QixjQUFRO0FBQ1IsYUFBTyxRQUFRLE1BQU07QUFBQSxJQUN2QjtBQUFBO0FBQUE7QTs7Ozs7Ozs7QUNyWkE7QUFBQTtBQUFBLFFBQU0sWUFBWTtBQUFBO0FBQUEsTUFDaEIsUUFBUTtBQUFBLE1BQ1IsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLE1BQ1QsU0FBUztBQUFBLElBQ1g7QUFFQSxRQUFJO0FBQ0YsYUFBTyxVQUFVLGFBQWMsYUFBYTtBQUFBLElBQzlDLFFBQVE7QUFDTixhQUFPLFVBQVU7QUFBQSxJQUNuQjtBQUFBO0FBQUE7OztBQ2JBO0FBQUE7QUFBQSxRQUFNLEVBQUUsVUFBQUMsV0FBVSxVQUFBQyxXQUFVLGVBQWUsSUFBSTtBQUMvQyxRQUFNQyxPQUFNO0FBRVosUUFBTSxZQUFZO0FBQ2xCLFFBQU0sVUFBVTtBQUVoQixRQUFNLFFBQVE7QUFDZCxRQUFNLFFBQVE7QUFFZCxRQUFNLGFBQWFBLEtBQUksTUFBTSxJQUFJO0FBRWpDLFFBQU0sT0FBTixjQUFtQkQsVUFBUztBQUFBLE1BQzFCLFlBQWEsTUFBTSxRQUFRLFVBQVU7QUFDbkMsY0FBTSxFQUFFLGFBQWEsV0FBVyxLQUFLLENBQUM7QUFFdEMsYUFBSyxVQUFVO0FBQ2YsYUFBSyxTQUFTO0FBRWQsYUFBSyxZQUFZO0FBQ2pCLGFBQUssWUFBWTtBQUNqQixhQUFLLGNBQWMsT0FBTyxTQUFTLGFBQWEsQ0FBQyxPQUFPO0FBQ3hELGFBQUssVUFBVSxPQUFPLFNBQVMsVUFBVSxPQUFPLFNBQVM7QUFDekQsYUFBSyxZQUFZO0FBQ2pCLGFBQUssUUFBUTtBQUNiLGFBQUssZ0JBQWdCO0FBRXJCLFlBQUksS0FBSyxNQUFNLFlBQVksS0FBTSxNQUFLLE1BQU0sVUFBVTtBQUFBLFlBQ2pELE1BQUssTUFBTSxTQUFTLEtBQUssSUFBSTtBQUFBLE1BQ3BDO0FBQUEsTUFFQSxNQUFPLElBQUk7QUFDVCxhQUFLLGdCQUFnQjtBQUNyQixZQUFJLEtBQUssTUFBTSxZQUFZLEtBQU0sTUFBSyxjQUFjO0FBQUEsTUFDdEQ7QUFBQSxNQUVBLGNBQWUsS0FBSztBQUNsQixZQUFJLEtBQUssY0FBYyxLQUFNO0FBRTdCLGNBQU0sV0FBVyxLQUFLO0FBQ3RCLGFBQUssWUFBWTtBQUVqQixpQkFBUyxHQUFHO0FBQUEsTUFDZDtBQUFBLE1BRUEsZ0JBQWlCO0FBQ2YsWUFBSSxLQUFLLE1BQU0sWUFBWSxLQUFNLE1BQUssTUFBTSxVQUFVO0FBRXRELGNBQU0sS0FBSyxLQUFLO0FBQ2hCLGFBQUssZ0JBQWdCO0FBQ3JCLFlBQUksT0FBTyxLQUFNO0FBRWpCLFlBQUksS0FBSyxNQUFNLFdBQVksUUFBTyxHQUFHLElBQUksTUFBTSx1QkFBdUIsQ0FBQztBQUN2RSxZQUFJLEtBQUssTUFBTSxXQUFZLFFBQU8sR0FBRyxJQUFJLE1BQU0sa0NBQWtDLENBQUM7QUFFbEYsYUFBSyxNQUFNLFVBQVU7QUFFckIsWUFBSSxDQUFDLEtBQUssYUFBYTtBQUNyQixlQUFLLE1BQU0sUUFBUSxLQUFLLE1BQU07QUFBQSxRQUNoQztBQUVBLFlBQUksS0FBSyxTQUFTO0FBQ2hCLGVBQUssUUFBUTtBQUNiLGVBQUssY0FBYyxJQUFJO0FBQUEsUUFDekI7QUFFQSxXQUFHLElBQUk7QUFBQSxNQUNUO0FBQUEsTUFFQSxPQUFRLE1BQU0sSUFBSTtBQUNoQixZQUFJLEtBQUssYUFBYTtBQUNwQixlQUFLLFlBQVksS0FBSyxZQUFZQyxLQUFJLE9BQU8sQ0FBQyxLQUFLLFdBQVcsSUFBSSxDQUFDLElBQUk7QUFDdkUsaUJBQU8sR0FBRyxJQUFJO0FBQUEsUUFDaEI7QUFFQSxZQUFJLEtBQUssU0FBUztBQUNoQixjQUFJLEtBQUssYUFBYSxHQUFHO0FBQ3ZCLG1CQUFPLEdBQUcsSUFBSSxNQUFNLGdDQUFnQyxDQUFDO0FBQUEsVUFDdkQ7QUFDQSxpQkFBTyxHQUFHO0FBQUEsUUFDWjtBQUVBLGFBQUssV0FBVyxLQUFLO0FBQ3JCLFlBQUksS0FBSyxNQUFNLEtBQUssSUFBSSxFQUFHLFFBQU8sR0FBRztBQUNyQyxhQUFLLE1BQU0sU0FBUztBQUFBLE1BQ3RCO0FBQUEsTUFFQSxVQUFXO0FBQ1QsWUFBSSxLQUFLLFVBQVc7QUFDcEIsYUFBSyxZQUFZO0FBRWpCLFlBQUksS0FBSyxhQUFhO0FBQ3BCLGVBQUssT0FBTyxXQUFXLEtBQUssWUFBWUEsS0FBSSxTQUFTLEtBQUssV0FBVyxPQUFPLElBQUk7QUFDaEYsZUFBSyxNQUFNLFFBQVEsS0FBSyxNQUFNO0FBQUEsUUFDaEM7QUFFQSxpQkFBUyxLQUFLLE9BQU8sS0FBSyxPQUFPLElBQUk7QUFFckMsYUFBSyxNQUFNLE1BQU0sSUFBSTtBQUFBLE1BQ3ZCO0FBQUEsTUFFQSxPQUFRLElBQUk7QUFDVixZQUFJLEtBQUssWUFBWSxLQUFLLE9BQU8sTUFBTTtBQUNyQyxpQkFBTyxHQUFHLElBQUksTUFBTSxlQUFlLENBQUM7QUFBQSxRQUN0QztBQUVBLGFBQUssUUFBUTtBQUNiLFdBQUcsSUFBSTtBQUFBLE1BQ1Q7QUFBQSxNQUVBLFlBQWE7QUFDWCxlQUFPLGVBQWUsSUFBSSxLQUFLLElBQUksTUFBTSxxQkFBcUI7QUFBQSxNQUNoRTtBQUFBLE1BRUEsY0FBZTtBQUNiLGFBQUssTUFBTSxRQUFRLEtBQUssVUFBVSxDQUFDO0FBQUEsTUFDckM7QUFBQSxNQUVBLFNBQVUsSUFBSTtBQUNaLGFBQUssTUFBTSxNQUFNLElBQUk7QUFFckIsYUFBSyxjQUFjLEtBQUssWUFBWSxPQUFPLEtBQUssVUFBVSxDQUFDO0FBRTNELFdBQUc7QUFBQSxNQUNMO0FBQUEsSUFDRjtBQUVBLFFBQU0sT0FBTixjQUFtQkYsVUFBUztBQUFBLE1BQzFCLFlBQWEsTUFBTTtBQUNqQixjQUFNLElBQUk7QUFDVixhQUFLLFNBQVM7QUFDZCxhQUFLLGFBQWE7QUFDbEIsYUFBSyxjQUFjO0FBQ25CLGFBQUssV0FBVyxDQUFDO0FBQ2pCLGFBQUssVUFBVTtBQUFBLE1BQ2pCO0FBQUEsTUFFQSxNQUFPLFFBQVEsUUFBUSxVQUFVO0FBQy9CLFlBQUksS0FBSyxjQUFjLEtBQUssV0FBWSxPQUFNLElBQUksTUFBTSxnQ0FBZ0M7QUFFeEYsWUFBSSxPQUFPLFdBQVcsWUFBWTtBQUNoQyxxQkFBVztBQUNYLG1CQUFTO0FBQUEsUUFDWDtBQUVBLFlBQUksQ0FBQyxTQUFVLFlBQVc7QUFFMUIsWUFBSSxDQUFDLE9BQU8sUUFBUSxPQUFPLFNBQVMsVUFBVyxRQUFPLE9BQU87QUFDN0QsWUFBSSxDQUFDLE9BQU8sS0FBTSxRQUFPLE9BQU8sV0FBVyxPQUFPLElBQUk7QUFDdEQsWUFBSSxDQUFDLE9BQU8sS0FBTSxRQUFPLE9BQU8sT0FBTyxTQUFTLGNBQWMsUUFBUTtBQUN0RSxZQUFJLENBQUMsT0FBTyxJQUFLLFFBQU8sTUFBTTtBQUM5QixZQUFJLENBQUMsT0FBTyxJQUFLLFFBQU8sTUFBTTtBQUM5QixZQUFJLENBQUMsT0FBTyxNQUFPLFFBQU8sUUFBUSxvQkFBSSxLQUFLO0FBRTNDLFlBQUksT0FBTyxXQUFXLFNBQVUsVUFBU0UsS0FBSSxLQUFLLE1BQU07QUFFeEQsY0FBTSxPQUFPLElBQUksS0FBSyxNQUFNLFFBQVEsUUFBUTtBQUU1QyxZQUFJQSxLQUFJLFNBQVMsTUFBTSxHQUFHO0FBQ3hCLGlCQUFPLE9BQU8sT0FBTztBQUNyQixlQUFLLE1BQU0sTUFBTTtBQUNqQixlQUFLLElBQUk7QUFDVCxpQkFBTztBQUFBLFFBQ1Q7QUFFQSxZQUFJLEtBQUssU0FBUztBQUNoQixpQkFBTztBQUFBLFFBQ1Q7QUFFQSxlQUFPO0FBQUEsTUFDVDtBQUFBLE1BRUEsV0FBWTtBQUNWLFlBQUksS0FBSyxXQUFXLEtBQUssU0FBUyxTQUFTLEdBQUc7QUFDNUMsZUFBSyxjQUFjO0FBQ25CO0FBQUEsUUFDRjtBQUVBLFlBQUksS0FBSyxXQUFZO0FBQ3JCLGFBQUssYUFBYTtBQUVsQixhQUFLLEtBQUssVUFBVTtBQUNwQixhQUFLLEtBQUssSUFBSTtBQUFBLE1BQ2hCO0FBQUEsTUFFQSxNQUFPLFFBQVE7QUFDYixZQUFJLFdBQVcsS0FBSyxRQUFTO0FBRTdCLGFBQUssVUFBVTtBQUVmLFlBQUksS0FBSyxZQUFhLE1BQUssU0FBUztBQUNwQyxZQUFJLEtBQUssU0FBUyxPQUFRLE1BQUssU0FBUyxNQUFNLEVBQUUsY0FBYztBQUFBLE1BQ2hFO0FBQUEsTUFFQSxRQUFTLFFBQVE7QUFDZixZQUFJLENBQUMsT0FBTyxLQUFLO0FBQ2YsZ0JBQU0sTUFBTSxRQUFRLE9BQU8sTUFBTTtBQUNqQyxjQUFJLEtBQUs7QUFDUCxpQkFBSyxLQUFLLEdBQUc7QUFDYjtBQUFBLFVBQ0Y7QUFBQSxRQUNGO0FBQ0EsYUFBSyxXQUFXLE1BQU07QUFBQSxNQUN4QjtBQUFBLE1BRUEsV0FBWSxRQUFRO0FBQ2xCLGNBQU0sWUFBWSxRQUFRLFVBQVU7QUFBQSxVQUNsQyxNQUFNLE9BQU87QUFBQSxVQUNiLFVBQVUsT0FBTztBQUFBLFVBQ2pCLEtBQUssT0FBTztBQUFBLFFBQ2QsQ0FBQztBQUVELGNBQU0sWUFBWTtBQUFBLFVBQ2hCLE1BQU07QUFBQSxVQUNOLE1BQU0sT0FBTztBQUFBLFVBQ2IsS0FBSyxPQUFPO0FBQUEsVUFDWixLQUFLLE9BQU87QUFBQSxVQUNaLE1BQU0sVUFBVTtBQUFBLFVBQ2hCLE9BQU8sT0FBTztBQUFBLFVBQ2QsTUFBTTtBQUFBLFVBQ04sVUFBVSxPQUFPLFlBQVk7QUFBQSxVQUM3QixPQUFPLE9BQU87QUFBQSxVQUNkLE9BQU8sT0FBTztBQUFBLFVBQ2QsVUFBVSxPQUFPO0FBQUEsVUFDakIsVUFBVSxPQUFPO0FBQUEsUUFDbkI7QUFFQSxhQUFLLEtBQUssUUFBUSxPQUFPLFNBQVMsQ0FBQztBQUNuQyxhQUFLLEtBQUssU0FBUztBQUNuQixpQkFBUyxNQUFNLFVBQVUsVUFBVTtBQUVuQyxrQkFBVSxPQUFPLE9BQU87QUFDeEIsa0JBQVUsT0FBTyxPQUFPO0FBQ3hCLGFBQUssS0FBSyxRQUFRLE9BQU8sU0FBUyxDQUFDO0FBQUEsTUFDckM7QUFBQSxNQUVBLFdBQVk7QUFDVixjQUFNLFFBQVEsS0FBSztBQUNuQixhQUFLLFNBQVM7QUFDZCxjQUFNO0FBQUEsTUFDUjtBQUFBLE1BRUEsY0FBZTtBQUNiLGNBQU0sTUFBTSxlQUFlLElBQUk7QUFFL0IsWUFBSSxLQUFLLFFBQVMsTUFBSyxRQUFRLFFBQVEsR0FBRztBQUUxQyxlQUFPLEtBQUssU0FBUyxRQUFRO0FBQzNCLGdCQUFNLFNBQVMsS0FBSyxTQUFTLE1BQU07QUFDbkMsaUJBQU8sUUFBUSxHQUFHO0FBQ2xCLGlCQUFPLGNBQWM7QUFBQSxRQUN2QjtBQUVBLGFBQUssU0FBUztBQUFBLE1BQ2hCO0FBQUEsTUFFQSxNQUFPLElBQUk7QUFDVCxhQUFLLFNBQVM7QUFDZCxXQUFHO0FBQUEsTUFDTDtBQUFBLElBQ0Y7QUFFQSxXQUFPLFVBQVUsU0FBUyxLQUFNLE1BQU07QUFDcEMsYUFBTyxJQUFJLEtBQUssSUFBSTtBQUFBLElBQ3RCO0FBRUEsYUFBUyxXQUFZLE1BQU07QUFDekIsY0FBUSxPQUFPLFVBQVUsUUFBUTtBQUFBLFFBQy9CLEtBQUssVUFBVTtBQUFTLGlCQUFPO0FBQUEsUUFDL0IsS0FBSyxVQUFVO0FBQVMsaUJBQU87QUFBQSxRQUMvQixLQUFLLFVBQVU7QUFBUyxpQkFBTztBQUFBLFFBQy9CLEtBQUssVUFBVTtBQUFTLGlCQUFPO0FBQUEsUUFDL0IsS0FBSyxVQUFVO0FBQVMsaUJBQU87QUFBQSxNQUNqQztBQUVBLGFBQU87QUFBQSxJQUNUO0FBRUEsYUFBUyxPQUFRO0FBQUEsSUFBQztBQUVsQixhQUFTLFNBQVVDLE9BQU0sTUFBTTtBQUM3QixjQUFRO0FBQ1IsVUFBSSxLQUFNLENBQUFBLE1BQUssS0FBSyxXQUFXLFNBQVMsR0FBRyxNQUFNLElBQUksQ0FBQztBQUFBLElBQ3hEO0FBRUEsYUFBUyxZQUFhLEtBQUs7QUFDekIsYUFBT0QsS0FBSSxTQUFTLEdBQUcsSUFBSSxNQUFNQSxLQUFJLEtBQUssR0FBRztBQUFBLElBQy9DO0FBQUE7QUFBQTs7O0FDOVJBO0FBQUE7QUFBQSxZQUFRLFVBQVU7QUFDbEIsWUFBUSxPQUFPO0FBQUE7QUFBQTs7O0FDRGYsd0JBQWdCOzs7QUNJVixJQUFPLFlBQVAsY0FBc0MsTUFBSztFQUN6QztFQUNBO0VBQ0E7RUFFUCxZQUFZLFVBQW9CLFNBQWtCLFNBQTBCO0FBQzNFLFVBQU0sT0FBUSxTQUFTLFVBQVUsU0FBUyxXQUFXLElBQUssU0FBUyxTQUFTO0FBQzVFLFVBQU0sUUFBUSxTQUFTLGNBQWM7QUFDckMsVUFBTSxTQUFTLEdBQUcsSUFBSSxJQUFJLEtBQUssR0FBRyxLQUFJO0FBQ3RDLFVBQU0sU0FBUyxTQUFTLGVBQWUsTUFBTSxLQUFLO0FBRWxELFVBQU0sdUJBQXVCLE1BQU0sS0FBSyxRQUFRLE1BQU0sSUFBSSxRQUFRLEdBQUcsRUFBRTtBQUV2RSxTQUFLLE9BQU87QUFDWixTQUFLLFdBQVc7QUFDaEIsU0FBSyxVQUFVO0FBQ2YsU0FBSyxVQUFVO0VBQ2hCOzs7O0FDbkJLLElBQU8sZUFBUCxjQUE0QixNQUFLO0VBQy9CO0VBRVAsWUFBWSxTQUFnQjtBQUMzQixVQUFNLHNCQUFzQixRQUFRLE1BQU0sSUFBSSxRQUFRLEdBQUcsRUFBRTtBQUMzRCxTQUFLLE9BQU87QUFDWixTQUFLLFVBQVU7RUFDaEI7Ozs7QUNSTSxJQUFNLFdBQVcsQ0FBQyxVQUFvQyxVQUFVLFFBQVEsT0FBTyxVQUFVOzs7QUNHekYsSUFBTSxtQkFBbUIsSUFBSSxZQUFrRTtBQUNyRyxhQUFXLFVBQVUsU0FBUztBQUM3QixTQUFLLENBQUMsU0FBUyxNQUFNLEtBQUssTUFBTSxRQUFRLE1BQU0sTUFBTSxXQUFXLFFBQVc7QUFDekUsWUFBTSxJQUFJLFVBQVUsMENBQTBDO0lBQy9EO0VBQ0Q7QUFFQSxTQUFPLFVBQVUsQ0FBQSxHQUFJLEdBQUcsT0FBTztBQUNoQztBQUVPLElBQU0sZUFBZSxDQUFDLFVBQXlCLENBQUEsR0FBSSxVQUF5QixDQUFBLE1BQU07QUFDeEYsUUFBTSxTQUFTLElBQUksV0FBVyxRQUFRLE9BQWlDO0FBQ3ZFLFFBQU0sb0JBQW9CLG1CQUFtQixXQUFXO0FBQ3hELFFBQU0sU0FBUyxJQUFJLFdBQVcsUUFBUSxPQUFpQztBQUV2RSxhQUFXLENBQUMsS0FBSyxLQUFLLEtBQUssT0FBTyxRQUFPLEdBQUk7QUFDNUMsUUFBSyxxQkFBcUIsVUFBVSxlQUFnQixVQUFVLFFBQVc7QUFDeEUsYUFBTyxPQUFPLEdBQUc7SUFDbEIsT0FBTztBQUNOLGFBQU8sSUFBSSxLQUFLLEtBQUs7SUFDdEI7RUFDRDtBQUVBLFNBQU87QUFDUjtBQUVBLFNBQVMsYUFBb0MsVUFBaUIsVUFBaUIsVUFBVztBQUN6RixTQUFRLE9BQU8sT0FBTyxVQUFVLFFBQVEsS0FBSyxTQUFTLFFBQVEsTUFBTSxTQUNqRSxDQUFBLElBQ0EsVUFBOEIsU0FBUyxRQUFRLEtBQUssQ0FBQSxHQUFJLFNBQVMsUUFBUSxLQUFLLENBQUEsQ0FBRTtBQUNwRjtBQUVPLElBQU0sYUFBYSxDQUFDLFdBQWtCLENBQUEsR0FBSSxXQUFrQixDQUFBLE9BQ2xFO0VBQ0MsZUFBZSxhQUFhLFVBQVUsVUFBVSxlQUFlO0VBQy9ELGFBQWEsYUFBYSxVQUFVLFVBQVUsYUFBYTtFQUMzRCxlQUFlLGFBQWEsVUFBVSxVQUFVLGVBQWU7RUFDL0QsYUFBYSxhQUFhLFVBQVUsVUFBVSxhQUFhOztBQUt0RCxJQUFNLFlBQVksSUFBTyxZQUE2QztBQUM1RSxNQUFJLGNBQW1CLENBQUE7QUFDdkIsTUFBSSxVQUFVLENBQUE7QUFDZCxNQUFJLFFBQVEsQ0FBQTtBQUVaLGFBQVcsVUFBVSxTQUFTO0FBQzdCLFFBQUksTUFBTSxRQUFRLE1BQU0sR0FBRztBQUMxQixVQUFJLENBQUMsTUFBTSxRQUFRLFdBQVcsR0FBRztBQUNoQyxzQkFBYyxDQUFBO01BQ2Y7QUFFQSxvQkFBYyxDQUFDLEdBQUcsYUFBYSxHQUFHLE1BQU07SUFDekMsV0FBVyxTQUFTLE1BQU0sR0FBRztBQUM1QixlQUFTLENBQUMsS0FBSyxLQUFLLEtBQUssT0FBTyxRQUFRLE1BQU0sR0FBRztBQUNoRCxZQUFJLFNBQVMsS0FBSyxLQUFLLE9BQU8sYUFBYTtBQUMxQyxrQkFBUSxVQUFVLFlBQVksR0FBRyxHQUFHLEtBQUs7UUFDMUM7QUFFQSxzQkFBYyxFQUFDLEdBQUcsYUFBYSxDQUFDLEdBQUcsR0FBRyxNQUFLO01BQzVDO0FBRUEsVUFBSSxTQUFVLE9BQWUsS0FBSyxHQUFHO0FBQ3BDLGdCQUFRLFdBQVcsT0FBUSxPQUFlLEtBQUs7QUFDL0Msb0JBQVksUUFBUTtNQUNyQjtBQUVBLFVBQUksU0FBVSxPQUFlLE9BQU8sR0FBRztBQUN0QyxrQkFBVSxhQUFhLFNBQVUsT0FBZSxPQUFPO0FBQ3ZELG9CQUFZLFVBQVU7TUFDdkI7SUFDRDtFQUNEO0FBRUEsU0FBTztBQUNSOzs7QUM1RU8sSUFBTSwwQkFBMEIsTUFBSztBQUMzQyxNQUFJLGlCQUFpQjtBQUNyQixNQUFJLGlCQUFpQjtBQUNyQixRQUFNLHlCQUF5QixPQUFPLFdBQVcsbUJBQW1CO0FBQ3BFLFFBQU0sa0JBQWtCLE9BQU8sV0FBVyxZQUFZO0FBRXRELE1BQUksMEJBQTBCLGlCQUFpQjtBQUM5QyxRQUFJO0FBQ0gsdUJBQWlCLElBQUksV0FBVyxRQUFRLHlCQUF5QjtRQUNoRSxNQUFNLElBQUksV0FBVyxlQUFjO1FBQ25DLFFBQVE7O1FBRVIsSUFBSSxTQUFNO0FBQ1QsMkJBQWlCO0FBQ2pCLGlCQUFPO1FBQ1I7T0FDQSxFQUFFLFFBQVEsSUFBSSxjQUFjO0lBQzlCLFNBQVMsT0FBTztBQUVmLFVBQUksaUJBQWlCLFNBQVMsTUFBTSxZQUFZLDZCQUE2QjtBQUM1RSxlQUFPO01BQ1I7QUFFQSxZQUFNO0lBQ1A7RUFDRDtBQUVBLFNBQU8sa0JBQWtCLENBQUM7QUFDM0IsR0FBRTtBQUVLLElBQU0sMEJBQTBCLE9BQU8sV0FBVyxvQkFBb0I7QUFDdEUsSUFBTSwwQkFBMEIsT0FBTyxXQUFXLG1CQUFtQjtBQUNyRSxJQUFNLG1CQUFtQixPQUFPLFdBQVcsYUFBYTtBQUV4RCxJQUFNLGlCQUFpQixDQUFDLE9BQU8sUUFBUSxPQUFPLFNBQVMsUUFBUSxRQUFRO0FBRTlFLElBQU0sV0FBVyxNQUE2QjtBQUM5QyxTQUFRO0FBSUQsSUFBTSxnQkFBZ0I7RUFDNUIsTUFBTTtFQUNOLE1BQU07RUFDTixVQUFVO0VBQ1YsYUFBYTtFQUNiLE1BQU07O0FBSUEsSUFBTSxpQkFBaUI7QUFFdkIsSUFBTSxPQUFPLE9BQU8sTUFBTTtBQUUxQixJQUFNLGVBQWtDO0VBQzlDLE1BQU07RUFDTixXQUFXO0VBQ1gsZUFBZTtFQUNmLGNBQWM7RUFDZCxXQUFXO0VBQ1gsT0FBTztFQUNQLFNBQVM7RUFDVCxPQUFPO0VBQ1AsaUJBQWlCO0VBQ2pCLG9CQUFvQjtFQUNwQixPQUFPOztBQUdELElBQU0seUJBQThDO0VBQzFELFFBQVE7RUFDUixTQUFTO0VBQ1QsTUFBTTtFQUNOLE1BQU07RUFDTixhQUFhO0VBQ2IsT0FBTztFQUNQLFVBQVU7RUFDVixVQUFVO0VBQ1YsZ0JBQWdCO0VBQ2hCLFdBQVc7RUFDWCxXQUFXO0VBQ1gsUUFBUTtFQUNSLFFBQVE7RUFDUixZQUFZO0VBQ1osUUFBUTtFQUNSLFVBQVU7Ozs7QUNwRkosSUFBTSx5QkFBeUIsQ0FBQyxVQUN0QyxlQUFlLFNBQVMsS0FBbUIsSUFBSSxNQUFNLFlBQVcsSUFBSztBQUV0RSxJQUFNLGVBQWUsQ0FBQyxPQUFPLE9BQU8sUUFBUSxVQUFVLFdBQVcsT0FBTztBQUV4RSxJQUFNLG1CQUFtQixDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssS0FBSyxLQUFLLEdBQUc7QUFFM0QsSUFBTSx3QkFBd0IsQ0FBQyxLQUFLLEtBQUssR0FBRztBQUU1QyxJQUFNLHNCQUE4QztFQUNuRCxPQUFPO0VBQ1AsU0FBUztFQUNULGFBQWE7RUFDYixrQkFBa0I7RUFDbEIsZUFBZSxPQUFPO0VBQ3RCLGNBQWMsT0FBTztFQUNyQixPQUFPLGtCQUFnQixNQUFPLE1BQU0sZUFBZSxLQUFNOztBQUduRCxJQUFNLHdCQUF3QixDQUFDLFFBQStCLENBQUEsTUFBOEI7QUFDbEcsTUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM5QixXQUFPO01BQ04sR0FBRztNQUNILE9BQU87O0VBRVQ7QUFFQSxNQUFJLE1BQU0sV0FBVyxDQUFDLE1BQU0sUUFBUSxNQUFNLE9BQU8sR0FBRztBQUNuRCxVQUFNLElBQUksTUFBTSxnQ0FBZ0M7RUFDakQ7QUFFQSxNQUFJLE1BQU0sZUFBZSxDQUFDLE1BQU0sUUFBUSxNQUFNLFdBQVcsR0FBRztBQUMzRCxVQUFNLElBQUksTUFBTSxvQ0FBb0M7RUFDckQ7QUFFQSxTQUFPO0lBQ04sR0FBRztJQUNILEdBQUc7O0FBRUw7OztBQ25DQSxlQUFPLFFBQ04sU0FDQSxNQUNBLGlCQUNBLFNBQXVCO0FBRXZCLFNBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFVO0FBQ3RDLFVBQU0sWUFBWSxXQUFXLE1BQUs7QUFDakMsVUFBSSxpQkFBaUI7QUFDcEIsd0JBQWdCLE1BQUs7TUFDdEI7QUFFQSxhQUFPLElBQUksYUFBYSxPQUFPLENBQUM7SUFDakMsR0FBRyxRQUFRLE9BQU87QUFFbEIsU0FBSyxRQUNILE1BQU0sU0FBUyxJQUFJLEVBQ25CLEtBQUssT0FBTyxFQUNaLE1BQU0sTUFBTSxFQUNaLEtBQUssTUFBSztBQUNWLG1CQUFhLFNBQVM7SUFDdkIsQ0FBQztFQUNILENBQUM7QUFDRjs7O0FDdkJBLGVBQU8sTUFDTixJQUNBLEVBQUMsT0FBTSxHQUFlO0FBRXRCLFNBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFVO0FBQ3RDLFFBQUksUUFBUTtBQUNYLGFBQU8sZUFBYztBQUNyQixhQUFPLGlCQUFpQixTQUFTLGNBQWMsRUFBQyxNQUFNLEtBQUksQ0FBQztJQUM1RDtBQUVBLGFBQVMsZUFBWTtBQUNwQixtQkFBYSxTQUFTO0FBQ3RCLGFBQU8sT0FBUSxNQUFlO0lBQy9CO0FBRUEsVUFBTSxZQUFZLFdBQVcsTUFBSztBQUNqQyxjQUFRLG9CQUFvQixTQUFTLFlBQVk7QUFDakQsY0FBTztJQUNSLEdBQUcsRUFBRTtFQUNOLENBQUM7QUFDRjs7O0FDMUJPLElBQU0scUJBQXFCLENBQ2pDLFNBQ0EsWUFDNEI7QUFDNUIsUUFBTSxpQkFBMEMsQ0FBQTtBQUVoRCxhQUFXLE9BQU8sU0FBUztBQUMxQixRQUFJLEVBQUUsT0FBTywyQkFBMkIsRUFBRSxPQUFPLGlCQUFpQixFQUFFLE9BQU8sVUFBVTtBQUNwRixxQkFBZSxHQUFHLElBQUksUUFBUSxHQUFHO0lBQ2xDO0VBQ0Q7QUFFQSxTQUFPO0FBQ1I7OztBQ1dNLElBQU8sS0FBUCxNQUFPLElBQUU7RUFDZCxPQUFPLE9BQU8sT0FBYyxTQUFnQjtBQUMzQyxVQUFNRSxNQUFLLElBQUksSUFBRyxPQUFPLE9BQU87QUFFaEMsVUFBTSxZQUFZLFlBQThCO0FBQy9DLFVBQUksT0FBT0EsSUFBRyxTQUFTLFlBQVksWUFBWUEsSUFBRyxTQUFTLFVBQVUsZ0JBQWdCO0FBQ3BGLGNBQU0sSUFBSSxXQUFXLGlEQUFpRCxjQUFjLEVBQUU7TUFDdkY7QUFHQSxZQUFNLFFBQVEsUUFBTztBQUNyQixVQUFJLFdBQVcsTUFBTUEsSUFBRyxPQUFNO0FBRTlCLGlCQUFXLFFBQVFBLElBQUcsU0FBUyxNQUFNLGVBQWU7QUFFbkQsY0FBTSxtQkFBbUIsTUFBTSxLQUM5QkEsSUFBRyxTQUNIQSxJQUFHLFVBQ0hBLElBQUcsa0JBQWtCLFNBQVMsTUFBSyxDQUFFLENBQUM7QUFHdkMsWUFBSSw0QkFBNEIsV0FBVyxVQUFVO0FBQ3BELHFCQUFXO1FBQ1o7TUFDRDtBQUVBLE1BQUFBLElBQUcsa0JBQWtCLFFBQVE7QUFFN0IsVUFBSSxDQUFDLFNBQVMsTUFBTUEsSUFBRyxTQUFTLGlCQUFpQjtBQUNoRCxZQUFJLFFBQVEsSUFBSSxVQUFVLFVBQVVBLElBQUcsU0FBU0EsSUFBRyxRQUE2QjtBQUVoRixtQkFBVyxRQUFRQSxJQUFHLFNBQVMsTUFBTSxhQUFhO0FBRWpELGtCQUFRLE1BQU0sS0FBSyxLQUFLO1FBQ3pCO0FBRUEsY0FBTTtNQUNQO0FBSUEsVUFBSUEsSUFBRyxTQUFTLG9CQUFvQjtBQUNuQyxZQUFJLE9BQU9BLElBQUcsU0FBUyx1QkFBdUIsWUFBWTtBQUN6RCxnQkFBTSxJQUFJLFVBQVUsb0RBQW9EO1FBQ3pFO0FBRUEsWUFBSSxDQUFDLHlCQUF5QjtBQUM3QixnQkFBTSxJQUFJLE1BQU0sNkVBQTZFO1FBQzlGO0FBRUEsZUFBT0EsSUFBRyxRQUFRLFNBQVMsTUFBSyxHQUFJQSxJQUFHLFNBQVMsa0JBQWtCO01BQ25FO0FBRUEsYUFBTztJQUNSO0FBRUEsVUFBTSxvQkFBb0JBLElBQUcsU0FBUyxNQUFNLFFBQVEsU0FBU0EsSUFBRyxRQUFRLE9BQU8sWUFBVyxDQUFFO0FBQzVGLFVBQU0sU0FBVSxvQkFBb0JBLElBQUcsT0FBTyxTQUFTLElBQUksVUFBUztBQUVwRSxlQUFXLENBQUMsTUFBTSxRQUFRLEtBQUssT0FBTyxRQUFRLGFBQWEsR0FBMEM7QUFDcEcsYUFBTyxJQUFJLElBQUksWUFBVztBQUV6QixRQUFBQSxJQUFHLFFBQVEsUUFBUSxJQUFJLFVBQVVBLElBQUcsUUFBUSxRQUFRLElBQUksUUFBUSxLQUFLLFFBQVE7QUFFN0UsY0FBTSxXQUFXLE1BQU07QUFFdkIsWUFBSSxTQUFTLFFBQVE7QUFDcEIsY0FBSSxTQUFTLFdBQVcsS0FBSztBQUM1QixtQkFBTztVQUNSO0FBRUEsZ0JBQU0sY0FBYyxNQUFNLFNBQVMsTUFBSyxFQUFHLFlBQVc7QUFDdEQsZ0JBQU0sZUFBZSxZQUFZO0FBQ2pDLGNBQUksaUJBQWlCLEdBQUc7QUFDdkIsbUJBQU87VUFDUjtBQUVBLGNBQUksUUFBUSxXQUFXO0FBQ3RCLG1CQUFPLFFBQVEsVUFBVSxNQUFNLFNBQVMsS0FBSSxDQUFFO1VBQy9DO1FBQ0Q7QUFFQSxlQUFPLFNBQVMsSUFBSSxFQUFDO01BQ3RCO0lBQ0Q7QUFFQSxXQUFPO0VBQ1I7RUFFTztFQUNHO0VBQ0EsY0FBYztFQUNkO0VBQ0E7O0VBR1YsWUFBWSxPQUFjLFVBQW1CLENBQUEsR0FBRTtBQUM5QyxTQUFLLFNBQVM7QUFFZCxTQUFLLFdBQVc7TUFDZixHQUFHO01BQ0gsU0FBUyxhQUFjLEtBQUssT0FBbUIsU0FBUyxRQUFRLE9BQU87TUFDdkUsT0FBTyxXQUNOO1FBQ0MsZUFBZSxDQUFBO1FBQ2YsYUFBYSxDQUFBO1FBQ2IsYUFBYSxDQUFBO1FBQ2IsZUFBZSxDQUFBO1NBRWhCLFFBQVEsS0FBSztNQUVkLFFBQVEsdUJBQXVCLFFBQVEsVUFBVyxLQUFLLE9BQW1CLE1BQU07O01BRWhGLFdBQVcsT0FBTyxRQUFRLGFBQWEsRUFBRTtNQUN6QyxPQUFPLHNCQUFzQixRQUFRLEtBQUs7TUFDMUMsaUJBQWlCLFFBQVEsb0JBQW9CO01BQzdDLFNBQVMsUUFBUSxXQUFXO01BQzVCLE9BQU8sUUFBUSxTQUFTLFdBQVcsTUFBTSxLQUFLLFVBQVU7O0FBR3pELFFBQUksT0FBTyxLQUFLLFdBQVcsWUFBWSxFQUFFLEtBQUssa0JBQWtCLE9BQU8sS0FBSyxrQkFBa0IsV0FBVyxVQUFVO0FBQ2xILFlBQU0sSUFBSSxVQUFVLDJDQUEyQztJQUNoRTtBQUVBLFFBQUksS0FBSyxTQUFTLGFBQWEsT0FBTyxLQUFLLFdBQVcsVUFBVTtBQUMvRCxVQUFJLEtBQUssT0FBTyxXQUFXLEdBQUcsR0FBRztBQUNoQyxjQUFNLElBQUksTUFBTSw0REFBNEQ7TUFDN0U7QUFFQSxVQUFJLENBQUMsS0FBSyxTQUFTLFVBQVUsU0FBUyxHQUFHLEdBQUc7QUFDM0MsYUFBSyxTQUFTLGFBQWE7TUFDNUI7QUFFQSxXQUFLLFNBQVMsS0FBSyxTQUFTLFlBQVksS0FBSztJQUM5QztBQUVBLFFBQUkseUJBQXlCO0FBQzVCLFdBQUssa0JBQWtCLElBQUksV0FBVyxnQkFBZTtBQUNyRCxZQUFNLGlCQUFpQixLQUFLLFNBQVMsVUFBVyxLQUFLLE9BQW1CO0FBQ3hFLFVBQUksZ0JBQWdCLFNBQVM7QUFDNUIsYUFBSyxnQkFBZ0IsTUFBTSxnQkFBZ0IsTUFBTTtNQUNsRDtBQUVBLHNCQUFnQixpQkFBaUIsU0FBUyxNQUFLO0FBQzlDLGFBQUssZ0JBQWlCLE1BQU0sZUFBZSxNQUFNO01BQ2xELENBQUM7QUFDRCxXQUFLLFNBQVMsU0FBUyxLQUFLLGdCQUFnQjtJQUM3QztBQUVBLFFBQUksd0JBQXdCO0FBRTNCLFdBQUssU0FBUyxTQUFTO0lBQ3hCO0FBRUEsUUFBSSxLQUFLLFNBQVMsU0FBUyxRQUFXO0FBQ3JDLFdBQUssU0FBUyxPQUFPLEtBQUssU0FBUyxnQkFBZ0IsS0FBSyxTQUFTLElBQUksS0FBSyxLQUFLLFVBQVUsS0FBSyxTQUFTLElBQUk7QUFDM0csV0FBSyxTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLFFBQVEsSUFBSSxjQUFjLEtBQUssa0JBQWtCO0lBQzFHO0FBRUEsU0FBSyxVQUFVLElBQUksV0FBVyxRQUFRLEtBQUssUUFBUSxLQUFLLFFBQVE7QUFFaEUsUUFBSSxLQUFLLFNBQVMsY0FBYztBQUUvQixZQUFNLG1CQUFtQixPQUFPLEtBQUssU0FBUyxpQkFBaUIsV0FDNUQsS0FBSyxTQUFTLGFBQWEsUUFBUSxPQUFPLEVBQUUsSUFDNUMsSUFBSSxnQkFBZ0IsS0FBSyxTQUFTLFlBQTJDLEVBQUUsU0FBUTtBQUUxRixZQUFNLGVBQWUsTUFBTTtBQUMzQixZQUFNLE1BQU0sS0FBSyxRQUFRLElBQUksUUFBUSxxQkFBcUIsWUFBWTtBQUd0RSxXQUNHLG9CQUFvQixLQUFLLFNBQVMsZ0JBQWdCLFdBQVcsWUFDM0QsS0FBSyxTQUFTLGdCQUFnQixvQkFBb0IsRUFBRSxLQUFLLFNBQVMsV0FBWSxLQUFLLFNBQVMsUUFBbUMsY0FBYyxJQUNoSjtBQUNELGFBQUssUUFBUSxRQUFRLE9BQU8sY0FBYztNQUMzQztBQUdBLFdBQUssVUFBVSxJQUFJLFdBQVcsUUFBUSxJQUFJLFdBQVcsUUFBUSxLQUFLLEVBQUMsR0FBRyxLQUFLLFFBQU8sQ0FBQyxHQUFHLEtBQUssUUFBdUI7SUFDbkg7RUFDRDtFQUVVLHFCQUFxQixPQUFjO0FBQzVDLFNBQUs7QUFFTCxRQUFJLEtBQUssY0FBYyxLQUFLLFNBQVMsTUFBTSxTQUFTLGlCQUFpQixjQUFjO0FBQ2xGLFlBQU07SUFDUDtBQUVBLFFBQUksaUJBQWlCLFdBQVc7QUFDL0IsVUFBSSxDQUFDLEtBQUssU0FBUyxNQUFNLFlBQVksU0FBUyxNQUFNLFNBQVMsTUFBTSxHQUFHO0FBQ3JFLGNBQU07TUFDUDtBQUVBLFlBQU0sYUFBYSxNQUFNLFNBQVMsUUFBUSxJQUFJLGFBQWEsS0FDdkQsTUFBTSxTQUFTLFFBQVEsSUFBSSxpQkFBaUIsS0FDNUMsTUFBTSxTQUFTLFFBQVEsSUFBSSxtQkFBbUIsS0FDOUMsTUFBTSxTQUFTLFFBQVEsSUFBSSxvQkFBb0I7QUFDbkQsVUFBSSxjQUFjLEtBQUssU0FBUyxNQUFNLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxNQUFNLEdBQUc7QUFDdkYsWUFBSSxRQUFRLE9BQU8sVUFBVSxJQUFJO0FBQ2pDLFlBQUksT0FBTyxNQUFNLEtBQUssR0FBRztBQUN4QixrQkFBUSxLQUFLLE1BQU0sVUFBVSxJQUFJLEtBQUssSUFBRztRQUMxQyxXQUFXLFNBQVMsS0FBSyxNQUFNLFlBQVksR0FBRztBQUU3QyxtQkFBUyxLQUFLLElBQUc7UUFDbEI7QUFFQSxjQUFNLE1BQU0sS0FBSyxTQUFTLE1BQU0saUJBQWlCO0FBQ2pELGVBQU8sUUFBUSxNQUFNLFFBQVE7TUFDOUI7QUFFQSxVQUFJLE1BQU0sU0FBUyxXQUFXLEtBQUs7QUFDbEMsY0FBTTtNQUNQO0lBQ0Q7QUFFQSxVQUFNLGFBQWEsS0FBSyxTQUFTLE1BQU0sTUFBTSxLQUFLLFdBQVc7QUFDN0QsV0FBTyxLQUFLLElBQUksS0FBSyxTQUFTLE1BQU0sY0FBYyxVQUFVO0VBQzdEO0VBRVUsa0JBQWtCLFVBQWtCO0FBQzdDLFFBQUksS0FBSyxTQUFTLFdBQVc7QUFDNUIsZUFBUyxPQUFPLFlBQVksS0FBSyxTQUFTLFVBQVcsTUFBTSxTQUFTLEtBQUksQ0FBRTtJQUMzRTtBQUVBLFdBQU87RUFDUjtFQUVVLE1BQU0sT0FBdUQsV0FBWTtBQUNsRixRQUFJO0FBQ0gsYUFBTyxNQUFNLFVBQVM7SUFDdkIsU0FBUyxPQUFPO0FBQ2YsWUFBTSxLQUFLLEtBQUssSUFBSSxLQUFLLHFCQUFxQixLQUFLLEdBQUcsY0FBYztBQUNwRSxVQUFJLEtBQUssY0FBYyxHQUFHO0FBQ3pCLGNBQU07TUFDUDtBQUVBLFlBQU0sTUFBTSxJQUFJLEVBQUMsUUFBUSxLQUFLLFNBQVMsT0FBTSxDQUFDO0FBRTlDLGlCQUFXLFFBQVEsS0FBSyxTQUFTLE1BQU0sYUFBYTtBQUVuRCxjQUFNLGFBQWEsTUFBTSxLQUFLO1VBQzdCLFNBQVMsS0FBSztVQUNkLFNBQVUsS0FBSztVQUNmO1VBQ0EsWUFBWSxLQUFLO1NBQ2pCO0FBR0QsWUFBSSxlQUFlLE1BQU07QUFDeEI7UUFDRDtNQUNEO0FBRUEsYUFBTyxLQUFLLE9BQU8sU0FBUztJQUM3QjtFQUNEO0VBRVUsTUFBTSxTQUFNO0FBQ3JCLGVBQVcsUUFBUSxLQUFLLFNBQVMsTUFBTSxlQUFlO0FBRXJELFlBQU0sU0FBUyxNQUFNLEtBQUssS0FBSyxTQUFVLEtBQUssUUFBeUM7QUFFdkYsVUFBSSxrQkFBa0IsU0FBUztBQUM5QixhQUFLLFVBQVU7QUFDZjtNQUNEO0FBRUEsVUFBSSxrQkFBa0IsVUFBVTtBQUMvQixlQUFPO01BQ1I7SUFDRDtBQUVBLFVBQU0sb0JBQW9CLG1CQUFtQixLQUFLLFNBQVMsS0FBSyxRQUFRO0FBR3hFLFVBQU0sY0FBYyxLQUFLO0FBQ3pCLFNBQUssVUFBVSxZQUFZLE1BQUs7QUFFaEMsUUFBSSxLQUFLLFNBQVMsWUFBWSxPQUFPO0FBQ3BDLGFBQU8sS0FBSyxTQUFTLE1BQU0sYUFBYSxpQkFBaUI7SUFDMUQ7QUFFQSxXQUFPLFFBQVEsYUFBYSxtQkFBbUIsS0FBSyxpQkFBaUIsS0FBSyxRQUEwQjtFQUNyRzs7RUFHVSxRQUFRLFVBQW9CLG9CQUFpRDtBQUN0RixVQUFNLGFBQWEsT0FBTyxTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLO0FBQ3JFLFFBQUksbUJBQW1CO0FBRXZCLFFBQUksU0FBUyxXQUFXLEtBQUs7QUFDNUIsVUFBSSxvQkFBb0I7QUFDdkIsMkJBQW1CLEVBQUMsU0FBUyxHQUFHLFlBQVksaUJBQWdCLEdBQUcsSUFBSSxXQUFVLENBQUU7TUFDaEY7QUFFQSxhQUFPLElBQUksV0FBVyxTQUNyQixNQUNBO1FBQ0MsUUFBUSxTQUFTO1FBQ2pCLFlBQVksU0FBUztRQUNyQixTQUFTLFNBQVM7T0FDbEI7SUFFSDtBQUVBLFdBQU8sSUFBSSxXQUFXLFNBQ3JCLElBQUksV0FBVyxlQUFlO01BQzdCLE1BQU0sTUFBTSxZQUFVO0FBQ3JCLGNBQU0sU0FBUyxTQUFTLEtBQU0sVUFBUztBQUV2QyxZQUFJLG9CQUFvQjtBQUN2Qiw2QkFBbUIsRUFBQyxTQUFTLEdBQUcsa0JBQWtCLEdBQUcsV0FBVSxHQUFHLElBQUksV0FBVSxDQUFFO1FBQ25GO0FBRUEsdUJBQWUsT0FBSTtBQUNsQixnQkFBTSxFQUFDLE1BQU0sTUFBSyxJQUFJLE1BQU0sT0FBTyxLQUFJO0FBQ3ZDLGNBQUksTUFBTTtBQUNULHVCQUFXLE1BQUs7QUFDaEI7VUFDRDtBQUVBLGNBQUksb0JBQW9CO0FBQ3ZCLGdDQUFvQixNQUFNO0FBQzFCLGtCQUFNLFVBQVUsZUFBZSxJQUFJLElBQUksbUJBQW1CO0FBQzFELCtCQUFtQixFQUFDLFNBQVMsa0JBQWtCLFdBQVUsR0FBRyxLQUFLO1VBQ2xFO0FBRUEscUJBQVcsUUFBUSxLQUFLO0FBQ3hCLGdCQUFNLEtBQUk7UUFDWDtBQUVBLGNBQU0sS0FBSTtNQUNYO0tBQ0EsR0FDRDtNQUNDLFFBQVEsU0FBUztNQUNqQixZQUFZLFNBQVM7TUFDckIsU0FBUyxTQUFTO0tBQ2xCO0VBRUg7Ozs7QUN2V0QsSUFBTSxpQkFBaUIsQ0FBQyxhQUEyQztBQUVsRSxRQUFNQyxNQUFtQyxDQUFDLE9BQWMsWUFBc0IsR0FBRyxPQUFPLE9BQU8saUJBQWlCLFVBQVUsT0FBTyxDQUFDO0FBRWxJLGFBQVcsVUFBVSxnQkFBZ0I7QUFFcEMsSUFBQUEsSUFBRyxNQUFNLElBQUksQ0FBQyxPQUFjLFlBQXNCLEdBQUcsT0FBTyxPQUFPLGlCQUFpQixVQUFVLFNBQVMsRUFBQyxPQUFNLENBQUMsQ0FBQztFQUNqSDtBQUVBLEVBQUFBLElBQUcsU0FBUyxDQUFDLGdCQUFtQyxlQUFlLGlCQUFpQixXQUFXLENBQUM7QUFDNUYsRUFBQUEsSUFBRyxTQUFTLENBQUMsZ0JBQTZGO0FBQ3pHLFFBQUksT0FBTyxnQkFBZ0IsWUFBWTtBQUN0QyxvQkFBYyxZQUFZLFlBQVksQ0FBQSxDQUFFO0lBQ3pDO0FBRUEsV0FBTyxlQUFlLGlCQUFpQixVQUFVLFdBQVcsQ0FBQztFQUM5RDtBQUVBLEVBQUFBLElBQUcsT0FBTztBQUVWLFNBQU9BO0FBQ1I7QUFFQSxJQUFNLEtBQUssZUFBYztBQUV6QixJQUFBLHVCQUFlOzs7QUMvQlIsSUFBTSxVQUFOLE1BQWM7QUFBQSxFQUtuQixZQUFtQixNQUFxQixNQUFjO0FBQW5DO0FBQXFCO0FBQUEsRUFBZ0I7QUFBQSxFQUp4RCxTQUFrRCxDQUFDO0FBQUEsRUFDbkQsUUFBdUI7QUFBQSxFQUN2QixLQUFLLE9BQU8sV0FBVztBQUFBLEVBSXZCLFVBQVUsUUFBa0I7QUFDMUIsZUFBVyxTQUFTLFFBQVE7QUFDMUIsV0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDLElBQUksRUFBRTtBQUFBLElBQzlCO0FBQUEsRUFDRjtBQUFBLEVBQ0EsaUJBQWlCLE9BQWUsWUFBb0IsT0FBZTtBQUNqRSxTQUFLLE9BQU8sS0FBSyxJQUFJLENBQUMsWUFBWSxLQUFLO0FBQUEsRUFDekM7QUFBQSxFQUNBLFNBQVMsT0FBZTtBQUN0QixTQUFLLFFBQVE7QUFBQSxFQUNmO0FBQ0Y7QUFFTyxJQUFNLFdBQU4sTUFBTSxVQUFTO0FBQUEsRUFDcEIsWUFDUyxXQUNBLE1BQ0EsTUFBYyxVQUNkLFVBQ0EsUUFDUDtBQUxPO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFBQSxFQUNMO0FBQUEsRUFFSixPQUFPLE1BQU0sT0FBeUI7QUFDcEMsVUFBTSxRQUFRO0FBQ2QsVUFBTSxVQUFVLE1BQU0sTUFBTSxLQUFLO0FBQ2pDLFFBQUksQ0FBQyxTQUFTO0FBQ1osWUFBTSxJQUFJLE1BQU0sdUJBQXVCLEtBQUssRUFBRTtBQUFBLElBQ2hEO0FBQ0EsUUFBSSxDQUFDLEVBQUUsVUFBVSxXQUFXLE1BQU0sU0FBUyxJQUFJO0FBQy9DLFFBQUksQ0FBQyxhQUFhLFVBQVU7QUFDMUIsa0JBQVk7QUFDWixpQkFBVztBQUFBLElBQ2I7QUFDQSxRQUFJLFdBQVcsV0FBVyxTQUFTLEdBQUc7QUFDcEMsYUFBTyxJQUFJO0FBQUEsUUFDVCxhQUFhO0FBQUEsUUFDYjtBQUFBLFFBQ0E7QUFBQSxRQUNBO0FBQUEsUUFDQTtBQUFBLE1BQ0Y7QUFBQSxJQUNGO0FBQ0EsV0FBTyxJQUFJO0FBQUEsTUFDVCxhQUFhO0FBQUEsTUFDYjtBQUFBLE1BQ0EsYUFBYTtBQUFBLE1BQ2I7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUFBLEVBRUEsWUFBb0I7QUFDbEIsUUFBSSxNQUFNO0FBQ1YsUUFBSSxLQUFLLFVBQVU7QUFDakIsYUFBTyxHQUFHLEtBQUssUUFBUTtBQUFBLElBQ3pCO0FBQ0EsUUFBSSxLQUFLLGNBQWMsV0FBVztBQUNoQyxhQUFPLEdBQUcsS0FBSyxTQUFTO0FBQUEsSUFDMUI7QUFDQSxXQUFPLEtBQUs7QUFDWixXQUFPO0FBQUEsRUFDVDtBQUFBLEVBRUEsV0FBbUI7QUFDakIsV0FBTyxHQUFHLEtBQUssVUFBVSxDQUFDLElBQUksS0FBSyxHQUFHO0FBQUEsRUFDeEM7QUFBQSxFQUVBLGNBQXNCO0FBQ3BCLFdBQU8sS0FBSyxXQUNSLFdBQVcsS0FBSyxRQUFRLEtBQ3hCO0FBQUEsRUFDTjtBQUFBLEVBQ0EsTUFBTSxtQkFFSjtBQUNBLFFBQUk7QUFDRixZQUFNLE9BQU8sTUFBTSxNQUFNLEdBQUcsS0FBSyxZQUFZLENBQUMsTUFBTTtBQUVwRCxVQUFJLEtBQUssSUFBSTtBQUNYLGVBQU87QUFBQSxNQUNUO0FBRUEsVUFBSSxLQUFLLE1BQU0sS0FBSyxTQUFTLEdBQUcsTUFBTSxHQUFHO0FBQ3ZDLGNBQU0sVUFBVSxLQUFLLFFBQVEsSUFBSSxrQkFBa0IsR0FBRyxLQUFLO0FBQzNELFlBQUksQ0FBQyxTQUFTO0FBQ1osaUJBQU87QUFBQSxRQUNUO0FBRUEsY0FBTSxnQkFBZ0I7QUFDdEIsY0FBTSxpQkFBaUI7QUFDdkIsY0FBTSxlQUFlO0FBRXJCLFlBQUksQ0FBQyxRQUFRLFdBQVcsYUFBYSxHQUFHO0FBQ3RDLGdCQUFNLElBQUksTUFBTSw0QkFBNEIsT0FBTyxFQUFFO0FBQUEsUUFDdkQ7QUFFQSxZQUFJLFFBQVE7QUFDWixZQUFJLFVBQVU7QUFFZCxjQUFNLFFBQVEsUUFBUSxNQUFNLGNBQWMsTUFBTSxFQUFFLE1BQU0sTUFBTTtBQUM5RCxtQkFBVyxNQUFNLE9BQU87QUFDdEIsY0FBSSxHQUFHLFdBQVcsY0FBYyxHQUFHO0FBQ2pDLHNCQUFVLEdBQUcsTUFBTSxlQUFlLFFBQVEsRUFBRTtBQUFBLFVBQzlDO0FBQ0EsY0FBSSxHQUFHLFdBQVcsWUFBWSxHQUFHO0FBQy9CLG9CQUFRLEdBQUcsTUFBTSxhQUFhLFFBQVEsRUFBRTtBQUFBLFVBQzFDO0FBQUEsUUFDRjtBQUVBLGVBQU8sRUFBRSxPQUFPLFFBQVE7QUFBQSxNQUMxQjtBQUVBLGFBQU87QUFBQSxJQUNULFNBQVMsS0FBSztBQUNaLFlBQU0sSUFBSSxNQUFNLGlDQUFpQyxHQUFHLEVBQUU7QUFBQSxJQUN4RDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQXNCLFNBQ3BCLE9BQ0EsS0FDaUI7QUFDakIsUUFBTSxNQUFNLEdBQUcsSUFBSSxLQUFLLFlBQVksSUFBSSxPQUFPLHFCQUFxQixNQUFNLFNBQVMsSUFBSSxNQUFNLElBQUk7QUFFakcsUUFBTSxXQUFXLE1BQU0scUJBQUcsSUFBSSxHQUFHO0FBQ2pDLFFBQU0sU0FBYyxNQUFNLFNBQVMsS0FBSztBQUV4QyxNQUFJLE9BQU8sU0FBUyxPQUFPLE9BQU8sVUFBVSxVQUFVO0FBQ3BELFdBQU8sT0FBTztBQUFBLEVBQ2hCO0FBRUEsUUFBTSxJQUFJLE1BQU0sZ0NBQWdDO0FBQ2xEO0FBRUEsZUFBc0IsY0FDcEIsT0FDQSxLQUNjO0FBQ2QsUUFBTSxZQUFZLElBQUksYUFBYSxNQUFNO0FBQ3pDLFFBQU0sV0FBVyxNQUFNLFlBQVk7QUFFbkMsUUFBTSxNQUFNLEdBQUcsUUFBUSxPQUFPLE1BQU0sU0FBUyxJQUFJLE1BQU0sSUFBSSxjQUFjLFNBQVM7QUFFbEYsUUFBTSxVQUFrQztBQUFBLElBQ3RDLFFBQVE7QUFBQSxNQUNOO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsTUFDQTtBQUFBLElBQ0YsRUFBRSxLQUFLLEdBQUc7QUFBQSxFQUNaO0FBRUEsTUFBSSxJQUFJLE9BQU87QUFDYixZQUFRLGVBQWUsSUFBSSxVQUFVLElBQUksS0FBSztBQUFBLEVBQ2hEO0FBRUEsUUFBTSxXQUFXLE1BQU0scUJBQUcsSUFBSSxLQUFLLEVBQUUsUUFBUSxDQUFDO0FBQzlDLFNBQU8sTUFBTSxTQUFTLEtBQUs7QUFDN0I7QUFFQSxlQUFzQixVQUNwQixPQUNBLFVBQ0EsS0FDNkI7QUFDN0IsVUFBUSxJQUFJLGtCQUFrQixJQUFJLE9BQU8sTUFBTSxHQUFHLEVBQUUsQ0FBQyxFQUFFO0FBRXZELFFBQU0sTUFBTSxHQUFHLE1BQU0sWUFBWSxDQUFDLE9BQU8sTUFBTSxTQUFTLElBQUksTUFBTSxJQUNoRSxVQUFVLElBQUksTUFBTTtBQUV0QixRQUFNLFVBQWtDLENBQUM7QUFDekMsTUFBSSxJQUFJLE9BQU87QUFDYixZQUFRLGVBQWUsSUFBSSxVQUFVLElBQUksS0FBSztBQUFBLEVBQ2hEO0FBRUEsUUFBTSxXQUFXLE1BQU0scUJBQUcsSUFBSSxLQUFLO0FBQUEsSUFDakM7QUFBQSxJQUNBLG9CQUFvQixDQUFDLGFBQWE7QUFDaEMsVUFBSSxTQUFTO0FBQUEsUUFDWCxJQUFJO0FBQUEsUUFDSixTQUFTO0FBQUEsUUFDVCxTQUFTO0FBQUEsTUFDWDtBQUFBLElBQ0Y7QUFBQSxFQUVGLENBQUM7QUFFRCxRQUFNLGNBQWM7QUFBQSxJQUNsQixTQUFTLFFBQVEsSUFBSSxnQkFBZ0IsS0FBSztBQUFBLElBQzFDO0FBQUEsRUFDRjtBQUVBLE1BQUksQ0FBQyxJQUFJLE1BQU07QUFDYixXQUFPLE1BQU0sU0FBUyxLQUFLO0FBQUEsRUFDN0IsT0FBTztBQUNMLFVBQU0sV0FBVyxJQUFJLEtBQUssTUFBTTtBQUFBLE1BQzlCLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxNQUNOLE1BQU07QUFBQSxJQUNSLENBQUM7QUFDRCxVQUFNLE1BQU0sU0FBUyxLQUFNLFVBQVU7QUFDckMsV0FBTyxNQUFNO0FBRVgsWUFBTSxFQUFFLE1BQU0sTUFBTSxJQUFJLE1BQU0sSUFBSSxLQUFLO0FBQ3ZDLFVBQUksTUFBTTtBQUNSLGlCQUFTLElBQUk7QUFDYjtBQUFBLE1BQ0Y7QUFFQSxlQUFTLE1BQU0sS0FBTTtBQUFBLElBT3ZCO0FBQ0EsUUFBSSxTQUFTO0FBQUEsTUFDWCxJQUFJO0FBQUEsTUFDSjtBQUFBLE1BQ0E7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUNGO0FBUUEsZUFBc0IsdUJBQ3BCLE9BQ0EsTUFDQSxLQUNpQztBQUNqQyxRQUFNLGVBQWUsSUFBSSxhQUFhLE9BQU87QUFDN0MsUUFBTSxVQUFVLGFBQWEsUUFBUSxXQUFXLEVBQUU7QUFFbEQsTUFBSSxVQUFVO0FBQ2QsTUFBSSxZQUFpQixDQUFDO0FBQ3RCLFFBQU0sYUFBdUIsQ0FBQztBQUM5QixRQUFNLGFBQWEsR0FBRyxPQUFPO0FBQzdCLFFBQU0sb0JBQW9CLE1BQU0sVUFBVSxPQUFPLFlBQVk7QUFBQSxJQUMzRCxPQUFPLElBQUk7QUFBQSxJQUNYLFFBQVE7QUFBQSxFQUNWLENBQUM7QUFDRCxPQUFLLE1BQU0sRUFBRSxNQUFNLFlBQVksTUFBTSxPQUFPLEdBQUcsaUJBQWlCO0FBS2hFLFFBQU0sU0FBUyxJQUFJLGFBQWE7QUFDaEMsTUFBSSxTQUFTLFVBQVUsT0FBTyxJQUFJLENBQUMsTUFBVyxFQUFFLE1BQU0sQ0FBQztBQUN2RCxhQUFXLFNBQVMsUUFBUTtBQUMxQixVQUFNLGlCQUFpQixNQUFNO0FBQzdCLFVBQU0sY0FBYyxNQUFNO0FBQzFCLFVBQU0sV0FBVztBQUdqQixVQUFNLE9BQU8sTUFBTSxPQUFPLE9BQU87QUFBQSxNQUMvQjtBQUFBLE1BQ0EsSUFBSSxZQUFZLEVBQUUsT0FBTyxHQUFHLE9BQU87QUFBQSxFQUFLLFdBQVcsRUFBRTtBQUFBLElBQ3ZEO0FBQ0EsY0FBVSxNQUFNLEtBQUssSUFBSSxXQUFXLElBQUksQ0FBQyxFQUN0QyxJQUFJLENBQUMsTUFBTSxFQUFFLFNBQVMsRUFBRSxFQUFFLFNBQVMsR0FBRyxHQUFHLENBQUMsRUFDMUMsS0FBSyxFQUFFO0FBS1YsU0FBSyxNQUFNLEVBQUUsTUFBTSxTQUFTLE1BQU0sWUFBWSxDQUFDO0FBQy9DLFVBQU0sV0FBVztBQUtqQixTQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsUUFBUSxZQUFZLE1BQU0sT0FBTyxHQUFHLEtBQUs7QUFLL0QsVUFBTSxXQUFXLEdBQUcsT0FBTztBQUMzQixlQUFXLEtBQUssUUFBUTtBQUV4QixnQkFBWTtBQUFBLE1BQ1YsSUFBSTtBQUFBLE1BQ0osU0FBUztBQUFBLE1BQ1Qsa0JBQWtCO0FBQUEsUUFDaEIsVUFBVTtBQUFBLFFBQ1YsWUFBWTtBQUFBLFFBQ1osTUFBTTtBQUFBLFFBQ04sYUFBYTtBQUFBLFFBQ2IsY0FBYztBQUFBLFFBQ2QsY0FBYztBQUFBLFFBQ2QsS0FBSztBQUFBLFFBQ0wsV0FBVztBQUFBLFFBQ1gsV0FBVztBQUFBLFFBQ1gsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsT0FBTztBQUFBLFFBQ1AsU0FBUztBQUFBLFFBQ1QsWUFBWTtBQUFBLFFBQ1osWUFBWTtBQUFBLFFBQ1osU0FBUztBQUFBLFFBQ1QsUUFBUTtBQUFBLE1BQ1Y7QUFBQSxJQUNGO0FBRUEsUUFBSSxVQUFVO0FBQ1osZ0JBQVUsV0FBVztBQUFBLElBQ3ZCO0FBTUEsU0FBSztBQUFBLE1BQ0gsRUFBRSxNQUFNLEdBQUcsUUFBUSxTQUFTLE1BQU0sT0FBTztBQUFBLE1BQ3pDLEtBQUssVUFBVSxTQUFTO0FBQUEsSUFDMUI7QUFFQSxRQUNFLG1CQUFtQixpREFDbkIsbUJBQW1CLHFEQUNuQjtBQUlBLGNBQVEsSUFBSSxRQUFRO0FBQ3BCLFlBQU0sVUFBVSxPQUFPLFVBQVU7QUFBQSxRQUMvQixPQUFPLElBQUk7QUFBQSxRQUNYLFFBQVE7QUFBQSxRQUNSO0FBQUEsUUFDQSxTQUFTLElBQUk7QUFBQSxNQUNmLENBQUM7QUFDRCxjQUFRLElBQUksU0FBUztBQUFBLElBQ3ZCLE9BQU87QUFDTCxZQUFNLElBQUk7QUFBQSxRQUNSLHVCQUF1QixNQUFNLElBQUksS0FBSyxjQUFjLE9BQU8sT0FBTztBQUFBLE1BQ3BFO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFPQSxRQUFNLGFBQWEsS0FBSyxNQUFNLGlCQUFrQjtBQUNoRCxhQUFXLEtBQUssVUFBVTtBQUMxQixNQUFJLFVBQVUsVUFBVTtBQUN0QixlQUFXLFdBQVcsVUFBVTtBQUFBLEVBQ2xDO0FBQ0EsU0FBTyxXQUFXO0FBQ2xCLFNBQU8sV0FBVztBQUlsQixPQUFLO0FBQUEsSUFDSCxFQUFFLE1BQU0sR0FBRyxPQUFPLFNBQVMsTUFBTSxPQUFPO0FBQUEsSUFDeEMsS0FBSyxVQUFVLFVBQVU7QUFBQSxFQUMzQjtBQVFBLFFBQU0sV0FBVztBQUFBLElBQ2YsUUFBUTtBQUFBLElBQ1IsVUFBVSxDQUFDLE1BQU0sU0FBUyxDQUFDO0FBQUEsSUFDM0IsUUFBUTtBQUFBLEVBQ1Y7QUFFQSxTQUFPLENBQUMsVUFBVSxPQUFPO0FBQzNCO0FBRUEsZUFBc0IsdUJBQ3BCLE9BQ0EsTUFDQSxLQUNpQztBQUNqQyxVQUFRLElBQUksaUJBQWlCLE1BQU0sU0FBUyxDQUFDLFVBQVU7QUFFdkQsUUFBTSxVQUFVLElBQUksYUFBYTtBQUNqQyxNQUFJLENBQUMsTUFBTSxRQUFRLE9BQU8sR0FBRztBQUMzQixVQUFNLElBQUksTUFBTSw4QkFBOEI7QUFBQSxFQUNoRDtBQUVBLFFBQU0sV0FBVyxJQUFJLGFBQWE7QUFDbEMsTUFBSSxDQUFDLE1BQU0sUUFBUSxRQUFRLEdBQUc7QUFDNUIsVUFBTSxJQUFJLE1BQU0sK0JBQStCO0FBQUEsRUFDakQ7QUFFQSxNQUFJLFNBQVMsVUFBVSxTQUFTLElBQUksQ0FBQyxNQUFXLEVBQUUsT0FBTyxDQUFDO0FBRTFELE1BQUksVUFBVTtBQUNkLFdBQVMsSUFBSSxHQUFHLElBQUksU0FBUyxRQUFRLEtBQUs7QUFDeEMsVUFBTSxRQUFRLFNBQVMsQ0FBQztBQUN4QixVQUFNLFNBQVMsTUFBTTtBQUNyQixRQUFJLE9BQU8sV0FBVyxVQUFVO0FBQzlCLFlBQU0sSUFBSSxNQUFNLCtCQUErQjtBQUFBLElBQ2pEO0FBRUEsVUFBTSxrQkFBa0IsUUFBUSxDQUFDLEVBQUU7QUFDbkMsUUFBSSxPQUFPLG9CQUFvQixVQUFVO0FBQ3ZDLFlBQU0sSUFBSSxNQUFNLHVDQUF1QztBQUFBLElBQ3pEO0FBRUEsVUFBTSxZQUFZLEtBQUssTUFBTSxlQUFlO0FBQzVDLGNBQVUsVUFBVTtBQUVwQixVQUFNLFdBQVc7QUFDakIsU0FBSyxNQUFNLEVBQUUsTUFBTSxTQUFTLE1BQU0sWUFBWSxDQUFDO0FBUS9DLFNBQUssTUFBTSxFQUFFLE1BQU0sR0FBRyxRQUFRLFlBQVksTUFBTSxPQUFPLEdBQUcsS0FBSztBQU0vRCxTQUFLLE1BQU0sRUFBRSxNQUFNLEdBQUcsUUFBUSxTQUFTLE1BQU0sT0FBTyxHQUFHLGVBQWU7QUFNdEUsWUFBUSxJQUFJLEdBQUcsUUFBUSxZQUFZO0FBQ25DLFVBQU0sVUFBVSxPQUFPLEdBQUcsUUFBUSxjQUFjO0FBQUEsTUFDOUMsT0FBTyxJQUFJO0FBQUEsTUFDWDtBQUFBLE1BQ0E7QUFBQSxNQUNBLFNBQVMsSUFBSTtBQUFBLElBQ2YsQ0FBQztBQUFBLEVBQ0g7QUFFQSxTQUFPO0FBQUEsSUFDTDtBQUFBLE1BQ0UsUUFBUSxHQUFHLE9BQU87QUFBQSxNQUNsQixVQUFVLENBQUMsTUFBTSxTQUFTLENBQUM7QUFBQSxNQUMzQixRQUFRLFNBQVMsSUFBSSxDQUFDLFVBQVUsR0FBRyxNQUFNLEVBQUUsWUFBWTtBQUFBLElBQ3pEO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFDRjtBQUVBLGVBQXNCLFlBQ3BCLE9BQ0EsTUFDQSxLQUNlO0FBQ2YsUUFBTSxjQUE4QixDQUFDO0FBQ3JDLFFBQU0sZUFBdUQsQ0FBQztBQUM5RCxRQUFNLGFBQWEsTUFBTSxNQUFNLGlCQUFpQjtBQUNoRCxRQUFNLFFBQVEsYUFBYSxNQUFNLFNBQVMsT0FBTyxVQUFVLElBQUk7QUFDL0QsUUFBTSxXQUFXLE1BQU0sY0FBYyxPQUFPLEVBQUUsTUFBTSxDQUFDO0FBRXJELFFBQU0sZ0JBQWdCLFNBQVM7QUFDL0IsTUFBSSxPQUFPLGtCQUFrQixVQUFVO0FBQ3JDLFVBQU0sSUFBSSxNQUFNLHFDQUFxQztBQUFBLEVBQ3ZEO0FBRUEsTUFBSSxrQkFBa0IsR0FBRztBQUN2QixVQUFNLFlBQVksU0FBUztBQUMzQixRQUFJLE9BQU8sY0FBYyxVQUFVO0FBQ2pDLFlBQU0sSUFBSSxNQUFNLGlDQUFpQztBQUFBLElBQ25EO0FBRUEsUUFBSTtBQUVKLFFBQ0UsY0FBYyxnREFDZCxjQUFjLHdEQUNkO0FBQ0EsY0FBUSxJQUFJLGlCQUFpQixNQUFNLFNBQVMsQ0FBQyxVQUFVO0FBQ3ZELFVBQUksSUFBSSxPQUFRO0FBQ2hCLFlBQU0sTUFBTSx1QkFBdUIsT0FBTyxNQUFNO0FBQUEsUUFDOUMsY0FBYztBQUFBLFFBQ2Q7QUFBQSxNQUNGLENBQUM7QUFBQSxJQUNILFdBQ0UsY0FBYyw2Q0FDZCxjQUFjLDZEQUNkO0FBQ0EsVUFBSSxRQUFRO0FBQ1osaUJBQVcsS0FBSyxTQUFTLFdBQVc7QUFDbEMsWUFBSSxFQUFFLFVBQVUsY0FBYyxNQUFNLEdBQUcsRUFBRSxTQUFTLElBQUksSUFBSSxHQUFHO0FBQzNELGtCQUFRO0FBQ1IsZ0JBQU0sZUFBZSxNQUFNLGNBQWMsT0FBTztBQUFBLFlBQzlDO0FBQUEsWUFDQSxXQUFXLEVBQUU7QUFBQSxVQUVmLENBQUM7QUFDRCxjQUFJLElBQUksT0FBUTtBQUNoQixrQkFBUSxJQUFJLGlCQUFpQixNQUFNLFNBQVMsQ0FBQyxXQUFXLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxZQUFZLEdBQUc7QUFDL0YsZ0JBQU0sTUFBTSx1QkFBdUIsT0FBTyxNQUFNO0FBQUEsWUFDOUM7QUFBQSxZQUNBO0FBQUEsWUFDQSxTQUFTLElBQUk7QUFBQSxVQUNmLENBQUM7QUFDRDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsVUFBSSxDQUFDLE9BQU87QUFDVixjQUFNLElBQUksTUFBTSxpQkFBaUIsSUFBSSxJQUFJLGdCQUFnQjtBQUFBLE1BQzNEO0FBQUEsSUFDRixPQUFPO0FBQ0wsWUFBTSxJQUFJO0FBQUEsUUFDUiwrQkFBK0IsTUFBTSxJQUFJLE9BQU8sU0FBUztBQUFBLE1BQzNEO0FBQUEsSUFDRjtBQUVBLFFBQUksQ0FBQyxJQUFLLE9BQU0sSUFBSSxNQUFNLHVCQUF1QjtBQUVqRCxVQUFNLENBQUMsY0FBYyxPQUFPLElBQUk7QUFDaEMsVUFBTSxTQUFpQyxDQUFDO0FBQ3hDLFdBQU8sTUFBTSxHQUFHLElBQUk7QUFDcEIsaUJBQWEsTUFBTSxJQUFJLElBQUk7QUFDM0IsZ0JBQVksS0FBSyxZQUFZO0FBQUEsRUFDL0IsV0FBVyxrQkFBa0IsR0FBRztBQUM5QixRQUFJLElBQUksT0FBUTtBQUNoQixZQUFRLElBQUksaUJBQWlCLE1BQU0sU0FBUyxDQUFDLFVBQVU7QUFDdkQsVUFBTSxDQUFDLGNBQWMsT0FBTyxJQUFJLE1BQU0sdUJBQXVCLE9BQU8sTUFBTTtBQUFBLE1BQ3hFLGNBQWM7QUFBQSxNQUNkO0FBQUEsTUFDQSxTQUFTLElBQUk7QUFBQSxJQUNmLENBQUM7QUFDRCxVQUFNLFNBQWlDLENBQUM7QUFDeEMsV0FBTyxNQUFNLEdBQUcsSUFBSTtBQUNwQixpQkFBYSxNQUFNLElBQUksSUFBSTtBQUMzQixnQkFBWSxLQUFLLFlBQVk7QUFBQSxFQUMvQixPQUFPO0FBQ0wsVUFBTSxJQUFJLE1BQU0sK0JBQStCLGFBQWEsRUFBRTtBQUFBLEVBQ2hFO0FBU0EsT0FBSztBQUFBLElBQ0gsRUFBRSxNQUFNLGdCQUFnQixNQUFNLE9BQU87QUFBQSxJQUNyQyxLQUFLLFVBQVUsWUFBWTtBQUFBLEVBQzdCO0FBU0EsT0FBSztBQUFBLElBQ0gsRUFBRSxNQUFNLGlCQUFpQixNQUFNLE9BQU87QUFBQSxJQUN0QyxLQUFLLFVBQVUsV0FBVztBQUFBLEVBQzVCO0FBQ0Y7OztBQ2prQkEscUJBQTJDO0FBRXBDLFNBQVMsUUFBUSxXQUFXLFVBQVUsQ0FBQyxHQUFHO0FBQzdDLE1BQUkscUJBQXFCLGtCQUFrQixxQkFBcUIsZ0JBQWdCO0FBQzVFLFdBQU8sSUFBSSxnQkFBZ0IsV0FBVyxXQUFXLE9BQU87QUFBQSxFQUM1RCxXQUFXLHFCQUFxQixnQkFBZ0I7QUFDNUMsV0FBTyxJQUFJLGtCQUFrQixXQUFXLE9BQU87QUFBQSxFQUNuRCxXQUFXLHFCQUFxQixnQkFBZ0I7QUFDNUMsV0FBTyxJQUFJLGtCQUFrQixXQUFXLE9BQU87QUFBQSxFQUNuRCxXQUFXLFVBQVUsWUFBWSxVQUFVLFVBQVU7QUFDakQsV0FBTyxJQUFJLGdCQUFnQixVQUFVLFVBQVUsVUFBVSxVQUFVLE9BQU87QUFBQSxFQUM5RSxXQUFXLFVBQVUsVUFBVTtBQUMzQixXQUFPLElBQUksa0JBQWtCLFVBQVUsVUFBVSxPQUFPO0FBQUEsRUFDNUQsV0FBVyxVQUFVLFVBQVU7QUFDM0IsV0FBTyxJQUFJLGtCQUFrQixVQUFVLFVBQVUsT0FBTztBQUFBLEVBQzVELE9BQU87QUFDSCxVQUFNLElBQUksTUFBTSwyREFBMkQ7QUFBQSxFQUMvRTtBQUNKO0FBRUEsSUFBTSxvQkFBTixjQUFnQyx3QkFBUztBQUFBLEVBQ3JDLFlBQVksZ0JBQWdCLFNBQVM7QUFDakMsVUFBTSxPQUFPO0FBQ2IsU0FBSyxVQUFVLGVBQWUsVUFBVTtBQUN4QyxTQUFLLG9CQUFvQjtBQUFBLEVBQzdCO0FBQUEsRUFFQSxzQkFBc0I7QUFDbEIsU0FBSyxRQUFRLE9BQU8sTUFBTSxXQUFTO0FBQy9CLFdBQUssUUFBUSxLQUFLO0FBQUEsSUFDdEIsQ0FBQztBQUFBLEVBQ0w7QUFBQSxFQUVBLE1BQU0sTUFBTSxJQUFJO0FBQ1osUUFBSTtBQUNBLFlBQU0sRUFBRSxNQUFNLE1BQU0sSUFBSSxNQUFNLEtBQUssUUFBUSxLQUFLO0FBQ2hELFVBQUksTUFBTTtBQUNOLGFBQUssS0FBSyxJQUFJO0FBQUEsTUFDbEIsT0FBTztBQUNILGFBQUssS0FBSyxLQUFLO0FBQUEsTUFDbkI7QUFDQSxTQUFHO0FBQUEsSUFDUCxTQUFTLE9BQU87QUFDWixXQUFLLFFBQVEsS0FBSztBQUNsQixTQUFHLEtBQUs7QUFBQSxJQUNaO0FBQUEsRUFDSjtBQUFBLEVBRUEsU0FBUyxJQUFJO0FBQ1QsU0FBSyxRQUFRLFlBQVk7QUFDekIsT0FBRztBQUFBLEVBQ1A7QUFDSjtBQUVBLElBQU0sb0JBQU4sY0FBZ0Msd0JBQVM7QUFBQSxFQUNyQyxZQUFZLGdCQUFnQixTQUFTO0FBQ2pDLFVBQU0sT0FBTztBQUNiLFNBQUssVUFBVSxlQUFlLFVBQVU7QUFBQSxFQUM1QztBQUFBLEVBRUEsTUFBTSxPQUFPLE9BQU8sSUFBSTtBQUNwQixRQUFJO0FBQ0EsWUFBTSxLQUFLLFFBQVEsTUFBTSxLQUFLO0FBQzlCLFNBQUc7QUFBQSxJQUNQLFNBQVMsT0FBTztBQUNaLFdBQUssUUFBUSxLQUFLO0FBQ2xCLFNBQUcsS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNKO0FBQUEsRUFFQSxNQUFNLE9BQU8sSUFBSTtBQUNiLFFBQUk7QUFDQSxZQUFNLEtBQUssUUFBUSxNQUFNO0FBQ3pCLFNBQUc7QUFBQSxJQUNQLFNBQVMsT0FBTztBQUNaLFdBQUssUUFBUSxLQUFLO0FBQ2xCLFNBQUcsS0FBSztBQUFBLElBQ1o7QUFBQSxFQUNKO0FBQUEsRUFFQSxTQUFTLElBQUk7QUFDVCxTQUFLLFFBQVEsWUFBWTtBQUN6QixPQUFHO0FBQUEsRUFDUDtBQUNKO0FBRUEsSUFBTSxrQkFBTixjQUE4QixzQkFBTztBQUFBLEVBQ2pDLFlBQVksZ0JBQWdCLGdCQUFnQixTQUFTO0FBQ2pELFVBQU0sT0FBTztBQUNiLFNBQUssVUFBVSxlQUFlLFVBQVU7QUFDeEMsU0FBSyxVQUFVLGVBQWUsVUFBVTtBQUN4QyxTQUFLLG9CQUFvQjtBQUN6QixTQUFLLGtCQUFrQjtBQUFBLEVBQzNCO0FBQUEsRUFFQSxzQkFBc0I7QUFDbEIsU0FBSyxRQUFRLE9BQU8sTUFBTSxXQUFTO0FBQy9CLFdBQUssUUFBUSxLQUFLO0FBQUEsSUFDdEIsQ0FBQztBQUNELFNBQUssUUFBUSxPQUFPLE1BQU0sV0FBUztBQUMvQixXQUFLLFFBQVEsS0FBSztBQUFBLElBQ3RCLENBQUM7QUFBQSxFQUNMO0FBQUEsRUFFQSxNQUFNLE1BQU0sSUFBSTtBQUNaLFFBQUk7QUFDQSxZQUFNLEVBQUUsTUFBTSxNQUFNLElBQUksTUFBTSxLQUFLLFFBQVEsS0FBSztBQUNoRCxVQUFJLE1BQU07QUFDTixhQUFLLEtBQUssSUFBSTtBQUFBLE1BQ2xCLE9BQU87QUFDSCxhQUFLLEtBQUssS0FBSztBQUFBLE1BQ25CO0FBQ0EsU0FBRztBQUFBLElBQ1AsU0FBUyxPQUFPO0FBQ1osV0FBSyxRQUFRLEtBQUs7QUFDbEIsU0FBRyxLQUFLO0FBQUEsSUFDWjtBQUFBLEVBQ0o7QUFBQSxFQUVBLE1BQU0sT0FBTyxPQUFPLElBQUk7QUFDcEIsUUFBSTtBQUNBLFlBQU0sS0FBSyxRQUFRLE1BQU0sS0FBSztBQUM5QixTQUFHO0FBQUEsSUFDUCxTQUFTLE9BQU87QUFDWixXQUFLLFFBQVEsS0FBSztBQUNsQixTQUFHLEtBQUs7QUFBQSxJQUNaO0FBQUEsRUFDSjtBQUFBLEVBRUEsTUFBTSxPQUFPLElBQUk7QUFDYixRQUFJO0FBQ0EsWUFBTSxLQUFLLFFBQVEsTUFBTTtBQUN6QixTQUFHO0FBQUEsSUFDUCxTQUFTLE9BQU87QUFDWixXQUFLLFFBQVEsS0FBSztBQUNsQixTQUFHLEtBQUs7QUFBQSxJQUNaO0FBQUEsRUFDSjtBQUFBLEVBRUEsU0FBUyxJQUFJO0FBQ1QsU0FBSyxRQUFRLFlBQVk7QUFDekIsU0FBSyxRQUFRLFlBQVk7QUFDekIsT0FBRztBQUFBLEVBQ1A7QUFBQSxFQUVBLG9CQUFvQjtBQUNoQixTQUFLLEdBQUcsVUFBVSxNQUFNO0FBQ3BCLFdBQUssS0FBSyxLQUFLO0FBQUEsSUFDbkIsQ0FBQztBQUFBLEVBQ0w7QUFDSjs7O0FDckpBLElBQU0sZ0JBQW1CLE9BQWdCOzs7QUNLekMsaUJBQWdCOzs7QWZBaEIsSUFBTSxRQUFtQixDQUFDO0FBYzFCLE9BQU8sUUFBUSxVQUFVLFlBQVksQ0FBQyxTQUFTLFNBQVMsaUJBQWlCO0FBQ3ZFLE1BQUksUUFBUSxTQUFTLGdCQUFnQjtBQUNuQyxpQkFBYTtBQUFBLE1BQ1gsTUFBTTtBQUFBLE1BQ04sT0FBTyxNQUFNLElBQUksUUFBTTtBQUFBLFFBQ3JCLE1BQU0sRUFBRTtBQUFBLFFBQ1IsSUFBSSxFQUFFO0FBQUEsUUFDTixNQUFNLEVBQUU7QUFBQSxRQUNSLFFBQVEsRUFBRTtBQUFBLFFBQ1YsT0FBTyxFQUFFO0FBQUEsTUFDWCxFQUFFO0FBQUEsSUFDSixDQUFDO0FBQUEsRUFDSCxXQUFXLFFBQVEsU0FBUyxVQUFVO0FBQ3BDLEtBQUMsWUFBWTtBQUNYLFVBQUk7QUFDRixjQUFNLE9BQU8sa0JBQUFDLFFBQUksS0FBSztBQUN0QixjQUFNLFlBQVksU0FBUyxNQUFNLFFBQVEsS0FBSyxHQUFHLE1BQU0sRUFBRSxNQUFNLFFBQVEsUUFBUSxTQUFTLFFBQVEsS0FBSyxDQUFDO0FBQ3RHLHFCQUFhLEVBQUUsTUFBTSxVQUFVLElBQUksS0FBSyxDQUFDO0FBQUEsTUFDM0MsU0FBUyxHQUFHO0FBQ1YscUJBQWEsRUFBRSxNQUFNLFVBQVUsSUFBSSxPQUFPLE9BQVEsRUFBWSxRQUFRLENBQUM7QUFBQSxNQUN6RTtBQUFBLElBQ0YsR0FBRztBQUNILFdBQU87QUFBQSxFQUNULFdBQVcsUUFBUSxTQUFTLFNBQVM7QUFDbkMsVUFBTSxPQUFPLENBQUM7QUFBQSxFQUNoQixPQUFPO0FBQ0wsaUJBQWEsQ0FBQyxDQUFDO0FBQUEsRUFDakI7QUFFRixDQUFDO0FBRUQsS0FBSyxpQkFBaUIsU0FBUyxDQUFDLFVBQXNCO0FBQ3BELFFBQU0sTUFBTSxJQUFJLElBQUksTUFBTSxRQUFRLEdBQUc7QUFDckMsTUFBSSxDQUFDLElBQUksU0FBUyxXQUFXLFFBQVEsR0FBRztBQUN0QztBQUNBLFFBQUksV0FBVztBQUNmLFFBQUksT0FBTztBQUNYLFFBQUksT0FBTztBQUNYLFVBQU0sY0FBYyxNQUFNLEtBQUssRUFBRSxNQUFNLE1BQU0sUUFBUSxNQUFNLFNBQVMsTUFBTSxRQUFRLFFBQVEsQ0FBQztBQUMzRixXQUFPLE1BQU0sWUFBWSxXQUFXO0FBQUEsRUFFdEM7QUFDQSxRQUFNLE9BQU8sSUFBSSxTQUFTLE1BQU0sQ0FBQztBQUNqQyxRQUFNLE9BQU8sa0JBQUFBLFFBQUksS0FBSztBQUN0QixRQUFNLE9BQU8sSUFBSSxhQUFhLElBQUksTUFBTSxLQUFLO0FBRTdDLFFBQU0sVUFBVSxJQUFJLFFBQVEsTUFBTSxJQUFJO0FBQ3RDLFFBQU0sS0FBSyxPQUFPO0FBRWxCLE1BQUk7QUFDSixRQUFNLEtBQUssSUFBSSxnQkFBZ0I7QUFBQSxJQUM3QixNQUFNLFlBQVk7QUFDaEIsb0JBQWM7QUFBQSxJQUNoQjtBQUFBLEVBQ0YsQ0FBQztBQUNELGNBQVksU0FBUyxNQUFNLElBQUksR0FBRyxNQUFNLEVBQUUsTUFBTSxRQUFRLENBQUMsRUFDdEQsS0FBSyxNQUFNO0FBQ1YsU0FBSyxTQUFTO0FBQUEsRUFDaEIsQ0FBQyxFQUNBLE1BQU0sQ0FBQyxNQUFNO0FBQ1osWUFBUSxNQUFNLENBQUM7QUFDZixTQUFLLFFBQVEsQ0FBQztBQUNkLGdCQUFZLE1BQU0sQ0FBQztBQUNuQixZQUFRLFNBQVMsR0FBRyxPQUFPO0FBQUEsRUFDN0IsQ0FBQztBQUVILE9BQUssS0FBSyxRQUFRLEdBQUcsVUFBVSxJQUFJLENBQUM7QUFFcEMsTUFBSSxXQUFXLEtBQUssV0FBVyxVQUFVLEdBQUc7QUFDNUMsTUFBSSxTQUFTLFNBQVM7QUFDcEIsZ0JBQVksTUFBTTtBQUFBLEVBQ3BCO0FBQ0EsUUFBTTtBQUFBLElBQ0osSUFBSSxTQUFTLEdBQUcsVUFBVTtBQUFBLE1BQ3hCLFNBQVM7QUFBQSxRQUNQLHFCQUFxQjtBQUFBLFFBQ3JCLGdCQUFnQjtBQUFBLFFBQ2hCLHVCQUF1Qix5QkFBeUIsUUFBUTtBQUFBLE1BQzFEO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNGLENBQUM7IiwKICAibmFtZXMiOiBbIlRleHREZWNvZGVyIiwgIldSSVRFX1dSSVRJTkciLCAiaXNTdHJlYW14IiwgImRhdGEiLCAiUmVhZGFibGUiLCAiV3JpdGFibGUiLCAiRHVwbGV4IiwgIm9uZXJyb3IiLCAiaXNTdHJlYW0iLCAiY29kZSIsICJ0b1N0cmluZyIsICJ3cml0ZSIsICJmaWxsIiwgImNvcHkiLCAiYjRhIiwgIldyaXRhYmxlIiwgIlJlYWRhYmxlIiwgImI0YSIsICJzZWxmIiwgImRyYWluZWQiLCAiUmVhZGFibGUiLCAiV3JpdGFibGUiLCAiYjRhIiwgInNlbGYiLCAia3kiLCAia3kiLCAidGFyIl0KfQo=
